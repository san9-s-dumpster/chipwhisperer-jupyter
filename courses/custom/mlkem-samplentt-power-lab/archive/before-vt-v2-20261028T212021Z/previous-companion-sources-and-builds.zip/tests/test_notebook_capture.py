import hashlib
import json
from types import SimpleNamespace
import numpy as np
import pytest
from analysis.ground_truth import generated_seed,ground_truth,output_digest
from analysis.hardware import classify_roi,seed_roi
from capture.hardware import HardwareBackend,HardwareSettings
from capture.records import acquire_batch,Capture


def connected(tmp_path,wrong_variant=False):
    image=tmp_path/'sampler.hex'
    image.write_bytes(b':test image')
    build={"target_platform":"CW308_STM32F4","image":str(image),
           "firmware_sha256":hashlib.sha256(image.read_bytes()).hexdigest(),
           "source_commit":"fd72834bd789c644b52fe0d62b2fa3b9f34dfaec","variant":"variable_time"}
    (tmp_path/'build.json').write_text(json.dumps(build))
    class Scope:
        adc=SimpleNamespace(samples=64,offset=0,errors=False,trig_count=32)
        clock=SimpleNamespace(adc_freq=7372800.)
        def __str__(self):return 'cwhusky Device (fake)'
        def arm(self):pass
        def capture(self):return False
        def get_last_trace(self):return np.zeros(64)
    class Target:
        def flush(self):pass
        def simpleserial_write(self,cmd,data):self.cmd,self.data=cmd,data
        def simpleserial_read(self,cmd,size,**kw):
            if cmd=='i':return bytes([int(wrong_variant)])+bytes.fromhex(build['source_commit'])
            return output_digest(ground_truth(bytes(self.data[:32]),self.data[32],self.data[33]).coefficients)
    settings=HardwareSettings('Husky','CW308_STM32F4',str(tmp_path/'build.json'),'fake',
                              samples=64,adc_multiplier=1)
    return Scope(),Target(),settings


def test_borrow_existing_scope_and_target(tmp_path):
    scope,target,settings=connected(tmp_path)
    backend=HardwareBackend.from_connected(scope,target,settings,cw_version='fake')
    assert backend.scope is scope and backend.target is target
    record=backend.capture(generated_seed(0))
    assert record.metadata['full_operation_captured']
    assert record.metadata['settings']['adc_multiplier']==1


def test_attach_rejects_wrong_firmware(tmp_path):
    with pytest.raises(RuntimeError,match='handshake'):
        HardwareBackend.from_connected(*connected(tmp_path,wrong_variant=True))


def test_attach_rejects_stale_window_settings(tmp_path):
    scope,target,settings=connected(tmp_path)
    scope.adc.offset=16
    with pytest.raises(ValueError,match='window'):
        HardwareBackend.from_connected(scope,target,settings)


def test_progress_wrapper_receives_all_trials():
    seen=[]
    def progress(items):
        seen.extend(items)
        return items
    class Backend:
        def capture(self,*args):raise TimeoutError('injected')
    _,failures=acquire_batch(Backend(),[generated_seed(0)],'fls',repeats=3,progress=progress)
    assert len(seen)==len(failures)==3


def test_notebook_interrupt_returns_partial_data():
    class Backend:
        count=0
        def capture(self,*args):
            self.count+=1
            if self.count==2:raise KeyboardInterrupt()
            return Capture(np.zeros(4),{}, {})
    records,failures=acquire_batch(Backend(),[generated_seed(0)],'fls',repeats=3,
                                  keep_partial_on_interrupt=True)
    assert len(records)==len(failures)==1
    assert failures[0]['unattempted_trials']==1
    assert 'KeyboardInterrupt' in failures[0]['error']


def test_hardware_roi_keeps_seeds_disjoint():
    records=[]
    for i in range(96):
        gt=ground_truth(generated_seed(i)).to_dict()
        for repeat in range(2):
            wave=np.full(64,float(gt['valid'][0]))
            records.append(Capture(wave,gt,{"backend":"fake", "sample_window_start":0,
                                          "adc_frequency_hz":7372800.}))
    result=classify_roi(records,0,64,bins=8)
    assert not set(result['train_seeds']) & set(result['test_seeds'])
    assert len(result['train_seeds'])+len(result['test_seeds'])==96
    assert result['balanced_accuracy']==1
    assert result['majority_balanced_accuracy']==0.5
    with pytest.raises(ValueError,match='ROI'):
        seed_roi(records,0,128)
