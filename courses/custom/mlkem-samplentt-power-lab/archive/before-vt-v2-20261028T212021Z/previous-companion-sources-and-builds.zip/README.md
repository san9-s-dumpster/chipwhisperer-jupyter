# ML-KEM SampleNTT power lab

The companion files live in `jupyter/courses/custom/mlkem-samplentt-power-lab`.
Open **Lab 7_1 - ML-KEM SampleNTT Power Lab.ipynb** in `jupyter/courses/custom`.
It is the guided **hardware lab for Husky + CW308_STM32F4**: work down the cells
with Shift+Enter to connect, build, program, capture one verified trace, tune
ADC settings, acquire a batch, analyze measured results, then repeat for FLS.

The main notebook uses real device operations. The programming cells replace
the STM32F4 target firmware when executed. Configuration is in visible cells,
and the connected `scope` and `target` remain available for adjustment.

The earlier mock workflow is preserved separately as
**ML-KEM SampleNTT - Software Validation.ipynb** in this folder. It provides
hardware-free correctness checks and synthetic acquisition/evaluation.

Both samplers use the pinned ProjectTempo top-level A0/A1 sources. Physical
capture behavior and leakage are not established by compilation or software
API tests. Candidate-operation localization and formal seed-distinction
experiments still need controlled measurements.

## Use the new repository's environment

The working repository is `~/Desktop/work/chipwhisperer-new`. Use its existing
`.venv`, which now contains the lab requirements:

```bash
cd "$HOME/Desktop/work/chipwhisperer-new"
source .venv/bin/activate
python -m pip install -r jupyter/courses/custom/mlkem-samplentt-power-lab/requirements.txt
python -m pip install -e .
cd jupyter/courses/custom
jupyter lab 'Lab 7_1 - ML-KEM SampleNTT Power Lab.ipynb'
```

In VS Code, select the Python environment at
`~/Desktop/work/chipwhisperer-new/.venv/bin/python` in the notebook's kernel
picker. The first code cell prints the interpreter and repository paths.

The STM32F4 support submodule has been initialized. For a future fresh clone,
initialize it from the repository root before building:

```bash
git submodule update --init firmware/mcu/hal/chipwhisperer-fw-extra
```

The build requires `make`, `arm-none-eabi-gcc`, and the matching ARM C library.
On Arch, the compiler packages are `arm-none-eabi-gcc arm-none-eabi-newlib`;
on Ubuntu, use `gcc-arm-none-eabi libnewlib-arm-none-eabi`. USB permissions
must be configured for Husky. The main notebook selects the confirmed
Husky/CW308_STM32F4 setup and STM32FProgrammer; see
[hardware.md](docs/hardware.md).

## Layout and source selection

`analysis/ground_truth.py` uses independent `hashlib.shake_128` to decode the
candidate stream and label it. `analysis/c_reference.py` builds unchanged
upstream C as a host shared library and checks source hashes. The reference is
pinned to ProjectTempo `fd72834bd789c644b52fe0d62b2fa3b9f34dfaec`.
Read [reference-inspection.md](docs/reference-inspection.md) for real function
signatures, locations, dependencies, and differences between top-level and
pqm4 FLS. This lab uses the **top-level A0/A1** code for both host and firmware.

`capture/` provides batch scheduling, portable NPZ/JSON data, and the
ChipWhisperer recorder. `HardwareBackend.from_connected` attaches it to the
notebook's existing scope and target without reopening them. `simulation/` supplies the seeded mock backend.
`analysis/` provides seed-separated logistic regression, balanced accuracy,
precision/recall, ROC-AUC, confusion matrix, an exploratory Welch statistic,
and plotting. Repetitions are averaged per seed before evaluation.
`firmware/variable_time` and `firmware/fls` build the initial adapters;
`firmware/common` holds the trigger and SimpleSerial protocol.
`experiments/variable_time`, `experiments/fls`, `results/figures`, and
`results/metrics` are reserved for later curated hardware results.

Default mock acquisitions and notebook outputs go into unique
`results/runs/<UTC timestamp>-<id>/` directories. A dataset contains one numeric
NPZ waveform per capture, one JSON record with full ground truth and metadata,
and a manifest with parameters, environment, trace order and failure records.
There is no pickle input. The capture metadata distinguishes partial windows
from complete operations and measured data from synthetic traces.

## Terminal commands

From the `mlkem-samplentt-power-lab` directory with the environment active:

```bash
python -m pytest -q
MPLBACKEND=Agg python experiments/run_mock.py
```

The mock command saves datasets, a labeled figure, and a metrics JSON file.
Use `--seeds`, `--repeats`, `--noise-sd` to explore the injected model.
Do not interpret its timing or power scores as experimental evidence.
No machine learning dependency is needed just to import the ground-truth
generator or run the basic C correctness checks.

## Interpretation and next experiment

ML-KEM input is `rho || x || y`, with x=column,y=row for an untransposed
matrix. The conventional C implementation is capped at 280 pairs. FLS runs
all 280 pairs (560 candidate comparisons), including after the output fills.
Validity and committing a coefficient are different labels. The top-level
FLS also makes transient writes for rejected candidates before the output
fills; its pqm4 copy has different update semantics.

The fixed-loop source and equal synthetic durations establish no property
of compiled hardware execution. The measurement interval includes upstream
SHAKE and malloc/free. Both adapters were cross-compiled for the confirmed CW308_STM32F4 target.
The agent has not flashed or physically validated them; the main notebook
contains the cells for you to do so.

On your confirmed Husky/CW308_STM32F4 setup, start with one verified
variable-time trace, select a meaningful capture
window, then collect randomized seed/repeat batches. Measure candidate
boundaries independently before applying acceptance classifiers. Repeat for
the exact FLS build with its own feature validation and assembly review.
Compare single and repeated traces, timing and power, then controlled
candidate-seed distinction on held-out generated seed sets. Do not claim
password recovery or a protocol compromise from leakage detection alone.

Physical access, compiler/MCU behavior, noise, capture length and alignment
all limit conclusions. Failure to detect leakage in one setup is not a proof
of side-channel security.

Sources: [Tempo artifact](https://github.com/afonsoarriaga/ProjectTempo),
[paper](https://doi.org/10.46586/tches.v2026.i3.744-768),
[FIPS 203](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.203.pdf).

Original lab code is provided under GPL-3.0-or-later; see LICENSE. Vendored
upstream files retain their own notices and Apache-2.0 license. The lab uses
the ChipWhisperer APIs and build system; SCA101 training materials are at
[ChipWhisperer.io](https://www.chipwhisperer.io/).
