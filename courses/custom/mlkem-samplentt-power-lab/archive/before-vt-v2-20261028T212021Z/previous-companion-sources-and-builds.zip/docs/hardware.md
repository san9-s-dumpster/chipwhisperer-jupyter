# Hardware workflow: Husky + CW308_STM32F4

The main notebook is configured for the user-confirmed **Husky +
CW308_STM32F4**. Its programming cells use STM32FProgrammer. Record:

- Capture device: CW-Lite or CW-Husky, serial, firmware/FPGA version.
- Target board and exact MCU, ChipWhisperer `PLATFORM`, programmer and reset method.
- Target supply/shunt/probe wiring and clock source/frequency, UART voltage and baud.
- ADC clock, samples, offset, gain, timeout, trigger pin and polarity.
- Compiler version, full build log, source revision, firmware image hash, optimization.

The adapter uses SimpleSerial **1.1**, 38400 baud at the example 7.3728 MHz
target clock, TIO1 RX, TIO2 TX, TIO4 rising-edge trigger, and HS2 clock output.
These follow the CW308 STM32F4 external-clock setup used by the local course
labs; retain your known-working target power/shunt and clock jumper settings.
Changing the target clock can require changing UART baud. Lite uses
`clkgen_x1`/`clkgen_x4`; Husky uses `adc_mul`. The notebook can select a single attached Husky automatically, records its
actual serial, and checks the requested model and firmware variant/revision.
The identity handshake does not prove the flashed binary hash; keep the
programming record tied to the recorded build/image hash.

Build example (no hardware is needed; run from the lab directory):

```bash
python firmware/build.py --chipwhisperer "$HOME/Desktop/work/chipwhisperer-new" \
  --platform CW308_STM32F4 --variant variable_time
python firmware/build.py --chipwhisperer "$HOME/Desktop/work/chipwhisperer-new" \
  --platform CW308_STM32F4 --variant fls
```

Builds produce `.hex`, `.elf`, `.asm`, `build.log`, `build.json` beside the
selected Makefile. Each invocation uses a clean rebuild. Source hashes are
checked first. Default optimization is O2. Inspect `algorithmA1` and its
callees in the assembly: loop bounds, branches, indexed addresses, masking,
and possible compiler transformations. An assembly dump alone is not a
constant-time audit. Keep separate build directories for distinct debug or
instrumented firmware; do not pool those traces with representative builds.

After connecting the confirmed CW308_STM32F4 target, the main notebook
executes this programmer invocation in a separate, explained cell:

```python
cw.program_target(scope, cw.programmers.STM32FProgrammer, str(firmware_hex))
```

Run the notebook cells deliberately in order. The programming cells replace
the target firmware when executed. The recorder attaches to those same
scope/target objects through `HardwareBackend.from_connected`; it does not
connect another USB session.

One `p` command carries a 32-byte seed and x,y (34 bytes total). The trigger
covers the complete selected upstream function. Polynomial initialization,
encoding, SHA3-256 verification and UART communication occur outside it.
The `r` reply is 32 bytes: SHA3-256 of all 256 coefficients encoded LE16.
An application `i` command returns the variant byte and 20-byte upstream commit ID.

Begin with one trace and verify the digest before a batch. Set ADC gain using
the actual waveform; detect saturation and inspect noise manually on Lite,
and check Husky's ADC error flags. A fixed-length ADC array may contain only
part of the operation. `full_operation_captured` records whether an offset-zero
window covers the trigger duration. Partial windows are intentionally retained
and labeled, while timeouts, missing replies, digest mismatches, ADC errors
and short arrays are failures. Failure entries retain the seed, variant and
repetition; capture order is randomized to reduce drift confounding.

The trigger counter is read only after the complete target reply, when the
trigger is low. Its units are ADC clock cycles, not target CPU cycles.
The class records raw counts and measured ADC frequency as well as seconds.
Do not interpret host round-trip latency as operation timing.

FLS can greatly exceed Lite's single-trace buffer. Start with a short window.
Repeat the **same seed** at different ADC offsets to inspect later portions;
these are separate acquisitions, not one continuous trace. Check alignment
and drift across repeats. A single trigger pulse does not support candidate
segmentation automatically. The main notebook also exposes Husky streaming as a window-setting option.
Begin at ADC_MUL=1 (7.3728 MS/s), presamples=0, and a sample count large
enough for the operation; inspect ADC error flags and trigger coverage.
The checkout documents an approximate 10 MS/s streaming limit. Use a
shorter useful window for batches after surveying the operation. Native
segmentation is not implemented, because one trigger encloses the whole call.

Hardware candidate-operation boundaries must be measured from timing,
disassembly and optional separately labeled debug builds. Mock boundaries
are not valid for hardware: SHAKE work, variable-time branches and the FLS
scans give different temporal structure. The supplied classifier explicitly
refuses automatic segmentation of hardware traces.

Keep fixed/random or accept/reject statistics independent at the seed level;
repetitions are not new independent seeds. Choose windows/features using
training data, then freeze them for unseen-seed tests. Treat Welch tests as
exploratory unless a full preplanned leakage-test design is used. Evaluate
FLS timing, power and known-seed distinction separately before making any
claim about security implications.

The main notebook's optional ROI classifier uses a user-selected interval in
measured traces, averages repeats per seed, and fits a fresh model per variant
on disjoint training/test seeds. It assumes no candidate boundaries. Its
validity-label score is an exploratory association, not a seed-identification
rate or proof of a localized acceptance comparison. Choose and freeze the ROI
without tuning it on held-out scores.

SimpleSerial reserves `v`, `w`, and `y`. The lab identity request and reply
use `i`; its 21-byte payload is the variant byte followed by the sampler
commit ID. The ordinary SimpleSerial `z00` acknowledgement follows it.
Changing this command requires rebuilding and programming the STM32F4
adapter, plus reloading `capture.hardware` in an already running notebook.

### Gain calibration and clipping

The notebook starts at 10 dB gain. The gain must be calibrated for the actual
board/shunt/probe setup. An `ADC clipped` error means the ADC exceeded its
range, even if the polynomial verification succeeded. Reduce gain (for
example 25 → 10 → 0 dB), clear flags, recreate the recorder to snapshot the
new gain, then acquire again. Section 8a plots the last raw ADC buffer even
when section 8 was rejected before assigning `first`. It is diagnostic data,
not an accepted capture. Keep clipping detection enabled during experiments.

### ADC display units under ChipWhisperer 7

`get_last_trace()` defaults to raw integer ADC codes in version 7. The
recorder stores these as float32; this cast does not normalize the values.
The diagnostic cell explicitly requests `as_int=False` for a normalized
display with limits near -0.5 and +0.5. Saved raw trace arrays are preserved.
For the 12-bit data, normalization is `counts / 4096 - 0.5`. A global affine
rescaling does not change the ROI model after its StandardScaler step.
