
/home/ubuntu/Desktop/work/chipwhisperer-new/jupyter/courses/custom/mlkem-samplentt-power-lab/firmware/variable_time/samplentt-variable_time-CW308_STM32F4.elf:     file format elf32-littlearm


Disassembly of section .text:

08000188 <deregister_tm_clones>:
 8000188:	4803      	ldr	r0, [pc, #12]	@ (8000198 <deregister_tm_clones+0x10>)
 800018a:	4b04      	ldr	r3, [pc, #16]	@ (800019c <deregister_tm_clones+0x14>)
 800018c:	4283      	cmp	r3, r0
 800018e:	d002      	beq.n	8000196 <deregister_tm_clones+0xe>
 8000190:	4b03      	ldr	r3, [pc, #12]	@ (80001a0 <deregister_tm_clones+0x18>)
 8000192:	b103      	cbz	r3, 8000196 <deregister_tm_clones+0xe>
 8000194:	4718      	bx	r3
 8000196:	4770      	bx	lr
 8000198:	20000538 	.word	0x20000538
 800019c:	20000538 	.word	0x20000538
 80001a0:	00000000 	.word	0x00000000

080001a4 <register_tm_clones>:
 80001a4:	4805      	ldr	r0, [pc, #20]	@ (80001bc <register_tm_clones+0x18>)
 80001a6:	4b06      	ldr	r3, [pc, #24]	@ (80001c0 <register_tm_clones+0x1c>)
 80001a8:	1a1b      	subs	r3, r3, r0
 80001aa:	0fd9      	lsrs	r1, r3, #31
 80001ac:	eb01 01a3 	add.w	r1, r1, r3, asr #2
 80001b0:	1049      	asrs	r1, r1, #1
 80001b2:	d002      	beq.n	80001ba <register_tm_clones+0x16>
 80001b4:	4b03      	ldr	r3, [pc, #12]	@ (80001c4 <register_tm_clones+0x20>)
 80001b6:	b103      	cbz	r3, 80001ba <register_tm_clones+0x16>
 80001b8:	4718      	bx	r3
 80001ba:	4770      	bx	lr
 80001bc:	20000538 	.word	0x20000538
 80001c0:	20000538 	.word	0x20000538
 80001c4:	00000000 	.word	0x00000000

080001c8 <__do_global_dtors_aux>:
 80001c8:	b510      	push	{r4, lr}
 80001ca:	4c06      	ldr	r4, [pc, #24]	@ (80001e4 <__do_global_dtors_aux+0x1c>)
 80001cc:	7823      	ldrb	r3, [r4, #0]
 80001ce:	b943      	cbnz	r3, 80001e2 <__do_global_dtors_aux+0x1a>
 80001d0:	f7ff ffda 	bl	8000188 <deregister_tm_clones>
 80001d4:	4b04      	ldr	r3, [pc, #16]	@ (80001e8 <__do_global_dtors_aux+0x20>)
 80001d6:	b113      	cbz	r3, 80001de <__do_global_dtors_aux+0x16>
 80001d8:	4804      	ldr	r0, [pc, #16]	@ (80001ec <__do_global_dtors_aux+0x24>)
 80001da:	f3af 8000 	nop.w
 80001de:	2301      	movs	r3, #1
 80001e0:	7023      	strb	r3, [r4, #0]
 80001e2:	bd10      	pop	{r4, pc}
 80001e4:	20000538 	.word	0x20000538
 80001e8:	00000000 	.word	0x00000000
 80001ec:	08003518 	.word	0x08003518

080001f0 <frame_dummy>:
 80001f0:	b508      	push	{r3, lr}
 80001f2:	4b04      	ldr	r3, [pc, #16]	@ (8000204 <frame_dummy+0x14>)
 80001f4:	b11b      	cbz	r3, 80001fe <frame_dummy+0xe>
 80001f6:	4904      	ldr	r1, [pc, #16]	@ (8000208 <frame_dummy+0x18>)
 80001f8:	4804      	ldr	r0, [pc, #16]	@ (800020c <frame_dummy+0x1c>)
 80001fa:	f3af 8000 	nop.w
 80001fe:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
 8000202:	e7cf      	b.n	80001a4 <register_tm_clones>
 8000204:	00000000 	.word	0x00000000
 8000208:	2000053c 	.word	0x2000053c
 800020c:	08003518 	.word	0x08003518

08000210 <memcpy>:
 8000210:	4684      	mov	ip, r0
 8000212:	ea41 0300 	orr.w	r3, r1, r0
 8000216:	f013 0303 	ands.w	r3, r3, #3
 800021a:	d16d      	bne.n	80002f8 <memcpy+0xe8>
 800021c:	3a40      	subs	r2, #64	@ 0x40
 800021e:	d341      	bcc.n	80002a4 <memcpy+0x94>
 8000220:	f851 3b04 	ldr.w	r3, [r1], #4
 8000224:	f840 3b04 	str.w	r3, [r0], #4
 8000228:	f851 3b04 	ldr.w	r3, [r1], #4
 800022c:	f840 3b04 	str.w	r3, [r0], #4
 8000230:	f851 3b04 	ldr.w	r3, [r1], #4
 8000234:	f840 3b04 	str.w	r3, [r0], #4
 8000238:	f851 3b04 	ldr.w	r3, [r1], #4
 800023c:	f840 3b04 	str.w	r3, [r0], #4
 8000240:	f851 3b04 	ldr.w	r3, [r1], #4
 8000244:	f840 3b04 	str.w	r3, [r0], #4
 8000248:	f851 3b04 	ldr.w	r3, [r1], #4
 800024c:	f840 3b04 	str.w	r3, [r0], #4
 8000250:	f851 3b04 	ldr.w	r3, [r1], #4
 8000254:	f840 3b04 	str.w	r3, [r0], #4
 8000258:	f851 3b04 	ldr.w	r3, [r1], #4
 800025c:	f840 3b04 	str.w	r3, [r0], #4
 8000260:	f851 3b04 	ldr.w	r3, [r1], #4
 8000264:	f840 3b04 	str.w	r3, [r0], #4
 8000268:	f851 3b04 	ldr.w	r3, [r1], #4
 800026c:	f840 3b04 	str.w	r3, [r0], #4
 8000270:	f851 3b04 	ldr.w	r3, [r1], #4
 8000274:	f840 3b04 	str.w	r3, [r0], #4
 8000278:	f851 3b04 	ldr.w	r3, [r1], #4
 800027c:	f840 3b04 	str.w	r3, [r0], #4
 8000280:	f851 3b04 	ldr.w	r3, [r1], #4
 8000284:	f840 3b04 	str.w	r3, [r0], #4
 8000288:	f851 3b04 	ldr.w	r3, [r1], #4
 800028c:	f840 3b04 	str.w	r3, [r0], #4
 8000290:	f851 3b04 	ldr.w	r3, [r1], #4
 8000294:	f840 3b04 	str.w	r3, [r0], #4
 8000298:	f851 3b04 	ldr.w	r3, [r1], #4
 800029c:	f840 3b04 	str.w	r3, [r0], #4
 80002a0:	3a40      	subs	r2, #64	@ 0x40
 80002a2:	d2bd      	bcs.n	8000220 <memcpy+0x10>
 80002a4:	3230      	adds	r2, #48	@ 0x30
 80002a6:	d311      	bcc.n	80002cc <memcpy+0xbc>
 80002a8:	f851 3b04 	ldr.w	r3, [r1], #4
 80002ac:	f840 3b04 	str.w	r3, [r0], #4
 80002b0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002b4:	f840 3b04 	str.w	r3, [r0], #4
 80002b8:	f851 3b04 	ldr.w	r3, [r1], #4
 80002bc:	f840 3b04 	str.w	r3, [r0], #4
 80002c0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002c4:	f840 3b04 	str.w	r3, [r0], #4
 80002c8:	3a10      	subs	r2, #16
 80002ca:	d2ed      	bcs.n	80002a8 <memcpy+0x98>
 80002cc:	320c      	adds	r2, #12
 80002ce:	d305      	bcc.n	80002dc <memcpy+0xcc>
 80002d0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002d4:	f840 3b04 	str.w	r3, [r0], #4
 80002d8:	3a04      	subs	r2, #4
 80002da:	d2f9      	bcs.n	80002d0 <memcpy+0xc0>
 80002dc:	3204      	adds	r2, #4
 80002de:	d008      	beq.n	80002f2 <memcpy+0xe2>
 80002e0:	07d2      	lsls	r2, r2, #31
 80002e2:	bf1c      	itt	ne
 80002e4:	f811 3b01 	ldrbne.w	r3, [r1], #1
 80002e8:	f800 3b01 	strbne.w	r3, [r0], #1
 80002ec:	d301      	bcc.n	80002f2 <memcpy+0xe2>
 80002ee:	880b      	ldrh	r3, [r1, #0]
 80002f0:	8003      	strh	r3, [r0, #0]
 80002f2:	4660      	mov	r0, ip
 80002f4:	4770      	bx	lr
 80002f6:	bf00      	nop
 80002f8:	2a08      	cmp	r2, #8
 80002fa:	d313      	bcc.n	8000324 <memcpy+0x114>
 80002fc:	078b      	lsls	r3, r1, #30
 80002fe:	d08d      	beq.n	800021c <memcpy+0xc>
 8000300:	f010 0303 	ands.w	r3, r0, #3
 8000304:	d08a      	beq.n	800021c <memcpy+0xc>
 8000306:	f1c3 0304 	rsb	r3, r3, #4
 800030a:	1ad2      	subs	r2, r2, r3
 800030c:	07db      	lsls	r3, r3, #31
 800030e:	bf1c      	itt	ne
 8000310:	f811 3b01 	ldrbne.w	r3, [r1], #1
 8000314:	f800 3b01 	strbne.w	r3, [r0], #1
 8000318:	d380      	bcc.n	800021c <memcpy+0xc>
 800031a:	f831 3b02 	ldrh.w	r3, [r1], #2
 800031e:	f820 3b02 	strh.w	r3, [r0], #2
 8000322:	e77b      	b.n	800021c <memcpy+0xc>
 8000324:	3a04      	subs	r2, #4
 8000326:	d3d9      	bcc.n	80002dc <memcpy+0xcc>
 8000328:	3a01      	subs	r2, #1
 800032a:	f811 3b01 	ldrb.w	r3, [r1], #1
 800032e:	f800 3b01 	strb.w	r3, [r0], #1
 8000332:	d2f9      	bcs.n	8000328 <memcpy+0x118>
 8000334:	780b      	ldrb	r3, [r1, #0]
 8000336:	7003      	strb	r3, [r0, #0]
 8000338:	784b      	ldrb	r3, [r1, #1]
 800033a:	7043      	strb	r3, [r0, #1]
 800033c:	788b      	ldrb	r3, [r1, #2]
 800033e:	7083      	strb	r3, [r0, #2]
 8000340:	4660      	mov	r0, ip
 8000342:	4770      	bx	lr

08000344 <__libc_init_array>:
 8000344:	b570      	push	{r4, r5, r6, lr}
 8000346:	4b0f      	ldr	r3, [pc, #60]	@ (8000384 <__libc_init_array+0x40>)
 8000348:	4d0f      	ldr	r5, [pc, #60]	@ (8000388 <__libc_init_array+0x44>)
 800034a:	42ab      	cmp	r3, r5
 800034c:	eba3 0605 	sub.w	r6, r3, r5
 8000350:	d007      	beq.n	8000362 <__libc_init_array+0x1e>
 8000352:	10b6      	asrs	r6, r6, #2
 8000354:	2400      	movs	r4, #0
 8000356:	f855 3b04 	ldr.w	r3, [r5], #4
 800035a:	3401      	adds	r4, #1
 800035c:	4798      	blx	r3
 800035e:	42a6      	cmp	r6, r4
 8000360:	d8f9      	bhi.n	8000356 <__libc_init_array+0x12>
 8000362:	f003 f8d9 	bl	8003518 <_init>
 8000366:	4d09      	ldr	r5, [pc, #36]	@ (800038c <__libc_init_array+0x48>)
 8000368:	4b09      	ldr	r3, [pc, #36]	@ (8000390 <__libc_init_array+0x4c>)
 800036a:	1b5e      	subs	r6, r3, r5
 800036c:	42ab      	cmp	r3, r5
 800036e:	ea4f 06a6 	mov.w	r6, r6, asr #2
 8000372:	d006      	beq.n	8000382 <__libc_init_array+0x3e>
 8000374:	2400      	movs	r4, #0
 8000376:	f855 3b04 	ldr.w	r3, [r5], #4
 800037a:	3401      	adds	r4, #1
 800037c:	4798      	blx	r3
 800037e:	42a6      	cmp	r6, r4
 8000380:	d8f9      	bhi.n	8000376 <__libc_init_array+0x32>
 8000382:	bd70      	pop	{r4, r5, r6, pc}
 8000384:	08003620 	.word	0x08003620
 8000388:	08003620 	.word	0x08003620
 800038c:	08003620 	.word	0x08003620
 8000390:	08003628 	.word	0x08003628

08000394 <__errno>:
 8000394:	4b01      	ldr	r3, [pc, #4]	@ (800039c <__errno+0x8>)
 8000396:	6818      	ldr	r0, [r3, #0]
 8000398:	4770      	bx	lr
 800039a:	bf00      	nop
 800039c:	20000000 	.word	0x20000000

080003a0 <__libc_fini_array>:
 80003a0:	b538      	push	{r3, r4, r5, lr}
 80003a2:	4d07      	ldr	r5, [pc, #28]	@ (80003c0 <__libc_fini_array+0x20>)
 80003a4:	4c07      	ldr	r4, [pc, #28]	@ (80003c4 <__libc_fini_array+0x24>)
 80003a6:	1b2c      	subs	r4, r5, r4
 80003a8:	10a4      	asrs	r4, r4, #2
 80003aa:	d005      	beq.n	80003b8 <__libc_fini_array+0x18>
 80003ac:	3c01      	subs	r4, #1
 80003ae:	f855 3d04 	ldr.w	r3, [r5, #-4]!
 80003b2:	4798      	blx	r3
 80003b4:	2c00      	cmp	r4, #0
 80003b6:	d1f9      	bne.n	80003ac <__libc_fini_array+0xc>
 80003b8:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
 80003bc:	f003 b8b2 	b.w	8003524 <_fini>
 80003c0:	0800362c 	.word	0x0800362c
 80003c4:	08003628 	.word	0x08003628

080003c8 <malloc>:
 80003c8:	4b02      	ldr	r3, [pc, #8]	@ (80003d4 <malloc+0xc>)
 80003ca:	4601      	mov	r1, r0
 80003cc:	6818      	ldr	r0, [r3, #0]
 80003ce:	f000 b86d 	b.w	80004ac <_malloc_r>
 80003d2:	bf00      	nop
 80003d4:	20000000 	.word	0x20000000

080003d8 <free>:
 80003d8:	4b02      	ldr	r3, [pc, #8]	@ (80003e4 <free+0xc>)
 80003da:	4601      	mov	r1, r0
 80003dc:	6818      	ldr	r0, [r3, #0]
 80003de:	f000 bb9b 	b.w	8000b18 <_free_r>
 80003e2:	bf00      	nop
 80003e4:	20000000 	.word	0x20000000

080003e8 <memset>:
 80003e8:	0783      	lsls	r3, r0, #30
 80003ea:	b530      	push	{r4, r5, lr}
 80003ec:	d046      	beq.n	800047c <memset+0x94>
 80003ee:	1884      	adds	r4, r0, r2
 80003f0:	4684      	mov	ip, r0
 80003f2:	e004      	b.n	80003fe <memset+0x16>
 80003f4:	f803 1b01 	strb.w	r1, [r3], #1
 80003f8:	079d      	lsls	r5, r3, #30
 80003fa:	d004      	beq.n	8000406 <memset+0x1e>
 80003fc:	469c      	mov	ip, r3
 80003fe:	45a4      	cmp	ip, r4
 8000400:	4663      	mov	r3, ip
 8000402:	d1f7      	bne.n	80003f4 <memset+0xc>
 8000404:	bd30      	pop	{r4, r5, pc}
 8000406:	3a01      	subs	r2, #1
 8000408:	4402      	add	r2, r0
 800040a:	eba2 020c 	sub.w	r2, r2, ip
 800040e:	2a03      	cmp	r2, #3
 8000410:	d929      	bls.n	8000466 <memset+0x7e>
 8000412:	b2cc      	uxtb	r4, r1
 8000414:	eb04 2404 	add.w	r4, r4, r4, lsl #8
 8000418:	2a0f      	cmp	r2, #15
 800041a:	eb04 4404 	add.w	r4, r4, r4, lsl #16
 800041e:	d92f      	bls.n	8000480 <memset+0x98>
 8000420:	f1a2 0c10 	sub.w	ip, r2, #16
 8000424:	f02c 0c0f 	bic.w	ip, ip, #15
 8000428:	f103 0510 	add.w	r5, r3, #16
 800042c:	44ac      	add	ip, r5
 800042e:	e9c3 4400 	strd	r4, r4, [r3]
 8000432:	e9c3 4402 	strd	r4, r4, [r3, #8]
 8000436:	3310      	adds	r3, #16
 8000438:	4563      	cmp	r3, ip
 800043a:	d1f8      	bne.n	800042e <memset+0x46>
 800043c:	f012 0f0c 	tst.w	r2, #12
 8000440:	f002 0e0f 	and.w	lr, r2, #15
 8000444:	d018      	beq.n	8000478 <memset+0x90>
 8000446:	f02e 0c03 	bic.w	ip, lr, #3
 800044a:	449c      	add	ip, r3
 800044c:	f1ae 0504 	sub.w	r5, lr, #4
 8000450:	461a      	mov	r2, r3
 8000452:	f842 4b04 	str.w	r4, [r2], #4
 8000456:	4562      	cmp	r2, ip
 8000458:	d1fb      	bne.n	8000452 <memset+0x6a>
 800045a:	f025 0403 	bic.w	r4, r5, #3
 800045e:	3304      	adds	r3, #4
 8000460:	f00e 0203 	and.w	r2, lr, #3
 8000464:	4423      	add	r3, r4
 8000466:	2a00      	cmp	r2, #0
 8000468:	d0cc      	beq.n	8000404 <memset+0x1c>
 800046a:	b2c9      	uxtb	r1, r1
 800046c:	441a      	add	r2, r3
 800046e:	f803 1b01 	strb.w	r1, [r3], #1
 8000472:	4293      	cmp	r3, r2
 8000474:	d1fb      	bne.n	800046e <memset+0x86>
 8000476:	bd30      	pop	{r4, r5, pc}
 8000478:	4672      	mov	r2, lr
 800047a:	e7f4      	b.n	8000466 <memset+0x7e>
 800047c:	4603      	mov	r3, r0
 800047e:	e7c6      	b.n	800040e <memset+0x26>
 8000480:	4696      	mov	lr, r2
 8000482:	e7e0      	b.n	8000446 <memset+0x5e>

08000484 <exit>:
 8000484:	b508      	push	{r3, lr}
 8000486:	2100      	movs	r1, #0
 8000488:	4604      	mov	r4, r0
 800048a:	f000 fc3d 	bl	8000d08 <__call_exitprocs>
 800048e:	4b03      	ldr	r3, [pc, #12]	@ (800049c <exit+0x18>)
 8000490:	681b      	ldr	r3, [r3, #0]
 8000492:	b103      	cbz	r3, 8000496 <exit+0x12>
 8000494:	4798      	blx	r3
 8000496:	4620      	mov	r0, r4
 8000498:	f000 fcd2 	bl	8000e40 <_exit>
 800049c:	20000d5c 	.word	0x20000d5c

080004a0 <atexit>:
 80004a0:	2300      	movs	r3, #0
 80004a2:	4601      	mov	r1, r0
 80004a4:	461a      	mov	r2, r3
 80004a6:	4618      	mov	r0, r3
 80004a8:	f000 bc86 	b.w	8000db8 <__register_exitproc>

080004ac <_malloc_r>:
 80004ac:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 80004b0:	f101 050b 	add.w	r5, r1, #11
 80004b4:	2d16      	cmp	r5, #22
 80004b6:	b083      	sub	sp, #12
 80004b8:	4606      	mov	r6, r0
 80004ba:	d823      	bhi.n	8000504 <_malloc_r+0x58>
 80004bc:	2910      	cmp	r1, #16
 80004be:	f200 80b4 	bhi.w	800062a <_malloc_r+0x17e>
 80004c2:	f000 fcab 	bl	8000e1c <__malloc_lock>
 80004c6:	2510      	movs	r5, #16
 80004c8:	2318      	movs	r3, #24
 80004ca:	2002      	movs	r0, #2
 80004cc:	4fc6      	ldr	r7, [pc, #792]	@ (80007e8 <_malloc_r+0x33c>)
 80004ce:	443b      	add	r3, r7
 80004d0:	f1a3 0208 	sub.w	r2, r3, #8
 80004d4:	685c      	ldr	r4, [r3, #4]
 80004d6:	4294      	cmp	r4, r2
 80004d8:	f000 816c 	beq.w	80007b4 <_malloc_r+0x308>
 80004dc:	6863      	ldr	r3, [r4, #4]
 80004de:	68e2      	ldr	r2, [r4, #12]
 80004e0:	68a1      	ldr	r1, [r4, #8]
 80004e2:	f023 0303 	bic.w	r3, r3, #3
 80004e6:	60ca      	str	r2, [r1, #12]
 80004e8:	4423      	add	r3, r4
 80004ea:	4630      	mov	r0, r6
 80004ec:	6091      	str	r1, [r2, #8]
 80004ee:	685a      	ldr	r2, [r3, #4]
 80004f0:	f042 0201 	orr.w	r2, r2, #1
 80004f4:	605a      	str	r2, [r3, #4]
 80004f6:	f000 fc93 	bl	8000e20 <__malloc_unlock>
 80004fa:	3408      	adds	r4, #8
 80004fc:	4620      	mov	r0, r4
 80004fe:	b003      	add	sp, #12
 8000500:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000504:	f035 0507 	bics.w	r5, r5, #7
 8000508:	f100 808f 	bmi.w	800062a <_malloc_r+0x17e>
 800050c:	42a9      	cmp	r1, r5
 800050e:	f200 808c 	bhi.w	800062a <_malloc_r+0x17e>
 8000512:	f000 fc83 	bl	8000e1c <__malloc_lock>
 8000516:	f5b5 7ffc 	cmp.w	r5, #504	@ 0x1f8
 800051a:	f0c0 81b9 	bcc.w	8000890 <_malloc_r+0x3e4>
 800051e:	ea5f 2e55 	movs.w	lr, r5, lsr #9
 8000522:	f000 8089 	beq.w	8000638 <_malloc_r+0x18c>
 8000526:	f1be 0f04 	cmp.w	lr, #4
 800052a:	f200 8171 	bhi.w	8000810 <_malloc_r+0x364>
 800052e:	ea4f 1e95 	mov.w	lr, r5, lsr #6
 8000532:	f10e 0039 	add.w	r0, lr, #57	@ 0x39
 8000536:	b203      	sxth	r3, r0
 8000538:	f10e 0e38 	add.w	lr, lr, #56	@ 0x38
 800053c:	00db      	lsls	r3, r3, #3
 800053e:	4faa      	ldr	r7, [pc, #680]	@ (80007e8 <_malloc_r+0x33c>)
 8000540:	443b      	add	r3, r7
 8000542:	f1a3 0c08 	sub.w	ip, r3, #8
 8000546:	685c      	ldr	r4, [r3, #4]
 8000548:	45a4      	cmp	ip, r4
 800054a:	d107      	bne.n	800055c <_malloc_r+0xb0>
 800054c:	e00d      	b.n	800056a <_malloc_r+0xbe>
 800054e:	2a00      	cmp	r2, #0
 8000550:	68e1      	ldr	r1, [r4, #12]
 8000552:	f280 8129 	bge.w	80007a8 <_malloc_r+0x2fc>
 8000556:	458c      	cmp	ip, r1
 8000558:	d007      	beq.n	800056a <_malloc_r+0xbe>
 800055a:	460c      	mov	r4, r1
 800055c:	6863      	ldr	r3, [r4, #4]
 800055e:	f023 0303 	bic.w	r3, r3, #3
 8000562:	1b5a      	subs	r2, r3, r5
 8000564:	2a0f      	cmp	r2, #15
 8000566:	ddf2      	ble.n	800054e <_malloc_r+0xa2>
 8000568:	4670      	mov	r0, lr
 800056a:	f8df 8280 	ldr.w	r8, [pc, #640]	@ 80007ec <_malloc_r+0x340>
 800056e:	693c      	ldr	r4, [r7, #16]
 8000570:	4544      	cmp	r4, r8
 8000572:	f000 8106 	beq.w	8000782 <_malloc_r+0x2d6>
 8000576:	6863      	ldr	r3, [r4, #4]
 8000578:	f023 0c03 	bic.w	ip, r3, #3
 800057c:	ebac 0305 	sub.w	r3, ip, r5
 8000580:	2b0f      	cmp	r3, #15
 8000582:	f300 818a 	bgt.w	800089a <_malloc_r+0x3ee>
 8000586:	2b00      	cmp	r3, #0
 8000588:	e9c7 8804 	strd	r8, r8, [r7, #16]
 800058c:	f280 8174 	bge.w	8000878 <_malloc_r+0x3cc>
 8000590:	f5bc 7f00 	cmp.w	ip, #512	@ 0x200
 8000594:	f8d7 e004 	ldr.w	lr, [r7, #4]
 8000598:	f080 8112 	bcs.w	80007c0 <_malloc_r+0x314>
 800059c:	ea4f 03dc 	mov.w	r3, ip, lsr #3
 80005a0:	3301      	adds	r3, #1
 80005a2:	b219      	sxth	r1, r3
 80005a4:	ea4f 1c5c 	mov.w	ip, ip, lsr #5
 80005a8:	2301      	movs	r3, #1
 80005aa:	fa03 f30c 	lsl.w	r3, r3, ip
 80005ae:	f857 2031 	ldr.w	r2, [r7, r1, lsl #3]
 80005b2:	60a2      	str	r2, [r4, #8]
 80005b4:	ea4e 0e03 	orr.w	lr, lr, r3
 80005b8:	eb07 03c1 	add.w	r3, r7, r1, lsl #3
 80005bc:	3b08      	subs	r3, #8
 80005be:	60e3      	str	r3, [r4, #12]
 80005c0:	f8c7 e004 	str.w	lr, [r7, #4]
 80005c4:	f847 4031 	str.w	r4, [r7, r1, lsl #3]
 80005c8:	60d4      	str	r4, [r2, #12]
 80005ca:	1083      	asrs	r3, r0, #2
 80005cc:	f04f 0c01 	mov.w	ip, #1
 80005d0:	fa0c fc03 	lsl.w	ip, ip, r3
 80005d4:	45f4      	cmp	ip, lr
 80005d6:	d835      	bhi.n	8000644 <_malloc_r+0x198>
 80005d8:	ea1c 0f0e 	tst.w	ip, lr
 80005dc:	d108      	bne.n	80005f0 <_malloc_r+0x144>
 80005de:	f020 0003 	bic.w	r0, r0, #3
 80005e2:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 80005e6:	ea1c 0f0e 	tst.w	ip, lr
 80005ea:	f100 0004 	add.w	r0, r0, #4
 80005ee:	d0f8      	beq.n	80005e2 <_malloc_r+0x136>
 80005f0:	eb07 0ac0 	add.w	sl, r7, r0, lsl #3
 80005f4:	46d6      	mov	lr, sl
 80005f6:	4681      	mov	r9, r0
 80005f8:	f8de 300c 	ldr.w	r3, [lr, #12]
 80005fc:	e00b      	b.n	8000616 <_malloc_r+0x16a>
 80005fe:	6859      	ldr	r1, [r3, #4]
 8000600:	f021 0103 	bic.w	r1, r1, #3
 8000604:	1b4a      	subs	r2, r1, r5
 8000606:	2a0f      	cmp	r2, #15
 8000608:	461c      	mov	r4, r3
 800060a:	68db      	ldr	r3, [r3, #12]
 800060c:	f300 8110 	bgt.w	8000830 <_malloc_r+0x384>
 8000610:	2a00      	cmp	r2, #0
 8000612:	f280 8124 	bge.w	800085e <_malloc_r+0x3b2>
 8000616:	459e      	cmp	lr, r3
 8000618:	d1f1      	bne.n	80005fe <_malloc_r+0x152>
 800061a:	f109 0901 	add.w	r9, r9, #1
 800061e:	f019 0f03 	tst.w	r9, #3
 8000622:	f10e 0e08 	add.w	lr, lr, #8
 8000626:	d1e7      	bne.n	80005f8 <_malloc_r+0x14c>
 8000628:	e162      	b.n	80008f0 <_malloc_r+0x444>
 800062a:	230c      	movs	r3, #12
 800062c:	6033      	str	r3, [r6, #0]
 800062e:	2400      	movs	r4, #0
 8000630:	4620      	mov	r0, r4
 8000632:	b003      	add	sp, #12
 8000634:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000638:	f44f 7300 	mov.w	r3, #512	@ 0x200
 800063c:	2040      	movs	r0, #64	@ 0x40
 800063e:	f04f 0e3f 	mov.w	lr, #63	@ 0x3f
 8000642:	e77c      	b.n	800053e <_malloc_r+0x92>
 8000644:	68bc      	ldr	r4, [r7, #8]
 8000646:	6863      	ldr	r3, [r4, #4]
 8000648:	f023 0903 	bic.w	r9, r3, #3
 800064c:	45a9      	cmp	r9, r5
 800064e:	d304      	bcc.n	800065a <_malloc_r+0x1ae>
 8000650:	eba9 0305 	sub.w	r3, r9, r5
 8000654:	2b0f      	cmp	r3, #15
 8000656:	f300 8097 	bgt.w	8000788 <_malloc_r+0x2dc>
 800065a:	f8df b194 	ldr.w	fp, [pc, #404]	@ 80007f0 <_malloc_r+0x344>
 800065e:	f8db 2000 	ldr.w	r2, [fp]
 8000662:	eb04 0309 	add.w	r3, r4, r9
 8000666:	3210      	adds	r2, #16
 8000668:	2008      	movs	r0, #8
 800066a:	eb02 0805 	add.w	r8, r2, r5
 800066e:	9300      	str	r3, [sp, #0]
 8000670:	f000 fbd8 	bl	8000e24 <sysconf>
 8000674:	f8d7 1408 	ldr.w	r1, [r7, #1032]	@ 0x408
 8000678:	3101      	adds	r1, #1
 800067a:	4602      	mov	r2, r0
 800067c:	d005      	beq.n	800068a <_malloc_r+0x1de>
 800067e:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 8000682:	4480      	add	r8, r0
 8000684:	4241      	negs	r1, r0
 8000686:	ea01 0808 	and.w	r8, r1, r8
 800068a:	4641      	mov	r1, r8
 800068c:	4630      	mov	r0, r6
 800068e:	9200      	str	r2, [sp, #0]
 8000690:	f000 f9d4 	bl	8000a3c <_sbrk_r>
 8000694:	f1b0 3fff 	cmp.w	r0, #4294967295	@ 0xffffffff
 8000698:	9a00      	ldr	r2, [sp, #0]
 800069a:	4682      	mov	sl, r0
 800069c:	f000 8119 	beq.w	80008d2 <_malloc_r+0x426>
 80006a0:	eb04 0309 	add.w	r3, r4, r9
 80006a4:	4283      	cmp	r3, r0
 80006a6:	f200 8112 	bhi.w	80008ce <_malloc_r+0x422>
 80006aa:	f8db 1004 	ldr.w	r1, [fp, #4]
 80006ae:	4441      	add	r1, r8
 80006b0:	f8cb 1004 	str.w	r1, [fp, #4]
 80006b4:	f102 3cff 	add.w	ip, r2, #4294967295	@ 0xffffffff
 80006b8:	f000 816d 	beq.w	8000996 <_malloc_r+0x4ea>
 80006bc:	f8d7 0408 	ldr.w	r0, [r7, #1032]	@ 0x408
 80006c0:	3001      	adds	r0, #1
 80006c2:	f000 8174 	beq.w	80009ae <_malloc_r+0x502>
 80006c6:	eb04 0309 	add.w	r3, r4, r9
 80006ca:	ebaa 0303 	sub.w	r3, sl, r3
 80006ce:	4419      	add	r1, r3
 80006d0:	f8cb 1004 	str.w	r1, [fp, #4]
 80006d4:	f01a 0307 	ands.w	r3, sl, #7
 80006d8:	9300      	str	r3, [sp, #0]
 80006da:	f000 812e 	beq.w	800093a <_malloc_r+0x48e>
 80006de:	f1c3 0108 	rsb	r1, r3, #8
 80006e2:	448a      	add	sl, r1
 80006e4:	44d0      	add	r8, sl
 80006e6:	440a      	add	r2, r1
 80006e8:	ea08 010c 	and.w	r1, r8, ip
 80006ec:	1a52      	subs	r2, r2, r1
 80006ee:	ea02 010c 	and.w	r1, r2, ip
 80006f2:	4630      	mov	r0, r6
 80006f4:	9101      	str	r1, [sp, #4]
 80006f6:	f000 f9a1 	bl	8000a3c <_sbrk_r>
 80006fa:	1c42      	adds	r2, r0, #1
 80006fc:	f000 8174 	beq.w	80009e8 <_malloc_r+0x53c>
 8000700:	9901      	ldr	r1, [sp, #4]
 8000702:	eba0 000a 	sub.w	r0, r0, sl
 8000706:	eb00 0801 	add.w	r8, r0, r1
 800070a:	f8db 2004 	ldr.w	r2, [fp, #4]
 800070e:	f8c7 a008 	str.w	sl, [r7, #8]
 8000712:	f048 0001 	orr.w	r0, r8, #1
 8000716:	4411      	add	r1, r2
 8000718:	42bc      	cmp	r4, r7
 800071a:	f8ca 0004 	str.w	r0, [sl, #4]
 800071e:	f8cb 1004 	str.w	r1, [fp, #4]
 8000722:	d015      	beq.n	8000750 <_malloc_r+0x2a4>
 8000724:	f1b9 0f0f 	cmp.w	r9, #15
 8000728:	f240 8144 	bls.w	80009b4 <_malloc_r+0x508>
 800072c:	6862      	ldr	r2, [r4, #4]
 800072e:	f1a9 000c 	sub.w	r0, r9, #12
 8000732:	f020 0007 	bic.w	r0, r0, #7
 8000736:	f002 0201 	and.w	r2, r2, #1
 800073a:	4302      	orrs	r2, r0
 800073c:	6062      	str	r2, [r4, #4]
 800073e:	2305      	movs	r3, #5
 8000740:	1822      	adds	r2, r4, r0
 8000742:	280f      	cmp	r0, #15
 8000744:	e9c2 3301 	strd	r3, r3, [r2, #4]
 8000748:	f200 8156 	bhi.w	80009f8 <_malloc_r+0x54c>
 800074c:	f8da 0004 	ldr.w	r0, [sl, #4]
 8000750:	f8db 202c 	ldr.w	r2, [fp, #44]	@ 0x2c
 8000754:	428a      	cmp	r2, r1
 8000756:	f8db 2030 	ldr.w	r2, [fp, #48]	@ 0x30
 800075a:	bf38      	it	cc
 800075c:	f8cb 102c 	strcc.w	r1, [fp, #44]	@ 0x2c
 8000760:	428a      	cmp	r2, r1
 8000762:	bf38      	it	cc
 8000764:	f8cb 1030 	strcc.w	r1, [fp, #48]	@ 0x30
 8000768:	4654      	mov	r4, sl
 800076a:	f020 0803 	bic.w	r8, r0, #3
 800076e:	45a8      	cmp	r8, r5
 8000770:	eba8 0305 	sub.w	r3, r8, r5
 8000774:	d301      	bcc.n	800077a <_malloc_r+0x2ce>
 8000776:	2b0f      	cmp	r3, #15
 8000778:	dc06      	bgt.n	8000788 <_malloc_r+0x2dc>
 800077a:	4630      	mov	r0, r6
 800077c:	f000 fb50 	bl	8000e20 <__malloc_unlock>
 8000780:	e755      	b.n	800062e <_malloc_r+0x182>
 8000782:	f8d7 e004 	ldr.w	lr, [r7, #4]
 8000786:	e720      	b.n	80005ca <_malloc_r+0x11e>
 8000788:	1962      	adds	r2, r4, r5
 800078a:	f043 0301 	orr.w	r3, r3, #1
 800078e:	f045 0501 	orr.w	r5, r5, #1
 8000792:	6065      	str	r5, [r4, #4]
 8000794:	4630      	mov	r0, r6
 8000796:	60ba      	str	r2, [r7, #8]
 8000798:	6053      	str	r3, [r2, #4]
 800079a:	f000 fb41 	bl	8000e20 <__malloc_unlock>
 800079e:	3408      	adds	r4, #8
 80007a0:	4620      	mov	r0, r4
 80007a2:	b003      	add	sp, #12
 80007a4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 80007a8:	68a2      	ldr	r2, [r4, #8]
 80007aa:	4423      	add	r3, r4
 80007ac:	60d1      	str	r1, [r2, #12]
 80007ae:	4630      	mov	r0, r6
 80007b0:	608a      	str	r2, [r1, #8]
 80007b2:	e69c      	b.n	80004ee <_malloc_r+0x42>
 80007b4:	68dc      	ldr	r4, [r3, #12]
 80007b6:	42a3      	cmp	r3, r4
 80007b8:	f47f ae90 	bne.w	80004dc <_malloc_r+0x30>
 80007bc:	3002      	adds	r0, #2
 80007be:	e6d4      	b.n	800056a <_malloc_r+0xbe>
 80007c0:	f5bc 6f20 	cmp.w	ip, #2560	@ 0xa00
 80007c4:	ea4f 225c 	mov.w	r2, ip, lsr #9
 80007c8:	d379      	bcc.n	80008be <_malloc_r+0x412>
 80007ca:	2a14      	cmp	r2, #20
 80007cc:	f200 80c5 	bhi.w	800095a <_malloc_r+0x4ae>
 80007d0:	f102 035c 	add.w	r3, r2, #92	@ 0x5c
 80007d4:	b21b      	sxth	r3, r3
 80007d6:	325b      	adds	r2, #91	@ 0x5b
 80007d8:	00db      	lsls	r3, r3, #3
 80007da:	18f9      	adds	r1, r7, r3
 80007dc:	58fb      	ldr	r3, [r7, r3]
 80007de:	3908      	subs	r1, #8
 80007e0:	4299      	cmp	r1, r3
 80007e2:	d10a      	bne.n	80007fa <_malloc_r+0x34e>
 80007e4:	e09f      	b.n	8000926 <_malloc_r+0x47a>
 80007e6:	bf00      	nop
 80007e8:	20000128 	.word	0x20000128
 80007ec:	20000130 	.word	0x20000130
 80007f0:	20000d60 	.word	0x20000d60
 80007f4:	689b      	ldr	r3, [r3, #8]
 80007f6:	4299      	cmp	r1, r3
 80007f8:	d004      	beq.n	8000804 <_malloc_r+0x358>
 80007fa:	685a      	ldr	r2, [r3, #4]
 80007fc:	f022 0203 	bic.w	r2, r2, #3
 8000800:	4562      	cmp	r2, ip
 8000802:	d8f7      	bhi.n	80007f4 <_malloc_r+0x348>
 8000804:	68d9      	ldr	r1, [r3, #12]
 8000806:	e9c4 3102 	strd	r3, r1, [r4, #8]
 800080a:	608c      	str	r4, [r1, #8]
 800080c:	60dc      	str	r4, [r3, #12]
 800080e:	e6dc      	b.n	80005ca <_malloc_r+0x11e>
 8000810:	f1be 0f14 	cmp.w	lr, #20
 8000814:	d960      	bls.n	80008d8 <_malloc_r+0x42c>
 8000816:	f1be 0f54 	cmp.w	lr, #84	@ 0x54
 800081a:	f200 80a8 	bhi.w	800096e <_malloc_r+0x4c2>
 800081e:	ea4f 3e15 	mov.w	lr, r5, lsr #12
 8000822:	f10e 006f 	add.w	r0, lr, #111	@ 0x6f
 8000826:	b203      	sxth	r3, r0
 8000828:	f10e 0e6e 	add.w	lr, lr, #110	@ 0x6e
 800082c:	00db      	lsls	r3, r3, #3
 800082e:	e686      	b.n	800053e <_malloc_r+0x92>
 8000830:	f8d4 c008 	ldr.w	ip, [r4, #8]
 8000834:	4630      	mov	r0, r6
 8000836:	1966      	adds	r6, r4, r5
 8000838:	f045 0501 	orr.w	r5, r5, #1
 800083c:	6065      	str	r5, [r4, #4]
 800083e:	f8cc 300c 	str.w	r3, [ip, #12]
 8000842:	f8c3 c008 	str.w	ip, [r3, #8]
 8000846:	f042 0301 	orr.w	r3, r2, #1
 800084a:	e9c7 6604 	strd	r6, r6, [r7, #16]
 800084e:	e9c6 8802 	strd	r8, r8, [r6, #8]
 8000852:	6073      	str	r3, [r6, #4]
 8000854:	5062      	str	r2, [r4, r1]
 8000856:	f000 fae3 	bl	8000e20 <__malloc_unlock>
 800085a:	3408      	adds	r4, #8
 800085c:	e6e8      	b.n	8000630 <_malloc_r+0x184>
 800085e:	4421      	add	r1, r4
 8000860:	4630      	mov	r0, r6
 8000862:	684a      	ldr	r2, [r1, #4]
 8000864:	f042 0201 	orr.w	r2, r2, #1
 8000868:	604a      	str	r2, [r1, #4]
 800086a:	f854 2f08 	ldr.w	r2, [r4, #8]!
 800086e:	60d3      	str	r3, [r2, #12]
 8000870:	609a      	str	r2, [r3, #8]
 8000872:	f000 fad5 	bl	8000e20 <__malloc_unlock>
 8000876:	e6db      	b.n	8000630 <_malloc_r+0x184>
 8000878:	44a4      	add	ip, r4
 800087a:	4630      	mov	r0, r6
 800087c:	f8dc 3004 	ldr.w	r3, [ip, #4]
 8000880:	f043 0301 	orr.w	r3, r3, #1
 8000884:	f8cc 3004 	str.w	r3, [ip, #4]
 8000888:	f000 faca 	bl	8000e20 <__malloc_unlock>
 800088c:	3408      	adds	r4, #8
 800088e:	e6cf      	b.n	8000630 <_malloc_r+0x184>
 8000890:	08e8      	lsrs	r0, r5, #3
 8000892:	1c43      	adds	r3, r0, #1
 8000894:	b21b      	sxth	r3, r3
 8000896:	00db      	lsls	r3, r3, #3
 8000898:	e618      	b.n	80004cc <_malloc_r+0x20>
 800089a:	1962      	adds	r2, r4, r5
 800089c:	f043 0101 	orr.w	r1, r3, #1
 80008a0:	f045 0501 	orr.w	r5, r5, #1
 80008a4:	6065      	str	r5, [r4, #4]
 80008a6:	4630      	mov	r0, r6
 80008a8:	e9c7 2204 	strd	r2, r2, [r7, #16]
 80008ac:	e9c2 8802 	strd	r8, r8, [r2, #8]
 80008b0:	6051      	str	r1, [r2, #4]
 80008b2:	f844 300c 	str.w	r3, [r4, ip]
 80008b6:	f000 fab3 	bl	8000e20 <__malloc_unlock>
 80008ba:	3408      	adds	r4, #8
 80008bc:	e6b8      	b.n	8000630 <_malloc_r+0x184>
 80008be:	ea4f 129c 	mov.w	r2, ip, lsr #6
 80008c2:	f102 0339 	add.w	r3, r2, #57	@ 0x39
 80008c6:	b21b      	sxth	r3, r3
 80008c8:	3238      	adds	r2, #56	@ 0x38
 80008ca:	00db      	lsls	r3, r3, #3
 80008cc:	e785      	b.n	80007da <_malloc_r+0x32e>
 80008ce:	42bc      	cmp	r4, r7
 80008d0:	d059      	beq.n	8000986 <_malloc_r+0x4da>
 80008d2:	68bc      	ldr	r4, [r7, #8]
 80008d4:	6860      	ldr	r0, [r4, #4]
 80008d6:	e748      	b.n	800076a <_malloc_r+0x2be>
 80008d8:	f10e 005c 	add.w	r0, lr, #92	@ 0x5c
 80008dc:	b203      	sxth	r3, r0
 80008de:	f10e 0e5b 	add.w	lr, lr, #91	@ 0x5b
 80008e2:	00db      	lsls	r3, r3, #3
 80008e4:	e62b      	b.n	800053e <_malloc_r+0x92>
 80008e6:	f85a 3908 	ldr.w	r3, [sl], #-8
 80008ea:	4553      	cmp	r3, sl
 80008ec:	f040 80a3 	bne.w	8000a36 <_malloc_r+0x58a>
 80008f0:	f010 0f03 	tst.w	r0, #3
 80008f4:	f100 30ff 	add.w	r0, r0, #4294967295	@ 0xffffffff
 80008f8:	d1f5      	bne.n	80008e6 <_malloc_r+0x43a>
 80008fa:	687b      	ldr	r3, [r7, #4]
 80008fc:	ea23 030c 	bic.w	r3, r3, ip
 8000900:	607b      	str	r3, [r7, #4]
 8000902:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 8000906:	459c      	cmp	ip, r3
 8000908:	f63f ae9c 	bhi.w	8000644 <_malloc_r+0x198>
 800090c:	f1bc 0f00 	cmp.w	ip, #0
 8000910:	d104      	bne.n	800091c <_malloc_r+0x470>
 8000912:	e697      	b.n	8000644 <_malloc_r+0x198>
 8000914:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 8000918:	f109 0904 	add.w	r9, r9, #4
 800091c:	ea1c 0f03 	tst.w	ip, r3
 8000920:	d0f8      	beq.n	8000914 <_malloc_r+0x468>
 8000922:	4648      	mov	r0, r9
 8000924:	e664      	b.n	80005f0 <_malloc_r+0x144>
 8000926:	1092      	asrs	r2, r2, #2
 8000928:	f04f 0c01 	mov.w	ip, #1
 800092c:	fa0c f202 	lsl.w	r2, ip, r2
 8000930:	ea4e 0e02 	orr.w	lr, lr, r2
 8000934:	f8c7 e004 	str.w	lr, [r7, #4]
 8000938:	e765      	b.n	8000806 <_malloc_r+0x35a>
 800093a:	eb0a 0108 	add.w	r1, sl, r8
 800093e:	ea01 010c 	and.w	r1, r1, ip
 8000942:	1a52      	subs	r2, r2, r1
 8000944:	ea02 010c 	and.w	r1, r2, ip
 8000948:	4630      	mov	r0, r6
 800094a:	9101      	str	r1, [sp, #4]
 800094c:	f000 f876 	bl	8000a3c <_sbrk_r>
 8000950:	1c43      	adds	r3, r0, #1
 8000952:	f47f aed5 	bne.w	8000700 <_malloc_r+0x254>
 8000956:	9900      	ldr	r1, [sp, #0]
 8000958:	e6d7      	b.n	800070a <_malloc_r+0x25e>
 800095a:	2a54      	cmp	r2, #84	@ 0x54
 800095c:	d82e      	bhi.n	80009bc <_malloc_r+0x510>
 800095e:	ea4f 321c 	mov.w	r2, ip, lsr #12
 8000962:	f102 036f 	add.w	r3, r2, #111	@ 0x6f
 8000966:	b21b      	sxth	r3, r3
 8000968:	326e      	adds	r2, #110	@ 0x6e
 800096a:	00db      	lsls	r3, r3, #3
 800096c:	e735      	b.n	80007da <_malloc_r+0x32e>
 800096e:	f5be 7faa 	cmp.w	lr, #340	@ 0x154
 8000972:	d82e      	bhi.n	80009d2 <_malloc_r+0x526>
 8000974:	ea4f 3ed5 	mov.w	lr, r5, lsr #15
 8000978:	f10e 0078 	add.w	r0, lr, #120	@ 0x78
 800097c:	b203      	sxth	r3, r0
 800097e:	f10e 0e77 	add.w	lr, lr, #119	@ 0x77
 8000982:	00db      	lsls	r3, r3, #3
 8000984:	e5db      	b.n	800053e <_malloc_r+0x92>
 8000986:	f8db 1004 	ldr.w	r1, [fp, #4]
 800098a:	4441      	add	r1, r8
 800098c:	f8cb 1004 	str.w	r1, [fp, #4]
 8000990:	f102 3cff 	add.w	ip, r2, #4294967295	@ 0xffffffff
 8000994:	e692      	b.n	80006bc <_malloc_r+0x210>
 8000996:	ea10 0f0c 	tst.w	r0, ip
 800099a:	f47f ae8f 	bne.w	80006bc <_malloc_r+0x210>
 800099e:	f8d7 a008 	ldr.w	sl, [r7, #8]
 80009a2:	44c8      	add	r8, r9
 80009a4:	f048 0001 	orr.w	r0, r8, #1
 80009a8:	f8ca 0004 	str.w	r0, [sl, #4]
 80009ac:	e6d0      	b.n	8000750 <_malloc_r+0x2a4>
 80009ae:	f8c7 a408 	str.w	sl, [r7, #1032]	@ 0x408
 80009b2:	e68f      	b.n	80006d4 <_malloc_r+0x228>
 80009b4:	2301      	movs	r3, #1
 80009b6:	f8ca 3004 	str.w	r3, [sl, #4]
 80009ba:	e6de      	b.n	800077a <_malloc_r+0x2ce>
 80009bc:	f5b2 7faa 	cmp.w	r2, #340	@ 0x154
 80009c0:	d824      	bhi.n	8000a0c <_malloc_r+0x560>
 80009c2:	ea4f 32dc 	mov.w	r2, ip, lsr #15
 80009c6:	f102 0378 	add.w	r3, r2, #120	@ 0x78
 80009ca:	b21b      	sxth	r3, r3
 80009cc:	3277      	adds	r2, #119	@ 0x77
 80009ce:	00db      	lsls	r3, r3, #3
 80009d0:	e703      	b.n	80007da <_malloc_r+0x32e>
 80009d2:	f240 5354 	movw	r3, #1364	@ 0x554
 80009d6:	459e      	cmp	lr, r3
 80009d8:	d823      	bhi.n	8000a22 <_malloc_r+0x576>
 80009da:	0cab      	lsrs	r3, r5, #18
 80009dc:	f103 007d 	add.w	r0, r3, #125	@ 0x7d
 80009e0:	f103 0e7c 	add.w	lr, r3, #124	@ 0x7c
 80009e4:	00c3      	lsls	r3, r0, #3
 80009e6:	e5aa      	b.n	800053e <_malloc_r+0x92>
 80009e8:	9b00      	ldr	r3, [sp, #0]
 80009ea:	f1a3 0208 	sub.w	r2, r3, #8
 80009ee:	4490      	add	r8, r2
 80009f0:	eba8 080a 	sub.w	r8, r8, sl
 80009f4:	2100      	movs	r1, #0
 80009f6:	e688      	b.n	800070a <_malloc_r+0x25e>
 80009f8:	f104 0108 	add.w	r1, r4, #8
 80009fc:	4630      	mov	r0, r6
 80009fe:	f000 f88b 	bl	8000b18 <_free_r>
 8000a02:	f8db 1004 	ldr.w	r1, [fp, #4]
 8000a06:	f8d7 a008 	ldr.w	sl, [r7, #8]
 8000a0a:	e69f      	b.n	800074c <_malloc_r+0x2a0>
 8000a0c:	f240 5354 	movw	r3, #1364	@ 0x554
 8000a10:	429a      	cmp	r2, r3
 8000a12:	d80c      	bhi.n	8000a2e <_malloc_r+0x582>
 8000a14:	ea4f 429c 	mov.w	r2, ip, lsr #18
 8000a18:	f102 037d 	add.w	r3, r2, #125	@ 0x7d
 8000a1c:	00db      	lsls	r3, r3, #3
 8000a1e:	327c      	adds	r2, #124	@ 0x7c
 8000a20:	e6db      	b.n	80007da <_malloc_r+0x32e>
 8000a22:	f44f 737e 	mov.w	r3, #1016	@ 0x3f8
 8000a26:	207f      	movs	r0, #127	@ 0x7f
 8000a28:	f04f 0e7e 	mov.w	lr, #126	@ 0x7e
 8000a2c:	e587      	b.n	800053e <_malloc_r+0x92>
 8000a2e:	f44f 737e 	mov.w	r3, #1016	@ 0x3f8
 8000a32:	227e      	movs	r2, #126	@ 0x7e
 8000a34:	e6d1      	b.n	80007da <_malloc_r+0x32e>
 8000a36:	687b      	ldr	r3, [r7, #4]
 8000a38:	e763      	b.n	8000902 <_malloc_r+0x456>
 8000a3a:	bf00      	nop

08000a3c <_sbrk_r>:
 8000a3c:	b538      	push	{r3, r4, r5, lr}
 8000a3e:	4d07      	ldr	r5, [pc, #28]	@ (8000a5c <_sbrk_r+0x20>)
 8000a40:	2200      	movs	r2, #0
 8000a42:	4604      	mov	r4, r0
 8000a44:	4608      	mov	r0, r1
 8000a46:	602a      	str	r2, [r5, #0]
 8000a48:	f002 fb7a 	bl	8003140 <_sbrk>
 8000a4c:	1c43      	adds	r3, r0, #1
 8000a4e:	d000      	beq.n	8000a52 <_sbrk_r+0x16>
 8000a50:	bd38      	pop	{r3, r4, r5, pc}
 8000a52:	682b      	ldr	r3, [r5, #0]
 8000a54:	2b00      	cmp	r3, #0
 8000a56:	d0fb      	beq.n	8000a50 <_sbrk_r+0x14>
 8000a58:	6023      	str	r3, [r4, #0]
 8000a5a:	bd38      	pop	{r3, r4, r5, pc}
 8000a5c:	20000f28 	.word	0x20000f28

08000a60 <_malloc_trim_r>:
 8000a60:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
 8000a64:	4606      	mov	r6, r0
 8000a66:	2008      	movs	r0, #8
 8000a68:	4689      	mov	r9, r1
 8000a6a:	f000 f9db 	bl	8000e24 <sysconf>
 8000a6e:	f8df 809c 	ldr.w	r8, [pc, #156]	@ 8000b0c <_malloc_trim_r+0xac>
 8000a72:	4605      	mov	r5, r0
 8000a74:	4630      	mov	r0, r6
 8000a76:	f000 f9d1 	bl	8000e1c <__malloc_lock>
 8000a7a:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000a7e:	685f      	ldr	r7, [r3, #4]
 8000a80:	f027 0703 	bic.w	r7, r7, #3
 8000a84:	f1a7 0411 	sub.w	r4, r7, #17
 8000a88:	eba4 0409 	sub.w	r4, r4, r9
 8000a8c:	442c      	add	r4, r5
 8000a8e:	fbb4 f4f5 	udiv	r4, r4, r5
 8000a92:	3c01      	subs	r4, #1
 8000a94:	fb05 f404 	mul.w	r4, r5, r4
 8000a98:	42a5      	cmp	r5, r4
 8000a9a:	dc08      	bgt.n	8000aae <_malloc_trim_r+0x4e>
 8000a9c:	2100      	movs	r1, #0
 8000a9e:	4630      	mov	r0, r6
 8000aa0:	f7ff ffcc 	bl	8000a3c <_sbrk_r>
 8000aa4:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000aa8:	443b      	add	r3, r7
 8000aaa:	4298      	cmp	r0, r3
 8000aac:	d005      	beq.n	8000aba <_malloc_trim_r+0x5a>
 8000aae:	4630      	mov	r0, r6
 8000ab0:	f000 f9b6 	bl	8000e20 <__malloc_unlock>
 8000ab4:	2000      	movs	r0, #0
 8000ab6:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
 8000aba:	4261      	negs	r1, r4
 8000abc:	4630      	mov	r0, r6
 8000abe:	f7ff ffbd 	bl	8000a3c <_sbrk_r>
 8000ac2:	3001      	adds	r0, #1
 8000ac4:	d00f      	beq.n	8000ae6 <_malloc_trim_r+0x86>
 8000ac6:	4a12      	ldr	r2, [pc, #72]	@ (8000b10 <_malloc_trim_r+0xb0>)
 8000ac8:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000acc:	1b3f      	subs	r7, r7, r4
 8000ace:	f047 0701 	orr.w	r7, r7, #1
 8000ad2:	605f      	str	r7, [r3, #4]
 8000ad4:	6813      	ldr	r3, [r2, #0]
 8000ad6:	4630      	mov	r0, r6
 8000ad8:	1b1b      	subs	r3, r3, r4
 8000ada:	6013      	str	r3, [r2, #0]
 8000adc:	f000 f9a0 	bl	8000e20 <__malloc_unlock>
 8000ae0:	2001      	movs	r0, #1
 8000ae2:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
 8000ae6:	2100      	movs	r1, #0
 8000ae8:	4630      	mov	r0, r6
 8000aea:	f7ff ffa7 	bl	8000a3c <_sbrk_r>
 8000aee:	f8d8 2008 	ldr.w	r2, [r8, #8]
 8000af2:	1a83      	subs	r3, r0, r2
 8000af4:	2b0f      	cmp	r3, #15
 8000af6:	ddda      	ble.n	8000aae <_malloc_trim_r+0x4e>
 8000af8:	f043 0301 	orr.w	r3, r3, #1
 8000afc:	6053      	str	r3, [r2, #4]
 8000afe:	4b05      	ldr	r3, [pc, #20]	@ (8000b14 <_malloc_trim_r+0xb4>)
 8000b00:	4903      	ldr	r1, [pc, #12]	@ (8000b10 <_malloc_trim_r+0xb0>)
 8000b02:	681b      	ldr	r3, [r3, #0]
 8000b04:	1ac0      	subs	r0, r0, r3
 8000b06:	6008      	str	r0, [r1, #0]
 8000b08:	e7d1      	b.n	8000aae <_malloc_trim_r+0x4e>
 8000b0a:	bf00      	nop
 8000b0c:	20000128 	.word	0x20000128
 8000b10:	20000d64 	.word	0x20000d64
 8000b14:	20000530 	.word	0x20000530

08000b18 <_free_r>:
 8000b18:	2900      	cmp	r1, #0
 8000b1a:	d05b      	beq.n	8000bd4 <_free_r+0xbc>
 8000b1c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 8000b1e:	460c      	mov	r4, r1
 8000b20:	4607      	mov	r7, r0
 8000b22:	f000 f97b 	bl	8000e1c <__malloc_lock>
 8000b26:	f854 cc04 	ldr.w	ip, [r4, #-4]
 8000b2a:	4d74      	ldr	r5, [pc, #464]	@ (8000cfc <_free_r+0x1e4>)
 8000b2c:	f1a4 0208 	sub.w	r2, r4, #8
 8000b30:	f02c 0301 	bic.w	r3, ip, #1
 8000b34:	18d1      	adds	r1, r2, r3
 8000b36:	68a8      	ldr	r0, [r5, #8]
 8000b38:	684e      	ldr	r6, [r1, #4]
 8000b3a:	4288      	cmp	r0, r1
 8000b3c:	f026 0603 	bic.w	r6, r6, #3
 8000b40:	f00c 0e01 	and.w	lr, ip, #1
 8000b44:	d07e      	beq.n	8000c44 <_free_r+0x12c>
 8000b46:	1988      	adds	r0, r1, r6
 8000b48:	604e      	str	r6, [r1, #4]
 8000b4a:	6840      	ldr	r0, [r0, #4]
 8000b4c:	f000 0001 	and.w	r0, r0, #1
 8000b50:	f1be 0f00 	cmp.w	lr, #0
 8000b54:	d12f      	bne.n	8000bb6 <_free_r+0x9e>
 8000b56:	f854 4c08 	ldr.w	r4, [r4, #-8]
 8000b5a:	1b12      	subs	r2, r2, r4
 8000b5c:	4423      	add	r3, r4
 8000b5e:	6894      	ldr	r4, [r2, #8]
 8000b60:	f105 0c08 	add.w	ip, r5, #8
 8000b64:	4564      	cmp	r4, ip
 8000b66:	d062      	beq.n	8000c2e <_free_r+0x116>
 8000b68:	f8d2 e00c 	ldr.w	lr, [r2, #12]
 8000b6c:	f8c4 e00c 	str.w	lr, [r4, #12]
 8000b70:	f8ce 4008 	str.w	r4, [lr, #8]
 8000b74:	2800      	cmp	r0, #0
 8000b76:	d07f      	beq.n	8000c78 <_free_r+0x160>
 8000b78:	f043 0001 	orr.w	r0, r3, #1
 8000b7c:	6050      	str	r0, [r2, #4]
 8000b7e:	600b      	str	r3, [r1, #0]
 8000b80:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
 8000b84:	d22f      	bcs.n	8000be6 <_free_r+0xce>
 8000b86:	08d9      	lsrs	r1, r3, #3
 8000b88:	6868      	ldr	r0, [r5, #4]
 8000b8a:	095c      	lsrs	r4, r3, #5
 8000b8c:	3101      	adds	r1, #1
 8000b8e:	2301      	movs	r3, #1
 8000b90:	b209      	sxth	r1, r1
 8000b92:	40a3      	lsls	r3, r4
 8000b94:	4303      	orrs	r3, r0
 8000b96:	606b      	str	r3, [r5, #4]
 8000b98:	f855 0031 	ldr.w	r0, [r5, r1, lsl #3]
 8000b9c:	6090      	str	r0, [r2, #8]
 8000b9e:	eb05 03c1 	add.w	r3, r5, r1, lsl #3
 8000ba2:	3b08      	subs	r3, #8
 8000ba4:	60d3      	str	r3, [r2, #12]
 8000ba6:	f845 2031 	str.w	r2, [r5, r1, lsl #3]
 8000baa:	60c2      	str	r2, [r0, #12]
 8000bac:	4638      	mov	r0, r7
 8000bae:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
 8000bb2:	f000 b935 	b.w	8000e20 <__malloc_unlock>
 8000bb6:	b970      	cbnz	r0, 8000bd6 <_free_r+0xbe>
 8000bb8:	4433      	add	r3, r6
 8000bba:	f105 0c08 	add.w	ip, r5, #8
 8000bbe:	6888      	ldr	r0, [r1, #8]
 8000bc0:	4560      	cmp	r0, ip
 8000bc2:	f043 0401 	orr.w	r4, r3, #1
 8000bc6:	d071      	beq.n	8000cac <_free_r+0x194>
 8000bc8:	68c9      	ldr	r1, [r1, #12]
 8000bca:	60c1      	str	r1, [r0, #12]
 8000bcc:	6088      	str	r0, [r1, #8]
 8000bce:	6054      	str	r4, [r2, #4]
 8000bd0:	50d3      	str	r3, [r2, r3]
 8000bd2:	e7d5      	b.n	8000b80 <_free_r+0x68>
 8000bd4:	4770      	bx	lr
 8000bd6:	f04c 0101 	orr.w	r1, ip, #1
 8000bda:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
 8000bde:	f844 1c04 	str.w	r1, [r4, #-4]
 8000be2:	50d3      	str	r3, [r2, r3]
 8000be4:	d3cf      	bcc.n	8000b86 <_free_r+0x6e>
 8000be6:	f5b3 6f20 	cmp.w	r3, #2560	@ 0xa00
 8000bea:	ea4f 2053 	mov.w	r0, r3, lsr #9
 8000bee:	d245      	bcs.n	8000c7c <_free_r+0x164>
 8000bf0:	0998      	lsrs	r0, r3, #6
 8000bf2:	f100 0139 	add.w	r1, r0, #57	@ 0x39
 8000bf6:	b209      	sxth	r1, r1
 8000bf8:	f100 0438 	add.w	r4, r0, #56	@ 0x38
 8000bfc:	00c9      	lsls	r1, r1, #3
 8000bfe:	1868      	adds	r0, r5, r1
 8000c00:	5869      	ldr	r1, [r5, r1]
 8000c02:	3808      	subs	r0, #8
 8000c04:	4288      	cmp	r0, r1
 8000c06:	d103      	bne.n	8000c10 <_free_r+0xf8>
 8000c08:	e057      	b.n	8000cba <_free_r+0x1a2>
 8000c0a:	6889      	ldr	r1, [r1, #8]
 8000c0c:	4288      	cmp	r0, r1
 8000c0e:	d004      	beq.n	8000c1a <_free_r+0x102>
 8000c10:	684c      	ldr	r4, [r1, #4]
 8000c12:	f024 0403 	bic.w	r4, r4, #3
 8000c16:	429c      	cmp	r4, r3
 8000c18:	d8f7      	bhi.n	8000c0a <_free_r+0xf2>
 8000c1a:	68c8      	ldr	r0, [r1, #12]
 8000c1c:	e9c2 1002 	strd	r1, r0, [r2, #8]
 8000c20:	6082      	str	r2, [r0, #8]
 8000c22:	4638      	mov	r0, r7
 8000c24:	60ca      	str	r2, [r1, #12]
 8000c26:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
 8000c2a:	f000 b8f9 	b.w	8000e20 <__malloc_unlock>
 8000c2e:	bb88      	cbnz	r0, 8000c94 <_free_r+0x17c>
 8000c30:	441e      	add	r6, r3
 8000c32:	e9d1 1302 	ldrd	r1, r3, [r1, #8]
 8000c36:	60cb      	str	r3, [r1, #12]
 8000c38:	6099      	str	r1, [r3, #8]
 8000c3a:	f046 0301 	orr.w	r3, r6, #1
 8000c3e:	6053      	str	r3, [r2, #4]
 8000c40:	5196      	str	r6, [r2, r6]
 8000c42:	e7b3      	b.n	8000bac <_free_r+0x94>
 8000c44:	441e      	add	r6, r3
 8000c46:	f1be 0f00 	cmp.w	lr, #0
 8000c4a:	d107      	bne.n	8000c5c <_free_r+0x144>
 8000c4c:	f854 3c08 	ldr.w	r3, [r4, #-8]
 8000c50:	1ad2      	subs	r2, r2, r3
 8000c52:	441e      	add	r6, r3
 8000c54:	e9d2 1302 	ldrd	r1, r3, [r2, #8]
 8000c58:	60cb      	str	r3, [r1, #12]
 8000c5a:	6099      	str	r1, [r3, #8]
 8000c5c:	f046 0301 	orr.w	r3, r6, #1
 8000c60:	6053      	str	r3, [r2, #4]
 8000c62:	4b27      	ldr	r3, [pc, #156]	@ (8000d00 <_free_r+0x1e8>)
 8000c64:	60aa      	str	r2, [r5, #8]
 8000c66:	681b      	ldr	r3, [r3, #0]
 8000c68:	42b3      	cmp	r3, r6
 8000c6a:	d89f      	bhi.n	8000bac <_free_r+0x94>
 8000c6c:	4b25      	ldr	r3, [pc, #148]	@ (8000d04 <_free_r+0x1ec>)
 8000c6e:	4638      	mov	r0, r7
 8000c70:	6819      	ldr	r1, [r3, #0]
 8000c72:	f7ff fef5 	bl	8000a60 <_malloc_trim_r>
 8000c76:	e799      	b.n	8000bac <_free_r+0x94>
 8000c78:	4433      	add	r3, r6
 8000c7a:	e7a0      	b.n	8000bbe <_free_r+0xa6>
 8000c7c:	2814      	cmp	r0, #20
 8000c7e:	d90e      	bls.n	8000c9e <_free_r+0x186>
 8000c80:	2854      	cmp	r0, #84	@ 0x54
 8000c82:	d821      	bhi.n	8000cc8 <_free_r+0x1b0>
 8000c84:	0b18      	lsrs	r0, r3, #12
 8000c86:	f100 016f 	add.w	r1, r0, #111	@ 0x6f
 8000c8a:	b209      	sxth	r1, r1
 8000c8c:	f100 046e 	add.w	r4, r0, #110	@ 0x6e
 8000c90:	00c9      	lsls	r1, r1, #3
 8000c92:	e7b4      	b.n	8000bfe <_free_r+0xe6>
 8000c94:	f043 0001 	orr.w	r0, r3, #1
 8000c98:	6050      	str	r0, [r2, #4]
 8000c9a:	600b      	str	r3, [r1, #0]
 8000c9c:	e786      	b.n	8000bac <_free_r+0x94>
 8000c9e:	f100 015c 	add.w	r1, r0, #92	@ 0x5c
 8000ca2:	b209      	sxth	r1, r1
 8000ca4:	f100 045b 	add.w	r4, r0, #91	@ 0x5b
 8000ca8:	00c9      	lsls	r1, r1, #3
 8000caa:	e7a8      	b.n	8000bfe <_free_r+0xe6>
 8000cac:	e9c5 2204 	strd	r2, r2, [r5, #16]
 8000cb0:	e9c2 cc02 	strd	ip, ip, [r2, #8]
 8000cb4:	6054      	str	r4, [r2, #4]
 8000cb6:	50d3      	str	r3, [r2, r3]
 8000cb8:	e778      	b.n	8000bac <_free_r+0x94>
 8000cba:	686e      	ldr	r6, [r5, #4]
 8000cbc:	10a4      	asrs	r4, r4, #2
 8000cbe:	2301      	movs	r3, #1
 8000cc0:	40a3      	lsls	r3, r4
 8000cc2:	4333      	orrs	r3, r6
 8000cc4:	606b      	str	r3, [r5, #4]
 8000cc6:	e7a9      	b.n	8000c1c <_free_r+0x104>
 8000cc8:	f5b0 7faa 	cmp.w	r0, #340	@ 0x154
 8000ccc:	d807      	bhi.n	8000cde <_free_r+0x1c6>
 8000cce:	0bd8      	lsrs	r0, r3, #15
 8000cd0:	f100 0178 	add.w	r1, r0, #120	@ 0x78
 8000cd4:	b209      	sxth	r1, r1
 8000cd6:	f100 0477 	add.w	r4, r0, #119	@ 0x77
 8000cda:	00c9      	lsls	r1, r1, #3
 8000cdc:	e78f      	b.n	8000bfe <_free_r+0xe6>
 8000cde:	f240 5154 	movw	r1, #1364	@ 0x554
 8000ce2:	4288      	cmp	r0, r1
 8000ce4:	d806      	bhi.n	8000cf4 <_free_r+0x1dc>
 8000ce6:	0c98      	lsrs	r0, r3, #18
 8000ce8:	f100 017d 	add.w	r1, r0, #125	@ 0x7d
 8000cec:	f100 047c 	add.w	r4, r0, #124	@ 0x7c
 8000cf0:	00c9      	lsls	r1, r1, #3
 8000cf2:	e784      	b.n	8000bfe <_free_r+0xe6>
 8000cf4:	f44f 717e 	mov.w	r1, #1016	@ 0x3f8
 8000cf8:	247e      	movs	r4, #126	@ 0x7e
 8000cfa:	e780      	b.n	8000bfe <_free_r+0xe6>
 8000cfc:	20000128 	.word	0x20000128
 8000d00:	20000534 	.word	0x20000534
 8000d04:	20000d60 	.word	0x20000d60

08000d08 <__call_exitprocs>:
 8000d08:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8000d0c:	4f29      	ldr	r7, [pc, #164]	@ (8000db4 <__call_exitprocs+0xac>)
 8000d0e:	b083      	sub	sp, #12
 8000d10:	683e      	ldr	r6, [r7, #0]
 8000d12:	9001      	str	r0, [sp, #4]
 8000d14:	b1b6      	cbz	r6, 8000d44 <__call_exitprocs+0x3c>
 8000d16:	468b      	mov	fp, r1
 8000d18:	f04f 0900 	mov.w	r9, #0
 8000d1c:	f04f 0801 	mov.w	r8, #1
 8000d20:	6874      	ldr	r4, [r6, #4]
 8000d22:	1e65      	subs	r5, r4, #1
 8000d24:	d40e      	bmi.n	8000d44 <__call_exitprocs+0x3c>
 8000d26:	3401      	adds	r4, #1
 8000d28:	eb06 0484 	add.w	r4, r6, r4, lsl #2
 8000d2c:	f1bb 0f00 	cmp.w	fp, #0
 8000d30:	d00b      	beq.n	8000d4a <__call_exitprocs+0x42>
 8000d32:	f8d4 3100 	ldr.w	r3, [r4, #256]	@ 0x100
 8000d36:	455b      	cmp	r3, fp
 8000d38:	d007      	beq.n	8000d4a <__call_exitprocs+0x42>
 8000d3a:	3d01      	subs	r5, #1
 8000d3c:	1c6a      	adds	r2, r5, #1
 8000d3e:	f1a4 0404 	sub.w	r4, r4, #4
 8000d42:	d1f6      	bne.n	8000d32 <__call_exitprocs+0x2a>
 8000d44:	b003      	add	sp, #12
 8000d46:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000d4a:	6873      	ldr	r3, [r6, #4]
 8000d4c:	6822      	ldr	r2, [r4, #0]
 8000d4e:	3b01      	subs	r3, #1
 8000d50:	42ab      	cmp	r3, r5
 8000d52:	bf0c      	ite	eq
 8000d54:	6075      	streq	r5, [r6, #4]
 8000d56:	f8c4 9000 	strne.w	r9, [r4]
 8000d5a:	b17a      	cbz	r2, 8000d7c <__call_exitprocs+0x74>
 8000d5c:	f8d6 1188 	ldr.w	r1, [r6, #392]	@ 0x188
 8000d60:	f8d6 a004 	ldr.w	sl, [r6, #4]
 8000d64:	fa08 fc05 	lsl.w	ip, r8, r5
 8000d68:	ea1c 0f01 	tst.w	ip, r1
 8000d6c:	d10e      	bne.n	8000d8c <__call_exitprocs+0x84>
 8000d6e:	4790      	blx	r2
 8000d70:	6871      	ldr	r1, [r6, #4]
 8000d72:	683a      	ldr	r2, [r7, #0]
 8000d74:	4551      	cmp	r1, sl
 8000d76:	d116      	bne.n	8000da6 <__call_exitprocs+0x9e>
 8000d78:	42b2      	cmp	r2, r6
 8000d7a:	d114      	bne.n	8000da6 <__call_exitprocs+0x9e>
 8000d7c:	3d01      	subs	r5, #1
 8000d7e:	1c6b      	adds	r3, r5, #1
 8000d80:	f1a4 0404 	sub.w	r4, r4, #4
 8000d84:	d1d2      	bne.n	8000d2c <__call_exitprocs+0x24>
 8000d86:	b003      	add	sp, #12
 8000d88:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000d8c:	f8d6 318c 	ldr.w	r3, [r6, #396]	@ 0x18c
 8000d90:	f8d4 1080 	ldr.w	r1, [r4, #128]	@ 0x80
 8000d94:	ea1c 0f03 	tst.w	ip, r3
 8000d98:	d109      	bne.n	8000dae <__call_exitprocs+0xa6>
 8000d9a:	9801      	ldr	r0, [sp, #4]
 8000d9c:	4790      	blx	r2
 8000d9e:	6871      	ldr	r1, [r6, #4]
 8000da0:	683a      	ldr	r2, [r7, #0]
 8000da2:	4551      	cmp	r1, sl
 8000da4:	d0e8      	beq.n	8000d78 <__call_exitprocs+0x70>
 8000da6:	2a00      	cmp	r2, #0
 8000da8:	d0cc      	beq.n	8000d44 <__call_exitprocs+0x3c>
 8000daa:	4616      	mov	r6, r2
 8000dac:	e7b8      	b.n	8000d20 <__call_exitprocs+0x18>
 8000dae:	4608      	mov	r0, r1
 8000db0:	4790      	blx	r2
 8000db2:	e7dd      	b.n	8000d70 <__call_exitprocs+0x68>
 8000db4:	20000d94 	.word	0x20000d94

08000db8 <__register_exitproc>:
 8000db8:	b470      	push	{r4, r5, r6}
 8000dba:	4d16      	ldr	r5, [pc, #88]	@ (8000e14 <__register_exitproc+0x5c>)
 8000dbc:	682c      	ldr	r4, [r5, #0]
 8000dbe:	b31c      	cbz	r4, 8000e08 <__register_exitproc+0x50>
 8000dc0:	6865      	ldr	r5, [r4, #4]
 8000dc2:	2d1f      	cmp	r5, #31
 8000dc4:	dc23      	bgt.n	8000e0e <__register_exitproc+0x56>
 8000dc6:	b938      	cbnz	r0, 8000dd8 <__register_exitproc+0x20>
 8000dc8:	1cab      	adds	r3, r5, #2
 8000dca:	3501      	adds	r5, #1
 8000dcc:	6065      	str	r5, [r4, #4]
 8000dce:	f844 1023 	str.w	r1, [r4, r3, lsl #2]
 8000dd2:	2000      	movs	r0, #0
 8000dd4:	bc70      	pop	{r4, r5, r6}
 8000dd6:	4770      	bx	lr
 8000dd8:	eb04 0c85 	add.w	ip, r4, r5, lsl #2
 8000ddc:	2802      	cmp	r0, #2
 8000dde:	f8cc 2088 	str.w	r2, [ip, #136]	@ 0x88
 8000de2:	f8d4 6188 	ldr.w	r6, [r4, #392]	@ 0x188
 8000de6:	f04f 0201 	mov.w	r2, #1
 8000dea:	fa02 f205 	lsl.w	r2, r2, r5
 8000dee:	ea46 0602 	orr.w	r6, r6, r2
 8000df2:	f8c4 6188 	str.w	r6, [r4, #392]	@ 0x188
 8000df6:	f8cc 3108 	str.w	r3, [ip, #264]	@ 0x108
 8000dfa:	d1e5      	bne.n	8000dc8 <__register_exitproc+0x10>
 8000dfc:	f8d4 318c 	ldr.w	r3, [r4, #396]	@ 0x18c
 8000e00:	4313      	orrs	r3, r2
 8000e02:	f8c4 318c 	str.w	r3, [r4, #396]	@ 0x18c
 8000e06:	e7df      	b.n	8000dc8 <__register_exitproc+0x10>
 8000e08:	4c03      	ldr	r4, [pc, #12]	@ (8000e18 <__register_exitproc+0x60>)
 8000e0a:	602c      	str	r4, [r5, #0]
 8000e0c:	e7d8      	b.n	8000dc0 <__register_exitproc+0x8>
 8000e0e:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 8000e12:	e7df      	b.n	8000dd4 <__register_exitproc+0x1c>
 8000e14:	20000d94 	.word	0x20000d94
 8000e18:	20000d98 	.word	0x20000d98

08000e1c <__malloc_lock>:
 8000e1c:	4770      	bx	lr
 8000e1e:	bf00      	nop

08000e20 <__malloc_unlock>:
 8000e20:	4770      	bx	lr
 8000e22:	bf00      	nop

08000e24 <sysconf>:
 8000e24:	2808      	cmp	r0, #8
 8000e26:	d102      	bne.n	8000e2e <sysconf+0xa>
 8000e28:	f44f 5080 	mov.w	r0, #4096	@ 0x1000
 8000e2c:	4770      	bx	lr
 8000e2e:	b508      	push	{r3, lr}
 8000e30:	f7ff fab0 	bl	8000394 <__errno>
 8000e34:	2316      	movs	r3, #22
 8000e36:	6003      	str	r3, [r0, #0]
 8000e38:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 8000e3c:	bd08      	pop	{r3, pc}
 8000e3e:	bf00      	nop

08000e40 <_exit>:
 8000e40:	e7fe      	b.n	8000e40 <_exit>
 8000e42:	bf00      	nop

08000e44 <identity>:
 8000e44:	b109      	cbz	r1, 8000e4a <identity+0x6>
 8000e46:	2001      	movs	r0, #1
 8000e48:	4770      	bx	lr
 8000e4a:	b530      	push	{r4, r5, lr}
 8000e4c:	4d0a      	ldr	r5, [pc, #40]	@ (8000e78 <identity+0x34>)
 8000e4e:	460c      	mov	r4, r1
 8000e50:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
 8000e52:	b087      	sub	sp, #28
 8000e54:	46ec      	mov	ip, sp
 8000e56:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 8000e5a:	e895 0003 	ldmia.w	r5, {r0, r1}
 8000e5e:	f84c 0b04 	str.w	r0, [ip], #4
 8000e62:	466a      	mov	r2, sp
 8000e64:	f88c 1000 	strb.w	r1, [ip]
 8000e68:	2069      	movs	r0, #105	@ 0x69
 8000e6a:	2115      	movs	r1, #21
 8000e6c:	f002 fb20 	bl	80034b0 <simpleserial_put>
 8000e70:	4620      	mov	r0, r4
 8000e72:	b007      	add	sp, #28
 8000e74:	bd30      	pop	{r4, r5, pc}
 8000e76:	bf00      	nop
 8000e78:	08003530 	.word	0x08003530

08000e7c <sample>:
 8000e7c:	2922      	cmp	r1, #34	@ 0x22
 8000e7e:	d001      	beq.n	8000e84 <sample+0x8>
 8000e80:	2001      	movs	r0, #1
 8000e82:	4770      	bx	lr
 8000e84:	b510      	push	{r4, lr}
 8000e86:	f44f 7200 	mov.w	r2, #512	@ 0x200
 8000e8a:	2100      	movs	r1, #0
 8000e8c:	4604      	mov	r4, r0
 8000e8e:	4813      	ldr	r0, [pc, #76]	@ (8000edc <sample+0x60>)
 8000e90:	f7ff faaa 	bl	80003e8 <memset>
 8000e94:	f001 fc08 	bl	80026a8 <trigger_high>
 8000e98:	4810      	ldr	r0, [pc, #64]	@ (8000edc <sample+0x60>)
 8000e9a:	4621      	mov	r1, r4
 8000e9c:	f000 f840 	bl	8000f20 <algorithmA0>
 8000ea0:	f001 fc0a 	bl	80026b8 <trigger_low>
 8000ea4:	490e      	ldr	r1, [pc, #56]	@ (8000ee0 <sample+0x64>)
 8000ea6:	f201 2302 	addw	r3, r1, #514	@ 0x202
 8000eaa:	f201 4002 	addw	r0, r1, #1026	@ 0x402
 8000eae:	f931 2f02 	ldrsh.w	r2, [r1, #2]!
 8000eb2:	701a      	strb	r2, [r3, #0]
 8000eb4:	f3c2 2207 	ubfx	r2, r2, #8, #8
 8000eb8:	705a      	strb	r2, [r3, #1]
 8000eba:	3302      	adds	r3, #2
 8000ebc:	4283      	cmp	r3, r0
 8000ebe:	d1f6      	bne.n	8000eae <sample+0x32>
 8000ec0:	4908      	ldr	r1, [pc, #32]	@ (8000ee4 <sample+0x68>)
 8000ec2:	f44f 7200 	mov.w	r2, #512	@ 0x200
 8000ec6:	1888      	adds	r0, r1, r2
 8000ec8:	f001 fb0e 	bl	80024e8 <sha3_256>
 8000ecc:	4a06      	ldr	r2, [pc, #24]	@ (8000ee8 <sample+0x6c>)
 8000ece:	2120      	movs	r1, #32
 8000ed0:	2072      	movs	r0, #114	@ 0x72
 8000ed2:	f002 faed 	bl	80034b0 <simpleserial_put>
 8000ed6:	2000      	movs	r0, #0
 8000ed8:	bd10      	pop	{r4, pc}
 8000eda:	bf00      	nop
 8000edc:	20000558 	.word	0x20000558
 8000ee0:	20000556 	.word	0x20000556
 8000ee4:	20000758 	.word	0x20000758
 8000ee8:	20000958 	.word	0x20000958

08000eec <main>:
 8000eec:	b508      	push	{r3, lr}
 8000eee:	f001 fb39 	bl	8002564 <platform_init>
 8000ef2:	f001 fb77 	bl	80025e4 <init_uart>
 8000ef6:	f001 fbb5 	bl	8002664 <trigger_setup>
 8000efa:	f002 fa11 	bl	8003320 <simpleserial_init>
 8000efe:	4a06      	ldr	r2, [pc, #24]	@ (8000f18 <main+0x2c>)
 8000f00:	2122      	movs	r1, #34	@ 0x22
 8000f02:	2070      	movs	r0, #112	@ 0x70
 8000f04:	f002 fa42 	bl	800338c <simpleserial_addcmd>
 8000f08:	4a04      	ldr	r2, [pc, #16]	@ (8000f1c <main+0x30>)
 8000f0a:	2100      	movs	r1, #0
 8000f0c:	2069      	movs	r0, #105	@ 0x69
 8000f0e:	f002 fa3d 	bl	800338c <simpleserial_addcmd>
 8000f12:	f002 fa57 	bl	80033c4 <simpleserial_get>
 8000f16:	e7fc      	b.n	8000f12 <main+0x26>
 8000f18:	08000e7d 	.word	0x08000e7d
 8000f1c:	08000e45 	.word	0x08000e45

08000f20 <algorithmA0>:
 8000f20:	b570      	push	{r4, r5, r6, lr}
 8000f22:	b082      	sub	sp, #8
 8000f24:	460c      	mov	r4, r1
 8000f26:	4606      	mov	r6, r0
 8000f28:	a801      	add	r0, sp, #4
 8000f2a:	f001 fa8b 	bl	8002444 <shake128_inc_init>
 8000f2e:	4621      	mov	r1, r4
 8000f30:	2222      	movs	r2, #34	@ 0x22
 8000f32:	a801      	add	r0, sp, #4
 8000f34:	f001 fa9a 	bl	800246c <shake128_inc_absorb>
 8000f38:	a801      	add	r0, sp, #4
 8000f3a:	f001 fa9d 	bl	8002478 <shake128_inc_finalize>
 8000f3e:	f44f 758c 	mov.w	r5, #280	@ 0x118
 8000f42:	2400      	movs	r4, #0
 8000f44:	e00a      	b.n	8000f5c <algorithmA0+0x3c>
 8000f46:	f5b3 6f50 	cmp.w	r3, #3328	@ 0xd00
 8000f4a:	dc05      	bgt.n	8000f58 <algorithmA0+0x38>
 8000f4c:	f826 3014 	strh.w	r3, [r6, r4, lsl #1]
 8000f50:	3401      	adds	r4, #1
 8000f52:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
 8000f56:	d01e      	beq.n	8000f96 <algorithmA0+0x76>
 8000f58:	3d01      	subs	r5, #1
 8000f5a:	d01c      	beq.n	8000f96 <algorithmA0+0x76>
 8000f5c:	aa01      	add	r2, sp, #4
 8000f5e:	2103      	movs	r1, #3
 8000f60:	4668      	mov	r0, sp
 8000f62:	f001 fab9 	bl	80024d8 <shake128_inc_squeeze>
 8000f66:	f8bd 2000 	ldrh.w	r2, [sp]
 8000f6a:	f89d 3002 	ldrb.w	r3, [sp, #2]
 8000f6e:	f89d 1001 	ldrb.w	r1, [sp, #1]
 8000f72:	f3c2 020b 	ubfx	r2, r2, #0, #12
 8000f76:	011b      	lsls	r3, r3, #4
 8000f78:	f5b2 6f50 	cmp.w	r2, #3328	@ 0xd00
 8000f7c:	ea43 1311 	orr.w	r3, r3, r1, lsr #4
 8000f80:	f104 0101 	add.w	r1, r4, #1
 8000f84:	dcdf      	bgt.n	8000f46 <algorithmA0+0x26>
 8000f86:	f5b3 6f50 	cmp.w	r3, #3328	@ 0xd00
 8000f8a:	f826 2014 	strh.w	r2, [r6, r4, lsl #1]
 8000f8e:	dc07      	bgt.n	8000fa0 <algorithmA0+0x80>
 8000f90:	f5b1 7f80 	cmp.w	r1, #256	@ 0x100
 8000f94:	d106      	bne.n	8000fa4 <algorithmA0+0x84>
 8000f96:	a801      	add	r0, sp, #4
 8000f98:	f001 faa2 	bl	80024e0 <shake128_inc_ctx_release>
 8000f9c:	b002      	add	sp, #8
 8000f9e:	bd70      	pop	{r4, r5, r6, pc}
 8000fa0:	460c      	mov	r4, r1
 8000fa2:	e7d6      	b.n	8000f52 <algorithmA0+0x32>
 8000fa4:	460c      	mov	r4, r1
 8000fa6:	e7d1      	b.n	8000f4c <algorithmA0+0x2c>

08000fa8 <KeccakF1600_StatePermute>:
 8000fa8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8000fac:	b0bf      	sub	sp, #252	@ 0xfc
 8000fae:	6803      	ldr	r3, [r0, #0]
 8000fb0:	9304      	str	r3, [sp, #16]
 8000fb2:	6843      	ldr	r3, [r0, #4]
 8000fb4:	9305      	str	r3, [sp, #20]
 8000fb6:	6883      	ldr	r3, [r0, #8]
 8000fb8:	9306      	str	r3, [sp, #24]
 8000fba:	68c3      	ldr	r3, [r0, #12]
 8000fbc:	9303      	str	r3, [sp, #12]
 8000fbe:	4b35      	ldr	r3, [pc, #212]	@ (8001094 <KeccakF1600_StatePermute+0xec>)
 8000fc0:	9301      	str	r3, [sp, #4]
 8000fc2:	6903      	ldr	r3, [r0, #16]
 8000fc4:	9307      	str	r3, [sp, #28]
 8000fc6:	6943      	ldr	r3, [r0, #20]
 8000fc8:	9308      	str	r3, [sp, #32]
 8000fca:	6983      	ldr	r3, [r0, #24]
 8000fcc:	9309      	str	r3, [sp, #36]	@ 0x24
 8000fce:	69c3      	ldr	r3, [r0, #28]
 8000fd0:	930a      	str	r3, [sp, #40]	@ 0x28
 8000fd2:	6a03      	ldr	r3, [r0, #32]
 8000fd4:	930b      	str	r3, [sp, #44]	@ 0x2c
 8000fd6:	6a43      	ldr	r3, [r0, #36]	@ 0x24
 8000fd8:	930c      	str	r3, [sp, #48]	@ 0x30
 8000fda:	6a83      	ldr	r3, [r0, #40]	@ 0x28
 8000fdc:	930d      	str	r3, [sp, #52]	@ 0x34
 8000fde:	6ac3      	ldr	r3, [r0, #44]	@ 0x2c
 8000fe0:	930e      	str	r3, [sp, #56]	@ 0x38
 8000fe2:	6b03      	ldr	r3, [r0, #48]	@ 0x30
 8000fe4:	930f      	str	r3, [sp, #60]	@ 0x3c
 8000fe6:	6b43      	ldr	r3, [r0, #52]	@ 0x34
 8000fe8:	9310      	str	r3, [sp, #64]	@ 0x40
 8000fea:	6b83      	ldr	r3, [r0, #56]	@ 0x38
 8000fec:	9311      	str	r3, [sp, #68]	@ 0x44
 8000fee:	6bc3      	ldr	r3, [r0, #60]	@ 0x3c
 8000ff0:	9312      	str	r3, [sp, #72]	@ 0x48
 8000ff2:	6c03      	ldr	r3, [r0, #64]	@ 0x40
 8000ff4:	9313      	str	r3, [sp, #76]	@ 0x4c
 8000ff6:	6c43      	ldr	r3, [r0, #68]	@ 0x44
 8000ff8:	9314      	str	r3, [sp, #80]	@ 0x50
 8000ffa:	6c83      	ldr	r3, [r0, #72]	@ 0x48
 8000ffc:	9315      	str	r3, [sp, #84]	@ 0x54
 8000ffe:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
 8001000:	9316      	str	r3, [sp, #88]	@ 0x58
 8001002:	e9d0 9314 	ldrd	r9, r3, [r0, #80]	@ 0x50
 8001006:	9317      	str	r3, [sp, #92]	@ 0x5c
 8001008:	6d83      	ldr	r3, [r0, #88]	@ 0x58
 800100a:	9318      	str	r3, [sp, #96]	@ 0x60
 800100c:	6dc3      	ldr	r3, [r0, #92]	@ 0x5c
 800100e:	9319      	str	r3, [sp, #100]	@ 0x64
 8001010:	6e03      	ldr	r3, [r0, #96]	@ 0x60
 8001012:	931a      	str	r3, [sp, #104]	@ 0x68
 8001014:	6e43      	ldr	r3, [r0, #100]	@ 0x64
 8001016:	931b      	str	r3, [sp, #108]	@ 0x6c
 8001018:	6e83      	ldr	r3, [r0, #104]	@ 0x68
 800101a:	931c      	str	r3, [sp, #112]	@ 0x70
 800101c:	6ec3      	ldr	r3, [r0, #108]	@ 0x6c
 800101e:	931d      	str	r3, [sp, #116]	@ 0x74
 8001020:	6f03      	ldr	r3, [r0, #112]	@ 0x70
 8001022:	931e      	str	r3, [sp, #120]	@ 0x78
 8001024:	6f43      	ldr	r3, [r0, #116]	@ 0x74
 8001026:	931f      	str	r3, [sp, #124]	@ 0x7c
 8001028:	6f83      	ldr	r3, [r0, #120]	@ 0x78
 800102a:	9320      	str	r3, [sp, #128]	@ 0x80
 800102c:	6fc3      	ldr	r3, [r0, #124]	@ 0x7c
 800102e:	9321      	str	r3, [sp, #132]	@ 0x84
 8001030:	f8d0 3080 	ldr.w	r3, [r0, #128]	@ 0x80
 8001034:	9322      	str	r3, [sp, #136]	@ 0x88
 8001036:	f8d0 3084 	ldr.w	r3, [r0, #132]	@ 0x84
 800103a:	9323      	str	r3, [sp, #140]	@ 0x8c
 800103c:	f8d0 3088 	ldr.w	r3, [r0, #136]	@ 0x88
 8001040:	9324      	str	r3, [sp, #144]	@ 0x90
 8001042:	f8d0 308c 	ldr.w	r3, [r0, #140]	@ 0x8c
 8001046:	9325      	str	r3, [sp, #148]	@ 0x94
 8001048:	f8d0 3090 	ldr.w	r3, [r0, #144]	@ 0x90
 800104c:	9326      	str	r3, [sp, #152]	@ 0x98
 800104e:	f8d0 3094 	ldr.w	r3, [r0, #148]	@ 0x94
 8001052:	9327      	str	r3, [sp, #156]	@ 0x9c
 8001054:	f8d0 3098 	ldr.w	r3, [r0, #152]	@ 0x98
 8001058:	9328      	str	r3, [sp, #160]	@ 0xa0
 800105a:	f8d0 309c 	ldr.w	r3, [r0, #156]	@ 0x9c
 800105e:	9329      	str	r3, [sp, #164]	@ 0xa4
 8001060:	f8d0 30a8 	ldr.w	r3, [r0, #168]	@ 0xa8
 8001064:	932a      	str	r3, [sp, #168]	@ 0xa8
 8001066:	e9d0 832b 	ldrd	r8, r3, [r0, #172]	@ 0xac
 800106a:	932b      	str	r3, [sp, #172]	@ 0xac
 800106c:	f8d0 30b4 	ldr.w	r3, [r0, #180]	@ 0xb4
 8001070:	932c      	str	r3, [sp, #176]	@ 0xb0
 8001072:	f8d0 30b8 	ldr.w	r3, [r0, #184]	@ 0xb8
 8001076:	932d      	str	r3, [sp, #180]	@ 0xb4
 8001078:	f8d0 30bc 	ldr.w	r3, [r0, #188]	@ 0xbc
 800107c:	932e      	str	r3, [sp, #184]	@ 0xb8
 800107e:	f8d0 30c0 	ldr.w	r3, [r0, #192]	@ 0xc0
 8001082:	e9d0 6a28 	ldrd	r6, sl, [r0, #160]	@ 0xa0
 8001086:	932f      	str	r3, [sp, #188]	@ 0xbc
 8001088:	f8d0 30c4 	ldr.w	r3, [r0, #196]	@ 0xc4
 800108c:	9330      	str	r3, [sp, #192]	@ 0xc0
 800108e:	903d      	str	r0, [sp, #244]	@ 0xf4
 8001090:	46cb      	mov	fp, r9
 8001092:	e001      	b.n	8001098 <KeccakF1600_StatePermute+0xf0>
 8001094:	08003548 	.word	0x08003548
 8001098:	9a0d      	ldr	r2, [sp, #52]	@ 0x34
 800109a:	9b04      	ldr	r3, [sp, #16]
 800109c:	9905      	ldr	r1, [sp, #20]
 800109e:	980e      	ldr	r0, [sp, #56]	@ 0x38
 80010a0:	9c06      	ldr	r4, [sp, #24]
 80010a2:	9d0f      	ldr	r5, [sp, #60]	@ 0x3c
 80010a4:	f8dd c060 	ldr.w	ip, [sp, #96]	@ 0x60
 80010a8:	4053      	eors	r3, r2
 80010aa:	9a20      	ldr	r2, [sp, #128]	@ 0x80
 80010ac:	ea83 030b 	eor.w	r3, r3, fp
 80010b0:	4053      	eors	r3, r2
 80010b2:	ea83 0706 	eor.w	r7, r3, r6
 80010b6:	ea81 0300 	eor.w	r3, r1, r0
 80010ba:	9917      	ldr	r1, [sp, #92]	@ 0x5c
 80010bc:	9821      	ldr	r0, [sp, #132]	@ 0x84
 80010be:	9733      	str	r7, [sp, #204]	@ 0xcc
 80010c0:	404b      	eors	r3, r1
 80010c2:	4043      	eors	r3, r0
 80010c4:	ea83 000a 	eor.w	r0, r3, sl
 80010c8:	ea84 0e05 	eor.w	lr, r4, r5
 80010cc:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 80010ce:	9d03      	ldr	r5, [sp, #12]
 80010d0:	9f10      	ldr	r7, [sp, #64]	@ 0x40
 80010d2:	9a23      	ldr	r2, [sp, #140]	@ 0x8c
 80010d4:	9c2a      	ldr	r4, [sp, #168]	@ 0xa8
 80010d6:	9907      	ldr	r1, [sp, #28]
 80010d8:	9034      	str	r0, [sp, #208]	@ 0xd0
 80010da:	ea8e 0e0c 	eor.w	lr, lr, ip
 80010de:	ea8e 0e03 	eor.w	lr, lr, r3
 80010e2:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 80010e4:	9811      	ldr	r0, [sp, #68]	@ 0x44
 80010e6:	ea85 0c07 	eor.w	ip, r5, r7
 80010ea:	ea8c 0c03 	eor.w	ip, ip, r3
 80010ee:	9f08      	ldr	r7, [sp, #32]
 80010f0:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 80010f2:	9d24      	ldr	r5, [sp, #144]	@ 0x90
 80010f4:	ea8c 0c02 	eor.w	ip, ip, r2
 80010f8:	9a12      	ldr	r2, [sp, #72]	@ 0x48
 80010fa:	ea8e 0e04 	eor.w	lr, lr, r4
 80010fe:	ea81 0400 	eor.w	r4, r1, r0
 8001102:	991b      	ldr	r1, [sp, #108]	@ 0x6c
 8001104:	9825      	ldr	r0, [sp, #148]	@ 0x94
 8001106:	405c      	eors	r4, r3
 8001108:	407a      	eors	r2, r7
 800110a:	9b2b      	ldr	r3, [sp, #172]	@ 0xac
 800110c:	9f09      	ldr	r7, [sp, #36]	@ 0x24
 800110e:	406c      	eors	r4, r5
 8001110:	404a      	eors	r2, r1
 8001112:	9d2c      	ldr	r5, [sp, #176]	@ 0xb0
 8001114:	9913      	ldr	r1, [sp, #76]	@ 0x4c
 8001116:	405c      	eors	r4, r3
 8001118:	4042      	eors	r2, r0
 800111a:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
 800111c:	406a      	eors	r2, r5
 800111e:	ea87 0501 	eor.w	r5, r7, r1
 8001122:	9926      	ldr	r1, [sp, #152]	@ 0x98
 8001124:	982d      	ldr	r0, [sp, #180]	@ 0xb4
 8001126:	9f0a      	ldr	r7, [sp, #40]	@ 0x28
 8001128:	f8dd 9050 	ldr.w	r9, [sp, #80]	@ 0x50
 800112c:	405d      	eors	r5, r3
 800112e:	404d      	eors	r5, r1
 8001130:	9b1d      	ldr	r3, [sp, #116]	@ 0x74
 8001132:	9927      	ldr	r1, [sp, #156]	@ 0x9c
 8001134:	4045      	eors	r5, r0
 8001136:	ea87 0009 	eor.w	r0, r7, r9
 800113a:	4058      	eors	r0, r3
 800113c:	9b2e      	ldr	r3, [sp, #184]	@ 0xb8
 800113e:	9f0b      	ldr	r7, [sp, #44]	@ 0x2c
 8001140:	f8dd 9054 	ldr.w	r9, [sp, #84]	@ 0x54
 8001144:	4048      	eors	r0, r1
 8001146:	4043      	eors	r3, r0
 8001148:	9302      	str	r3, [sp, #8]
 800114a:	9b1e      	ldr	r3, [sp, #120]	@ 0x78
 800114c:	ea87 0109 	eor.w	r1, r7, r9
 8001150:	4059      	eors	r1, r3
 8001152:	9b28      	ldr	r3, [sp, #160]	@ 0xa0
 8001154:	9f0c      	ldr	r7, [sp, #48]	@ 0x30
 8001156:	f8dd 9058 	ldr.w	r9, [sp, #88]	@ 0x58
 800115a:	4059      	eors	r1, r3
 800115c:	9b2f      	ldr	r3, [sp, #188]	@ 0xbc
 800115e:	ea8c 0c08 	eor.w	ip, ip, r8
 8001162:	4059      	eors	r1, r3
 8001164:	ea87 0309 	eor.w	r3, r7, r9
 8001168:	ea4f 094e 	mov.w	r9, lr, lsl #1
 800116c:	ea49 79dc 	orr.w	r9, r9, ip, lsr #31
 8001170:	ea89 0901 	eor.w	r9, r9, r1
 8001174:	ea89 0606 	eor.w	r6, r9, r6
 8001178:	9635      	str	r6, [sp, #212]	@ 0xd4
 800117a:	9e04      	ldr	r6, [sp, #16]
 800117c:	9f1f      	ldr	r7, [sp, #124]	@ 0x7c
 800117e:	ea89 0606 	eor.w	r6, r9, r6
 8001182:	9631      	str	r6, [sp, #196]	@ 0xc4
 8001184:	9e0d      	ldr	r6, [sp, #52]	@ 0x34
 8001186:	ea89 0606 	eor.w	r6, r9, r6
 800118a:	407b      	eors	r3, r7
 800118c:	9637      	str	r6, [sp, #220]	@ 0xdc
 800118e:	9f29      	ldr	r7, [sp, #164]	@ 0xa4
 8001190:	9e20      	ldr	r6, [sp, #128]	@ 0x80
 8001192:	407b      	eors	r3, r7
 8001194:	ea89 0606 	eor.w	r6, r9, r6
 8001198:	9f30      	ldr	r7, [sp, #192]	@ 0xc0
 800119a:	9632      	str	r6, [sp, #200]	@ 0xc8
 800119c:	ea4f 064c 	mov.w	r6, ip, lsl #1
 80011a0:	407b      	eors	r3, r7
 80011a2:	ea89 0b0b 	eor.w	fp, r9, fp
 80011a6:	ea46 76de 	orr.w	r6, r6, lr, lsr #31
 80011aa:	f8dd 905c 	ldr.w	r9, [sp, #92]	@ 0x5c
 80011ae:	405e      	eors	r6, r3
 80011b0:	ea86 0909 	eor.w	r9, r6, r9
 80011b4:	f8cd 905c 	str.w	r9, [sp, #92]	@ 0x5c
 80011b8:	ea86 090a 	eor.w	r9, r6, sl
 80011bc:	f8cd 90d8 	str.w	r9, [sp, #216]	@ 0xd8
 80011c0:	f8dd 9014 	ldr.w	r9, [sp, #20]
 80011c4:	f8dd a038 	ldr.w	sl, [sp, #56]	@ 0x38
 80011c8:	ea86 0909 	eor.w	r9, r6, r9
 80011cc:	f8cd 9034 	str.w	r9, [sp, #52]	@ 0x34
 80011d0:	ea86 090a 	eor.w	r9, r6, sl
 80011d4:	f8dd a084 	ldr.w	sl, [sp, #132]	@ 0x84
 80011d8:	f8cd 90e0 	str.w	r9, [sp, #224]	@ 0xe0
 80011dc:	ea86 060a 	eor.w	r6, r6, sl
 80011e0:	963a      	str	r6, [sp, #232]	@ 0xe8
 80011e2:	9f33      	ldr	r7, [sp, #204]	@ 0xcc
 80011e4:	f8dd 903c 	ldr.w	r9, [sp, #60]	@ 0x3c
 80011e8:	f8dd a018 	ldr.w	sl, [sp, #24]
 80011ec:	9834      	ldr	r0, [sp, #208]	@ 0xd0
 80011ee:	0066      	lsls	r6, r4, #1
 80011f0:	ea46 76d2 	orr.w	r6, r6, r2, lsr #31
 80011f4:	407e      	eors	r6, r7
 80011f6:	ea86 0909 	eor.w	r9, r6, r9
 80011fa:	f8cd 9014 	str.w	r9, [sp, #20]
 80011fe:	f8dd 9088 	ldr.w	r9, [sp, #136]	@ 0x88
 8001202:	ea86 0909 	eor.w	r9, r6, r9
 8001206:	f8cd 9038 	str.w	r9, [sp, #56]	@ 0x38
 800120a:	ea86 090a 	eor.w	r9, r6, sl
 800120e:	f8dd a060 	ldr.w	sl, [sp, #96]	@ 0x60
 8001212:	f8cd 9080 	str.w	r9, [sp, #128]	@ 0x80
 8001216:	ea86 0a0a 	eor.w	sl, r6, sl
 800121a:	f8cd a0cc 	str.w	sl, [sp, #204]	@ 0xcc
 800121e:	f8dd a0a8 	ldr.w	sl, [sp, #168]	@ 0xa8
 8001222:	f8dd 9040 	ldr.w	r9, [sp, #64]	@ 0x40
 8001226:	ea86 060a 	eor.w	r6, r6, sl
 800122a:	963b      	str	r6, [sp, #236]	@ 0xec
 800122c:	0056      	lsls	r6, r2, #1
 800122e:	f8dd a08c 	ldr.w	sl, [sp, #140]	@ 0x8c
 8001232:	ea46 76d4 	orr.w	r6, r6, r4, lsr #31
 8001236:	4046      	eors	r6, r0
 8001238:	ea86 0a0a 	eor.w	sl, r6, sl
 800123c:	f8cd a03c 	str.w	sl, [sp, #60]	@ 0x3c
 8001240:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001244:	ea86 0a0a 	eor.w	sl, r6, sl
 8001248:	ea86 0808 	eor.w	r8, r6, r8
 800124c:	f8cd a00c 	str.w	sl, [sp, #12]
 8001250:	f8dd a064 	ldr.w	sl, [sp, #100]	@ 0x64
 8001254:	f8cd 80f0 	str.w	r8, [sp, #240]	@ 0xf0
 8001258:	f8dd 8008 	ldr.w	r8, [sp, #8]
 800125c:	ea86 0909 	eor.w	r9, r6, r9
 8001260:	ea86 0a0a 	eor.w	sl, r6, sl
 8001264:	006e      	lsls	r6, r5, #1
 8001266:	ea46 76d8 	orr.w	r6, r6, r8, lsr #31
 800126a:	ea86 060e 	eor.w	r6, r6, lr
 800126e:	f8dd e0ac 	ldr.w	lr, [sp, #172]	@ 0xac
 8001272:	f8cd a0a8 	str.w	sl, [sp, #168]	@ 0xa8
 8001276:	f8dd a044 	ldr.w	sl, [sp, #68]	@ 0x44
 800127a:	f8dd 8068 	ldr.w	r8, [sp, #104]	@ 0x68
 800127e:	ea86 0e0e 	eor.w	lr, r6, lr
 8001282:	f8cd e060 	str.w	lr, [sp, #96]	@ 0x60
 8001286:	ea86 0e0a 	eor.w	lr, r6, sl
 800128a:	f8cd e068 	str.w	lr, [sp, #104]	@ 0x68
 800128e:	f8dd e090 	ldr.w	lr, [sp, #144]	@ 0x90
 8001292:	ea86 0e0e 	eor.w	lr, r6, lr
 8001296:	f8cd e0ac 	str.w	lr, [sp, #172]	@ 0xac
 800129a:	f8dd e01c 	ldr.w	lr, [sp, #28]
 800129e:	ea86 0808 	eor.w	r8, r6, r8
 80012a2:	ea86 0e0e 	eor.w	lr, r6, lr
 80012a6:	9e02      	ldr	r6, [sp, #8]
 80012a8:	f8cd e0d0 	str.w	lr, [sp, #208]	@ 0xd0
 80012ac:	0076      	lsls	r6, r6, #1
 80012ae:	ea46 76d5 	orr.w	r6, r6, r5, lsr #31
 80012b2:	ea86 060c 	eor.w	r6, r6, ip
 80012b6:	f8dd c06c 	ldr.w	ip, [sp, #108]	@ 0x6c
 80012ba:	f8dd e0b0 	ldr.w	lr, [sp, #176]	@ 0xb0
 80012be:	f8dd a048 	ldr.w	sl, [sp, #72]	@ 0x48
 80012c2:	ea86 0a0a 	eor.w	sl, r6, sl
 80012c6:	f8cd a010 	str.w	sl, [sp, #16]
 80012ca:	f8dd a094 	ldr.w	sl, [sp, #148]	@ 0x94
 80012ce:	ea86 0e0e 	eor.w	lr, r6, lr
 80012d2:	f8cd e064 	str.w	lr, [sp, #100]	@ 0x64
 80012d6:	ea86 0e0a 	eor.w	lr, r6, sl
 80012da:	f8cd e0b0 	str.w	lr, [sp, #176]	@ 0xb0
 80012de:	f8dd e020 	ldr.w	lr, [sp, #32]
 80012e2:	f8dd a028 	ldr.w	sl, [sp, #40]	@ 0x28
 80012e6:	ea86 0c0c 	eor.w	ip, r6, ip
 80012ea:	ea86 060e 	eor.w	r6, r6, lr
 80012ee:	9639      	str	r6, [sp, #228]	@ 0xe4
 80012f0:	004e      	lsls	r6, r1, #1
 80012f2:	ea46 76d3 	orr.w	r6, r6, r3, lsr #31
 80012f6:	4066      	eors	r6, r4
 80012f8:	9c26      	ldr	r4, [sp, #152]	@ 0x98
 80012fa:	005b      	lsls	r3, r3, #1
 80012fc:	ea86 0e04 	eor.w	lr, r6, r4
 8001300:	ea43 73d1 	orr.w	r3, r3, r1, lsr #31
 8001304:	9c27      	ldr	r4, [sp, #156]	@ 0x9c
 8001306:	4053      	eors	r3, r2
 8001308:	ea83 0204 	eor.w	r2, r3, r4
 800130c:	9207      	str	r2, [sp, #28]
 800130e:	9a09      	ldr	r2, [sp, #36]	@ 0x24
 8001310:	ea86 0402 	eor.w	r4, r6, r2
 8001314:	9a1c      	ldr	r2, [sp, #112]	@ 0x70
 8001316:	4072      	eors	r2, r6
 8001318:	921b      	str	r2, [sp, #108]	@ 0x6c
 800131a:	9a2d      	ldr	r2, [sp, #180]	@ 0xb4
 800131c:	ea83 010a 	eor.w	r1, r3, sl
 8001320:	f8dd a074 	ldr.w	sl, [sp, #116]	@ 0x74
 8001324:	4072      	eors	r2, r6
 8001326:	ea83 0a0a 	eor.w	sl, r3, sl
 800132a:	9226      	str	r2, [sp, #152]	@ 0x98
 800132c:	9a13      	ldr	r2, [sp, #76]	@ 0x4c
 800132e:	f8cd a070 	str.w	sl, [sp, #112]	@ 0x70
 8001332:	f8dd a0b8 	ldr.w	sl, [sp, #184]	@ 0xb8
 8001336:	4072      	eors	r2, r6
 8001338:	9222      	str	r2, [sp, #136]	@ 0x88
 800133a:	ea83 020a 	eor.w	r2, r3, sl
 800133e:	9227      	str	r2, [sp, #156]	@ 0x9c
 8001340:	9a14      	ldr	r2, [sp, #80]	@ 0x50
 8001342:	463e      	mov	r6, r7
 8001344:	405a      	eors	r2, r3
 8001346:	ea4f 0a47 	mov.w	sl, r7, lsl #1
 800134a:	9b02      	ldr	r3, [sp, #8]
 800134c:	922d      	str	r2, [sp, #180]	@ 0xb4
 800134e:	0047      	lsls	r7, r0, #1
 8001350:	9a16      	ldr	r2, [sp, #88]	@ 0x58
 8001352:	ea4a 7ad0 	orr.w	sl, sl, r0, lsr #31
 8001356:	ea47 77d6 	orr.w	r7, r7, r6, lsr #31
 800135a:	ea8a 0a05 	eor.w	sl, sl, r5
 800135e:	405f      	eors	r7, r3
 8001360:	9d2f      	ldr	r5, [sp, #188]	@ 0xbc
 8001362:	ea87 0302 	eor.w	r3, r7, r2
 8001366:	9a28      	ldr	r2, [sp, #160]	@ 0xa0
 8001368:	ea8a 0605 	eor.w	r6, sl, r5
 800136c:	9d30      	ldr	r5, [sp, #192]	@ 0xc0
 800136e:	ea8a 0202 	eor.w	r2, sl, r2
 8001372:	ea87 0005 	eor.w	r0, r7, r5
 8001376:	9214      	str	r2, [sp, #80]	@ 0x50
 8001378:	9d15      	ldr	r5, [sp, #84]	@ 0x54
 800137a:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 800137c:	407a      	eors	r2, r7
 800137e:	9215      	str	r2, [sp, #84]	@ 0x54
 8001380:	9a0b      	ldr	r2, [sp, #44]	@ 0x2c
 8001382:	ea8a 0202 	eor.w	r2, sl, r2
 8001386:	9224      	str	r2, [sp, #144]	@ 0x90
 8001388:	9a1e      	ldr	r2, [sp, #120]	@ 0x78
 800138a:	ea8a 0505 	eor.w	r5, sl, r5
 800138e:	ea8a 0a02 	eor.w	sl, sl, r2
 8001392:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
 8001394:	f8cd a08c 	str.w	sl, [sp, #140]	@ 0x8c
 8001398:	ea87 0a02 	eor.w	sl, r7, r2
 800139c:	9a1f      	ldr	r2, [sp, #124]	@ 0x7c
 800139e:	f8cd a094 	str.w	sl, [sp, #148]	@ 0x94
 80013a2:	f8dd a004 	ldr.w	sl, [sp, #4]
 80013a6:	4057      	eors	r7, r2
 80013a8:	9728      	str	r7, [sp, #160]	@ 0xa0
 80013aa:	9a31      	ldr	r2, [sp, #196]	@ 0xc4
 80013ac:	f8da 7000 	ldr.w	r7, [sl]
 80013b0:	4057      	eors	r7, r2
 80013b2:	9709      	str	r7, [sp, #36]	@ 0x24
 80013b4:	9a0d      	ldr	r2, [sp, #52]	@ 0x34
 80013b6:	f8da 7004 	ldr.w	r7, [sl, #4]
 80013ba:	4057      	eors	r7, r2
 80013bc:	9a05      	ldr	r2, [sp, #20]
 80013be:	970a      	str	r7, [sp, #40]	@ 0x28
 80013c0:	0d17      	lsrs	r7, r2, #20
 80013c2:	ea47 3709 	orr.w	r7, r7, r9, lsl #12
 80013c6:	ea4f 5919 	mov.w	r9, r9, lsr #20
 80013ca:	ea49 3902 	orr.w	r9, r9, r2, lsl #12
 80013ce:	f8cd 9018 	str.w	r9, [sp, #24]
 80013d2:	ea4f 3986 	mov.w	r9, r6, lsl #14
 80013d6:	ea49 4990 	orr.w	r9, r9, r0, lsr #18
 80013da:	0380      	lsls	r0, r0, #14
 80013dc:	ea40 4096 	orr.w	r0, r0, r6, lsr #18
 80013e0:	ea4f 5a58 	mov.w	sl, r8, lsr #21
 80013e4:	0726      	lsls	r6, r4, #28
 80013e6:	ea4a 2acc 	orr.w	sl, sl, ip, lsl #11
 80013ea:	ea46 1611 	orr.w	r6, r6, r1, lsr #4
 80013ee:	9a07      	ldr	r2, [sp, #28]
 80013f0:	900b      	str	r0, [sp, #44]	@ 0x2c
 80013f2:	ea4f 5c5c 	mov.w	ip, ip, lsr #21
 80013f6:	0709      	lsls	r1, r1, #28
 80013f8:	ea41 1014 	orr.w	r0, r1, r4, lsr #4
 80013fc:	ea4c 28c8 	orr.w	r8, ip, r8, lsl #11
 8001400:	052c      	lsls	r4, r5, #20
 8001402:	ea4f 5c4e 	mov.w	ip, lr, lsl #21
 8001406:	ea4c 2cd2 	orr.w	ip, ip, r2, lsr #11
 800140a:	ea44 3413 	orr.w	r4, r4, r3, lsr #12
 800140e:	0552      	lsls	r2, r2, #21
 8001410:	051b      	lsls	r3, r3, #20
 8001412:	ea42 22de 	orr.w	r2, r2, lr, lsr #11
 8001416:	ea43 3e15 	orr.w	lr, r3, r5, lsr #12
 800141a:	9d17      	ldr	r5, [sp, #92]	@ 0x5c
 800141c:	f8cd e048 	str.w	lr, [sp, #72]	@ 0x48
 8001420:	f8dd e03c 	ldr.w	lr, [sp, #60]	@ 0x3c
 8001424:	f8cd 8020 	str.w	r8, [sp, #32]
 8001428:	00eb      	lsls	r3, r5, #3
 800142a:	ea4f 08cb 	mov.w	r8, fp, lsl #3
 800142e:	ea48 7855 	orr.w	r8, r8, r5, lsr #29
 8001432:	990e      	ldr	r1, [sp, #56]	@ 0x38
 8001434:	9410      	str	r4, [sp, #64]	@ 0x40
 8001436:	ea43 755b 	orr.w	r5, r3, fp, lsr #29
 800143a:	4673      	mov	r3, lr
 800143c:	9c18      	ldr	r4, [sp, #96]	@ 0x60
 800143e:	9513      	str	r5, [sp, #76]	@ 0x4c
 8001440:	0cdb      	lsrs	r3, r3, #19
 8001442:	ea43 3341 	orr.w	r3, r3, r1, lsl #13
 8001446:	0ccd      	lsrs	r5, r1, #19
 8001448:	9919      	ldr	r1, [sp, #100]	@ 0x64
 800144a:	9011      	str	r0, [sp, #68]	@ 0x44
 800144c:	ea45 354e 	orr.w	r5, r5, lr, lsl #13
 8001450:	ea4f 0ed4 	mov.w	lr, r4, lsr #3
 8001454:	ea4e 7e41 	orr.w	lr, lr, r1, lsl #29
 8001458:	08c9      	lsrs	r1, r1, #3
 800145a:	ea41 7144 	orr.w	r1, r1, r4, lsl #29
 800145e:	9c20      	ldr	r4, [sp, #128]	@ 0x80
 8001460:	9803      	ldr	r0, [sp, #12]
 8001462:	ea4f 0b44 	mov.w	fp, r4, lsl #1
 8001466:	ea4b 70d0 	orr.w	r0, fp, r0, lsr #31
 800146a:	f8dd b00c 	ldr.w	fp, [sp, #12]
 800146e:	901e      	str	r0, [sp, #120]	@ 0x78
 8001470:	ea4f 0b4b 	mov.w	fp, fp, lsl #1
 8001474:	ea4b 7bd4 	orr.w	fp, fp, r4, lsr #31
 8001478:	9c1a      	ldr	r4, [sp, #104]	@ 0x68
 800147a:	9804      	ldr	r0, [sp, #16]
 800147c:	f8cd b07c 	str.w	fp, [sp, #124]	@ 0x7c
 8001480:	ea4f 1b84 	mov.w	fp, r4, lsl #6
 8001484:	ea4b 6090 	orr.w	r0, fp, r0, lsr #26
 8001488:	9002      	str	r0, [sp, #8]
 800148a:	9804      	ldr	r0, [sp, #16]
 800148c:	ea4f 1b80 	mov.w	fp, r0, lsl #6
 8001490:	ea4b 6094 	orr.w	r0, fp, r4, lsr #26
 8001494:	9c1b      	ldr	r4, [sp, #108]	@ 0x6c
 8001496:	9004      	str	r0, [sp, #16]
 8001498:	981c      	ldr	r0, [sp, #112]	@ 0x70
 800149a:	ea4f 6b44 	mov.w	fp, r4, lsl #25
 800149e:	ea4b 1bd0 	orr.w	fp, fp, r0, lsr #7
 80014a2:	f8cd b068 	str.w	fp, [sp, #104]	@ 0x68
 80014a6:	ea4f 6b40 	mov.w	fp, r0, lsl #25
 80014aa:	ea4b 10d4 	orr.w	r0, fp, r4, lsr #7
 80014ae:	9c14      	ldr	r4, [sp, #80]	@ 0x50
 80014b0:	901b      	str	r0, [sp, #108]	@ 0x6c
 80014b2:	9815      	ldr	r0, [sp, #84]	@ 0x54
 80014b4:	ea4f 2b04 	mov.w	fp, r4, lsl #8
 80014b8:	ea4b 6b10 	orr.w	fp, fp, r0, lsr #24
 80014bc:	f8cd b014 	str.w	fp, [sp, #20]
 80014c0:	ea4f 2b00 	mov.w	fp, r0, lsl #8
 80014c4:	ea4b 6014 	orr.w	r0, fp, r4, lsr #24
 80014c8:	9003      	str	r0, [sp, #12]
 80014ca:	9835      	ldr	r0, [sp, #212]	@ 0xd4
 80014cc:	9c36      	ldr	r4, [sp, #216]	@ 0xd8
 80014ce:	ea4f 4b80 	mov.w	fp, r0, lsl #18
 80014d2:	ea4b 3b94 	orr.w	fp, fp, r4, lsr #14
 80014d6:	f8cd b070 	str.w	fp, [sp, #112]	@ 0x70
 80014da:	ea4f 4b84 	mov.w	fp, r4, lsl #18
 80014de:	9c09      	ldr	r4, [sp, #36]	@ 0x24
 80014e0:	ea4b 3090 	orr.w	r0, fp, r0, lsr #14
 80014e4:	ea2a 0b07 	bic.w	fp, sl, r7
 80014e8:	ea84 040b 	eor.w	r4, r4, fp
 80014ec:	901d      	str	r0, [sp, #116]	@ 0x74
 80014ee:	f8dd b018 	ldr.w	fp, [sp, #24]
 80014f2:	9808      	ldr	r0, [sp, #32]
 80014f4:	9407      	str	r4, [sp, #28]
 80014f6:	9c0a      	ldr	r4, [sp, #40]	@ 0x28
 80014f8:	ea20 0b0b 	bic.w	fp, r0, fp
 80014fc:	ea84 040b 	eor.w	r4, r4, fp
 8001500:	ea2c 0b0a 	bic.w	fp, ip, sl
 8001504:	9408      	str	r4, [sp, #32]
 8001506:	ea8b 0407 	eor.w	r4, fp, r7
 800150a:	f8dd b0c4 	ldr.w	fp, [sp, #196]	@ 0xc4
 800150e:	9409      	str	r4, [sp, #36]	@ 0x24
 8001510:	ea27 070b 	bic.w	r7, r7, fp
 8001514:	ea2b 0b09 	bic.w	fp, fp, r9
 8001518:	ea8b 040c 	eor.w	r4, fp, ip
 800151c:	ea29 0c0c 	bic.w	ip, r9, ip
 8001520:	ea8c 0c0a 	eor.w	ip, ip, sl
 8001524:	f8cd c028 	str.w	ip, [sp, #40]	@ 0x28
 8001528:	ea87 0c09 	eor.w	ip, r7, r9
 800152c:	940c      	str	r4, [sp, #48]	@ 0x30
 800152e:	f8cd c038 	str.w	ip, [sp, #56]	@ 0x38
 8001532:	f8dd 9018 	ldr.w	r9, [sp, #24]
 8001536:	9c10      	ldr	r4, [sp, #64]	@ 0x40
 8001538:	f8dd b07c 	ldr.w	fp, [sp, #124]	@ 0x7c
 800153c:	ea22 0700 	bic.w	r7, r2, r0
 8001540:	ea87 0c09 	eor.w	ip, r7, r9
 8001544:	4682      	mov	sl, r0
 8001546:	f8cd c018 	str.w	ip, [sp, #24]
 800154a:	980b      	ldr	r0, [sp, #44]	@ 0x2c
 800154c:	f8dd c034 	ldr.w	ip, [sp, #52]	@ 0x34
 8001550:	ea29 070c 	bic.w	r7, r9, ip
 8001554:	ea2c 0c00 	bic.w	ip, ip, r0
 8001558:	ea8c 0c02 	eor.w	ip, ip, r2
 800155c:	ea20 0202 	bic.w	r2, r0, r2
 8001560:	ea82 090a 	eor.w	r9, r2, sl
 8001564:	4047      	eors	r7, r0
 8001566:	ea28 0204 	bic.w	r2, r8, r4
 800156a:	970f      	str	r7, [sp, #60]	@ 0x3c
 800156c:	ea82 0706 	eor.w	r7, r2, r6
 8001570:	f8cd c034 	str.w	ip, [sp, #52]	@ 0x34
 8001574:	9710      	str	r7, [sp, #64]	@ 0x40
 8001576:	e9dd 7c12 	ldrd	r7, ip, [sp, #72]	@ 0x48
 800157a:	9811      	ldr	r0, [sp, #68]	@ 0x44
 800157c:	f8cd 902c 	str.w	r9, [sp, #44]	@ 0x2c
 8001580:	ea2c 0207 	bic.w	r2, ip, r7
 8001584:	4042      	eors	r2, r0
 8001586:	9211      	str	r2, [sp, #68]	@ 0x44
 8001588:	ea25 0208 	bic.w	r2, r5, r8
 800158c:	ea82 0904 	eor.w	r9, r2, r4
 8001590:	ea24 0406 	bic.w	r4, r4, r6
 8001594:	ea26 060e 	bic.w	r6, r6, lr
 8001598:	ea86 0a05 	eor.w	sl, r6, r5
 800159c:	ea2e 0505 	bic.w	r5, lr, r5
 80015a0:	ea23 020c 	bic.w	r2, r3, ip
 80015a4:	ea85 0508 	eor.w	r5, r5, r8
 80015a8:	9e02      	ldr	r6, [sp, #8]
 80015aa:	f8dd 8078 	ldr.w	r8, [sp, #120]	@ 0x78
 80015ae:	9514      	str	r5, [sp, #80]	@ 0x50
 80015b0:	ea84 0e0e 	eor.w	lr, r4, lr
 80015b4:	ea82 0507 	eor.w	r5, r2, r7
 80015b8:	ea27 0200 	bic.w	r2, r7, r0
 80015bc:	ea20 0001 	bic.w	r0, r0, r1
 80015c0:	9f1c      	ldr	r7, [sp, #112]	@ 0x70
 80015c2:	f8cd e060 	str.w	lr, [sp, #96]	@ 0x60
 80015c6:	ea80 0e03 	eor.w	lr, r0, r3
 80015ca:	ea21 0303 	bic.w	r3, r1, r3
 80015ce:	ea83 0c0c 	eor.w	ip, r3, ip
 80015d2:	ea26 0308 	bic.w	r3, r6, r8
 80015d6:	9513      	str	r5, [sp, #76]	@ 0x4c
 80015d8:	ea83 0507 	eor.w	r5, r3, r7
 80015dc:	f8cd c054 	str.w	ip, [sp, #84]	@ 0x54
 80015e0:	9520      	str	r5, [sp, #128]	@ 0x80
 80015e2:	ea82 0c01 	eor.w	ip, r2, r1
 80015e6:	9d04      	ldr	r5, [sp, #16]
 80015e8:	f8cd c064 	str.w	ip, [sp, #100]	@ 0x64
 80015ec:	f8dd c074 	ldr.w	ip, [sp, #116]	@ 0x74
 80015f0:	9f25      	ldr	r7, [sp, #148]	@ 0x94
 80015f2:	f8cd 9048 	str.w	r9, [sp, #72]	@ 0x48
 80015f6:	ea25 030b 	bic.w	r3, r5, fp
 80015fa:	9d24      	ldr	r5, [sp, #144]	@ 0x90
 80015fc:	f8cd a058 	str.w	sl, [sp, #88]	@ 0x58
 8001600:	ea83 000c 	eor.w	r0, r3, ip
 8001604:	9b37      	ldr	r3, [sp, #220]	@ 0xdc
 8001606:	f8cd e05c 	str.w	lr, [sp, #92]	@ 0x5c
 800160a:	9021      	str	r0, [sp, #132]	@ 0x84
 800160c:	ea4f 6ec5 	mov.w	lr, r5, lsl #27
 8001610:	9938      	ldr	r1, [sp, #224]	@ 0xe0
 8001612:	f8dd 90cc 	ldr.w	r9, [sp, #204]	@ 0xcc
 8001616:	9c27      	ldr	r4, [sp, #156]	@ 0x9c
 8001618:	ea4e 1e57 	orr.w	lr, lr, r7, lsr #5
 800161c:	06f8      	lsls	r0, r7, #27
 800161e:	0f1f      	lsrs	r7, r3, #28
 8001620:	ea47 1701 	orr.w	r7, r7, r1, lsl #4
 8001624:	0f0a      	lsrs	r2, r1, #28
 8001626:	992a      	ldr	r1, [sp, #168]	@ 0xa8
 8001628:	ea40 1055 	orr.w	r0, r0, r5, lsr #5
 800162c:	028d      	lsls	r5, r1, #10
 800162e:	ea45 5599 	orr.w	r5, r5, r9, lsr #22
 8001632:	ea4f 2a89 	mov.w	sl, r9, lsl #10
 8001636:	f8dd 90ac 	ldr.w	r9, [sp, #172]	@ 0xac
 800163a:	ea4a 5a91 	orr.w	sl, sl, r1, lsr #22
 800163e:	992c      	ldr	r1, [sp, #176]	@ 0xb0
 8001640:	ea42 1203 	orr.w	r2, r2, r3, lsl #4
 8001644:	ea4f 3cc9 	mov.w	ip, r9, lsl #15
 8001648:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 800164a:	ea4c 4c51 	orr.w	ip, ip, r1, lsr #17
 800164e:	03c9      	lsls	r1, r1, #15
 8001650:	ea41 4159 	orr.w	r1, r1, r9, lsr #17
 8001654:	ea4f 2913 	mov.w	r9, r3, lsr #8
 8001658:	ea49 6904 	orr.w	r9, r9, r4, lsl #24
 800165c:	0a24      	lsrs	r4, r4, #8
 800165e:	ea44 6403 	orr.w	r4, r4, r3, lsl #24
 8001662:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 8001664:	ea23 0306 	bic.w	r3, r3, r6
 8001668:	9e1c      	ldr	r6, [sp, #112]	@ 0x70
 800166a:	ea83 0308 	eor.w	r3, r3, r8
 800166e:	931e      	str	r3, [sp, #120]	@ 0x78
 8001670:	ea28 0306 	bic.w	r3, r8, r6
 8001674:	f8dd 8014 	ldr.w	r8, [sp, #20]
 8001678:	ea26 0608 	bic.w	r6, r6, r8
 800167c:	f8dd 8068 	ldr.w	r8, [sp, #104]	@ 0x68
 8001680:	ea86 0608 	eor.w	r6, r6, r8
 8001684:	961c      	str	r6, [sp, #112]	@ 0x70
 8001686:	9e05      	ldr	r6, [sp, #20]
 8001688:	ea26 0608 	bic.w	r6, r6, r8
 800168c:	f8dd 8008 	ldr.w	r8, [sp, #8]
 8001690:	ea86 0808 	eor.w	r8, r6, r8
 8001694:	f8cd 8068 	str.w	r8, [sp, #104]	@ 0x68
 8001698:	f8dd 8014 	ldr.w	r8, [sp, #20]
 800169c:	9e1b      	ldr	r6, [sp, #108]	@ 0x6c
 800169e:	ea83 0808 	eor.w	r8, r3, r8
 80016a2:	f8cd 807c 	str.w	r8, [sp, #124]	@ 0x7c
 80016a6:	f8dd 8010 	ldr.w	r8, [sp, #16]
 80016aa:	ea26 0308 	bic.w	r3, r6, r8
 80016ae:	9e1d      	ldr	r6, [sp, #116]	@ 0x74
 80016b0:	f8dd 800c 	ldr.w	r8, [sp, #12]
 80016b4:	ea83 030b 	eor.w	r3, r3, fp
 80016b8:	9305      	str	r3, [sp, #20]
 80016ba:	ea2b 0306 	bic.w	r3, fp, r6
 80016be:	f8dd b06c 	ldr.w	fp, [sp, #108]	@ 0x6c
 80016c2:	ea26 0608 	bic.w	r6, r6, r8
 80016c6:	ea86 060b 	eor.w	r6, r6, fp
 80016ca:	961b      	str	r6, [sp, #108]	@ 0x6c
 80016cc:	ea28 060b 	bic.w	r6, r8, fp
 80016d0:	f8dd 8010 	ldr.w	r8, [sp, #16]
 80016d4:	ea86 0b08 	eor.w	fp, r6, r8
 80016d8:	9e34      	ldr	r6, [sp, #208]	@ 0xd0
 80016da:	f8dd 800c 	ldr.w	r8, [sp, #12]
 80016de:	f8cd b010 	str.w	fp, [sp, #16]
 80016e2:	f8dd b0e4 	ldr.w	fp, [sp, #228]	@ 0xe4
 80016e6:	ea83 0808 	eor.w	r8, r3, r8
 80016ea:	08b3      	lsrs	r3, r6, #2
 80016ec:	f8cd 8074 	str.w	r8, [sp, #116]	@ 0x74
 80016f0:	ea43 788b 	orr.w	r8, r3, fp, lsl #30
 80016f4:	465b      	mov	r3, fp
 80016f6:	089b      	lsrs	r3, r3, #2
 80016f8:	ea43 7686 	orr.w	r6, r3, r6, lsl #30
 80016fc:	f8cd 8008 	str.w	r8, [sp, #8]
 8001700:	962c      	str	r6, [sp, #176]	@ 0xb0
 8001702:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 8001704:	f8dd b0b4 	ldr.w	fp, [sp, #180]	@ 0xb4
 8001708:	0a5e      	lsrs	r6, r3, #9
 800170a:	ea46 56cb 	orr.w	r6, r6, fp, lsl #23
 800170e:	465b      	mov	r3, fp
 8001710:	f8dd b088 	ldr.w	fp, [sp, #136]	@ 0x88
 8001714:	0a5b      	lsrs	r3, r3, #9
 8001716:	ea43 58cb 	orr.w	r8, r3, fp, lsl #23
 800171a:	9b23      	ldr	r3, [sp, #140]	@ 0x8c
 800171c:	f8dd b0a0 	ldr.w	fp, [sp, #160]	@ 0xa0
 8001720:	f8cd 80b4 	str.w	r8, [sp, #180]	@ 0xb4
 8001724:	0e5b      	lsrs	r3, r3, #25
 8001726:	ea43 18cb 	orr.w	r8, r3, fp, lsl #7
 800172a:	465b      	mov	r3, fp
 800172c:	f8dd b08c 	ldr.w	fp, [sp, #140]	@ 0x8c
 8001730:	f8cd 800c 	str.w	r8, [sp, #12]
 8001734:	0e5b      	lsrs	r3, r3, #25
 8001736:	ea43 1bcb 	orr.w	fp, r3, fp, lsl #7
 800173a:	9b32      	ldr	r3, [sp, #200]	@ 0xc8
 800173c:	f8dd 80e8 	ldr.w	r8, [sp, #232]	@ 0xe8
 8001740:	f8cd b0b8 	str.w	fp, [sp, #184]	@ 0xb8
 8001744:	0ddb      	lsrs	r3, r3, #23
 8001746:	f8dd b0c8 	ldr.w	fp, [sp, #200]	@ 0xc8
 800174a:	ea43 2348 	orr.w	r3, r3, r8, lsl #9
 800174e:	ea4f 58d8 	mov.w	r8, r8, lsr #23
 8001752:	9330      	str	r3, [sp, #192]	@ 0xc0
 8001754:	ea48 234b 	orr.w	r3, r8, fp, lsl #9
 8001758:	932f      	str	r3, [sp, #188]	@ 0xbc
 800175a:	9b3b      	ldr	r3, [sp, #236]	@ 0xec
 800175c:	f8dd b0f0 	ldr.w	fp, [sp, #240]	@ 0xf0
 8001760:	ea4f 0883 	mov.w	r8, r3, lsl #2
 8001764:	ea48 789b 	orr.w	r8, r8, fp, lsr #30
 8001768:	ea4f 0b8b 	mov.w	fp, fp, lsl #2
 800176c:	ea4b 7b93 	orr.w	fp, fp, r3, lsr #30
 8001770:	f8cd b0d0 	str.w	fp, [sp, #208]	@ 0xd0
 8001774:	ea2a 0b07 	bic.w	fp, sl, r7
 8001778:	ea8b 0b0e 	eor.w	fp, fp, lr
 800177c:	465b      	mov	r3, fp
 800177e:	ea25 0b02 	bic.w	fp, r5, r2
 8001782:	ea8b 0b00 	eor.w	fp, fp, r0
 8001786:	f8cd b08c 	str.w	fp, [sp, #140]	@ 0x8c
 800178a:	ea2c 0b0a 	bic.w	fp, ip, sl
 800178e:	ea8b 0b07 	eor.w	fp, fp, r7
 8001792:	ea27 070e 	bic.w	r7, r7, lr
 8001796:	ea2e 0e09 	bic.w	lr, lr, r9
 800179a:	ea8e 0e0c 	eor.w	lr, lr, ip
 800179e:	ea29 0c0c 	bic.w	ip, r9, ip
 80017a2:	ea8c 0a0a 	eor.w	sl, ip, sl
 80017a6:	f8cd e0a0 	str.w	lr, [sp, #160]	@ 0xa0
 80017aa:	ea87 0e09 	eor.w	lr, r7, r9
 80017ae:	ea21 0705 	bic.w	r7, r1, r5
 80017b2:	f8cd a098 	str.w	sl, [sp, #152]	@ 0x98
 80017b6:	ea87 0a02 	eor.w	sl, r7, r2
 80017ba:	ea22 0200 	bic.w	r2, r2, r0
 80017be:	ea20 0004 	bic.w	r0, r0, r4
 80017c2:	4048      	eors	r0, r1
 80017c4:	ea24 0101 	bic.w	r1, r4, r1
 80017c8:	4069      	eors	r1, r5
 80017ca:	f8cd e0a8 	str.w	lr, [sp, #168]	@ 0xa8
 80017ce:	9d07      	ldr	r5, [sp, #28]
 80017d0:	f8dd e040 	ldr.w	lr, [sp, #64]	@ 0x40
 80017d4:	9127      	str	r1, [sp, #156]	@ 0x9c
 80017d6:	ea82 0104 	eor.w	r1, r2, r4
 80017da:	912b      	str	r1, [sp, #172]	@ 0xac
 80017dc:	991e      	ldr	r1, [sp, #120]	@ 0x78
 80017de:	f8dd 9020 	ldr.w	r9, [sp, #32]
 80017e2:	9f05      	ldr	r7, [sp, #20]
 80017e4:	9029      	str	r0, [sp, #164]	@ 0xa4
 80017e6:	ea85 0e0e 	eor.w	lr, r5, lr
 80017ea:	9d11      	ldr	r5, [sp, #68]	@ 0x44
 80017ec:	9322      	str	r3, [sp, #136]	@ 0x88
 80017ee:	ea8e 0e01 	eor.w	lr, lr, r1
 80017f2:	f8cd b090 	str.w	fp, [sp, #144]	@ 0x90
 80017f6:	f8dd b08c 	ldr.w	fp, [sp, #140]	@ 0x8c
 80017fa:	9909      	ldr	r1, [sp, #36]	@ 0x24
 80017fc:	9812      	ldr	r0, [sp, #72]	@ 0x48
 80017fe:	9a1a      	ldr	r2, [sp, #104]	@ 0x68
 8001800:	f8cd a094 	str.w	sl, [sp, #148]	@ 0x94
 8001804:	ea89 0c05 	eor.w	ip, r9, r5
 8001808:	ea8c 0c07 	eor.w	ip, ip, r7
 800180c:	ea81 0500 	eor.w	r5, r1, r0
 8001810:	9f13      	ldr	r7, [sp, #76]	@ 0x4c
 8001812:	9806      	ldr	r0, [sp, #24]
 8001814:	9924      	ldr	r1, [sp, #144]	@ 0x90
 8001816:	f8dd 9054 	ldr.w	r9, [sp, #84]	@ 0x54
 800181a:	ea8e 0e03 	eor.w	lr, lr, r3
 800181e:	4055      	eors	r5, r2
 8001820:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 8001822:	ea80 0207 	eor.w	r2, r0, r7
 8001826:	9804      	ldr	r0, [sp, #16]
 8001828:	9f0a      	ldr	r7, [sp, #40]	@ 0x28
 800182a:	4042      	eors	r2, r0
 800182c:	ea87 0403 	eor.w	r4, r7, r3
 8001830:	9f1c      	ldr	r7, [sp, #112]	@ 0x70
 8001832:	981f      	ldr	r0, [sp, #124]	@ 0x7c
 8001834:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8001836:	404d      	eors	r5, r1
 8001838:	ea82 0a0a 	eor.w	sl, r2, sl
 800183c:	990b      	ldr	r1, [sp, #44]	@ 0x2c
 800183e:	9a26      	ldr	r2, [sp, #152]	@ 0x98
 8001840:	407c      	eors	r4, r7
 8001842:	4054      	eors	r4, r2
 8001844:	ea81 0209 	eor.w	r2, r1, r9
 8001848:	991b      	ldr	r1, [sp, #108]	@ 0x6c
 800184a:	f8dd 909c 	ldr.w	r9, [sp, #156]	@ 0x9c
 800184e:	9f0c      	ldr	r7, [sp, #48]	@ 0x30
 8001850:	9431      	str	r4, [sp, #196]	@ 0xc4
 8001852:	9c16      	ldr	r4, [sp, #88]	@ 0x58
 8001854:	404a      	eors	r2, r1
 8001856:	ea8c 0c0b 	eor.w	ip, ip, fp
 800185a:	4067      	eors	r7, r4
 800185c:	ea82 0b09 	eor.w	fp, r2, r9
 8001860:	9c17      	ldr	r4, [sp, #92]	@ 0x5c
 8001862:	9a28      	ldr	r2, [sp, #160]	@ 0xa0
 8001864:	f8dd 9034 	ldr.w	r9, [sp, #52]	@ 0x34
 8001868:	4047      	eors	r7, r0
 800186a:	981d      	ldr	r0, [sp, #116]	@ 0x74
 800186c:	4057      	eors	r7, r2
 800186e:	ea89 0104 	eor.w	r1, r9, r4
 8001872:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 8001874:	f8dd 9060 	ldr.w	r9, [sp, #96]	@ 0x60
 8001878:	9c20      	ldr	r4, [sp, #128]	@ 0x80
 800187a:	4041      	eors	r1, r0
 800187c:	4051      	eors	r1, r2
 800187e:	9a0e      	ldr	r2, [sp, #56]	@ 0x38
 8001880:	ea89 0004 	eor.w	r0, r9, r4
 8001884:	4050      	eors	r0, r2
 8001886:	9c21      	ldr	r4, [sp, #132]	@ 0x84
 8001888:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 800188a:	4050      	eors	r0, r2
 800188c:	ea83 0204 	eor.w	r2, r3, r4
 8001890:	9b0f      	ldr	r3, [sp, #60]	@ 0x3c
 8001892:	405a      	eors	r2, r3
 8001894:	9b2b      	ldr	r3, [sp, #172]	@ 0xac
 8001896:	4053      	eors	r3, r2
 8001898:	9a03      	ldr	r2, [sp, #12]
 800189a:	9336      	str	r3, [sp, #216]	@ 0xd8
 800189c:	9b02      	ldr	r3, [sp, #8]
 800189e:	ea22 0906 	bic.w	r9, r2, r6
 80018a2:	ea89 0903 	eor.w	r9, r9, r3
 80018a6:	ea8e 0e09 	eor.w	lr, lr, r9
 80018aa:	f8cd e0cc 	str.w	lr, [sp, #204]	@ 0xcc
 80018ae:	e9dd 4e2d 	ldrd	r4, lr, [sp, #180]	@ 0xb4
 80018b2:	ea2e 0e04 	bic.w	lr, lr, r4
 80018b6:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 80018b8:	ea8e 0e04 	eor.w	lr, lr, r4
 80018bc:	4614      	mov	r4, r2
 80018be:	9a30      	ldr	r2, [sp, #192]	@ 0xc0
 80018c0:	ea8c 0c0e 	eor.w	ip, ip, lr
 80018c4:	f8cd c0d4 	str.w	ip, [sp, #212]	@ 0xd4
 80018c8:	ea22 0c04 	bic.w	ip, r2, r4
 80018cc:	ea8c 0c06 	eor.w	ip, ip, r6
 80018d0:	ea26 0603 	bic.w	r6, r6, r3
 80018d4:	ea23 0308 	bic.w	r3, r3, r8
 80018d8:	4053      	eors	r3, r2
 80018da:	f8cd c0c0 	str.w	ip, [sp, #192]	@ 0xc0
 80018de:	469c      	mov	ip, r3
 80018e0:	ea28 0302 	bic.w	r3, r8, r2
 80018e4:	4063      	eors	r3, r4
 80018e6:	9c30      	ldr	r4, [sp, #192]	@ 0xc0
 80018e8:	9a34      	ldr	r2, [sp, #208]	@ 0xd0
 80018ea:	4065      	eors	r5, r4
 80018ec:	9c31      	ldr	r4, [sp, #196]	@ 0xc4
 80018ee:	f8cd c0c4 	str.w	ip, [sp, #196]	@ 0xc4
 80018f2:	405c      	eors	r4, r3
 80018f4:	ea86 0808 	eor.w	r8, r6, r8
 80018f8:	4646      	mov	r6, r8
 80018fa:	9402      	str	r4, [sp, #8]
 80018fc:	ea87 080c 	eor.w	r8, r7, ip
 8001900:	e9dd 472e 	ldrd	r4, r7, [sp, #184]	@ 0xb8
 8001904:	4070      	eors	r0, r6
 8001906:	9632      	str	r6, [sp, #200]	@ 0xc8
 8001908:	9e2d      	ldr	r6, [sp, #180]	@ 0xb4
 800190a:	f8cd 800c 	str.w	r8, [sp, #12]
 800190e:	ea27 0704 	bic.w	r7, r7, r4
 8001912:	4077      	eors	r7, r6
 8001914:	46b4      	mov	ip, r6
 8001916:	9e2c      	ldr	r6, [sp, #176]	@ 0xb0
 8001918:	ea2c 0806 	bic.w	r8, ip, r6
 800191c:	f8dd c0bc 	ldr.w	ip, [sp, #188]	@ 0xbc
 8001920:	ea26 0602 	bic.w	r6, r6, r2
 8001924:	ea86 060c 	eor.w	r6, r6, ip
 8001928:	962c      	str	r6, [sp, #176]	@ 0xb0
 800192a:	ea22 060c 	bic.w	r6, r2, ip
 800192e:	4066      	eors	r6, r4
 8001930:	ea88 0802 	eor.w	r8, r8, r2
 8001934:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 8001936:	9a36      	ldr	r2, [sp, #216]	@ 0xd8
 8001938:	ea8a 0a07 	eor.w	sl, sl, r7
 800193c:	46c4      	mov	ip, r8
 800193e:	ea8b 0806 	eor.w	r8, fp, r6
 8001942:	ea4f 0b45 	mov.w	fp, r5, lsl #1
 8001946:	4061      	eors	r1, r4
 8001948:	f8cd c0b4 	str.w	ip, [sp, #180]	@ 0xb4
 800194c:	4664      	mov	r4, ip
 800194e:	ea4b 7bda 	orr.w	fp, fp, sl, lsr #31
 8001952:	f8dd c078 	ldr.w	ip, [sp, #120]	@ 0x78
 8001956:	ea8b 0b00 	eor.w	fp, fp, r0
 800195a:	4062      	eors	r2, r4
 800195c:	ea8c 040b 	eor.w	r4, ip, fp
 8001960:	f8dd c040 	ldr.w	ip, [sp, #64]	@ 0x40
 8001964:	941e      	str	r4, [sp, #120]	@ 0x78
 8001966:	ea89 040b 	eor.w	r4, r9, fp
 800196a:	ea8c 090b 	eor.w	r9, ip, fp
 800196e:	942e      	str	r4, [sp, #184]	@ 0xb8
 8001970:	f8cd 90d0 	str.w	r9, [sp, #208]	@ 0xd0
 8001974:	f8dd c088 	ldr.w	ip, [sp, #136]	@ 0x88
 8001978:	9c02      	ldr	r4, [sp, #8]
 800197a:	ea8c 0c0b 	eor.w	ip, ip, fp
 800197e:	f8cd c0e4 	str.w	ip, [sp, #228]	@ 0xe4
 8001982:	f8dd c01c 	ldr.w	ip, [sp, #28]
 8001986:	ea4f 094a 	mov.w	r9, sl, lsl #1
 800198a:	ea8c 0c0b 	eor.w	ip, ip, fp
 800198e:	f8cd c01c 	str.w	ip, [sp, #28]
 8001992:	ea49 79d5 	orr.w	r9, r9, r5, lsr #31
 8001996:	f8dd c014 	ldr.w	ip, [sp, #20]
 800199a:	ea89 0902 	eor.w	r9, r9, r2
 800199e:	ea8c 0c09 	eor.w	ip, ip, r9
 80019a2:	ea8e 0e09 	eor.w	lr, lr, r9
 80019a6:	f8cd c088 	str.w	ip, [sp, #136]	@ 0x88
 80019aa:	f8dd c044 	ldr.w	ip, [sp, #68]	@ 0x44
 80019ae:	f8cd e0bc 	str.w	lr, [sp, #188]	@ 0xbc
 80019b2:	f8dd e08c 	ldr.w	lr, [sp, #140]	@ 0x8c
 80019b6:	ea8c 0c09 	eor.w	ip, ip, r9
 80019ba:	f8cd c0d8 	str.w	ip, [sp, #216]	@ 0xd8
 80019be:	ea8e 0c09 	eor.w	ip, lr, r9
 80019c2:	f8dd e020 	ldr.w	lr, [sp, #32]
 80019c6:	f8cd c0e8 	str.w	ip, [sp, #232]	@ 0xe8
 80019ca:	ea8e 0e09 	eor.w	lr, lr, r9
 80019ce:	f8dd c0cc 	ldr.w	ip, [sp, #204]	@ 0xcc
 80019d2:	f8cd e020 	str.w	lr, [sp, #32]
 80019d6:	ea4f 0e44 	mov.w	lr, r4, lsl #1
 80019da:	f8dd 9090 	ldr.w	r9, [sp, #144]	@ 0x90
 80019de:	ea4e 7ed8 	orr.w	lr, lr, r8, lsr #31
 80019e2:	ea8e 0e0c 	eor.w	lr, lr, ip
 80019e6:	ea89 090e 	eor.w	r9, r9, lr
 80019ea:	f8cd 908c 	str.w	r9, [sp, #140]	@ 0x8c
 80019ee:	f8dd 9024 	ldr.w	r9, [sp, #36]	@ 0x24
 80019f2:	f8dd c048 	ldr.w	ip, [sp, #72]	@ 0x48
 80019f6:	ea89 090e 	eor.w	r9, r9, lr
 80019fa:	ea8c 0b0e 	eor.w	fp, ip, lr
 80019fe:	f8cd 9014 	str.w	r9, [sp, #20]
 8001a02:	f8dd 90c0 	ldr.w	r9, [sp, #192]	@ 0xc0
 8001a06:	f8cd b040 	str.w	fp, [sp, #64]	@ 0x40
 8001a0a:	f8dd b068 	ldr.w	fp, [sp, #104]	@ 0x68
 8001a0e:	f8dd c04c 	ldr.w	ip, [sp, #76]	@ 0x4c
 8001a12:	ea89 090e 	eor.w	r9, r9, lr
 8001a16:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001a1a:	f8cd 90ec 	str.w	r9, [sp, #236]	@ 0xec
 8001a1e:	ea4f 0e48 	mov.w	lr, r8, lsl #1
 8001a22:	f8dd 90d4 	ldr.w	r9, [sp, #212]	@ 0xd4
 8001a26:	f8cd b0dc 	str.w	fp, [sp, #220]	@ 0xdc
 8001a2a:	ea4e 7ed4 	orr.w	lr, lr, r4, lsr #31
 8001a2e:	f8dd b094 	ldr.w	fp, [sp, #148]	@ 0x94
 8001a32:	ea8e 0e09 	eor.w	lr, lr, r9
 8001a36:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001a3a:	f8cd b024 	str.w	fp, [sp, #36]	@ 0x24
 8001a3e:	f8dd b018 	ldr.w	fp, [sp, #24]
 8001a42:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001a46:	f8cd b090 	str.w	fp, [sp, #144]	@ 0x90
 8001a4a:	f8dd b010 	ldr.w	fp, [sp, #16]
 8001a4e:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001a52:	f8cd b0c0 	str.w	fp, [sp, #192]	@ 0xc0
 8001a56:	9c03      	ldr	r4, [sp, #12]
 8001a58:	f8dd b028 	ldr.w	fp, [sp, #40]	@ 0x28
 8001a5c:	ea87 070e 	eor.w	r7, r7, lr
 8001a60:	973c      	str	r7, [sp, #240]	@ 0xf0
 8001a62:	0067      	lsls	r7, r4, #1
 8001a64:	ea47 77d1 	orr.w	r7, r7, r1, lsr #31
 8001a68:	406f      	eors	r7, r5
 8001a6a:	ea8c 0c0e 	eor.w	ip, ip, lr
 8001a6e:	f8dd e050 	ldr.w	lr, [sp, #80]	@ 0x50
 8001a72:	9d1c      	ldr	r5, [sp, #112]	@ 0x70
 8001a74:	407b      	eors	r3, r7
 8001a76:	9313      	str	r3, [sp, #76]	@ 0x4c
 8001a78:	ea8e 0307 	eor.w	r3, lr, r7
 8001a7c:	931c      	str	r3, [sp, #112]	@ 0x70
 8001a7e:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 8001a80:	f8dd e030 	ldr.w	lr, [sp, #48]	@ 0x30
 8001a84:	407b      	eors	r3, r7
 8001a86:	9326      	str	r3, [sp, #152]	@ 0x98
 8001a88:	004b      	lsls	r3, r1, #1
 8001a8a:	ea43 73d4 	orr.w	r3, r3, r4, lsr #31
 8001a8e:	ea83 030a 	eor.w	r3, r3, sl
 8001a92:	405e      	eors	r6, r3
 8001a94:	961a      	str	r6, [sp, #104]	@ 0x68
 8001a96:	9e15      	ldr	r6, [sp, #84]	@ 0x54
 8001a98:	f8dd a06c 	ldr.w	sl, [sp, #108]	@ 0x6c
 8001a9c:	9c02      	ldr	r4, [sp, #8]
 8001a9e:	405e      	eors	r6, r3
 8001aa0:	9615      	str	r6, [sp, #84]	@ 0x54
 8001aa2:	9e27      	ldr	r6, [sp, #156]	@ 0x9c
 8001aa4:	405e      	eors	r6, r3
 8001aa6:	9627      	str	r6, [sp, #156]	@ 0x9c
 8001aa8:	9e0b      	ldr	r6, [sp, #44]	@ 0x2c
 8001aaa:	407d      	eors	r5, r7
 8001aac:	ea8b 0707 	eor.w	r7, fp, r7
 8001ab0:	9735      	str	r7, [sp, #212]	@ 0xd4
 8001ab2:	ea8a 0703 	eor.w	r7, sl, r3
 8001ab6:	4073      	eors	r3, r6
 8001ab8:	9338      	str	r3, [sp, #224]	@ 0xe0
 8001aba:	0043      	lsls	r3, r0, #1
 8001abc:	f8dd a0a0 	ldr.w	sl, [sp, #160]	@ 0xa0
 8001ac0:	f8dd b034 	ldr.w	fp, [sp, #52]	@ 0x34
 8001ac4:	ea43 73d2 	orr.w	r3, r3, r2, lsr #31
 8001ac8:	0052      	lsls	r2, r2, #1
 8001aca:	4063      	eors	r3, r4
 8001acc:	ea42 72d0 	orr.w	r2, r2, r0, lsr #31
 8001ad0:	ea82 0208 	eor.w	r2, r2, r8
 8001ad4:	ea8a 0803 	eor.w	r8, sl, r3
 8001ad8:	f8dd a0a4 	ldr.w	sl, [sp, #164]	@ 0xa4
 8001adc:	981d      	ldr	r0, [sp, #116]	@ 0x74
 8001ade:	ea8a 0602 	eor.w	r6, sl, r2
 8001ae2:	f8dd a07c 	ldr.w	sl, [sp, #124]	@ 0x7c
 8001ae6:	ea8a 0a03 	eor.w	sl, sl, r3
 8001aea:	f8cd a02c 	str.w	sl, [sp, #44]	@ 0x2c
 8001aee:	ea80 0a02 	eor.w	sl, r0, r2
 8001af2:	f8cd a074 	str.w	sl, [sp, #116]	@ 0x74
 8001af6:	f8dd a0c4 	ldr.w	sl, [sp, #196]	@ 0xc4
 8001afa:	ea8b 0402 	eor.w	r4, fp, r2
 8001afe:	ea8a 0003 	eor.w	r0, sl, r3
 8001b02:	f8dd b058 	ldr.w	fp, [sp, #88]	@ 0x58
 8001b06:	f8dd a0b0 	ldr.w	sl, [sp, #176]	@ 0xb0
 8001b0a:	9028      	str	r0, [sp, #160]	@ 0xa0
 8001b0c:	ea8e 0e03 	eor.w	lr, lr, r3
 8001b10:	ea8b 0003 	eor.w	r0, fp, r3
 8001b14:	ea8a 0302 	eor.w	r3, sl, r2
 8001b18:	9031      	str	r0, [sp, #196]	@ 0xc4
 8001b1a:	9329      	str	r3, [sp, #164]	@ 0xa4
 8001b1c:	9833      	ldr	r0, [sp, #204]	@ 0xcc
 8001b1e:	f8dd b05c 	ldr.w	fp, [sp, #92]	@ 0x5c
 8001b22:	0043      	lsls	r3, r0, #1
 8001b24:	ea8b 0b02 	eor.w	fp, fp, r2
 8001b28:	9a03      	ldr	r2, [sp, #12]
 8001b2a:	f8cd b0b0 	str.w	fp, [sp, #176]	@ 0xb0
 8001b2e:	ea43 73d9 	orr.w	r3, r3, r9, lsr #31
 8001b32:	4053      	eors	r3, r2
 8001b34:	9a32      	ldr	r2, [sp, #200]	@ 0xc8
 8001b36:	ea4f 0b49 	mov.w	fp, r9, lsl #1
 8001b3a:	ea82 0a03 	eor.w	sl, r2, r3
 8001b3e:	ea4b 7bd0 	orr.w	fp, fp, r0, lsr #31
 8001b42:	9a2d      	ldr	r2, [sp, #180]	@ 0xb4
 8001b44:	9819      	ldr	r0, [sp, #100]	@ 0x64
 8001b46:	f8dd 9060 	ldr.w	r9, [sp, #96]	@ 0x60
 8001b4a:	ea8b 0b01 	eor.w	fp, fp, r1
 8001b4e:	ea82 020b 	eor.w	r2, r2, fp
 8001b52:	9202      	str	r2, [sp, #8]
 8001b54:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 8001b56:	405a      	eors	r2, r3
 8001b58:	921f      	str	r2, [sp, #124]	@ 0x7c
 8001b5a:	9a2b      	ldr	r2, [sp, #172]	@ 0xac
 8001b5c:	ea82 010b 	eor.w	r1, r2, fp
 8001b60:	9a0e      	ldr	r2, [sp, #56]	@ 0x38
 8001b62:	405a      	eors	r2, r3
 8001b64:	9225      	str	r2, [sp, #148]	@ 0x94
 8001b66:	9a20      	ldr	r2, [sp, #128]	@ 0x80
 8001b68:	405a      	eors	r2, r3
 8001b6a:	9232      	str	r2, [sp, #200]	@ 0xc8
 8001b6c:	9a0f      	ldr	r2, [sp, #60]	@ 0x3c
 8001b6e:	ea82 020b 	eor.w	r2, r2, fp
 8001b72:	9220      	str	r2, [sp, #128]	@ 0x80
 8001b74:	9a21      	ldr	r2, [sp, #132]	@ 0x84
 8001b76:	ea80 000b 	eor.w	r0, r0, fp
 8001b7a:	ea82 020b 	eor.w	r2, r2, fp
 8001b7e:	f8dd b004 	ldr.w	fp, [sp, #4]
 8001b82:	9233      	str	r2, [sp, #204]	@ 0xcc
 8001b84:	ea89 0903 	eor.w	r9, r9, r3
 8001b88:	9a07      	ldr	r2, [sp, #28]
 8001b8a:	f8db 3008 	ldr.w	r3, [fp, #8]
 8001b8e:	4053      	eors	r3, r2
 8001b90:	f10b 0210 	add.w	r2, fp, #16
 8001b94:	9304      	str	r3, [sp, #16]
 8001b96:	9201      	str	r2, [sp, #4]
 8001b98:	f8db 300c 	ldr.w	r3, [fp, #12]
 8001b9c:	9a10      	ldr	r2, [sp, #64]	@ 0x40
 8001b9e:	f8dd b020 	ldr.w	fp, [sp, #32]
 8001ba2:	ea8b 0b03 	eor.w	fp, fp, r3
 8001ba6:	0d13      	lsrs	r3, r2, #20
 8001ba8:	f8cd b018 	str.w	fp, [sp, #24]
 8001bac:	ea43 3b0c 	orr.w	fp, r3, ip, lsl #12
 8001bb0:	0d6b      	lsrs	r3, r5, #21
 8001bb2:	ea43 23c7 	orr.w	r3, r3, r7, lsl #11
 8001bb6:	9303      	str	r3, [sp, #12]
 8001bb8:	ea4f 5348 	mov.w	r3, r8, lsl #21
 8001bbc:	ea43 23d6 	orr.w	r3, r3, r6, lsr #11
 8001bc0:	ea4f 5c1c 	mov.w	ip, ip, lsr #20
 8001bc4:	0d7f      	lsrs	r7, r7, #21
 8001bc6:	0576      	lsls	r6, r6, #21
 8001bc8:	ea4c 3c02 	orr.w	ip, ip, r2, lsl #12
 8001bcc:	ea47 27c5 	orr.w	r7, r7, r5, lsl #11
 8001bd0:	ea46 26d8 	orr.w	r6, r6, r8, lsr #11
 8001bd4:	f8cd c028 	str.w	ip, [sp, #40]	@ 0x28
 8001bd8:	970c      	str	r7, [sp, #48]	@ 0x30
 8001bda:	960d      	str	r6, [sp, #52]	@ 0x34
 8001bdc:	9a02      	ldr	r2, [sp, #8]
 8001bde:	9f22      	ldr	r7, [sp, #136]	@ 0x88
 8001be0:	ea4f 760e 	mov.w	r6, lr, lsl #28
 8001be4:	ea46 1814 	orr.w	r8, r6, r4, lsr #4
 8001be8:	ea4f 358a 	mov.w	r5, sl, lsl #14
 8001bec:	0724      	lsls	r4, r4, #28
 8001bee:	ea45 4592 	orr.w	r5, r5, r2, lsr #18
 8001bf2:	ea44 1e1e 	orr.w	lr, r4, lr, lsr #4
 8001bf6:	0392      	lsls	r2, r2, #14
 8001bf8:	ea4f 5409 	mov.w	r4, r9, lsl #20
 8001bfc:	ea42 429a 	orr.w	r2, r2, sl, lsr #18
 8001c00:	ea44 3a10 	orr.w	sl, r4, r0, lsr #12
 8001c04:	9c1e      	ldr	r4, [sp, #120]	@ 0x78
 8001c06:	f8cd 8038 	str.w	r8, [sp, #56]	@ 0x38
 8001c0a:	0500      	lsls	r0, r0, #20
 8001c0c:	f8dd 8024 	ldr.w	r8, [sp, #36]	@ 0x24
 8001c10:	f8cd e03c 	str.w	lr, [sp, #60]	@ 0x3c
 8001c14:	ea40 3919 	orr.w	r9, r0, r9, lsr #12
 8001c18:	00e0      	lsls	r0, r4, #3
 8001c1a:	ea40 7657 	orr.w	r6, r0, r7, lsr #29
 8001c1e:	00f8      	lsls	r0, r7, #3
 8001c20:	ea40 7754 	orr.w	r7, r0, r4, lsr #29
 8001c24:	9c23      	ldr	r4, [sp, #140]	@ 0x8c
 8001c26:	9602      	str	r6, [sp, #8]
 8001c28:	4640      	mov	r0, r8
 8001c2a:	0cc0      	lsrs	r0, r0, #19
 8001c2c:	ea40 3e44 	orr.w	lr, r0, r4, lsl #13
 8001c30:	0ce6      	lsrs	r6, r4, #19
 8001c32:	9c13      	ldr	r4, [sp, #76]	@ 0x4c
 8001c34:	981a      	ldr	r0, [sp, #104]	@ 0x68
 8001c36:	9710      	str	r7, [sp, #64]	@ 0x40
 8001c38:	08e7      	lsrs	r7, r4, #3
 8001c3a:	ea47 7740 	orr.w	r7, r7, r0, lsl #29
 8001c3e:	08c0      	lsrs	r0, r0, #3
 8001c40:	ea40 7044 	orr.w	r0, r0, r4, lsl #29
 8001c44:	9c05      	ldr	r4, [sp, #20]
 8001c46:	f8cd 9048 	str.w	r9, [sp, #72]	@ 0x48
 8001c4a:	ea46 3648 	orr.w	r6, r6, r8, lsl #13
 8001c4e:	f8dd 8090 	ldr.w	r8, [sp, #144]	@ 0x90
 8001c52:	f8dd 9014 	ldr.w	r9, [sp, #20]
 8001c56:	9016      	str	r0, [sp, #88]	@ 0x58
 8001c58:	0064      	lsls	r4, r4, #1
 8001c5a:	ea44 70d8 	orr.w	r0, r4, r8, lsr #31
 8001c5e:	4644      	mov	r4, r8
 8001c60:	0064      	lsls	r4, r4, #1
 8001c62:	ea44 78d9 	orr.w	r8, r4, r9, lsr #31
 8001c66:	9017      	str	r0, [sp, #92]	@ 0x5c
 8001c68:	981c      	ldr	r0, [sp, #112]	@ 0x70
 8001c6a:	f8cd 8060 	str.w	r8, [sp, #96]	@ 0x60
 8001c6e:	f8dd 8054 	ldr.w	r8, [sp, #84]	@ 0x54
 8001c72:	f8cd e050 	str.w	lr, [sp, #80]	@ 0x50
 8001c76:	0184      	lsls	r4, r0, #6
 8001c78:	ea44 6998 	orr.w	r9, r4, r8, lsr #26
 8001c7c:	4644      	mov	r4, r8
 8001c7e:	01a4      	lsls	r4, r4, #6
 8001c80:	ea44 6c90 	orr.w	ip, r4, r0, lsr #26
 8001c84:	980b      	ldr	r0, [sp, #44]	@ 0x2c
 8001c86:	f8dd 8074 	ldr.w	r8, [sp, #116]	@ 0x74
 8001c8a:	f8cd 9068 	str.w	r9, [sp, #104]	@ 0x68
 8001c8e:	0644      	lsls	r4, r0, #25
 8001c90:	f8dd 907c 	ldr.w	r9, [sp, #124]	@ 0x7c
 8001c94:	f8cd c06c 	str.w	ip, [sp, #108]	@ 0x6c
 8001c98:	ea44 1ed8 	orr.w	lr, r4, r8, lsr #7
 8001c9c:	f8cd e070 	str.w	lr, [sp, #112]	@ 0x70
 8001ca0:	4644      	mov	r4, r8
 8001ca2:	f8dd e0bc 	ldr.w	lr, [sp, #188]	@ 0xbc
 8001ca6:	f8cd a044 	str.w	sl, [sp, #68]	@ 0x44
 8001caa:	ea4f 2c09 	mov.w	ip, r9, lsl #8
 8001cae:	ea4c 6c11 	orr.w	ip, ip, r1, lsr #24
 8001cb2:	0664      	lsls	r4, r4, #25
 8001cb4:	0209      	lsls	r1, r1, #8
 8001cb6:	ea44 18d0 	orr.w	r8, r4, r0, lsr #7
 8001cba:	ea41 6919 	orr.w	r9, r1, r9, lsr #24
 8001cbe:	9c2e      	ldr	r4, [sp, #184]	@ 0xb8
 8001cc0:	f8cd 9074 	str.w	r9, [sp, #116]	@ 0x74
 8001cc4:	4671      	mov	r1, lr
 8001cc6:	0489      	lsls	r1, r1, #18
 8001cc8:	ea4f 4984 	mov.w	r9, r4, lsl #18
 8001ccc:	ea41 3494 	orr.w	r4, r1, r4, lsr #14
 8001cd0:	f8cd 8064 	str.w	r8, [sp, #100]	@ 0x64
 8001cd4:	941f      	str	r4, [sp, #124]	@ 0x7c
 8001cd6:	9c25      	ldr	r4, [sp, #148]	@ 0x94
 8001cd8:	f8dd 8080 	ldr.w	r8, [sp, #128]	@ 0x80
 8001cdc:	9826      	ldr	r0, [sp, #152]	@ 0x98
 8001cde:	06e1      	lsls	r1, r4, #27
 8001ce0:	ea49 399e 	orr.w	r9, r9, lr, lsr #14
 8001ce4:	ea41 1e58 	orr.w	lr, r1, r8, lsr #5
 8001ce8:	4641      	mov	r1, r8
 8001cea:	06c9      	lsls	r1, r1, #27
 8001cec:	ea41 1454 	orr.w	r4, r1, r4, lsr #5
 8001cf0:	9421      	str	r4, [sp, #132]	@ 0x84
 8001cf2:	9c34      	ldr	r4, [sp, #208]	@ 0xd0
 8001cf4:	f8cd e080 	str.w	lr, [sp, #128]	@ 0x80
 8001cf8:	f8dd e0d8 	ldr.w	lr, [sp, #216]	@ 0xd8
 8001cfc:	0f21      	lsrs	r1, r4, #28
 8001cfe:	ea41 180e 	orr.w	r8, r1, lr, lsl #4
 8001d02:	4671      	mov	r1, lr
 8001d04:	0f09      	lsrs	r1, r1, #28
 8001d06:	ea41 1404 	orr.w	r4, r1, r4, lsl #4
 8001d0a:	9423      	str	r4, [sp, #140]	@ 0x8c
 8001d0c:	9c37      	ldr	r4, [sp, #220]	@ 0xdc
 8001d0e:	f8cd 8088 	str.w	r8, [sp, #136]	@ 0x88
 8001d12:	f8dd 80c0 	ldr.w	r8, [sp, #192]	@ 0xc0
 8001d16:	02a1      	lsls	r1, r4, #10
 8001d18:	ea41 5e98 	orr.w	lr, r1, r8, lsr #22
 8001d1c:	4641      	mov	r1, r8
 8001d1e:	0289      	lsls	r1, r1, #10
 8001d20:	ea41 5494 	orr.w	r4, r1, r4, lsr #22
 8001d24:	9927      	ldr	r1, [sp, #156]	@ 0x9c
 8001d26:	9425      	str	r4, [sp, #148]	@ 0x94
 8001d28:	03c4      	lsls	r4, r0, #15
 8001d2a:	ea44 4451 	orr.w	r4, r4, r1, lsr #17
 8001d2e:	03c9      	lsls	r1, r1, #15
 8001d30:	ea41 4150 	orr.w	r1, r1, r0, lsr #17
 8001d34:	f8cd e090 	str.w	lr, [sp, #144]	@ 0x90
 8001d38:	f8dd e0a0 	ldr.w	lr, [sp, #160]	@ 0xa0
 8001d3c:	9127      	str	r1, [sp, #156]	@ 0x9c
 8001d3e:	9929      	ldr	r1, [sp, #164]	@ 0xa4
 8001d40:	9835      	ldr	r0, [sp, #212]	@ 0xd4
 8001d42:	ea4f 281e 	mov.w	r8, lr, lsr #8
 8001d46:	ea48 6801 	orr.w	r8, r8, r1, lsl #24
 8001d4a:	0a09      	lsrs	r1, r1, #8
 8001d4c:	ea41 610e 	orr.w	r1, r1, lr, lsl #24
 8001d50:	f8dd e0e0 	ldr.w	lr, [sp, #224]	@ 0xe0
 8001d54:	9129      	str	r1, [sp, #164]	@ 0xa4
 8001d56:	0881      	lsrs	r1, r0, #2
 8001d58:	ea41 718e 	orr.w	r1, r1, lr, lsl #30
 8001d5c:	912a      	str	r1, [sp, #168]	@ 0xa8
 8001d5e:	4671      	mov	r1, lr
 8001d60:	0889      	lsrs	r1, r1, #2
 8001d62:	ea41 7180 	orr.w	r1, r1, r0, lsl #30
 8001d66:	9831      	ldr	r0, [sp, #196]	@ 0xc4
 8001d68:	f8dd e0b0 	ldr.w	lr, [sp, #176]	@ 0xb0
 8001d6c:	912b      	str	r1, [sp, #172]	@ 0xac
 8001d6e:	0a41      	lsrs	r1, r0, #9
 8001d70:	ea41 5ace 	orr.w	sl, r1, lr, lsl #23
 8001d74:	4671      	mov	r1, lr
 8001d76:	0a49      	lsrs	r1, r1, #9
 8001d78:	ea41 51c0 	orr.w	r1, r1, r0, lsl #23
 8001d7c:	9832      	ldr	r0, [sp, #200]	@ 0xc8
 8001d7e:	f8cd a0b0 	str.w	sl, [sp, #176]	@ 0xb0
 8001d82:	f8dd a0cc 	ldr.w	sl, [sp, #204]	@ 0xcc
 8001d86:	912d      	str	r1, [sp, #180]	@ 0xb4
 8001d88:	0e41      	lsrs	r1, r0, #25
 8001d8a:	ea41 1eca 	orr.w	lr, r1, sl, lsl #7
 8001d8e:	4651      	mov	r1, sl
 8001d90:	0e49      	lsrs	r1, r1, #25
 8001d92:	f8dd a0e8 	ldr.w	sl, [sp, #232]	@ 0xe8
 8001d96:	f8cd e0b8 	str.w	lr, [sp, #184]	@ 0xb8
 8001d9a:	ea41 11c0 	orr.w	r1, r1, r0, lsl #7
 8001d9e:	9839      	ldr	r0, [sp, #228]	@ 0xe4
 8001da0:	912f      	str	r1, [sp, #188]	@ 0xbc
 8001da2:	ea4f 5eda 	mov.w	lr, sl, lsr #23
 8001da6:	0dc1      	lsrs	r1, r0, #23
 8001da8:	ea41 214a 	orr.w	r1, r1, sl, lsl #9
 8001dac:	ea4e 2a40 	orr.w	sl, lr, r0, lsl #9
 8001db0:	f8cd a0c0 	str.w	sl, [sp, #192]	@ 0xc0
 8001db4:	983b      	ldr	r0, [sp, #236]	@ 0xec
 8001db6:	f8dd a0f0 	ldr.w	sl, [sp, #240]	@ 0xf0
 8001dba:	ea4f 0e80 	mov.w	lr, r0, lsl #2
 8001dbe:	ea4e 7e9a 	orr.w	lr, lr, sl, lsr #30
 8001dc2:	ea4f 0a8a 	mov.w	sl, sl, lsl #2
 8001dc6:	ea4a 7a90 	orr.w	sl, sl, r0, lsr #30
 8001dca:	f8cd a0c4 	str.w	sl, [sp, #196]	@ 0xc4
 8001dce:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001dd2:	9804      	ldr	r0, [sp, #16]
 8001dd4:	ea2a 0a0b 	bic.w	sl, sl, fp
 8001dd8:	ea80 000a 	eor.w	r0, r0, sl
 8001ddc:	9004      	str	r0, [sp, #16]
 8001dde:	f8dd a028 	ldr.w	sl, [sp, #40]	@ 0x28
 8001de2:	980c      	ldr	r0, [sp, #48]	@ 0x30
 8001de4:	ea20 0a0a 	bic.w	sl, r0, sl
 8001de8:	9806      	ldr	r0, [sp, #24]
 8001dea:	ea80 000a 	eor.w	r0, r0, sl
 8001dee:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001df2:	9005      	str	r0, [sp, #20]
 8001df4:	ea23 0a0a 	bic.w	sl, r3, sl
 8001df8:	ea8a 000b 	eor.w	r0, sl, fp
 8001dfc:	9006      	str	r0, [sp, #24]
 8001dfe:	9807      	ldr	r0, [sp, #28]
 8001e00:	ea2b 0a00 	bic.w	sl, fp, r0
 8001e04:	ea20 0b05 	bic.w	fp, r0, r5
 8001e08:	ea8b 0b03 	eor.w	fp, fp, r3
 8001e0c:	f8cd b024 	str.w	fp, [sp, #36]	@ 0x24
 8001e10:	f8dd b00c 	ldr.w	fp, [sp, #12]
 8001e14:	980e      	ldr	r0, [sp, #56]	@ 0x38
 8001e16:	ea25 0303 	bic.w	r3, r5, r3
 8001e1a:	ea83 030b 	eor.w	r3, r3, fp
 8001e1e:	9307      	str	r3, [sp, #28]
 8001e20:	ea8a 0305 	eor.w	r3, sl, r5
 8001e24:	e9dd ab0c 	ldrd	sl, fp, [sp, #48]	@ 0x30
 8001e28:	9d0a      	ldr	r5, [sp, #40]	@ 0x28
 8001e2a:	930b      	str	r3, [sp, #44]	@ 0x2c
 8001e2c:	ea2b 030a 	bic.w	r3, fp, sl
 8001e30:	406b      	eors	r3, r5
 8001e32:	9303      	str	r3, [sp, #12]
 8001e34:	9b08      	ldr	r3, [sp, #32]
 8001e36:	ea25 0503 	bic.w	r5, r5, r3
 8001e3a:	ea23 0302 	bic.w	r3, r3, r2
 8001e3e:	ea83 030b 	eor.w	r3, r3, fp
 8001e42:	930a      	str	r3, [sp, #40]	@ 0x28
 8001e44:	ea22 030b 	bic.w	r3, r2, fp
 8001e48:	ea83 030a 	eor.w	r3, r3, sl
 8001e4c:	9308      	str	r3, [sp, #32]
 8001e4e:	f8dd a044 	ldr.w	sl, [sp, #68]	@ 0x44
 8001e52:	f8dd b048 	ldr.w	fp, [sp, #72]	@ 0x48
 8001e56:	ea85 0302 	eor.w	r3, r5, r2
 8001e5a:	9a02      	ldr	r2, [sp, #8]
 8001e5c:	930c      	str	r3, [sp, #48]	@ 0x30
 8001e5e:	ea22 030a 	bic.w	r3, r2, sl
 8001e62:	4043      	eors	r3, r0
 8001e64:	930d      	str	r3, [sp, #52]	@ 0x34
 8001e66:	9b10      	ldr	r3, [sp, #64]	@ 0x40
 8001e68:	9d0f      	ldr	r5, [sp, #60]	@ 0x3c
 8001e6a:	ea23 030b 	bic.w	r3, r3, fp
 8001e6e:	406b      	eors	r3, r5
 8001e70:	930e      	str	r3, [sp, #56]	@ 0x38
 8001e72:	ea26 0302 	bic.w	r3, r6, r2
 8001e76:	ea83 030a 	eor.w	r3, r3, sl
 8001e7a:	ea20 0207 	bic.w	r2, r0, r7
 8001e7e:	930f      	str	r3, [sp, #60]	@ 0x3c
 8001e80:	ea2a 0300 	bic.w	r3, sl, r0
 8001e84:	9802      	ldr	r0, [sp, #8]
 8001e86:	f8dd a070 	ldr.w	sl, [sp, #112]	@ 0x70
 8001e8a:	4072      	eors	r2, r6
 8001e8c:	ea27 0606 	bic.w	r6, r7, r6
 8001e90:	9213      	str	r2, [sp, #76]	@ 0x4c
 8001e92:	ea86 0200 	eor.w	r2, r6, r0
 8001e96:	9e14      	ldr	r6, [sp, #80]	@ 0x50
 8001e98:	9810      	ldr	r0, [sp, #64]	@ 0x40
 8001e9a:	9211      	str	r2, [sp, #68]	@ 0x44
 8001e9c:	407b      	eors	r3, r7
 8001e9e:	9315      	str	r3, [sp, #84]	@ 0x54
 8001ea0:	9f16      	ldr	r7, [sp, #88]	@ 0x58
 8001ea2:	ea26 0300 	bic.w	r3, r6, r0
 8001ea6:	ea83 030b 	eor.w	r3, r3, fp
 8001eaa:	9310      	str	r3, [sp, #64]	@ 0x40
 8001eac:	ea25 0307 	bic.w	r3, r5, r7
 8001eb0:	4073      	eors	r3, r6
 8001eb2:	9314      	str	r3, [sp, #80]	@ 0x50
 8001eb4:	ea27 0306 	bic.w	r3, r7, r6
 8001eb8:	4043      	eors	r3, r0
 8001eba:	9e1a      	ldr	r6, [sp, #104]	@ 0x68
 8001ebc:	9312      	str	r3, [sp, #72]	@ 0x48
 8001ebe:	ea2b 0205 	bic.w	r2, fp, r5
 8001ec2:	463b      	mov	r3, r7
 8001ec4:	9817      	ldr	r0, [sp, #92]	@ 0x5c
 8001ec6:	9f1b      	ldr	r7, [sp, #108]	@ 0x6c
 8001ec8:	9d18      	ldr	r5, [sp, #96]	@ 0x60
 8001eca:	4053      	eors	r3, r2
 8001ecc:	9316      	str	r3, [sp, #88]	@ 0x58
 8001ece:	ea2a 0306 	bic.w	r3, sl, r6
 8001ed2:	ea83 0b00 	eor.w	fp, r3, r0
 8001ed6:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8001ed8:	ea23 0307 	bic.w	r3, r3, r7
 8001edc:	406b      	eors	r3, r5
 8001ede:	9317      	str	r3, [sp, #92]	@ 0x5c
 8001ee0:	ea2c 030a 	bic.w	r3, ip, sl
 8001ee4:	ea20 0209 	bic.w	r2, r0, r9
 8001ee8:	4073      	eors	r3, r6
 8001eea:	9318      	str	r3, [sp, #96]	@ 0x60
 8001eec:	ea26 0300 	bic.w	r3, r6, r0
 8001ef0:	ea82 060c 	eor.w	r6, r2, ip
 8001ef4:	ea29 0c0c 	bic.w	ip, r9, ip
 8001ef8:	961c      	str	r6, [sp, #112]	@ 0x70
 8001efa:	ea8c 060a 	eor.w	r6, ip, sl
 8001efe:	9819      	ldr	r0, [sp, #100]	@ 0x64
 8001f00:	961a      	str	r6, [sp, #104]	@ 0x68
 8001f02:	9e1d      	ldr	r6, [sp, #116]	@ 0x74
 8001f04:	f8dd c090 	ldr.w	ip, [sp, #144]	@ 0x90
 8001f08:	ea83 0309 	eor.w	r3, r3, r9
 8001f0c:	931e      	str	r3, [sp, #120]	@ 0x78
 8001f0e:	ea26 0300 	bic.w	r3, r6, r0
 8001f12:	407b      	eors	r3, r7
 8001f14:	9319      	str	r3, [sp, #100]	@ 0x64
 8001f16:	ea27 0305 	bic.w	r3, r7, r5
 8001f1a:	9f1f      	ldr	r7, [sp, #124]	@ 0x7c
 8001f1c:	ea25 0207 	bic.w	r2, r5, r7
 8001f20:	ea82 0906 	eor.w	r9, r2, r6
 8001f24:	ea27 0206 	bic.w	r2, r7, r6
 8001f28:	ea82 0600 	eor.w	r6, r2, r0
 8001f2c:	407b      	eors	r3, r7
 8001f2e:	961b      	str	r6, [sp, #108]	@ 0x6c
 8001f30:	9e22      	ldr	r6, [sp, #136]	@ 0x88
 8001f32:	f8cd 9074 	str.w	r9, [sp, #116]	@ 0x74
 8001f36:	931f      	str	r3, [sp, #124]	@ 0x7c
 8001f38:	9820      	ldr	r0, [sp, #128]	@ 0x80
 8001f3a:	9f23      	ldr	r7, [sp, #140]	@ 0x8c
 8001f3c:	f8dd 9094 	ldr.w	r9, [sp, #148]	@ 0x94
 8001f40:	9d21      	ldr	r5, [sp, #132]	@ 0x84
 8001f42:	ea2c 0306 	bic.w	r3, ip, r6
 8001f46:	4043      	eors	r3, r0
 8001f48:	9320      	str	r3, [sp, #128]	@ 0x80
 8001f4a:	ea29 0307 	bic.w	r3, r9, r7
 8001f4e:	406b      	eors	r3, r5
 8001f50:	9321      	str	r3, [sp, #132]	@ 0x84
 8001f52:	ea24 030c 	bic.w	r3, r4, ip
 8001f56:	4073      	eors	r3, r6
 8001f58:	ea20 0208 	bic.w	r2, r0, r8
 8001f5c:	9322      	str	r3, [sp, #136]	@ 0x88
 8001f5e:	ea26 0300 	bic.w	r3, r6, r0
 8001f62:	9827      	ldr	r0, [sp, #156]	@ 0x9c
 8001f64:	ea82 0604 	eor.w	r6, r2, r4
 8001f68:	ea83 0308 	eor.w	r3, r3, r8
 8001f6c:	ea28 0404 	bic.w	r4, r8, r4
 8001f70:	9626      	str	r6, [sp, #152]	@ 0x98
 8001f72:	9328      	str	r3, [sp, #160]	@ 0xa0
 8001f74:	ea84 060c 	eor.w	r6, r4, ip
 8001f78:	ea20 0309 	bic.w	r3, r0, r9
 8001f7c:	9c29      	ldr	r4, [sp, #164]	@ 0xa4
 8001f7e:	9624      	str	r6, [sp, #144]	@ 0x90
 8001f80:	407b      	eors	r3, r7
 8001f82:	ea25 0204 	bic.w	r2, r5, r4
 8001f86:	9323      	str	r3, [sp, #140]	@ 0x8c
 8001f88:	ea27 0305 	bic.w	r3, r7, r5
 8001f8c:	9f2e      	ldr	r7, [sp, #184]	@ 0xb8
 8001f8e:	f8dd c0bc 	ldr.w	ip, [sp, #188]	@ 0xbc
 8001f92:	9d2d      	ldr	r5, [sp, #180]	@ 0xb4
 8001f94:	ea82 0600 	eor.w	r6, r2, r0
 8001f98:	4063      	eors	r3, r4
 8001f9a:	ea24 0200 	bic.w	r2, r4, r0
 8001f9e:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 8001fa0:	9627      	str	r6, [sp, #156]	@ 0x9c
 8001fa2:	9329      	str	r3, [sp, #164]	@ 0xa4
 8001fa4:	ea82 0609 	eor.w	r6, r2, r9
 8001fa8:	ea21 0307 	bic.w	r3, r1, r7
 8001fac:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 8001fae:	9625      	str	r6, [sp, #148]	@ 0x94
 8001fb0:	4063      	eors	r3, r4
 8001fb2:	ea27 0604 	bic.w	r6, r7, r4
 8001fb6:	4056      	eors	r6, r2
 8001fb8:	932a      	str	r3, [sp, #168]	@ 0xa8
 8001fba:	ea24 0302 	bic.w	r3, r4, r2
 8001fbe:	ea22 020e 	bic.w	r2, r2, lr
 8001fc2:	ea82 0801 	eor.w	r8, r2, r1
 8001fc6:	ea2e 0101 	bic.w	r1, lr, r1
 8001fca:	404f      	eors	r7, r1
 8001fcc:	9930      	ldr	r1, [sp, #192]	@ 0xc0
 8001fce:	982b      	ldr	r0, [sp, #172]	@ 0xac
 8001fd0:	9c31      	ldr	r4, [sp, #196]	@ 0xc4
 8001fd2:	f8cd 80b4 	str.w	r8, [sp, #180]	@ 0xb4
 8001fd6:	ea83 030e 	eor.w	r3, r3, lr
 8001fda:	932f      	str	r3, [sp, #188]	@ 0xbc
 8001fdc:	ea21 030c 	bic.w	r3, r1, ip
 8001fe0:	ea20 0204 	bic.w	r2, r0, r4
 8001fe4:	ea2c 0a05 	bic.w	sl, ip, r5
 8001fe8:	ea83 0805 	eor.w	r8, r3, r5
 8001fec:	ea25 0300 	bic.w	r3, r5, r0
 8001ff0:	4063      	eors	r3, r4
 8001ff2:	ea8a 0a00 	eor.w	sl, sl, r0
 8001ff6:	ea82 0001 	eor.w	r0, r2, r1
 8001ffa:	ea24 0201 	bic.w	r2, r4, r1
 8001ffe:	ea82 010c 	eor.w	r1, r2, ip
 8002002:	9330      	str	r3, [sp, #192]	@ 0xc0
 8002004:	9a01      	ldr	r2, [sp, #4]
 8002006:	4b3b      	ldr	r3, [pc, #236]	@ (80020f4 <KeccakF1600_StatePermute+0x114c>)
 8002008:	972b      	str	r7, [sp, #172]	@ 0xac
 800200a:	4293      	cmp	r3, r2
 800200c:	902e      	str	r0, [sp, #184]	@ 0xb8
 800200e:	912c      	str	r1, [sp, #176]	@ 0xb0
 8002010:	f47f a842 	bne.w	8001098 <KeccakF1600_StatePermute+0xf0>
 8002014:	983d      	ldr	r0, [sp, #244]	@ 0xf4
 8002016:	9b04      	ldr	r3, [sp, #16]
 8002018:	6003      	str	r3, [r0, #0]
 800201a:	9b05      	ldr	r3, [sp, #20]
 800201c:	6043      	str	r3, [r0, #4]
 800201e:	9b06      	ldr	r3, [sp, #24]
 8002020:	6083      	str	r3, [r0, #8]
 8002022:	9b03      	ldr	r3, [sp, #12]
 8002024:	60c3      	str	r3, [r0, #12]
 8002026:	9b07      	ldr	r3, [sp, #28]
 8002028:	6103      	str	r3, [r0, #16]
 800202a:	9b08      	ldr	r3, [sp, #32]
 800202c:	6143      	str	r3, [r0, #20]
 800202e:	9b09      	ldr	r3, [sp, #36]	@ 0x24
 8002030:	6183      	str	r3, [r0, #24]
 8002032:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
 8002034:	61c3      	str	r3, [r0, #28]
 8002036:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
 8002038:	6203      	str	r3, [r0, #32]
 800203a:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
 800203c:	6243      	str	r3, [r0, #36]	@ 0x24
 800203e:	9b0d      	ldr	r3, [sp, #52]	@ 0x34
 8002040:	6283      	str	r3, [r0, #40]	@ 0x28
 8002042:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
 8002044:	62c3      	str	r3, [r0, #44]	@ 0x2c
 8002046:	9b0f      	ldr	r3, [sp, #60]	@ 0x3c
 8002048:	6303      	str	r3, [r0, #48]	@ 0x30
 800204a:	9b10      	ldr	r3, [sp, #64]	@ 0x40
 800204c:	6343      	str	r3, [r0, #52]	@ 0x34
 800204e:	9b11      	ldr	r3, [sp, #68]	@ 0x44
 8002050:	6383      	str	r3, [r0, #56]	@ 0x38
 8002052:	9b12      	ldr	r3, [sp, #72]	@ 0x48
 8002054:	63c3      	str	r3, [r0, #60]	@ 0x3c
 8002056:	9b13      	ldr	r3, [sp, #76]	@ 0x4c
 8002058:	6403      	str	r3, [r0, #64]	@ 0x40
 800205a:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 800205c:	6443      	str	r3, [r0, #68]	@ 0x44
 800205e:	9b15      	ldr	r3, [sp, #84]	@ 0x54
 8002060:	6483      	str	r3, [r0, #72]	@ 0x48
 8002062:	9b16      	ldr	r3, [sp, #88]	@ 0x58
 8002064:	e9c0 3b13 	strd	r3, fp, [r0, #76]	@ 0x4c
 8002068:	9b17      	ldr	r3, [sp, #92]	@ 0x5c
 800206a:	6543      	str	r3, [r0, #84]	@ 0x54
 800206c:	9b18      	ldr	r3, [sp, #96]	@ 0x60
 800206e:	6583      	str	r3, [r0, #88]	@ 0x58
 8002070:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8002072:	65c3      	str	r3, [r0, #92]	@ 0x5c
 8002074:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 8002076:	6603      	str	r3, [r0, #96]	@ 0x60
 8002078:	9b1b      	ldr	r3, [sp, #108]	@ 0x6c
 800207a:	6643      	str	r3, [r0, #100]	@ 0x64
 800207c:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
 800207e:	6683      	str	r3, [r0, #104]	@ 0x68
 8002080:	9b1d      	ldr	r3, [sp, #116]	@ 0x74
 8002082:	66c3      	str	r3, [r0, #108]	@ 0x6c
 8002084:	9b1e      	ldr	r3, [sp, #120]	@ 0x78
 8002086:	6703      	str	r3, [r0, #112]	@ 0x70
 8002088:	9b1f      	ldr	r3, [sp, #124]	@ 0x7c
 800208a:	6743      	str	r3, [r0, #116]	@ 0x74
 800208c:	9b20      	ldr	r3, [sp, #128]	@ 0x80
 800208e:	6783      	str	r3, [r0, #120]	@ 0x78
 8002090:	9b21      	ldr	r3, [sp, #132]	@ 0x84
 8002092:	67c3      	str	r3, [r0, #124]	@ 0x7c
 8002094:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 8002096:	f8c0 3080 	str.w	r3, [r0, #128]	@ 0x80
 800209a:	9b23      	ldr	r3, [sp, #140]	@ 0x8c
 800209c:	f8c0 3084 	str.w	r3, [r0, #132]	@ 0x84
 80020a0:	9b24      	ldr	r3, [sp, #144]	@ 0x90
 80020a2:	f8c0 3088 	str.w	r3, [r0, #136]	@ 0x88
 80020a6:	9b25      	ldr	r3, [sp, #148]	@ 0x94
 80020a8:	f8c0 308c 	str.w	r3, [r0, #140]	@ 0x8c
 80020ac:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 80020ae:	f8c0 3090 	str.w	r3, [r0, #144]	@ 0x90
 80020b2:	9b27      	ldr	r3, [sp, #156]	@ 0x9c
 80020b4:	f8c0 3094 	str.w	r3, [r0, #148]	@ 0x94
 80020b8:	9b28      	ldr	r3, [sp, #160]	@ 0xa0
 80020ba:	f8c0 3098 	str.w	r3, [r0, #152]	@ 0x98
 80020be:	9b29      	ldr	r3, [sp, #164]	@ 0xa4
 80020c0:	f8c0 a0a4 	str.w	sl, [r0, #164]	@ 0xa4
 80020c4:	e9c0 3627 	strd	r3, r6, [r0, #156]	@ 0x9c
 80020c8:	9b2a      	ldr	r3, [sp, #168]	@ 0xa8
 80020ca:	f8c0 70b0 	str.w	r7, [r0, #176]	@ 0xb0
 80020ce:	e9c0 382a 	strd	r3, r8, [r0, #168]	@ 0xa8
 80020d2:	9b2d      	ldr	r3, [sp, #180]	@ 0xb4
 80020d4:	f8c0 30b8 	str.w	r3, [r0, #184]	@ 0xb8
 80020d8:	9b2e      	ldr	r3, [sp, #184]	@ 0xb8
 80020da:	f8c0 30bc 	str.w	r3, [r0, #188]	@ 0xbc
 80020de:	9b2f      	ldr	r3, [sp, #188]	@ 0xbc
 80020e0:	f8c0 30c0 	str.w	r3, [r0, #192]	@ 0xc0
 80020e4:	9b30      	ldr	r3, [sp, #192]	@ 0xc0
 80020e6:	f8c0 10b4 	str.w	r1, [r0, #180]	@ 0xb4
 80020ea:	f8c0 30c4 	str.w	r3, [r0, #196]	@ 0xc4
 80020ee:	b03f      	add	sp, #252	@ 0xfc
 80020f0:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 80020f4:	08003608 	.word	0x08003608

080020f8 <keccak_absorb>:
 80020f8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 80020fc:	b0b7      	sub	sp, #220	@ 0xdc
 80020fe:	460d      	mov	r5, r1
 8002100:	461e      	mov	r6, r3
 8002102:	4617      	mov	r7, r2
 8002104:	2100      	movs	r1, #0
 8002106:	22c8      	movs	r2, #200	@ 0xc8
 8002108:	f89d 9100 	ldrb.w	r9, [sp, #256]	@ 0x100
 800210c:	4683      	mov	fp, r0
 800210e:	f7fe f96b 	bl	80003e8 <memset>
 8002112:	42ae      	cmp	r6, r5
 8002114:	ea4f 04d5 	mov.w	r4, r5, lsr #3
 8002118:	f1ab 0a08 	sub.w	sl, fp, #8
 800211c:	bf28      	it	cs
 800211e:	f8cd 900c 	strcs.w	r9, [sp, #12]
 8002122:	d339      	bcc.n	8002198 <keccak_absorb+0xa0>
 8002124:	4650      	mov	r0, sl
 8002126:	46b9      	mov	r9, r7
 8002128:	f04f 0800 	mov.w	r8, #0
 800212c:	465a      	mov	r2, fp
 800212e:	e9cd 8901 	strd	r8, r9, [sp, #4]
 8002132:	2300      	movs	r3, #0
 8002134:	46cb      	mov	fp, r9
 8002136:	469e      	mov	lr, r3
 8002138:	469c      	mov	ip, r3
 800213a:	f81b 1b01 	ldrb.w	r1, [fp], #1
 800213e:	f1a3 0820 	sub.w	r8, r3, #32
 8002142:	f1c3 0920 	rsb	r9, r3, #32
 8002146:	fa01 f808 	lsl.w	r8, r1, r8
 800214a:	fa21 f909 	lsr.w	r9, r1, r9
 800214e:	4099      	lsls	r1, r3
 8002150:	3308      	adds	r3, #8
 8002152:	ea48 0809 	orr.w	r8, r8, r9
 8002156:	2b40      	cmp	r3, #64	@ 0x40
 8002158:	ea48 0c0c 	orr.w	ip, r8, ip
 800215c:	ea41 0e0e 	orr.w	lr, r1, lr
 8002160:	d1eb      	bne.n	800213a <keccak_absorb+0x42>
 8002162:	f850 3f08 	ldr.w	r3, [r0, #8]!
 8002166:	e9dd 8901 	ldrd	r8, r9, [sp, #4]
 800216a:	ea83 030e 	eor.w	r3, r3, lr
 800216e:	6003      	str	r3, [r0, #0]
 8002170:	6843      	ldr	r3, [r0, #4]
 8002172:	f108 0801 	add.w	r8, r8, #1
 8002176:	ea83 030c 	eor.w	r3, r3, ip
 800217a:	45a0      	cmp	r8, r4
 800217c:	f109 0908 	add.w	r9, r9, #8
 8002180:	6043      	str	r3, [r0, #4]
 8002182:	d3d4      	bcc.n	800212e <keccak_absorb+0x36>
 8002184:	4610      	mov	r0, r2
 8002186:	1b76      	subs	r6, r6, r5
 8002188:	4693      	mov	fp, r2
 800218a:	f7fe ff0d 	bl	8000fa8 <KeccakF1600_StatePermute>
 800218e:	42b5      	cmp	r5, r6
 8002190:	442f      	add	r7, r5
 8002192:	d9c7      	bls.n	8002124 <keccak_absorb+0x2c>
 8002194:	f8dd 900c 	ldr.w	r9, [sp, #12]
 8002198:	462a      	mov	r2, r5
 800219a:	2100      	movs	r1, #0
 800219c:	a804      	add	r0, sp, #16
 800219e:	f7fe f923 	bl	80003e8 <memset>
 80021a2:	b126      	cbz	r6, 80021ae <keccak_absorb+0xb6>
 80021a4:	4639      	mov	r1, r7
 80021a6:	4632      	mov	r2, r6
 80021a8:	a804      	add	r0, sp, #16
 80021aa:	f7fe f831 	bl	8000210 <memcpy>
 80021ae:	446e      	add	r6, sp
 80021b0:	eb0d 0305 	add.w	r3, sp, r5
 80021b4:	f886 9010 	strb.w	r9, [r6, #16]
 80021b8:	7bda      	ldrb	r2, [r3, #15]
 80021ba:	f062 027f 	orn	r2, r2, #127	@ 0x7f
 80021be:	46d4      	mov	ip, sl
 80021c0:	f10d 0e10 	add.w	lr, sp, #16
 80021c4:	73da      	strb	r2, [r3, #15]
 80021c6:	f04f 0800 	mov.w	r8, #0
 80021ca:	2300      	movs	r3, #0
 80021cc:	4677      	mov	r7, lr
 80021ce:	461e      	mov	r6, r3
 80021d0:	461d      	mov	r5, r3
 80021d2:	f817 1b01 	ldrb.w	r1, [r7], #1
 80021d6:	f1a3 0220 	sub.w	r2, r3, #32
 80021da:	f1c3 0020 	rsb	r0, r3, #32
 80021de:	fa01 f202 	lsl.w	r2, r1, r2
 80021e2:	fa21 f000 	lsr.w	r0, r1, r0
 80021e6:	4099      	lsls	r1, r3
 80021e8:	3308      	adds	r3, #8
 80021ea:	4302      	orrs	r2, r0
 80021ec:	2b40      	cmp	r3, #64	@ 0x40
 80021ee:	ea46 0601 	orr.w	r6, r6, r1
 80021f2:	ea45 0502 	orr.w	r5, r5, r2
 80021f6:	d1ec      	bne.n	80021d2 <keccak_absorb+0xda>
 80021f8:	f85c 2f08 	ldr.w	r2, [ip, #8]!
 80021fc:	f8dc 3004 	ldr.w	r3, [ip, #4]
 8002200:	f108 0801 	add.w	r8, r8, #1
 8002204:	4072      	eors	r2, r6
 8002206:	406b      	eors	r3, r5
 8002208:	45a0      	cmp	r8, r4
 800220a:	e9cc 2300 	strd	r2, r3, [ip]
 800220e:	f10e 0e08 	add.w	lr, lr, #8
 8002212:	d3da      	bcc.n	80021ca <keccak_absorb+0xd2>
 8002214:	b037      	add	sp, #220	@ 0xdc
 8002216:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 800221a:	bf00      	nop

0800221c <keccak_inc_absorb>:
 800221c:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002220:	f8d0 40c8 	ldr.w	r4, [r0, #200]	@ 0xc8
 8002224:	460e      	mov	r6, r1
 8002226:	f8d0 10cc 	ldr.w	r1, [r0, #204]	@ 0xcc
 800222a:	4690      	mov	r8, r2
 800222c:	191a      	adds	r2, r3, r4
 800222e:	461f      	mov	r7, r3
 8002230:	f141 0300 	adc.w	r3, r1, #0
 8002234:	42b2      	cmp	r2, r6
 8002236:	f173 0300 	sbcs.w	r3, r3, #0
 800223a:	4605      	mov	r5, r0
 800223c:	d345      	bcc.n	80022ca <keccak_inc_absorb+0xae>
 800223e:	42a6      	cmp	r6, r4
 8002240:	d10c      	bne.n	800225c <keccak_inc_absorb+0x40>
 8002242:	2200      	movs	r2, #0
 8002244:	2300      	movs	r3, #0
 8002246:	1bbf      	subs	r7, r7, r6
 8002248:	4427      	add	r7, r4
 800224a:	e9c5 2332 	strd	r2, r3, [r5, #200]	@ 0xc8
 800224e:	4628      	mov	r0, r5
 8002250:	f7fe feaa 	bl	8000fa8 <KeccakF1600_StatePermute>
 8002254:	2400      	movs	r4, #0
 8002256:	42b7      	cmp	r7, r6
 8002258:	4621      	mov	r1, r4
 800225a:	d336      	bcc.n	80022ca <keccak_inc_absorb+0xae>
 800225c:	f04f 0c00 	mov.w	ip, #0
 8002260:	f108 32ff 	add.w	r2, r8, #4294967295	@ 0xffffffff
 8002264:	4663      	mov	r3, ip
 8002266:	eb14 040c 	adds.w	r4, r4, ip
 800226a:	eb43 0101 	adc.w	r1, r3, r1
 800226e:	08e0      	lsrs	r0, r4, #3
 8002270:	ea40 7041 	orr.w	r0, r0, r1, lsl #29
 8002274:	f004 0407 	and.w	r4, r4, #7
 8002278:	f812 ef01 	ldrb.w	lr, [r2, #1]!
 800227c:	f855 1030 	ldr.w	r1, [r5, r0, lsl #3]
 8002280:	00e4      	lsls	r4, r4, #3
 8002282:	eb05 0ac0 	add.w	sl, r5, r0, lsl #3
 8002286:	f1a4 0920 	sub.w	r9, r4, #32
 800228a:	f1c4 0b20 	rsb	fp, r4, #32
 800228e:	fa0e f909 	lsl.w	r9, lr, r9
 8002292:	fa2e fb0b 	lsr.w	fp, lr, fp
 8002296:	fa0e fe04 	lsl.w	lr, lr, r4
 800229a:	ea81 010e 	eor.w	r1, r1, lr
 800229e:	f8da e004 	ldr.w	lr, [sl, #4]
 80022a2:	f845 1030 	str.w	r1, [r5, r0, lsl #3]
 80022a6:	ea49 040b 	orr.w	r4, r9, fp
 80022aa:	ea8e 0404 	eor.w	r4, lr, r4
 80022ae:	f8ca 4004 	str.w	r4, [sl, #4]
 80022b2:	e9d5 4132 	ldrd	r4, r1, [r5, #200]	@ 0xc8
 80022b6:	f11c 0c01 	adds.w	ip, ip, #1
 80022ba:	eba6 0004 	sub.w	r0, r6, r4
 80022be:	f143 0300 	adc.w	r3, r3, #0
 80022c2:	4560      	cmp	r0, ip
 80022c4:	d8cf      	bhi.n	8002266 <keccak_inc_absorb+0x4a>
 80022c6:	4480      	add	r8, r0
 80022c8:	e7bb      	b.n	8002242 <keccak_inc_absorb+0x26>
 80022ca:	b38f      	cbz	r7, 8002330 <keccak_inc_absorb+0x114>
 80022cc:	1e7e      	subs	r6, r7, #1
 80022ce:	2300      	movs	r3, #0
 80022d0:	4446      	add	r6, r8
 80022d2:	4618      	mov	r0, r3
 80022d4:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 80022d8:	191c      	adds	r4, r3, r4
 80022da:	eb40 0101 	adc.w	r1, r0, r1
 80022de:	ea4f 0cd4 	mov.w	ip, r4, lsr #3
 80022e2:	ea4c 7c41 	orr.w	ip, ip, r1, lsl #29
 80022e6:	f004 0407 	and.w	r4, r4, #7
 80022ea:	f818 ef01 	ldrb.w	lr, [r8, #1]!
 80022ee:	f855 103c 	ldr.w	r1, [r5, ip, lsl #3]
 80022f2:	00e4      	lsls	r4, r4, #3
 80022f4:	eb05 09cc 	add.w	r9, r5, ip, lsl #3
 80022f8:	f1a4 0220 	sub.w	r2, r4, #32
 80022fc:	f1c4 0a20 	rsb	sl, r4, #32
 8002300:	fa0e f202 	lsl.w	r2, lr, r2
 8002304:	fa2e fa0a 	lsr.w	sl, lr, sl
 8002308:	fa0e fe04 	lsl.w	lr, lr, r4
 800230c:	f8d9 4004 	ldr.w	r4, [r9, #4]
 8002310:	ea81 010e 	eor.w	r1, r1, lr
 8002314:	ea42 020a 	orr.w	r2, r2, sl
 8002318:	f845 103c 	str.w	r1, [r5, ip, lsl #3]
 800231c:	4062      	eors	r2, r4
 800231e:	3301      	adds	r3, #1
 8002320:	f8c9 2004 	str.w	r2, [r9, #4]
 8002324:	f140 0000 	adc.w	r0, r0, #0
 8002328:	45b0      	cmp	r8, r6
 800232a:	e9d5 4132 	ldrd	r4, r1, [r5, #200]	@ 0xc8
 800232e:	d1d3      	bne.n	80022d8 <keccak_inc_absorb+0xbc>
 8002330:	193f      	adds	r7, r7, r4
 8002332:	f141 0100 	adc.w	r1, r1, #0
 8002336:	e9c5 7132 	strd	r7, r1, [r5, #200]	@ 0xc8
 800233a:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 800233e:	bf00      	nop

08002340 <keccak_inc_squeeze>:
 8002340:	2900      	cmp	r1, #0
 8002342:	d07e      	beq.n	8002442 <keccak_inc_squeeze+0x102>
 8002344:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002348:	4691      	mov	r9, r2
 800234a:	1e45      	subs	r5, r0, #1
 800234c:	2200      	movs	r2, #0
 800234e:	461e      	mov	r6, r3
 8002350:	186f      	adds	r7, r5, r1
 8002352:	4614      	mov	r4, r2
 8002354:	e027      	b.n	80023a6 <keccak_inc_squeeze+0x66>
 8002356:	1af3      	subs	r3, r6, r3
 8002358:	eb6e 0e4e 	sbc.w	lr, lr, lr, lsl #1
 800235c:	189b      	adds	r3, r3, r2
 800235e:	eb44 0e0e 	adc.w	lr, r4, lr
 8002362:	ea4f 0ad3 	mov.w	sl, r3, lsr #3
 8002366:	ea4a 7a4e 	orr.w	sl, sl, lr, lsl #29
 800236a:	eb09 0eca 	add.w	lr, r9, sl, lsl #3
 800236e:	f003 0307 	and.w	r3, r3, #7
 8002372:	f8de 8004 	ldr.w	r8, [lr, #4]
 8002376:	f859 b03a 	ldr.w	fp, [r9, sl, lsl #3]
 800237a:	00db      	lsls	r3, r3, #3
 800237c:	f1c3 0a20 	rsb	sl, r3, #32
 8002380:	f1a3 0e20 	sub.w	lr, r3, #32
 8002384:	fa08 fa0a 	lsl.w	sl, r8, sl
 8002388:	fa2b f303 	lsr.w	r3, fp, r3
 800238c:	ea43 030a 	orr.w	r3, r3, sl
 8002390:	fa28 fe0e 	lsr.w	lr, r8, lr
 8002394:	ea43 030e 	orr.w	r3, r3, lr
 8002398:	f805 3f01 	strb.w	r3, [r5, #1]!
 800239c:	3201      	adds	r2, #1
 800239e:	f144 0400 	adc.w	r4, r4, #0
 80023a2:	42bd      	cmp	r5, r7
 80023a4:	d048      	beq.n	8002438 <keccak_inc_squeeze+0xf8>
 80023a6:	e9d9 3e32 	ldrd	r3, lr, [r9, #200]	@ 0xc8
 80023aa:	429a      	cmp	r2, r3
 80023ac:	eb74 080e 	sbcs.w	r8, r4, lr
 80023b0:	4694      	mov	ip, r2
 80023b2:	d3d0      	bcc.n	8002356 <keccak_inc_squeeze+0x16>
 80023b4:	1a9b      	subs	r3, r3, r2
 80023b6:	eb6e 0404 	sbc.w	r4, lr, r4
 80023ba:	ebb1 070c 	subs.w	r7, r1, ip
 80023be:	e9c9 3432 	strd	r3, r4, [r9, #200]	@ 0xc8
 80023c2:	eb00 080c 	add.w	r8, r0, ip
 80023c6:	d030      	beq.n	800242a <keccak_inc_squeeze+0xea>
 80023c8:	2400      	movs	r4, #0
 80023ca:	2500      	movs	r5, #0
 80023cc:	4648      	mov	r0, r9
 80023ce:	f7fe fdeb 	bl	8000fa8 <KeccakF1600_StatePermute>
 80023d2:	f04f 0e00 	mov.w	lr, #0
 80023d6:	f108 30ff 	add.w	r0, r8, #4294967295	@ 0xffffffff
 80023da:	e001      	b.n	80023e0 <keccak_inc_squeeze+0xa0>
 80023dc:	4576      	cmp	r6, lr
 80023de:	d026      	beq.n	800242e <keccak_inc_squeeze+0xee>
 80023e0:	f02e 0307 	bic.w	r3, lr, #7
 80023e4:	ea4f 01de 	mov.w	r1, lr, lsr #3
 80023e8:	444b      	add	r3, r9
 80023ea:	f00e 0c07 	and.w	ip, lr, #7
 80023ee:	685a      	ldr	r2, [r3, #4]
 80023f0:	f859 1031 	ldr.w	r1, [r9, r1, lsl #3]
 80023f4:	ea4f 0ccc 	mov.w	ip, ip, lsl #3
 80023f8:	f1cc 0a20 	rsb	sl, ip, #32
 80023fc:	f1ac 0320 	sub.w	r3, ip, #32
 8002400:	fa02 fa0a 	lsl.w	sl, r2, sl
 8002404:	fa21 fc0c 	lsr.w	ip, r1, ip
 8002408:	ea4c 0c0a 	orr.w	ip, ip, sl
 800240c:	fa22 f303 	lsr.w	r3, r2, r3
 8002410:	f10e 0e01 	add.w	lr, lr, #1
 8002414:	ea4c 0c03 	orr.w	ip, ip, r3
 8002418:	45be      	cmp	lr, r7
 800241a:	f800 cf01 	strb.w	ip, [r0, #1]!
 800241e:	d1dd      	bne.n	80023dc <keccak_inc_squeeze+0x9c>
 8002420:	eba6 060e 	sub.w	r6, r6, lr
 8002424:	2300      	movs	r3, #0
 8002426:	e9c9 6332 	strd	r6, r3, [r9, #200]	@ 0xc8
 800242a:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 800242e:	e9c9 4532 	strd	r4, r5, [r9, #200]	@ 0xc8
 8002432:	44b0      	add	r8, r6
 8002434:	1bbf      	subs	r7, r7, r6
 8002436:	e7c9      	b.n	80023cc <keccak_inc_squeeze+0x8c>
 8002438:	e9d9 3e32 	ldrd	r3, lr, [r9, #200]	@ 0xc8
 800243c:	f10c 0c01 	add.w	ip, ip, #1
 8002440:	e7b8      	b.n	80023b4 <keccak_inc_squeeze+0x74>
 8002442:	4770      	bx	lr

08002444 <shake128_inc_init>:
 8002444:	b538      	push	{r3, r4, r5, lr}
 8002446:	4605      	mov	r5, r0
 8002448:	20d0      	movs	r0, #208	@ 0xd0
 800244a:	f7fd ffbd 	bl	80003c8 <malloc>
 800244e:	6028      	str	r0, [r5, #0]
 8002450:	b148      	cbz	r0, 8002466 <shake128_inc_init+0x22>
 8002452:	22c8      	movs	r2, #200	@ 0xc8
 8002454:	2100      	movs	r1, #0
 8002456:	4604      	mov	r4, r0
 8002458:	f7fd ffc6 	bl	80003e8 <memset>
 800245c:	2200      	movs	r2, #0
 800245e:	2300      	movs	r3, #0
 8002460:	e9c4 2332 	strd	r2, r3, [r4, #200]	@ 0xc8
 8002464:	bd38      	pop	{r3, r4, r5, pc}
 8002466:	206f      	movs	r0, #111	@ 0x6f
 8002468:	f7fe f80c 	bl	8000484 <exit>

0800246c <shake128_inc_absorb>:
 800246c:	4613      	mov	r3, r2
 800246e:	6800      	ldr	r0, [r0, #0]
 8002470:	460a      	mov	r2, r1
 8002472:	21a8      	movs	r1, #168	@ 0xa8
 8002474:	f7ff bed2 	b.w	800221c <keccak_inc_absorb>

08002478 <shake128_inc_finalize>:
 8002478:	6803      	ldr	r3, [r0, #0]
 800247a:	e9d3 2132 	ldrd	r2, r1, [r3, #200]	@ 0xc8
 800247e:	08d0      	lsrs	r0, r2, #3
 8002480:	f002 0207 	and.w	r2, r2, #7
 8002484:	ea40 7041 	orr.w	r0, r0, r1, lsl #29
 8002488:	00d2      	lsls	r2, r2, #3
 800248a:	b510      	push	{r4, lr}
 800248c:	f04f 0c1f 	mov.w	ip, #31
 8002490:	f1a2 0120 	sub.w	r1, r2, #32
 8002494:	f1c2 0420 	rsb	r4, r2, #32
 8002498:	eb03 0ec0 	add.w	lr, r3, r0, lsl #3
 800249c:	fa2c f404 	lsr.w	r4, ip, r4
 80024a0:	fa0c f101 	lsl.w	r1, ip, r1
 80024a4:	fa0c fc02 	lsl.w	ip, ip, r2
 80024a8:	f853 2030 	ldr.w	r2, [r3, r0, lsl #3]
 80024ac:	4321      	orrs	r1, r4
 80024ae:	ea82 040c 	eor.w	r4, r2, ip
 80024b2:	f8de 2004 	ldr.w	r2, [lr, #4]
 80024b6:	f843 4030 	str.w	r4, [r3, r0, lsl #3]
 80024ba:	404a      	eors	r2, r1
 80024bc:	f8ce 2004 	str.w	r2, [lr, #4]
 80024c0:	f8d3 20a4 	ldr.w	r2, [r3, #164]	@ 0xa4
 80024c4:	2000      	movs	r0, #0
 80024c6:	2100      	movs	r1, #0
 80024c8:	f102 4200 	add.w	r2, r2, #2147483648	@ 0x80000000
 80024cc:	e9c3 0132 	strd	r0, r1, [r3, #200]	@ 0xc8
 80024d0:	f8c3 20a4 	str.w	r2, [r3, #164]	@ 0xa4
 80024d4:	bd10      	pop	{r4, pc}
 80024d6:	bf00      	nop

080024d8 <shake128_inc_squeeze>:
 80024d8:	6812      	ldr	r2, [r2, #0]
 80024da:	23a8      	movs	r3, #168	@ 0xa8
 80024dc:	f7ff bf30 	b.w	8002340 <keccak_inc_squeeze>

080024e0 <shake128_inc_ctx_release>:
 80024e0:	6800      	ldr	r0, [r0, #0]
 80024e2:	f7fd bf79 	b.w	80003d8 <free>
 80024e6:	bf00      	nop

080024e8 <sha3_256>:
 80024e8:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
 80024ec:	b0d6      	sub	sp, #344	@ 0x158
 80024ee:	4613      	mov	r3, r2
 80024f0:	2206      	movs	r2, #6
 80024f2:	9200      	str	r2, [sp, #0]
 80024f4:	4606      	mov	r6, r0
 80024f6:	460a      	mov	r2, r1
 80024f8:	a824      	add	r0, sp, #144	@ 0x90
 80024fa:	2188      	movs	r1, #136	@ 0x88
 80024fc:	f7ff fdfc 	bl	80020f8 <keccak_absorb>
 8002500:	a824      	add	r0, sp, #144	@ 0x90
 8002502:	f7fe fd51 	bl	8000fa8 <KeccakF1600_StatePermute>
 8002506:	af02      	add	r7, sp, #8
 8002508:	f10d 0e88 	add.w	lr, sp, #136	@ 0x88
 800250c:	f50d 7888 	add.w	r8, sp, #272	@ 0x110
 8002510:	f85e 5f08 	ldr.w	r5, [lr, #8]!
 8002514:	f8de 4004 	ldr.w	r4, [lr, #4]
 8002518:	46bc      	mov	ip, r7
 800251a:	2300      	movs	r3, #0
 800251c:	f1c3 0020 	rsb	r0, r3, #32
 8002520:	f1a3 0120 	sub.w	r1, r3, #32
 8002524:	fa25 f203 	lsr.w	r2, r5, r3
 8002528:	fa04 f000 	lsl.w	r0, r4, r0
 800252c:	4302      	orrs	r2, r0
 800252e:	fa24 f101 	lsr.w	r1, r4, r1
 8002532:	3308      	adds	r3, #8
 8002534:	430a      	orrs	r2, r1
 8002536:	2b40      	cmp	r3, #64	@ 0x40
 8002538:	f80c 2b01 	strb.w	r2, [ip], #1
 800253c:	d1ee      	bne.n	800251c <sha3_256+0x34>
 800253e:	45f0      	cmp	r8, lr
 8002540:	f107 0708 	add.w	r7, r7, #8
 8002544:	d1e4      	bne.n	8002510 <sha3_256+0x28>
 8002546:	ac02      	add	r4, sp, #8
 8002548:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
 800254a:	6030      	str	r0, [r6, #0]
 800254c:	6071      	str	r1, [r6, #4]
 800254e:	60b2      	str	r2, [r6, #8]
 8002550:	60f3      	str	r3, [r6, #12]
 8002552:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
 8002554:	6130      	str	r0, [r6, #16]
 8002556:	6171      	str	r1, [r6, #20]
 8002558:	61b2      	str	r2, [r6, #24]
 800255a:	61f3      	str	r3, [r6, #28]
 800255c:	b056      	add	sp, #344	@ 0x158
 800255e:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 8002562:	bf00      	nop

08002564 <platform_init>:
 8002564:	b5f0      	push	{r4, r5, r6, r7, lr}
 8002566:	b093      	sub	sp, #76	@ 0x4c
 8002568:	2603      	movs	r6, #3
 800256a:	f44f 27a0 	mov.w	r7, #327680	@ 0x50000
 800256e:	2302      	movs	r3, #2
 8002570:	e9cd 6706 	strd	r6, r7, [sp, #24]
 8002574:	2501      	movs	r5, #1
 8002576:	f44f 0180 	mov.w	r1, #4194304	@ 0x400000
 800257a:	930c      	str	r3, [sp, #48]	@ 0x30
 800257c:	220c      	movs	r2, #12
 800257e:	23c4      	movs	r3, #196	@ 0xc4
 8002580:	2604      	movs	r6, #4
 8002582:	2707      	movs	r7, #7
 8002584:	a806      	add	r0, sp, #24
 8002586:	e9cd 120d 	strd	r1, r2, [sp, #52]	@ 0x34
 800258a:	e9cd 6710 	strd	r6, r7, [sp, #64]	@ 0x40
 800258e:	9509      	str	r5, [sp, #36]	@ 0x24
 8002590:	930f      	str	r3, [sp, #60]	@ 0x3c
 8002592:	f000 f8bf 	bl	8002714 <HAL_RCC_OscConfig>
 8002596:	b100      	cbz	r0, 800259a <platform_init+0x36>
 8002598:	e7fe      	b.n	8002598 <platform_init+0x34>
 800259a:	4604      	mov	r4, r0
 800259c:	230f      	movs	r3, #15
 800259e:	4601      	mov	r1, r0
 80025a0:	a801      	add	r0, sp, #4
 80025a2:	e9cd 3501 	strd	r3, r5, [sp, #4]
 80025a6:	e9cd 4403 	strd	r4, r4, [sp, #12]
 80025aa:	9405      	str	r4, [sp, #20]
 80025ac:	f000 fabe 	bl	8002b2c <HAL_RCC_ClockConfig>
 80025b0:	4b09      	ldr	r3, [pc, #36]	@ (80025d8 <platform_init+0x74>)
 80025b2:	9400      	str	r4, [sp, #0]
 80025b4:	6b5a      	ldr	r2, [r3, #52]	@ 0x34
 80025b6:	4809      	ldr	r0, [pc, #36]	@ (80025dc <platform_init+0x78>)
 80025b8:	4909      	ldr	r1, [pc, #36]	@ (80025e0 <platform_init+0x7c>)
 80025ba:	f042 0240 	orr.w	r2, r2, #64	@ 0x40
 80025be:	635a      	str	r2, [r3, #52]	@ 0x34
 80025c0:	6b5b      	ldr	r3, [r3, #52]	@ 0x34
 80025c2:	6001      	str	r1, [r0, #0]
 80025c4:	f003 0340 	and.w	r3, r3, #64	@ 0x40
 80025c8:	9300      	str	r3, [sp, #0]
 80025ca:	9b00      	ldr	r3, [sp, #0]
 80025cc:	7144      	strb	r4, [r0, #5]
 80025ce:	f000 fdd5 	bl	800317c <HAL_RNG_Init>
 80025d2:	b013      	add	sp, #76	@ 0x4c
 80025d4:	bdf0      	pop	{r4, r5, r6, r7, pc}
 80025d6:	bf00      	nop
 80025d8:	40023800 	.word	0x40023800
 80025dc:	20000978 	.word	0x20000978
 80025e0:	50060800 	.word	0x50060800

080025e4 <init_uart>:
 80025e4:	b530      	push	{r4, r5, lr}
 80025e6:	2302      	movs	r3, #2
 80025e8:	b089      	sub	sp, #36	@ 0x24
 80025ea:	2207      	movs	r2, #7
 80025ec:	f44f 60c0 	mov.w	r0, #1536	@ 0x600
 80025f0:	e9cd 0303 	strd	r0, r3, [sp, #12]
 80025f4:	e9cd 3206 	strd	r3, r2, [sp, #24]
 80025f8:	4d16      	ldr	r5, [pc, #88]	@ (8002654 <init_uart+0x70>)
 80025fa:	4817      	ldr	r0, [pc, #92]	@ (8002658 <init_uart+0x74>)
 80025fc:	2400      	movs	r4, #0
 80025fe:	2101      	movs	r1, #1
 8002600:	9401      	str	r4, [sp, #4]
 8002602:	9105      	str	r1, [sp, #20]
 8002604:	6b2b      	ldr	r3, [r5, #48]	@ 0x30
 8002606:	430b      	orrs	r3, r1
 8002608:	632b      	str	r3, [r5, #48]	@ 0x30
 800260a:	6b2b      	ldr	r3, [r5, #48]	@ 0x30
 800260c:	f003 0301 	and.w	r3, r3, #1
 8002610:	a903      	add	r1, sp, #12
 8002612:	9301      	str	r3, [sp, #4]
 8002614:	9b01      	ldr	r3, [sp, #4]
 8002616:	f000 fb47 	bl	8002ca8 <HAL_GPIO_Init>
 800261a:	9402      	str	r4, [sp, #8]
 800261c:	6c6a      	ldr	r2, [r5, #68]	@ 0x44
 800261e:	4b0f      	ldr	r3, [pc, #60]	@ (800265c <init_uart+0x78>)
 8002620:	490f      	ldr	r1, [pc, #60]	@ (8002660 <init_uart+0x7c>)
 8002622:	f44f 4016 	mov.w	r0, #38400	@ 0x9600
 8002626:	f042 0210 	orr.w	r2, r2, #16
 800262a:	6158      	str	r0, [r3, #20]
 800262c:	646a      	str	r2, [r5, #68]	@ 0x44
 800262e:	6c6a      	ldr	r2, [r5, #68]	@ 0x44
 8002630:	6119      	str	r1, [r3, #16]
 8002632:	f002 0210 	and.w	r2, r2, #16
 8002636:	210c      	movs	r1, #12
 8002638:	9202      	str	r2, [sp, #8]
 800263a:	f103 0010 	add.w	r0, r3, #16
 800263e:	e9c3 4406 	strd	r4, r4, [r3, #24]
 8002642:	e9c3 4108 	strd	r4, r1, [r3, #32]
 8002646:	9a02      	ldr	r2, [sp, #8]
 8002648:	629c      	str	r4, [r3, #40]	@ 0x28
 800264a:	f000 fc4f 	bl	8002eec <HAL_UART_Init>
 800264e:	b009      	add	sp, #36	@ 0x24
 8002650:	bd30      	pop	{r4, r5, pc}
 8002652:	bf00      	nop
 8002654:	40023800 	.word	0x40023800
 8002658:	40020000 	.word	0x40020000
 800265c:	20000978 	.word	0x20000978
 8002660:	40011000 	.word	0x40011000

08002664 <trigger_setup>:
 8002664:	b530      	push	{r4, r5, lr}
 8002666:	b089      	sub	sp, #36	@ 0x24
 8002668:	4b0d      	ldr	r3, [pc, #52]	@ (80026a0 <trigger_setup+0x3c>)
 800266a:	480e      	ldr	r0, [pc, #56]	@ (80026a4 <trigger_setup+0x40>)
 800266c:	2200      	movs	r2, #0
 800266e:	9201      	str	r2, [sp, #4]
 8002670:	6b1a      	ldr	r2, [r3, #48]	@ 0x30
 8002672:	f042 0201 	orr.w	r2, r2, #1
 8002676:	631a      	str	r2, [r3, #48]	@ 0x30
 8002678:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
 800267a:	f003 0301 	and.w	r3, r3, #1
 800267e:	9301      	str	r3, [sp, #4]
 8002680:	2200      	movs	r2, #0
 8002682:	f44f 5480 	mov.w	r4, #4096	@ 0x1000
 8002686:	2501      	movs	r5, #1
 8002688:	2302      	movs	r3, #2
 800268a:	a902      	add	r1, sp, #8
 800268c:	e9cd 2304 	strd	r2, r3, [sp, #16]
 8002690:	e9cd 4502 	strd	r4, r5, [sp, #8]
 8002694:	9b01      	ldr	r3, [sp, #4]
 8002696:	f000 fb07 	bl	8002ca8 <HAL_GPIO_Init>
 800269a:	b009      	add	sp, #36	@ 0x24
 800269c:	bd30      	pop	{r4, r5, pc}
 800269e:	bf00      	nop
 80026a0:	40023800 	.word	0x40023800
 80026a4:	40020000 	.word	0x40020000

080026a8 <trigger_high>:
 80026a8:	4802      	ldr	r0, [pc, #8]	@ (80026b4 <trigger_high+0xc>)
 80026aa:	2201      	movs	r2, #1
 80026ac:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
 80026b0:	f000 bc18 	b.w	8002ee4 <HAL_GPIO_WritePin>
 80026b4:	40020000 	.word	0x40020000

080026b8 <trigger_low>:
 80026b8:	4802      	ldr	r0, [pc, #8]	@ (80026c4 <trigger_low+0xc>)
 80026ba:	2200      	movs	r2, #0
 80026bc:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
 80026c0:	f000 bc10 	b.w	8002ee4 <HAL_GPIO_WritePin>
 80026c4:	40020000 	.word	0x40020000

080026c8 <getch>:
 80026c8:	b500      	push	{lr}
 80026ca:	b083      	sub	sp, #12
 80026cc:	4807      	ldr	r0, [pc, #28]	@ (80026ec <getch+0x24>)
 80026ce:	f241 3388 	movw	r3, #5000	@ 0x1388
 80026d2:	2201      	movs	r2, #1
 80026d4:	f10d 0107 	add.w	r1, sp, #7
 80026d8:	f000 fce0 	bl	800309c <HAL_UART_Receive>
 80026dc:	2800      	cmp	r0, #0
 80026de:	d1f5      	bne.n	80026cc <getch+0x4>
 80026e0:	f89d 0007 	ldrb.w	r0, [sp, #7]
 80026e4:	b003      	add	sp, #12
 80026e6:	f85d fb04 	ldr.w	pc, [sp], #4
 80026ea:	bf00      	nop
 80026ec:	20000988 	.word	0x20000988

080026f0 <putch>:
 80026f0:	b500      	push	{lr}
 80026f2:	b083      	sub	sp, #12
 80026f4:	4684      	mov	ip, r0
 80026f6:	f241 3388 	movw	r3, #5000	@ 0x1388
 80026fa:	2201      	movs	r2, #1
 80026fc:	f10d 0107 	add.w	r1, sp, #7
 8002700:	4803      	ldr	r0, [pc, #12]	@ (8002710 <putch+0x20>)
 8002702:	f88d c007 	strb.w	ip, [sp, #7]
 8002706:	f000 fc6d 	bl	8002fe4 <HAL_UART_Transmit>
 800270a:	b003      	add	sp, #12
 800270c:	f85d fb04 	ldr.w	pc, [sp], #4
 8002710:	20000988 	.word	0x20000988

08002714 <HAL_RCC_OscConfig>:
 8002714:	b4f0      	push	{r4, r5, r6, r7}
 8002716:	6805      	ldr	r5, [r0, #0]
 8002718:	07ea      	lsls	r2, r5, #31
 800271a:	b082      	sub	sp, #8
 800271c:	d53a      	bpl.n	8002794 <HAL_RCC_OscConfig+0x80>
 800271e:	4aa4      	ldr	r2, [pc, #656]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 8002720:	6893      	ldr	r3, [r2, #8]
 8002722:	f003 030c 	and.w	r3, r3, #12
 8002726:	2b04      	cmp	r3, #4
 8002728:	f000 80fd 	beq.w	8002926 <HAL_RCC_OscConfig+0x212>
 800272c:	6893      	ldr	r3, [r2, #8]
 800272e:	f003 030c 	and.w	r3, r3, #12
 8002732:	2b08      	cmp	r3, #8
 8002734:	f000 80f3 	beq.w	800291e <HAL_RCC_OscConfig+0x20a>
 8002738:	4a9e      	ldr	r2, [pc, #632]	@ (80029b4 <HAL_RCC_OscConfig+0x2a0>)
 800273a:	6841      	ldr	r1, [r0, #4]
 800273c:	6816      	ldr	r6, [r2, #0]
 800273e:	f5b1 3f80 	cmp.w	r1, #65536	@ 0x10000
 8002742:	f106 0301 	add.w	r3, r6, #1
 8002746:	f000 813f 	beq.w	80029c8 <HAL_RCC_OscConfig+0x2b4>
 800274a:	f5b1 2fa0 	cmp.w	r1, #327680	@ 0x50000
 800274e:	f000 8180 	beq.w	8002a52 <HAL_RCC_OscConfig+0x33e>
 8002752:	f8df c25c 	ldr.w	ip, [pc, #604]	@ 80029b0 <HAL_RCC_OscConfig+0x29c>
 8002756:	f8dc 4000 	ldr.w	r4, [ip]
 800275a:	f424 3480 	bic.w	r4, r4, #65536	@ 0x10000
 800275e:	f8cc 4000 	str.w	r4, [ip]
 8002762:	f8dc 4000 	ldr.w	r4, [ip]
 8002766:	f424 2480 	bic.w	r4, r4, #262144	@ 0x40000
 800276a:	f8cc 4000 	str.w	r4, [ip]
 800276e:	2900      	cmp	r1, #0
 8002770:	f040 812f 	bne.w	80029d2 <HAL_RCC_OscConfig+0x2be>
 8002774:	4f90      	ldr	r7, [pc, #576]	@ (80029b8 <HAL_RCC_OscConfig+0x2a4>)
 8002776:	6013      	str	r3, [r2, #0]
 8002778:	e004      	b.n	8002784 <HAL_RCC_OscConfig+0x70>
 800277a:	42bb      	cmp	r3, r7
 800277c:	6011      	str	r1, [r2, #0]
 800277e:	f200 80dd 	bhi.w	800293c <HAL_RCC_OscConfig+0x228>
 8002782:	460b      	mov	r3, r1
 8002784:	f8dc 4000 	ldr.w	r4, [ip]
 8002788:	03a4      	lsls	r4, r4, #14
 800278a:	f103 0101 	add.w	r1, r3, #1
 800278e:	eba3 0306 	sub.w	r3, r3, r6
 8002792:	d4f2      	bmi.n	800277a <HAL_RCC_OscConfig+0x66>
 8002794:	07ab      	lsls	r3, r5, #30
 8002796:	d531      	bpl.n	80027fc <HAL_RCC_OscConfig+0xe8>
 8002798:	4b85      	ldr	r3, [pc, #532]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 800279a:	689a      	ldr	r2, [r3, #8]
 800279c:	f012 0f0c 	tst.w	r2, #12
 80027a0:	f000 80d4 	beq.w	800294c <HAL_RCC_OscConfig+0x238>
 80027a4:	689a      	ldr	r2, [r3, #8]
 80027a6:	f002 020c 	and.w	r2, r2, #12
 80027aa:	2a08      	cmp	r2, #8
 80027ac:	f000 80ca 	beq.w	8002944 <HAL_RCC_OscConfig+0x230>
 80027b0:	68c3      	ldr	r3, [r0, #12]
 80027b2:	2b00      	cmp	r3, #0
 80027b4:	f000 811e 	beq.w	80029f4 <HAL_RCC_OscConfig+0x2e0>
 80027b8:	4b80      	ldr	r3, [pc, #512]	@ (80029bc <HAL_RCC_OscConfig+0x2a8>)
 80027ba:	4a7e      	ldr	r2, [pc, #504]	@ (80029b4 <HAL_RCC_OscConfig+0x2a0>)
 80027bc:	4d7c      	ldr	r5, [pc, #496]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 80027be:	2101      	movs	r1, #1
 80027c0:	6019      	str	r1, [r3, #0]
 80027c2:	6816      	ldr	r6, [r2, #0]
 80027c4:	1873      	adds	r3, r6, r1
 80027c6:	6013      	str	r3, [r2, #0]
 80027c8:	e004      	b.n	80027d4 <HAL_RCC_OscConfig+0xc0>
 80027ca:	2b02      	cmp	r3, #2
 80027cc:	6011      	str	r1, [r2, #0]
 80027ce:	f200 80b5 	bhi.w	800293c <HAL_RCC_OscConfig+0x228>
 80027d2:	460b      	mov	r3, r1
 80027d4:	682c      	ldr	r4, [r5, #0]
 80027d6:	07a7      	lsls	r7, r4, #30
 80027d8:	f103 0101 	add.w	r1, r3, #1
 80027dc:	eba3 0306 	sub.w	r3, r3, r6
 80027e0:	d5f3      	bpl.n	80027ca <HAL_RCC_OscConfig+0xb6>
 80027e2:	6829      	ldr	r1, [r5, #0]
 80027e4:	22f8      	movs	r2, #248	@ 0xf8
 80027e6:	fa92 f2a2 	rbit	r2, r2
 80027ea:	6903      	ldr	r3, [r0, #16]
 80027ec:	fab2 f282 	clz	r2, r2
 80027f0:	4093      	lsls	r3, r2
 80027f2:	f021 02f8 	bic.w	r2, r1, #248	@ 0xf8
 80027f6:	4313      	orrs	r3, r2
 80027f8:	602b      	str	r3, [r5, #0]
 80027fa:	6805      	ldr	r5, [r0, #0]
 80027fc:	072b      	lsls	r3, r5, #28
 80027fe:	d51d      	bpl.n	800283c <HAL_RCC_OscConfig+0x128>
 8002800:	6944      	ldr	r4, [r0, #20]
 8002802:	4b6e      	ldr	r3, [pc, #440]	@ (80029bc <HAL_RCC_OscConfig+0x2a8>)
 8002804:	4a6b      	ldr	r2, [pc, #428]	@ (80029b4 <HAL_RCC_OscConfig+0x2a0>)
 8002806:	2c00      	cmp	r4, #0
 8002808:	f000 80ab 	beq.w	8002962 <HAL_RCC_OscConfig+0x24e>
 800280c:	2101      	movs	r1, #1
 800280e:	f8c3 1e80 	str.w	r1, [r3, #3712]	@ 0xe80
 8002812:	6814      	ldr	r4, [r2, #0]
 8002814:	4e66      	ldr	r6, [pc, #408]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 8002816:	1863      	adds	r3, r4, r1
 8002818:	6013      	str	r3, [r2, #0]
 800281a:	3404      	adds	r4, #4
 800281c:	2500      	movs	r5, #0
 800281e:	e005      	b.n	800282c <HAL_RCC_OscConfig+0x118>
 8002820:	3301      	adds	r3, #1
 8002822:	42a3      	cmp	r3, r4
 8002824:	f04f 0501 	mov.w	r5, #1
 8002828:	f000 8087 	beq.w	800293a <HAL_RCC_OscConfig+0x226>
 800282c:	6f71      	ldr	r1, [r6, #116]	@ 0x74
 800282e:	078f      	lsls	r7, r1, #30
 8002830:	d5f6      	bpl.n	8002820 <HAL_RCC_OscConfig+0x10c>
 8002832:	2d00      	cmp	r5, #0
 8002834:	f000 816d 	beq.w	8002b12 <HAL_RCC_OscConfig+0x3fe>
 8002838:	6805      	ldr	r5, [r0, #0]
 800283a:	6013      	str	r3, [r2, #0]
 800283c:	076b      	lsls	r3, r5, #29
 800283e:	d54a      	bpl.n	80028d6 <HAL_RCC_OscConfig+0x1c2>
 8002840:	4b5b      	ldr	r3, [pc, #364]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 8002842:	4d5f      	ldr	r5, [pc, #380]	@ (80029c0 <HAL_RCC_OscConfig+0x2ac>)
 8002844:	2400      	movs	r4, #0
 8002846:	9401      	str	r4, [sp, #4]
 8002848:	6c1a      	ldr	r2, [r3, #64]	@ 0x40
 800284a:	f042 5280 	orr.w	r2, r2, #268435456	@ 0x10000000
 800284e:	641a      	str	r2, [r3, #64]	@ 0x40
 8002850:	6c1b      	ldr	r3, [r3, #64]	@ 0x40
 8002852:	4a58      	ldr	r2, [pc, #352]	@ (80029b4 <HAL_RCC_OscConfig+0x2a0>)
 8002854:	f003 5380 	and.w	r3, r3, #268435456	@ 0x10000000
 8002858:	9301      	str	r3, [sp, #4]
 800285a:	9b01      	ldr	r3, [sp, #4]
 800285c:	682b      	ldr	r3, [r5, #0]
 800285e:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
 8002862:	602b      	str	r3, [r5, #0]
 8002864:	6813      	ldr	r3, [r2, #0]
 8002866:	1c5e      	adds	r6, r3, #1
 8002868:	f103 0c04 	add.w	ip, r3, #4
 800286c:	6016      	str	r6, [r2, #0]
 800286e:	4633      	mov	r3, r6
 8002870:	e004      	b.n	800287c <HAL_RCC_OscConfig+0x168>
 8002872:	3301      	adds	r3, #1
 8002874:	4563      	cmp	r3, ip
 8002876:	f04f 0401 	mov.w	r4, #1
 800287a:	d05e      	beq.n	800293a <HAL_RCC_OscConfig+0x226>
 800287c:	6829      	ldr	r1, [r5, #0]
 800287e:	05cf      	lsls	r7, r1, #23
 8002880:	d5f7      	bpl.n	8002872 <HAL_RCC_OscConfig+0x15e>
 8002882:	2c00      	cmp	r4, #0
 8002884:	f000 80ef 	beq.w	8002a66 <HAL_RCC_OscConfig+0x352>
 8002888:	6013      	str	r3, [r2, #0]
 800288a:	6884      	ldr	r4, [r0, #8]
 800288c:	2c01      	cmp	r4, #1
 800288e:	f103 0601 	add.w	r6, r3, #1
 8002892:	f000 80c4 	beq.w	8002a1e <HAL_RCC_OscConfig+0x30a>
 8002896:	2c05      	cmp	r4, #5
 8002898:	f000 8131 	beq.w	8002afe <HAL_RCC_OscConfig+0x3ea>
 800289c:	4d44      	ldr	r5, [pc, #272]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 800289e:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 80028a0:	f021 0101 	bic.w	r1, r1, #1
 80028a4:	6729      	str	r1, [r5, #112]	@ 0x70
 80028a6:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 80028a8:	f021 0104 	bic.w	r1, r1, #4
 80028ac:	6729      	str	r1, [r5, #112]	@ 0x70
 80028ae:	2c00      	cmp	r4, #0
 80028b0:	f040 80ba 	bne.w	8002a28 <HAL_RCC_OscConfig+0x314>
 80028b4:	f503 539c 	add.w	r3, r3, #4992	@ 0x1380
 80028b8:	6016      	str	r6, [r2, #0]
 80028ba:	330a      	adds	r3, #10
 80028bc:	e005      	b.n	80028ca <HAL_RCC_OscConfig+0x1b6>
 80028be:	3601      	adds	r6, #1
 80028c0:	429e      	cmp	r6, r3
 80028c2:	f04f 0401 	mov.w	r4, #1
 80028c6:	f000 8118 	beq.w	8002afa <HAL_RCC_OscConfig+0x3e6>
 80028ca:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 80028cc:	078f      	lsls	r7, r1, #30
 80028ce:	d4f6      	bmi.n	80028be <HAL_RCC_OscConfig+0x1aa>
 80028d0:	2c00      	cmp	r4, #0
 80028d2:	f040 80bc 	bne.w	8002a4e <HAL_RCC_OscConfig+0x33a>
 80028d6:	6983      	ldr	r3, [r0, #24]
 80028d8:	b1eb      	cbz	r3, 8002916 <HAL_RCC_OscConfig+0x202>
 80028da:	4e35      	ldr	r6, [pc, #212]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 80028dc:	68b2      	ldr	r2, [r6, #8]
 80028de:	f002 020c 	and.w	r2, r2, #12
 80028e2:	2a08      	cmp	r2, #8
 80028e4:	d039      	beq.n	800295a <HAL_RCC_OscConfig+0x246>
 80028e6:	2b02      	cmp	r3, #2
 80028e8:	4b34      	ldr	r3, [pc, #208]	@ (80029bc <HAL_RCC_OscConfig+0x2a8>)
 80028ea:	4a32      	ldr	r2, [pc, #200]	@ (80029b4 <HAL_RCC_OscConfig+0x2a0>)
 80028ec:	f04f 0100 	mov.w	r1, #0
 80028f0:	6619      	str	r1, [r3, #96]	@ 0x60
 80028f2:	f000 80ba 	beq.w	8002a6a <HAL_RCC_OscConfig+0x356>
 80028f6:	6814      	ldr	r4, [r2, #0]
 80028f8:	4d32      	ldr	r5, [pc, #200]	@ (80029c4 <HAL_RCC_OscConfig+0x2b0>)
 80028fa:	1c63      	adds	r3, r4, #1
 80028fc:	6013      	str	r3, [r2, #0]
 80028fe:	e003      	b.n	8002908 <HAL_RCC_OscConfig+0x1f4>
 8002900:	42ab      	cmp	r3, r5
 8002902:	6011      	str	r1, [r2, #0]
 8002904:	d81a      	bhi.n	800293c <HAL_RCC_OscConfig+0x228>
 8002906:	460b      	mov	r3, r1
 8002908:	6830      	ldr	r0, [r6, #0]
 800290a:	0180      	lsls	r0, r0, #6
 800290c:	f103 0101 	add.w	r1, r3, #1
 8002910:	eba3 0304 	sub.w	r3, r3, r4
 8002914:	d4f4      	bmi.n	8002900 <HAL_RCC_OscConfig+0x1ec>
 8002916:	2000      	movs	r0, #0
 8002918:	b002      	add	sp, #8
 800291a:	bcf0      	pop	{r4, r5, r6, r7}
 800291c:	4770      	bx	lr
 800291e:	6853      	ldr	r3, [r2, #4]
 8002920:	025f      	lsls	r7, r3, #9
 8002922:	f57f af09 	bpl.w	8002738 <HAL_RCC_OscConfig+0x24>
 8002926:	4b22      	ldr	r3, [pc, #136]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 8002928:	681b      	ldr	r3, [r3, #0]
 800292a:	039e      	lsls	r6, r3, #14
 800292c:	f57f af32 	bpl.w	8002794 <HAL_RCC_OscConfig+0x80>
 8002930:	6843      	ldr	r3, [r0, #4]
 8002932:	2b00      	cmp	r3, #0
 8002934:	f47f af2e 	bne.w	8002794 <HAL_RCC_OscConfig+0x80>
 8002938:	e00f      	b.n	800295a <HAL_RCC_OscConfig+0x246>
 800293a:	6013      	str	r3, [r2, #0]
 800293c:	2003      	movs	r0, #3
 800293e:	b002      	add	sp, #8
 8002940:	bcf0      	pop	{r4, r5, r6, r7}
 8002942:	4770      	bx	lr
 8002944:	685b      	ldr	r3, [r3, #4]
 8002946:	025a      	lsls	r2, r3, #9
 8002948:	f53f af32 	bmi.w	80027b0 <HAL_RCC_OscConfig+0x9c>
 800294c:	4b18      	ldr	r3, [pc, #96]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 800294e:	681b      	ldr	r3, [r3, #0]
 8002950:	079b      	lsls	r3, r3, #30
 8002952:	d51c      	bpl.n	800298e <HAL_RCC_OscConfig+0x27a>
 8002954:	68c3      	ldr	r3, [r0, #12]
 8002956:	2b01      	cmp	r3, #1
 8002958:	d019      	beq.n	800298e <HAL_RCC_OscConfig+0x27a>
 800295a:	2001      	movs	r0, #1
 800295c:	b002      	add	sp, #8
 800295e:	bcf0      	pop	{r4, r5, r6, r7}
 8002960:	4770      	bx	lr
 8002962:	f8c3 4e80 	str.w	r4, [r3, #3712]	@ 0xe80
 8002966:	6815      	ldr	r5, [r2, #0]
 8002968:	4e11      	ldr	r6, [pc, #68]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 800296a:	1c6b      	adds	r3, r5, #1
 800296c:	6013      	str	r3, [r2, #0]
 800296e:	3504      	adds	r5, #4
 8002970:	e004      	b.n	800297c <HAL_RCC_OscConfig+0x268>
 8002972:	3301      	adds	r3, #1
 8002974:	42ab      	cmp	r3, r5
 8002976:	f04f 0401 	mov.w	r4, #1
 800297a:	d0de      	beq.n	800293a <HAL_RCC_OscConfig+0x226>
 800297c:	6f71      	ldr	r1, [r6, #116]	@ 0x74
 800297e:	0789      	lsls	r1, r1, #30
 8002980:	d4f7      	bmi.n	8002972 <HAL_RCC_OscConfig+0x25e>
 8002982:	6805      	ldr	r5, [r0, #0]
 8002984:	2c00      	cmp	r4, #0
 8002986:	f43f af59 	beq.w	800283c <HAL_RCC_OscConfig+0x128>
 800298a:	6013      	str	r3, [r2, #0]
 800298c:	e756      	b.n	800283c <HAL_RCC_OscConfig+0x128>
 800298e:	4c08      	ldr	r4, [pc, #32]	@ (80029b0 <HAL_RCC_OscConfig+0x29c>)
 8002990:	22f8      	movs	r2, #248	@ 0xf8
 8002992:	6821      	ldr	r1, [r4, #0]
 8002994:	fa92 f2a2 	rbit	r2, r2
 8002998:	6903      	ldr	r3, [r0, #16]
 800299a:	fab2 f282 	clz	r2, r2
 800299e:	f021 01f8 	bic.w	r1, r1, #248	@ 0xf8
 80029a2:	4093      	lsls	r3, r2
 80029a4:	430b      	orrs	r3, r1
 80029a6:	6023      	str	r3, [r4, #0]
 80029a8:	072b      	lsls	r3, r5, #28
 80029aa:	f57f af47 	bpl.w	800283c <HAL_RCC_OscConfig+0x128>
 80029ae:	e727      	b.n	8002800 <HAL_RCC_OscConfig+0xec>
 80029b0:	40023800 	.word	0x40023800
 80029b4:	20000a18 	.word	0x20000a18
 80029b8:	05f5e100 	.word	0x05f5e100
 80029bc:	42470000 	.word	0x42470000
 80029c0:	40007000 	.word	0x40007000
 80029c4:	001e8480 	.word	0x001e8480
 80029c8:	4c53      	ldr	r4, [pc, #332]	@ (8002b18 <HAL_RCC_OscConfig+0x404>)
 80029ca:	6821      	ldr	r1, [r4, #0]
 80029cc:	f441 3180 	orr.w	r1, r1, #65536	@ 0x10000
 80029d0:	6021      	str	r1, [r4, #0]
 80029d2:	4f51      	ldr	r7, [pc, #324]	@ (8002b18 <HAL_RCC_OscConfig+0x404>)
 80029d4:	f8df c144 	ldr.w	ip, [pc, #324]	@ 8002b1c <HAL_RCC_OscConfig+0x408>
 80029d8:	6013      	str	r3, [r2, #0]
 80029da:	e003      	b.n	80029e4 <HAL_RCC_OscConfig+0x2d0>
 80029dc:	4563      	cmp	r3, ip
 80029de:	6011      	str	r1, [r2, #0]
 80029e0:	d8ac      	bhi.n	800293c <HAL_RCC_OscConfig+0x228>
 80029e2:	460b      	mov	r3, r1
 80029e4:	683c      	ldr	r4, [r7, #0]
 80029e6:	03a4      	lsls	r4, r4, #14
 80029e8:	f103 0101 	add.w	r1, r3, #1
 80029ec:	eba3 0306 	sub.w	r3, r3, r6
 80029f0:	d5f4      	bpl.n	80029dc <HAL_RCC_OscConfig+0x2c8>
 80029f2:	e6cf      	b.n	8002794 <HAL_RCC_OscConfig+0x80>
 80029f4:	494a      	ldr	r1, [pc, #296]	@ (8002b20 <HAL_RCC_OscConfig+0x40c>)
 80029f6:	4a4b      	ldr	r2, [pc, #300]	@ (8002b24 <HAL_RCC_OscConfig+0x410>)
 80029f8:	600b      	str	r3, [r1, #0]
 80029fa:	6815      	ldr	r5, [r2, #0]
 80029fc:	4e46      	ldr	r6, [pc, #280]	@ (8002b18 <HAL_RCC_OscConfig+0x404>)
 80029fe:	1c6b      	adds	r3, r5, #1
 8002a00:	6013      	str	r3, [r2, #0]
 8002a02:	e003      	b.n	8002a0c <HAL_RCC_OscConfig+0x2f8>
 8002a04:	2b02      	cmp	r3, #2
 8002a06:	6011      	str	r1, [r2, #0]
 8002a08:	d898      	bhi.n	800293c <HAL_RCC_OscConfig+0x228>
 8002a0a:	460b      	mov	r3, r1
 8002a0c:	6834      	ldr	r4, [r6, #0]
 8002a0e:	07a4      	lsls	r4, r4, #30
 8002a10:	f103 0101 	add.w	r1, r3, #1
 8002a14:	eba3 0305 	sub.w	r3, r3, r5
 8002a18:	d4f4      	bmi.n	8002a04 <HAL_RCC_OscConfig+0x2f0>
 8002a1a:	6805      	ldr	r5, [r0, #0]
 8002a1c:	e6ee      	b.n	80027fc <HAL_RCC_OscConfig+0xe8>
 8002a1e:	4c3e      	ldr	r4, [pc, #248]	@ (8002b18 <HAL_RCC_OscConfig+0x404>)
 8002a20:	6f21      	ldr	r1, [r4, #112]	@ 0x70
 8002a22:	f041 0101 	orr.w	r1, r1, #1
 8002a26:	6721      	str	r1, [r4, #112]	@ 0x70
 8002a28:	f503 539c 	add.w	r3, r3, #4992	@ 0x1380
 8002a2c:	4c3a      	ldr	r4, [pc, #232]	@ (8002b18 <HAL_RCC_OscConfig+0x404>)
 8002a2e:	6016      	str	r6, [r2, #0]
 8002a30:	330a      	adds	r3, #10
 8002a32:	2500      	movs	r5, #0
 8002a34:	e005      	b.n	8002a42 <HAL_RCC_OscConfig+0x32e>
 8002a36:	3601      	adds	r6, #1
 8002a38:	42b3      	cmp	r3, r6
 8002a3a:	f04f 0501 	mov.w	r5, #1
 8002a3e:	f43f af7c 	beq.w	800293a <HAL_RCC_OscConfig+0x226>
 8002a42:	6f21      	ldr	r1, [r4, #112]	@ 0x70
 8002a44:	0789      	lsls	r1, r1, #30
 8002a46:	d5f6      	bpl.n	8002a36 <HAL_RCC_OscConfig+0x322>
 8002a48:	2d00      	cmp	r5, #0
 8002a4a:	f43f af44 	beq.w	80028d6 <HAL_RCC_OscConfig+0x1c2>
 8002a4e:	6016      	str	r6, [r2, #0]
 8002a50:	e741      	b.n	80028d6 <HAL_RCC_OscConfig+0x1c2>
 8002a52:	4931      	ldr	r1, [pc, #196]	@ (8002b18 <HAL_RCC_OscConfig+0x404>)
 8002a54:	680c      	ldr	r4, [r1, #0]
 8002a56:	f444 2480 	orr.w	r4, r4, #262144	@ 0x40000
 8002a5a:	600c      	str	r4, [r1, #0]
 8002a5c:	680c      	ldr	r4, [r1, #0]
 8002a5e:	f444 3480 	orr.w	r4, r4, #65536	@ 0x10000
 8002a62:	600c      	str	r4, [r1, #0]
 8002a64:	e7b5      	b.n	80029d2 <HAL_RCC_OscConfig+0x2be>
 8002a66:	4633      	mov	r3, r6
 8002a68:	e70f      	b.n	800288a <HAL_RCC_OscConfig+0x176>
 8002a6a:	6815      	ldr	r5, [r2, #0]
 8002a6c:	4f2e      	ldr	r7, [pc, #184]	@ (8002b28 <HAL_RCC_OscConfig+0x414>)
 8002a6e:	1c6b      	adds	r3, r5, #1
 8002a70:	6013      	str	r3, [r2, #0]
 8002a72:	e004      	b.n	8002a7e <HAL_RCC_OscConfig+0x36a>
 8002a74:	42bb      	cmp	r3, r7
 8002a76:	6011      	str	r1, [r2, #0]
 8002a78:	f63f af60 	bhi.w	800293c <HAL_RCC_OscConfig+0x228>
 8002a7c:	460b      	mov	r3, r1
 8002a7e:	6834      	ldr	r4, [r6, #0]
 8002a80:	01a4      	lsls	r4, r4, #6
 8002a82:	f103 0101 	add.w	r1, r3, #1
 8002a86:	eba3 0305 	sub.w	r3, r3, r5
 8002a8a:	d4f3      	bmi.n	8002a74 <HAL_RCC_OscConfig+0x360>
 8002a8c:	f647 75c0 	movw	r5, #32704	@ 0x7fc0
 8002a90:	fa95 f5a5 	rbit	r5, r5
 8002a94:	f44f 3740 	mov.w	r7, #196608	@ 0x30000
 8002a98:	fab5 f585 	clz	r5, r5
 8002a9c:	fa97 f7a7 	rbit	r7, r7
 8002aa0:	f04f 6470 	mov.w	r4, #251658240	@ 0xf000000
 8002aa4:	fab7 f787 	clz	r7, r7
 8002aa8:	fa94 f4a4 	rbit	r4, r4
 8002aac:	6a83      	ldr	r3, [r0, #40]	@ 0x28
 8002aae:	0859      	lsrs	r1, r3, #1
 8002ab0:	3901      	subs	r1, #1
 8002ab2:	40b9      	lsls	r1, r7
 8002ab4:	e9d0 3707 	ldrd	r3, r7, [r0, #28]
 8002ab8:	433b      	orrs	r3, r7
 8002aba:	6a47      	ldr	r7, [r0, #36]	@ 0x24
 8002abc:	40af      	lsls	r7, r5
 8002abe:	433b      	orrs	r3, r7
 8002ac0:	430b      	orrs	r3, r1
 8002ac2:	6ac1      	ldr	r1, [r0, #44]	@ 0x2c
 8002ac4:	4816      	ldr	r0, [pc, #88]	@ (8002b20 <HAL_RCC_OscConfig+0x40c>)
 8002ac6:	4d14      	ldr	r5, [pc, #80]	@ (8002b18 <HAL_RCC_OscConfig+0x404>)
 8002ac8:	fab4 f484 	clz	r4, r4
 8002acc:	40a1      	lsls	r1, r4
 8002ace:	430b      	orrs	r3, r1
 8002ad0:	6073      	str	r3, [r6, #4]
 8002ad2:	2301      	movs	r3, #1
 8002ad4:	6603      	str	r3, [r0, #96]	@ 0x60
 8002ad6:	6814      	ldr	r4, [r2, #0]
 8002ad8:	4e13      	ldr	r6, [pc, #76]	@ (8002b28 <HAL_RCC_OscConfig+0x414>)
 8002ada:	18e3      	adds	r3, r4, r3
 8002adc:	6013      	str	r3, [r2, #0]
 8002ade:	e004      	b.n	8002aea <HAL_RCC_OscConfig+0x3d6>
 8002ae0:	42b3      	cmp	r3, r6
 8002ae2:	6011      	str	r1, [r2, #0]
 8002ae4:	f63f af2a 	bhi.w	800293c <HAL_RCC_OscConfig+0x228>
 8002ae8:	460b      	mov	r3, r1
 8002aea:	6828      	ldr	r0, [r5, #0]
 8002aec:	0187      	lsls	r7, r0, #6
 8002aee:	f103 0101 	add.w	r1, r3, #1
 8002af2:	eba3 0304 	sub.w	r3, r3, r4
 8002af6:	d5f3      	bpl.n	8002ae0 <HAL_RCC_OscConfig+0x3cc>
 8002af8:	e70d      	b.n	8002916 <HAL_RCC_OscConfig+0x202>
 8002afa:	6016      	str	r6, [r2, #0]
 8002afc:	e71e      	b.n	800293c <HAL_RCC_OscConfig+0x228>
 8002afe:	4906      	ldr	r1, [pc, #24]	@ (8002b18 <HAL_RCC_OscConfig+0x404>)
 8002b00:	6f0c      	ldr	r4, [r1, #112]	@ 0x70
 8002b02:	f044 0404 	orr.w	r4, r4, #4
 8002b06:	670c      	str	r4, [r1, #112]	@ 0x70
 8002b08:	6f0c      	ldr	r4, [r1, #112]	@ 0x70
 8002b0a:	f044 0401 	orr.w	r4, r4, #1
 8002b0e:	670c      	str	r4, [r1, #112]	@ 0x70
 8002b10:	e78a      	b.n	8002a28 <HAL_RCC_OscConfig+0x314>
 8002b12:	6805      	ldr	r5, [r0, #0]
 8002b14:	e692      	b.n	800283c <HAL_RCC_OscConfig+0x128>
 8002b16:	bf00      	nop
 8002b18:	40023800 	.word	0x40023800
 8002b1c:	05f5e100 	.word	0x05f5e100
 8002b20:	42470000 	.word	0x42470000
 8002b24:	20000a18 	.word	0x20000a18
 8002b28:	001e8480 	.word	0x001e8480

08002b2c <HAL_RCC_ClockConfig>:
 8002b2c:	4a5b      	ldr	r2, [pc, #364]	@ (8002c9c <HAL_RCC_ClockConfig+0x170>)
 8002b2e:	6813      	ldr	r3, [r2, #0]
 8002b30:	f003 030f 	and.w	r3, r3, #15
 8002b34:	428b      	cmp	r3, r1
 8002b36:	d208      	bcs.n	8002b4a <HAL_RCC_ClockConfig+0x1e>
 8002b38:	b2cb      	uxtb	r3, r1
 8002b3a:	7013      	strb	r3, [r2, #0]
 8002b3c:	6813      	ldr	r3, [r2, #0]
 8002b3e:	f003 030f 	and.w	r3, r3, #15
 8002b42:	428b      	cmp	r3, r1
 8002b44:	d001      	beq.n	8002b4a <HAL_RCC_ClockConfig+0x1e>
 8002b46:	2001      	movs	r0, #1
 8002b48:	4770      	bx	lr
 8002b4a:	b5f0      	push	{r4, r5, r6, r7, lr}
 8002b4c:	6804      	ldr	r4, [r0, #0]
 8002b4e:	07a5      	lsls	r5, r4, #30
 8002b50:	d506      	bpl.n	8002b60 <HAL_RCC_ClockConfig+0x34>
 8002b52:	4a53      	ldr	r2, [pc, #332]	@ (8002ca0 <HAL_RCC_ClockConfig+0x174>)
 8002b54:	6885      	ldr	r5, [r0, #8]
 8002b56:	6893      	ldr	r3, [r2, #8]
 8002b58:	f023 03f0 	bic.w	r3, r3, #240	@ 0xf0
 8002b5c:	432b      	orrs	r3, r5
 8002b5e:	6093      	str	r3, [r2, #8]
 8002b60:	07e2      	lsls	r2, r4, #31
 8002b62:	d526      	bpl.n	8002bb2 <HAL_RCC_ClockConfig+0x86>
 8002b64:	6842      	ldr	r2, [r0, #4]
 8002b66:	2a01      	cmp	r2, #1
 8002b68:	d075      	beq.n	8002c56 <HAL_RCC_ClockConfig+0x12a>
 8002b6a:	1e93      	subs	r3, r2, #2
 8002b6c:	4e4c      	ldr	r6, [pc, #304]	@ (8002ca0 <HAL_RCC_ClockConfig+0x174>)
 8002b6e:	2b01      	cmp	r3, #1
 8002b70:	6833      	ldr	r3, [r6, #0]
 8002b72:	d943      	bls.n	8002bfc <HAL_RCC_ClockConfig+0xd0>
 8002b74:	079d      	lsls	r5, r3, #30
 8002b76:	d529      	bpl.n	8002bcc <HAL_RCC_ClockConfig+0xa0>
 8002b78:	68b3      	ldr	r3, [r6, #8]
 8002b7a:	4d4a      	ldr	r5, [pc, #296]	@ (8002ca4 <HAL_RCC_ClockConfig+0x178>)
 8002b7c:	f023 0303 	bic.w	r3, r3, #3
 8002b80:	4313      	orrs	r3, r2
 8002b82:	60b3      	str	r3, [r6, #8]
 8002b84:	682f      	ldr	r7, [r5, #0]
 8002b86:	1c7b      	adds	r3, r7, #1
 8002b88:	f04f 0c00 	mov.w	ip, #0
 8002b8c:	f241 3e88 	movw	lr, #5000	@ 0x1388
 8002b90:	602b      	str	r3, [r5, #0]
 8002b92:	e006      	b.n	8002ba2 <HAL_RCC_ClockConfig+0x76>
 8002b94:	3301      	adds	r3, #1
 8002b96:	1bda      	subs	r2, r3, r7
 8002b98:	3a01      	subs	r2, #1
 8002b9a:	4572      	cmp	r2, lr
 8002b9c:	f04f 0c01 	mov.w	ip, #1
 8002ba0:	d878      	bhi.n	8002c94 <HAL_RCC_ClockConfig+0x168>
 8002ba2:	68b2      	ldr	r2, [r6, #8]
 8002ba4:	f012 0f0c 	tst.w	r2, #12
 8002ba8:	d1f4      	bne.n	8002b94 <HAL_RCC_ClockConfig+0x68>
 8002baa:	f1bc 0f00 	cmp.w	ip, #0
 8002bae:	d000      	beq.n	8002bb2 <HAL_RCC_ClockConfig+0x86>
 8002bb0:	602b      	str	r3, [r5, #0]
 8002bb2:	4a3a      	ldr	r2, [pc, #232]	@ (8002c9c <HAL_RCC_ClockConfig+0x170>)
 8002bb4:	6813      	ldr	r3, [r2, #0]
 8002bb6:	f003 030f 	and.w	r3, r3, #15
 8002bba:	428b      	cmp	r3, r1
 8002bbc:	d909      	bls.n	8002bd2 <HAL_RCC_ClockConfig+0xa6>
 8002bbe:	b2cb      	uxtb	r3, r1
 8002bc0:	7013      	strb	r3, [r2, #0]
 8002bc2:	6813      	ldr	r3, [r2, #0]
 8002bc4:	f003 030f 	and.w	r3, r3, #15
 8002bc8:	428b      	cmp	r3, r1
 8002bca:	d001      	beq.n	8002bd0 <HAL_RCC_ClockConfig+0xa4>
 8002bcc:	2001      	movs	r0, #1
 8002bce:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002bd0:	6804      	ldr	r4, [r0, #0]
 8002bd2:	0762      	lsls	r2, r4, #29
 8002bd4:	d506      	bpl.n	8002be4 <HAL_RCC_ClockConfig+0xb8>
 8002bd6:	4a32      	ldr	r2, [pc, #200]	@ (8002ca0 <HAL_RCC_ClockConfig+0x174>)
 8002bd8:	68c1      	ldr	r1, [r0, #12]
 8002bda:	6893      	ldr	r3, [r2, #8]
 8002bdc:	f423 53e0 	bic.w	r3, r3, #7168	@ 0x1c00
 8002be0:	430b      	orrs	r3, r1
 8002be2:	6093      	str	r3, [r2, #8]
 8002be4:	0723      	lsls	r3, r4, #28
 8002be6:	d507      	bpl.n	8002bf8 <HAL_RCC_ClockConfig+0xcc>
 8002be8:	4a2d      	ldr	r2, [pc, #180]	@ (8002ca0 <HAL_RCC_ClockConfig+0x174>)
 8002bea:	6901      	ldr	r1, [r0, #16]
 8002bec:	6893      	ldr	r3, [r2, #8]
 8002bee:	f423 4360 	bic.w	r3, r3, #57344	@ 0xe000
 8002bf2:	ea43 03c1 	orr.w	r3, r3, r1, lsl #3
 8002bf6:	6093      	str	r3, [r2, #8]
 8002bf8:	2000      	movs	r0, #0
 8002bfa:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002bfc:	019f      	lsls	r7, r3, #6
 8002bfe:	d5e5      	bpl.n	8002bcc <HAL_RCC_ClockConfig+0xa0>
 8002c00:	68b3      	ldr	r3, [r6, #8]
 8002c02:	4d28      	ldr	r5, [pc, #160]	@ (8002ca4 <HAL_RCC_ClockConfig+0x178>)
 8002c04:	f023 0303 	bic.w	r3, r3, #3
 8002c08:	4313      	orrs	r3, r2
 8002c0a:	60b3      	str	r3, [r6, #8]
 8002c0c:	682f      	ldr	r7, [r5, #0]
 8002c0e:	2a02      	cmp	r2, #2
 8002c10:	f107 0301 	add.w	r3, r7, #1
 8002c14:	602b      	str	r3, [r5, #0]
 8002c16:	f04f 0c00 	mov.w	ip, #0
 8002c1a:	f241 3e88 	movw	lr, #5000	@ 0x1388
 8002c1e:	d007      	beq.n	8002c30 <HAL_RCC_ClockConfig+0x104>
 8002c20:	e013      	b.n	8002c4a <HAL_RCC_ClockConfig+0x11e>
 8002c22:	3301      	adds	r3, #1
 8002c24:	1bda      	subs	r2, r3, r7
 8002c26:	3a01      	subs	r2, #1
 8002c28:	4572      	cmp	r2, lr
 8002c2a:	f04f 0c01 	mov.w	ip, #1
 8002c2e:	d831      	bhi.n	8002c94 <HAL_RCC_ClockConfig+0x168>
 8002c30:	68b2      	ldr	r2, [r6, #8]
 8002c32:	f002 020c 	and.w	r2, r2, #12
 8002c36:	2a08      	cmp	r2, #8
 8002c38:	d1f3      	bne.n	8002c22 <HAL_RCC_ClockConfig+0xf6>
 8002c3a:	e7b6      	b.n	8002baa <HAL_RCC_ClockConfig+0x7e>
 8002c3c:	3301      	adds	r3, #1
 8002c3e:	1bda      	subs	r2, r3, r7
 8002c40:	3a01      	subs	r2, #1
 8002c42:	4572      	cmp	r2, lr
 8002c44:	f04f 0c01 	mov.w	ip, #1
 8002c48:	d824      	bhi.n	8002c94 <HAL_RCC_ClockConfig+0x168>
 8002c4a:	68b2      	ldr	r2, [r6, #8]
 8002c4c:	f002 020c 	and.w	r2, r2, #12
 8002c50:	2a0c      	cmp	r2, #12
 8002c52:	d1f3      	bne.n	8002c3c <HAL_RCC_ClockConfig+0x110>
 8002c54:	e7a9      	b.n	8002baa <HAL_RCC_ClockConfig+0x7e>
 8002c56:	4f12      	ldr	r7, [pc, #72]	@ (8002ca0 <HAL_RCC_ClockConfig+0x174>)
 8002c58:	683b      	ldr	r3, [r7, #0]
 8002c5a:	039b      	lsls	r3, r3, #14
 8002c5c:	d5b6      	bpl.n	8002bcc <HAL_RCC_ClockConfig+0xa0>
 8002c5e:	68bb      	ldr	r3, [r7, #8]
 8002c60:	4d10      	ldr	r5, [pc, #64]	@ (8002ca4 <HAL_RCC_ClockConfig+0x178>)
 8002c62:	f023 0303 	bic.w	r3, r3, #3
 8002c66:	f043 0301 	orr.w	r3, r3, #1
 8002c6a:	60bb      	str	r3, [r7, #8]
 8002c6c:	682e      	ldr	r6, [r5, #0]
 8002c6e:	1c73      	adds	r3, r6, #1
 8002c70:	f506 569c 	add.w	r6, r6, #4992	@ 0x1380
 8002c74:	f04f 0c00 	mov.w	ip, #0
 8002c78:	602b      	str	r3, [r5, #0]
 8002c7a:	360a      	adds	r6, #10
 8002c7c:	e004      	b.n	8002c88 <HAL_RCC_ClockConfig+0x15c>
 8002c7e:	3301      	adds	r3, #1
 8002c80:	429e      	cmp	r6, r3
 8002c82:	f04f 0c01 	mov.w	ip, #1
 8002c86:	d005      	beq.n	8002c94 <HAL_RCC_ClockConfig+0x168>
 8002c88:	68ba      	ldr	r2, [r7, #8]
 8002c8a:	f002 020c 	and.w	r2, r2, #12
 8002c8e:	2a04      	cmp	r2, #4
 8002c90:	d1f5      	bne.n	8002c7e <HAL_RCC_ClockConfig+0x152>
 8002c92:	e78a      	b.n	8002baa <HAL_RCC_ClockConfig+0x7e>
 8002c94:	602b      	str	r3, [r5, #0]
 8002c96:	2003      	movs	r0, #3
 8002c98:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002c9a:	bf00      	nop
 8002c9c:	40023c00 	.word	0x40023c00
 8002ca0:	40023800 	.word	0x40023800
 8002ca4:	20000a18 	.word	0x20000a18

08002ca8 <HAL_GPIO_Init>:
 8002ca8:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002cac:	2300      	movs	r3, #0
 8002cae:	680c      	ldr	r4, [r1, #0]
 8002cb0:	f8df b20c 	ldr.w	fp, [pc, #524]	@ 8002ec0 <HAL_GPIO_Init+0x218>
 8002cb4:	b085      	sub	sp, #20
 8002cb6:	468a      	mov	sl, r1
 8002cb8:	e003      	b.n	8002cc2 <HAL_GPIO_Init+0x1a>
 8002cba:	3301      	adds	r3, #1
 8002cbc:	2b10      	cmp	r3, #16
 8002cbe:	f000 80a2 	beq.w	8002e06 <HAL_GPIO_Init+0x15e>
 8002cc2:	2201      	movs	r2, #1
 8002cc4:	fa02 f103 	lsl.w	r1, r2, r3
 8002cc8:	ea31 0204 	bics.w	r2, r1, r4
 8002ccc:	ea01 0704 	and.w	r7, r1, r4
 8002cd0:	d1f3      	bne.n	8002cba <HAL_GPIO_Init+0x12>
 8002cd2:	f8da 2004 	ldr.w	r2, [sl, #4]
 8002cd6:	f8da 5008 	ldr.w	r5, [sl, #8]
 8002cda:	005e      	lsls	r6, r3, #1
 8002cdc:	fa05 fc06 	lsl.w	ip, r5, r6
 8002ce0:	f022 0810 	bic.w	r8, r2, #16
 8002ce4:	2503      	movs	r5, #3
 8002ce6:	40b5      	lsls	r5, r6
 8002ce8:	f002 0e03 	and.w	lr, r2, #3
 8002cec:	f1b8 0f02 	cmp.w	r8, #2
 8002cf0:	ea6f 0505 	mvn.w	r5, r5
 8002cf4:	fa0e fe06 	lsl.w	lr, lr, r6
 8002cf8:	f000 8088 	beq.w	8002e0c <HAL_GPIO_Init+0x164>
 8002cfc:	f8d0 9000 	ldr.w	r9, [r0]
 8002d00:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 8002d04:	ea09 0905 	and.w	r9, r9, r5
 8002d08:	ea49 0e0e 	orr.w	lr, r9, lr
 8002d0c:	f1b8 0f01 	cmp.w	r8, #1
 8002d10:	f8c0 e000 	str.w	lr, [r0]
 8002d14:	f240 809a 	bls.w	8002e4c <HAL_GPIO_Init+0x1a4>
 8002d18:	68c1      	ldr	r1, [r0, #12]
 8002d1a:	4029      	ands	r1, r5
 8002d1c:	ea41 010c 	orr.w	r1, r1, ip
 8002d20:	60c1      	str	r1, [r0, #12]
 8002d22:	00d1      	lsls	r1, r2, #3
 8002d24:	d5c9      	bpl.n	8002cba <HAL_GPIO_Init+0x12>
 8002d26:	4d67      	ldr	r5, [pc, #412]	@ (8002ec4 <HAL_GPIO_Init+0x21c>)
 8002d28:	2100      	movs	r1, #0
 8002d2a:	9103      	str	r1, [sp, #12]
 8002d2c:	6c69      	ldr	r1, [r5, #68]	@ 0x44
 8002d2e:	f441 4180 	orr.w	r1, r1, #16384	@ 0x4000
 8002d32:	6469      	str	r1, [r5, #68]	@ 0x44
 8002d34:	6c69      	ldr	r1, [r5, #68]	@ 0x44
 8002d36:	f401 4180 	and.w	r1, r1, #16384	@ 0x4000
 8002d3a:	9103      	str	r1, [sp, #12]
 8002d3c:	9903      	ldr	r1, [sp, #12]
 8002d3e:	f023 0103 	bic.w	r1, r3, #3
 8002d42:	f101 4180 	add.w	r1, r1, #1073741824	@ 0x40000000
 8002d46:	f501 319c 	add.w	r1, r1, #79872	@ 0x13800
 8002d4a:	f003 0603 	and.w	r6, r3, #3
 8002d4e:	688d      	ldr	r5, [r1, #8]
 8002d50:	00b6      	lsls	r6, r6, #2
 8002d52:	f04f 0c0f 	mov.w	ip, #15
 8002d56:	fa0c fc06 	lsl.w	ip, ip, r6
 8002d5a:	ea25 050c 	bic.w	r5, r5, ip
 8002d5e:	f8df c168 	ldr.w	ip, [pc, #360]	@ 8002ec8 <HAL_GPIO_Init+0x220>
 8002d62:	4560      	cmp	r0, ip
 8002d64:	d028      	beq.n	8002db8 <HAL_GPIO_Init+0x110>
 8002d66:	f50c 6c80 	add.w	ip, ip, #1024	@ 0x400
 8002d6a:	4560      	cmp	r0, ip
 8002d6c:	f000 8084 	beq.w	8002e78 <HAL_GPIO_Init+0x1d0>
 8002d70:	f8df c158 	ldr.w	ip, [pc, #344]	@ 8002ecc <HAL_GPIO_Init+0x224>
 8002d74:	4560      	cmp	r0, ip
 8002d76:	f000 8085 	beq.w	8002e84 <HAL_GPIO_Init+0x1dc>
 8002d7a:	f8df c154 	ldr.w	ip, [pc, #340]	@ 8002ed0 <HAL_GPIO_Init+0x228>
 8002d7e:	4560      	cmp	r0, ip
 8002d80:	f000 8086 	beq.w	8002e90 <HAL_GPIO_Init+0x1e8>
 8002d84:	f8df c14c 	ldr.w	ip, [pc, #332]	@ 8002ed4 <HAL_GPIO_Init+0x22c>
 8002d88:	4560      	cmp	r0, ip
 8002d8a:	f000 8087 	beq.w	8002e9c <HAL_GPIO_Init+0x1f4>
 8002d8e:	f8df c148 	ldr.w	ip, [pc, #328]	@ 8002ed8 <HAL_GPIO_Init+0x230>
 8002d92:	4560      	cmp	r0, ip
 8002d94:	f000 8088 	beq.w	8002ea8 <HAL_GPIO_Init+0x200>
 8002d98:	f8df c140 	ldr.w	ip, [pc, #320]	@ 8002edc <HAL_GPIO_Init+0x234>
 8002d9c:	4560      	cmp	r0, ip
 8002d9e:	f000 8089 	beq.w	8002eb4 <HAL_GPIO_Init+0x20c>
 8002da2:	f8df c13c 	ldr.w	ip, [pc, #316]	@ 8002ee0 <HAL_GPIO_Init+0x238>
 8002da6:	4560      	cmp	r0, ip
 8002da8:	bf0c      	ite	eq
 8002daa:	f04f 0c07 	moveq.w	ip, #7
 8002dae:	f04f 0c08 	movne.w	ip, #8
 8002db2:	fa0c f606 	lsl.w	r6, ip, r6
 8002db6:	4335      	orrs	r5, r6
 8002db8:	608d      	str	r5, [r1, #8]
 8002dba:	f8db 1000 	ldr.w	r1, [fp]
 8002dbe:	43fd      	mvns	r5, r7
 8002dc0:	03d6      	lsls	r6, r2, #15
 8002dc2:	bf54      	ite	pl
 8002dc4:	4029      	andpl	r1, r5
 8002dc6:	4339      	orrmi	r1, r7
 8002dc8:	f8cb 1000 	str.w	r1, [fp]
 8002dcc:	f8db 1004 	ldr.w	r1, [fp, #4]
 8002dd0:	0396      	lsls	r6, r2, #14
 8002dd2:	bf54      	ite	pl
 8002dd4:	4029      	andpl	r1, r5
 8002dd6:	4339      	orrmi	r1, r7
 8002dd8:	f8cb 1004 	str.w	r1, [fp, #4]
 8002ddc:	f8db 1008 	ldr.w	r1, [fp, #8]
 8002de0:	02d6      	lsls	r6, r2, #11
 8002de2:	bf54      	ite	pl
 8002de4:	4029      	andpl	r1, r5
 8002de6:	4339      	orrmi	r1, r7
 8002de8:	f8cb 1008 	str.w	r1, [fp, #8]
 8002dec:	f8db 100c 	ldr.w	r1, [fp, #12]
 8002df0:	0292      	lsls	r2, r2, #10
 8002df2:	f103 0301 	add.w	r3, r3, #1
 8002df6:	bf54      	ite	pl
 8002df8:	4029      	andpl	r1, r5
 8002dfa:	4339      	orrmi	r1, r7
 8002dfc:	2b10      	cmp	r3, #16
 8002dfe:	f8cb 100c 	str.w	r1, [fp, #12]
 8002e02:	f47f af5e 	bne.w	8002cc2 <HAL_GPIO_Init+0x1a>
 8002e06:	b005      	add	sp, #20
 8002e08:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8002e0c:	ea4f 09d3 	mov.w	r9, r3, lsr #3
 8002e10:	eb00 0989 	add.w	r9, r0, r9, lsl #2
 8002e14:	f003 0807 	and.w	r8, r3, #7
 8002e18:	f8d9 7020 	ldr.w	r7, [r9, #32]
 8002e1c:	9700      	str	r7, [sp, #0]
 8002e1e:	f8da 7010 	ldr.w	r7, [sl, #16]
 8002e22:	ea4f 0888 	mov.w	r8, r8, lsl #2
 8002e26:	fa07 f708 	lsl.w	r7, r7, r8
 8002e2a:	9701      	str	r7, [sp, #4]
 8002e2c:	270f      	movs	r7, #15
 8002e2e:	fa07 f808 	lsl.w	r8, r7, r8
 8002e32:	9f00      	ldr	r7, [sp, #0]
 8002e34:	ea27 0808 	bic.w	r8, r7, r8
 8002e38:	9f01      	ldr	r7, [sp, #4]
 8002e3a:	ea47 0708 	orr.w	r7, r7, r8
 8002e3e:	f8c9 7020 	str.w	r7, [r9, #32]
 8002e42:	6807      	ldr	r7, [r0, #0]
 8002e44:	402f      	ands	r7, r5
 8002e46:	ea47 070e 	orr.w	r7, r7, lr
 8002e4a:	6007      	str	r7, [r0, #0]
 8002e4c:	6887      	ldr	r7, [r0, #8]
 8002e4e:	ea07 0e05 	and.w	lr, r7, r5
 8002e52:	f8da 700c 	ldr.w	r7, [sl, #12]
 8002e56:	40b7      	lsls	r7, r6
 8002e58:	ea47 070e 	orr.w	r7, r7, lr
 8002e5c:	6087      	str	r7, [r0, #8]
 8002e5e:	6846      	ldr	r6, [r0, #4]
 8002e60:	0912      	lsrs	r2, r2, #4
 8002e62:	409a      	lsls	r2, r3
 8002e64:	ea26 0101 	bic.w	r1, r6, r1
 8002e68:	430a      	orrs	r2, r1
 8002e6a:	6042      	str	r2, [r0, #4]
 8002e6c:	68c2      	ldr	r2, [r0, #12]
 8002e6e:	402a      	ands	r2, r5
 8002e70:	ea42 020c 	orr.w	r2, r2, ip
 8002e74:	60c2      	str	r2, [r0, #12]
 8002e76:	e720      	b.n	8002cba <HAL_GPIO_Init+0x12>
 8002e78:	f04f 0c01 	mov.w	ip, #1
 8002e7c:	fa0c f606 	lsl.w	r6, ip, r6
 8002e80:	4335      	orrs	r5, r6
 8002e82:	e799      	b.n	8002db8 <HAL_GPIO_Init+0x110>
 8002e84:	f04f 0c02 	mov.w	ip, #2
 8002e88:	fa0c f606 	lsl.w	r6, ip, r6
 8002e8c:	4335      	orrs	r5, r6
 8002e8e:	e793      	b.n	8002db8 <HAL_GPIO_Init+0x110>
 8002e90:	f04f 0c03 	mov.w	ip, #3
 8002e94:	fa0c f606 	lsl.w	r6, ip, r6
 8002e98:	4335      	orrs	r5, r6
 8002e9a:	e78d      	b.n	8002db8 <HAL_GPIO_Init+0x110>
 8002e9c:	f04f 0c04 	mov.w	ip, #4
 8002ea0:	fa0c f606 	lsl.w	r6, ip, r6
 8002ea4:	4335      	orrs	r5, r6
 8002ea6:	e787      	b.n	8002db8 <HAL_GPIO_Init+0x110>
 8002ea8:	f04f 0c05 	mov.w	ip, #5
 8002eac:	fa0c f606 	lsl.w	r6, ip, r6
 8002eb0:	4335      	orrs	r5, r6
 8002eb2:	e781      	b.n	8002db8 <HAL_GPIO_Init+0x110>
 8002eb4:	f04f 0c06 	mov.w	ip, #6
 8002eb8:	fa0c f606 	lsl.w	r6, ip, r6
 8002ebc:	4335      	orrs	r5, r6
 8002ebe:	e77b      	b.n	8002db8 <HAL_GPIO_Init+0x110>
 8002ec0:	40013c00 	.word	0x40013c00
 8002ec4:	40023800 	.word	0x40023800
 8002ec8:	40020000 	.word	0x40020000
 8002ecc:	40020800 	.word	0x40020800
 8002ed0:	40020c00 	.word	0x40020c00
 8002ed4:	40021000 	.word	0x40021000
 8002ed8:	40021400 	.word	0x40021400
 8002edc:	40021800 	.word	0x40021800
 8002ee0:	40021c00 	.word	0x40021c00

08002ee4 <HAL_GPIO_WritePin>:
 8002ee4:	b902      	cbnz	r2, 8002ee8 <HAL_GPIO_WritePin+0x4>
 8002ee6:	0409      	lsls	r1, r1, #16
 8002ee8:	6181      	str	r1, [r0, #24]
 8002eea:	4770      	bx	lr

08002eec <HAL_UART_Init>:
 8002eec:	2800      	cmp	r0, #0
 8002eee:	d073      	beq.n	8002fd8 <HAL_UART_Init+0xec>
 8002ef0:	b430      	push	{r4, r5}
 8002ef2:	f890 2039 	ldrb.w	r2, [r0, #57]	@ 0x39
 8002ef6:	4603      	mov	r3, r0
 8002ef8:	f002 01ff 	and.w	r1, r2, #255	@ 0xff
 8002efc:	2a00      	cmp	r2, #0
 8002efe:	d04f      	beq.n	8002fa0 <HAL_UART_Init+0xb4>
 8002f00:	681a      	ldr	r2, [r3, #0]
 8002f02:	68dc      	ldr	r4, [r3, #12]
 8002f04:	691d      	ldr	r5, [r3, #16]
 8002f06:	2124      	movs	r1, #36	@ 0x24
 8002f08:	f883 1039 	strb.w	r1, [r3, #57]	@ 0x39
 8002f0c:	68d1      	ldr	r1, [r2, #12]
 8002f0e:	f421 5100 	bic.w	r1, r1, #8192	@ 0x2000
 8002f12:	60d1      	str	r1, [r2, #12]
 8002f14:	6910      	ldr	r0, [r2, #16]
 8002f16:	6899      	ldr	r1, [r3, #8]
 8002f18:	f420 5040 	bic.w	r0, r0, #12288	@ 0x3000
 8002f1c:	4320      	orrs	r0, r4
 8002f1e:	6110      	str	r0, [r2, #16]
 8002f20:	68d0      	ldr	r0, [r2, #12]
 8002f22:	69dc      	ldr	r4, [r3, #28]
 8002f24:	4329      	orrs	r1, r5
 8002f26:	695d      	ldr	r5, [r3, #20]
 8002f28:	f420 4016 	bic.w	r0, r0, #38400	@ 0x9600
 8002f2c:	4329      	orrs	r1, r5
 8002f2e:	f020 000c 	bic.w	r0, r0, #12
 8002f32:	4321      	orrs	r1, r4
 8002f34:	4301      	orrs	r1, r0
 8002f36:	60d1      	str	r1, [r2, #12]
 8002f38:	6951      	ldr	r1, [r2, #20]
 8002f3a:	6998      	ldr	r0, [r3, #24]
 8002f3c:	f421 7140 	bic.w	r1, r1, #768	@ 0x300
 8002f40:	4301      	orrs	r1, r0
 8002f42:	f5b4 4f00 	cmp.w	r4, #32768	@ 0x8000
 8002f46:	6858      	ldr	r0, [r3, #4]
 8002f48:	6151      	str	r1, [r2, #20]
 8002f4a:	d02c      	beq.n	8002fa6 <HAL_UART_Init+0xba>
 8002f4c:	4c23      	ldr	r4, [pc, #140]	@ (8002fdc <HAL_UART_Init+0xf0>)
 8002f4e:	4924      	ldr	r1, [pc, #144]	@ (8002fe0 <HAL_UART_Init+0xf4>)
 8002f50:	0080      	lsls	r0, r0, #2
 8002f52:	fbb1 f1f0 	udiv	r1, r1, r0
 8002f56:	fba4 5001 	umull	r5, r0, r4, r1
 8002f5a:	0940      	lsrs	r0, r0, #5
 8002f5c:	2564      	movs	r5, #100	@ 0x64
 8002f5e:	fb05 1110 	mls	r1, r5, r0, r1
 8002f62:	0109      	lsls	r1, r1, #4
 8002f64:	3132      	adds	r1, #50	@ 0x32
 8002f66:	fba4 4101 	umull	r4, r1, r4, r1
 8002f6a:	0100      	lsls	r0, r0, #4
 8002f6c:	eb00 1051 	add.w	r0, r0, r1, lsr #5
 8002f70:	6090      	str	r0, [r2, #8]
 8002f72:	6911      	ldr	r1, [r2, #16]
 8002f74:	f421 4190 	bic.w	r1, r1, #18432	@ 0x4800
 8002f78:	6111      	str	r1, [r2, #16]
 8002f7a:	6951      	ldr	r1, [r2, #20]
 8002f7c:	f021 012a 	bic.w	r1, r1, #42	@ 0x2a
 8002f80:	6151      	str	r1, [r2, #20]
 8002f82:	68d1      	ldr	r1, [r2, #12]
 8002f84:	2400      	movs	r4, #0
 8002f86:	f04f 0c20 	mov.w	ip, #32
 8002f8a:	f441 5100 	orr.w	r1, r1, #8192	@ 0x2000
 8002f8e:	60d1      	str	r1, [r2, #12]
 8002f90:	63dc      	str	r4, [r3, #60]	@ 0x3c
 8002f92:	f883 c039 	strb.w	ip, [r3, #57]	@ 0x39
 8002f96:	f883 c03a 	strb.w	ip, [r3, #58]	@ 0x3a
 8002f9a:	4620      	mov	r0, r4
 8002f9c:	bc30      	pop	{r4, r5}
 8002f9e:	4770      	bx	lr
 8002fa0:	f880 1038 	strb.w	r1, [r0, #56]	@ 0x38
 8002fa4:	e7ac      	b.n	8002f00 <HAL_UART_Init+0x14>
 8002fa6:	4d0d      	ldr	r5, [pc, #52]	@ (8002fdc <HAL_UART_Init+0xf0>)
 8002fa8:	490d      	ldr	r1, [pc, #52]	@ (8002fe0 <HAL_UART_Init+0xf4>)
 8002faa:	0040      	lsls	r0, r0, #1
 8002fac:	fbb1 f1f0 	udiv	r1, r1, r0
 8002fb0:	fba5 0401 	umull	r0, r4, r5, r1
 8002fb4:	0964      	lsrs	r4, r4, #5
 8002fb6:	2064      	movs	r0, #100	@ 0x64
 8002fb8:	fb00 1114 	mls	r1, r0, r4, r1
 8002fbc:	00c9      	lsls	r1, r1, #3
 8002fbe:	3132      	adds	r1, #50	@ 0x32
 8002fc0:	fba5 5101 	umull	r5, r1, r5, r1
 8002fc4:	f3c1 1042 	ubfx	r0, r1, #5, #3
 8002fc8:	0909      	lsrs	r1, r1, #4
 8002fca:	eb00 1004 	add.w	r0, r0, r4, lsl #4
 8002fce:	f401 71f8 	and.w	r1, r1, #496	@ 0x1f0
 8002fd2:	4401      	add	r1, r0
 8002fd4:	6091      	str	r1, [r2, #8]
 8002fd6:	e7cc      	b.n	8002f72 <HAL_UART_Init+0x86>
 8002fd8:	2001      	movs	r0, #1
 8002fda:	4770      	bx	lr
 8002fdc:	51eb851f 	.word	0x51eb851f
 8002fe0:	0afb6e90 	.word	0x0afb6e90

08002fe4 <HAL_UART_Transmit>:
 8002fe4:	f890 3039 	ldrb.w	r3, [r0, #57]	@ 0x39
 8002fe8:	2b20      	cmp	r3, #32
 8002fea:	d141      	bne.n	8003070 <HAL_UART_Transmit+0x8c>
 8002fec:	2900      	cmp	r1, #0
 8002fee:	d03d      	beq.n	800306c <HAL_UART_Transmit+0x88>
 8002ff0:	2a00      	cmp	r2, #0
 8002ff2:	d03b      	beq.n	800306c <HAL_UART_Transmit+0x88>
 8002ff4:	f890 3038 	ldrb.w	r3, [r0, #56]	@ 0x38
 8002ff8:	2b01      	cmp	r3, #1
 8002ffa:	d039      	beq.n	8003070 <HAL_UART_Transmit+0x8c>
 8002ffc:	b410      	push	{r4}
 8002ffe:	2321      	movs	r3, #33	@ 0x21
 8003000:	2400      	movs	r4, #0
 8003002:	63c4      	str	r4, [r0, #60]	@ 0x3c
 8003004:	f880 3039 	strb.w	r3, [r0, #57]	@ 0x39
 8003008:	84c2      	strh	r2, [r0, #38]	@ 0x26
 800300a:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 800300c:	6804      	ldr	r4, [r0, #0]
 800300e:	8482      	strh	r2, [r0, #36]	@ 0x24
 8003010:	f04f 0c01 	mov.w	ip, #1
 8003014:	b29b      	uxth	r3, r3
 8003016:	f880 c038 	strb.w	ip, [r0, #56]	@ 0x38
 800301a:	b1db      	cbz	r3, 8003054 <HAL_UART_Transmit+0x70>
 800301c:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 800301e:	6882      	ldr	r2, [r0, #8]
 8003020:	3b01      	subs	r3, #1
 8003022:	b29b      	uxth	r3, r3
 8003024:	f5b2 5f80 	cmp.w	r2, #4096	@ 0x1000
 8003028:	84c3      	strh	r3, [r0, #38]	@ 0x26
 800302a:	d023      	beq.n	8003074 <HAL_UART_Transmit+0x90>
 800302c:	6823      	ldr	r3, [r4, #0]
 800302e:	061a      	lsls	r2, r3, #24
 8003030:	d5fc      	bpl.n	800302c <HAL_UART_Transmit+0x48>
 8003032:	f811 3b01 	ldrb.w	r3, [r1], #1
 8003036:	6063      	str	r3, [r4, #4]
 8003038:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 800303a:	b29b      	uxth	r3, r3
 800303c:	b153      	cbz	r3, 8003054 <HAL_UART_Transmit+0x70>
 800303e:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 8003040:	3b01      	subs	r3, #1
 8003042:	b29b      	uxth	r3, r3
 8003044:	84c3      	strh	r3, [r0, #38]	@ 0x26
 8003046:	6823      	ldr	r3, [r4, #0]
 8003048:	061a      	lsls	r2, r3, #24
 800304a:	d5ef      	bpl.n	800302c <HAL_UART_Transmit+0x48>
 800304c:	e7f1      	b.n	8003032 <HAL_UART_Transmit+0x4e>
 800304e:	b29b      	uxth	r3, r3
 8003050:	3101      	adds	r1, #1
 8003052:	b9f3      	cbnz	r3, 8003092 <HAL_UART_Transmit+0xae>
 8003054:	6823      	ldr	r3, [r4, #0]
 8003056:	065b      	lsls	r3, r3, #25
 8003058:	d5fc      	bpl.n	8003054 <HAL_UART_Transmit+0x70>
 800305a:	2300      	movs	r3, #0
 800305c:	2220      	movs	r2, #32
 800305e:	f880 2039 	strb.w	r2, [r0, #57]	@ 0x39
 8003062:	f880 3038 	strb.w	r3, [r0, #56]	@ 0x38
 8003066:	bc10      	pop	{r4}
 8003068:	4618      	mov	r0, r3
 800306a:	4770      	bx	lr
 800306c:	2001      	movs	r0, #1
 800306e:	4770      	bx	lr
 8003070:	2002      	movs	r0, #2
 8003072:	4770      	bx	lr
 8003074:	6902      	ldr	r2, [r0, #16]
 8003076:	6823      	ldr	r3, [r4, #0]
 8003078:	061b      	lsls	r3, r3, #24
 800307a:	d5fc      	bpl.n	8003076 <HAL_UART_Transmit+0x92>
 800307c:	880b      	ldrh	r3, [r1, #0]
 800307e:	f3c3 0308 	ubfx	r3, r3, #0, #9
 8003082:	6063      	str	r3, [r4, #4]
 8003084:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 8003086:	2a00      	cmp	r2, #0
 8003088:	d1e1      	bne.n	800304e <HAL_UART_Transmit+0x6a>
 800308a:	b29b      	uxth	r3, r3
 800308c:	3102      	adds	r1, #2
 800308e:	2b00      	cmp	r3, #0
 8003090:	d0e0      	beq.n	8003054 <HAL_UART_Transmit+0x70>
 8003092:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 8003094:	3b01      	subs	r3, #1
 8003096:	b29b      	uxth	r3, r3
 8003098:	84c3      	strh	r3, [r0, #38]	@ 0x26
 800309a:	e7ec      	b.n	8003076 <HAL_UART_Transmit+0x92>

0800309c <HAL_UART_Receive>:
 800309c:	f890 303a 	ldrb.w	r3, [r0, #58]	@ 0x3a
 80030a0:	2b20      	cmp	r3, #32
 80030a2:	d146      	bne.n	8003132 <HAL_UART_Receive+0x96>
 80030a4:	2900      	cmp	r1, #0
 80030a6:	d03e      	beq.n	8003126 <HAL_UART_Receive+0x8a>
 80030a8:	2a00      	cmp	r2, #0
 80030aa:	d03c      	beq.n	8003126 <HAL_UART_Receive+0x8a>
 80030ac:	f890 3038 	ldrb.w	r3, [r0, #56]	@ 0x38
 80030b0:	2b01      	cmp	r3, #1
 80030b2:	d03e      	beq.n	8003132 <HAL_UART_Receive+0x96>
 80030b4:	b410      	push	{r4}
 80030b6:	2322      	movs	r3, #34	@ 0x22
 80030b8:	2400      	movs	r4, #0
 80030ba:	63c4      	str	r4, [r0, #60]	@ 0x3c
 80030bc:	f880 303a 	strb.w	r3, [r0, #58]	@ 0x3a
 80030c0:	85c2      	strh	r2, [r0, #46]	@ 0x2e
 80030c2:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 80030c4:	8582      	strh	r2, [r0, #44]	@ 0x2c
 80030c6:	f04f 0c01 	mov.w	ip, #1
 80030ca:	b29b      	uxth	r3, r3
 80030cc:	f880 c038 	strb.w	ip, [r0, #56]	@ 0x38
 80030d0:	b1ab      	cbz	r3, 80030fe <HAL_UART_Receive+0x62>
 80030d2:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 80030d4:	6802      	ldr	r2, [r0, #0]
 80030d6:	3b01      	subs	r3, #1
 80030d8:	b29b      	uxth	r3, r3
 80030da:	85c3      	strh	r3, [r0, #46]	@ 0x2e
 80030dc:	6883      	ldr	r3, [r0, #8]
 80030de:	f5b3 5f80 	cmp.w	r3, #4096	@ 0x1000
 80030e2:	d015      	beq.n	8003110 <HAL_UART_Receive+0x74>
 80030e4:	6813      	ldr	r3, [r2, #0]
 80030e6:	069b      	lsls	r3, r3, #26
 80030e8:	d5fc      	bpl.n	80030e4 <HAL_UART_Receive+0x48>
 80030ea:	6903      	ldr	r3, [r0, #16]
 80030ec:	b9eb      	cbnz	r3, 800312a <HAL_UART_Receive+0x8e>
 80030ee:	6853      	ldr	r3, [r2, #4]
 80030f0:	b2db      	uxtb	r3, r3
 80030f2:	f801 3b01 	strb.w	r3, [r1], #1
 80030f6:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 80030f8:	b29b      	uxth	r3, r3
 80030fa:	2b00      	cmp	r3, #0
 80030fc:	d1e9      	bne.n	80030d2 <HAL_UART_Receive+0x36>
 80030fe:	2300      	movs	r3, #0
 8003100:	2220      	movs	r2, #32
 8003102:	f880 203a 	strb.w	r2, [r0, #58]	@ 0x3a
 8003106:	f880 3038 	strb.w	r3, [r0, #56]	@ 0x38
 800310a:	bc10      	pop	{r4}
 800310c:	4618      	mov	r0, r3
 800310e:	4770      	bx	lr
 8003110:	6813      	ldr	r3, [r2, #0]
 8003112:	069c      	lsls	r4, r3, #26
 8003114:	d5fc      	bpl.n	8003110 <HAL_UART_Receive+0x74>
 8003116:	6903      	ldr	r3, [r0, #16]
 8003118:	b96b      	cbnz	r3, 8003136 <HAL_UART_Receive+0x9a>
 800311a:	6853      	ldr	r3, [r2, #4]
 800311c:	f3c3 0308 	ubfx	r3, r3, #0, #9
 8003120:	f821 3b02 	strh.w	r3, [r1], #2
 8003124:	e7e7      	b.n	80030f6 <HAL_UART_Receive+0x5a>
 8003126:	2001      	movs	r0, #1
 8003128:	4770      	bx	lr
 800312a:	6853      	ldr	r3, [r2, #4]
 800312c:	f003 037f 	and.w	r3, r3, #127	@ 0x7f
 8003130:	e7df      	b.n	80030f2 <HAL_UART_Receive+0x56>
 8003132:	2002      	movs	r0, #2
 8003134:	4770      	bx	lr
 8003136:	6853      	ldr	r3, [r2, #4]
 8003138:	b2db      	uxtb	r3, r3
 800313a:	f821 3b01 	strh.w	r3, [r1], #1
 800313e:	e7da      	b.n	80030f6 <HAL_UART_Receive+0x5a>

08003140 <_sbrk>:
 8003140:	4a0b      	ldr	r2, [pc, #44]	@ (8003170 <_sbrk+0x30>)
 8003142:	b508      	push	{r3, lr}
 8003144:	4603      	mov	r3, r0
 8003146:	6810      	ldr	r0, [r2, #0]
 8003148:	b128      	cbz	r0, 8003156 <_sbrk+0x16>
 800314a:	4403      	add	r3, r0
 800314c:	4669      	mov	r1, sp
 800314e:	428b      	cmp	r3, r1
 8003150:	d807      	bhi.n	8003162 <_sbrk+0x22>
 8003152:	6013      	str	r3, [r2, #0]
 8003154:	bd08      	pop	{r3, pc}
 8003156:	4807      	ldr	r0, [pc, #28]	@ (8003174 <_sbrk+0x34>)
 8003158:	6010      	str	r0, [r2, #0]
 800315a:	4403      	add	r3, r0
 800315c:	4669      	mov	r1, sp
 800315e:	428b      	cmp	r3, r1
 8003160:	d9f7      	bls.n	8003152 <_sbrk+0x12>
 8003162:	f7fd f917 	bl	8000394 <__errno>
 8003166:	230c      	movs	r3, #12
 8003168:	6003      	str	r3, [r0, #0]
 800316a:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 800316e:	bd08      	pop	{r3, pc}
 8003170:	20000a1c 	.word	0x20000a1c
 8003174:	20000f30 	.word	0x20000f30

08003178 <HAL_RNG_MspInit>:
 8003178:	4770      	bx	lr
 800317a:	bf00      	nop

0800317c <HAL_RNG_Init>:
 800317c:	b1c0      	cbz	r0, 80031b0 <HAL_RNG_Init+0x34>
 800317e:	b510      	push	{r4, lr}
 8003180:	7903      	ldrb	r3, [r0, #4]
 8003182:	2b01      	cmp	r3, #1
 8003184:	4604      	mov	r4, r0
 8003186:	d015      	beq.n	80031b4 <HAL_RNG_Init+0x38>
 8003188:	7943      	ldrb	r3, [r0, #5]
 800318a:	f003 02ff 	and.w	r2, r3, #255	@ 0xff
 800318e:	b15b      	cbz	r3, 80031a8 <HAL_RNG_Init+0x2c>
 8003190:	6822      	ldr	r2, [r4, #0]
 8003192:	2302      	movs	r3, #2
 8003194:	7163      	strb	r3, [r4, #5]
 8003196:	6813      	ldr	r3, [r2, #0]
 8003198:	2000      	movs	r0, #0
 800319a:	f043 0304 	orr.w	r3, r3, #4
 800319e:	2101      	movs	r1, #1
 80031a0:	6013      	str	r3, [r2, #0]
 80031a2:	7161      	strb	r1, [r4, #5]
 80031a4:	7120      	strb	r0, [r4, #4]
 80031a6:	bd10      	pop	{r4, pc}
 80031a8:	7102      	strb	r2, [r0, #4]
 80031aa:	f7ff ffe5 	bl	8003178 <HAL_RNG_MspInit>
 80031ae:	e7ef      	b.n	8003190 <HAL_RNG_Init+0x14>
 80031b0:	2001      	movs	r0, #1
 80031b2:	4770      	bx	lr
 80031b4:	2002      	movs	r0, #2
 80031b6:	bd10      	pop	{r4, pc}

080031b8 <check_version>:
 80031b8:	2001      	movs	r0, #1
 80031ba:	4770      	bx	lr

080031bc <simpleserial_put.part.0>:
 80031bc:	b570      	push	{r4, r5, r6, lr}
 80031be:	460e      	mov	r6, r1
 80031c0:	4614      	mov	r4, r2
 80031c2:	f7ff fa95 	bl	80026f0 <putch>
 80031c6:	b17e      	cbz	r6, 80031e8 <simpleserial_put.part.0+0x2c>
 80031c8:	4d0a      	ldr	r5, [pc, #40]	@ (80031f4 <simpleserial_put.part.0+0x38>)
 80031ca:	4426      	add	r6, r4
 80031cc:	7823      	ldrb	r3, [r4, #0]
 80031ce:	091b      	lsrs	r3, r3, #4
 80031d0:	5ce8      	ldrb	r0, [r5, r3]
 80031d2:	f7ff fa8d 	bl	80026f0 <putch>
 80031d6:	f814 3b01 	ldrb.w	r3, [r4], #1
 80031da:	f003 030f 	and.w	r3, r3, #15
 80031de:	5ce8      	ldrb	r0, [r5, r3]
 80031e0:	f7ff fa86 	bl	80026f0 <putch>
 80031e4:	42a6      	cmp	r6, r4
 80031e6:	d1f1      	bne.n	80031cc <simpleserial_put.part.0+0x10>
 80031e8:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
 80031ec:	200a      	movs	r0, #10
 80031ee:	f7ff ba7f 	b.w	80026f0 <putch>
 80031f2:	bf00      	nop
 80031f4:	08003608 	.word	0x08003608

080031f8 <ss_get_commands>:
 80031f8:	b530      	push	{r4, r5, lr}
 80031fa:	4c12      	ldr	r4, [pc, #72]	@ (8003244 <ss_get_commands+0x4c>)
 80031fc:	6825      	ldr	r5, [r4, #0]
 80031fe:	f015 0eff 	ands.w	lr, r5, #255	@ 0xff
 8003202:	b099      	sub	sp, #100	@ 0x64
 8003204:	d013      	beq.n	800322e <ss_get_commands+0x36>
 8003206:	2200      	movs	r2, #0
 8003208:	4613      	mov	r3, r2
 800320a:	eb04 1003 	add.w	r0, r4, r3, lsl #4
 800320e:	3201      	adds	r2, #1
 8003210:	eb03 0343 	add.w	r3, r3, r3, lsl #1
 8003214:	446b      	add	r3, sp
 8003216:	b2d2      	uxtb	r2, r2
 8003218:	f890 c004 	ldrb.w	ip, [r0, #4]
 800321c:	6881      	ldr	r1, [r0, #8]
 800321e:	7c00      	ldrb	r0, [r0, #16]
 8003220:	f883 c000 	strb.w	ip, [r3]
 8003224:	4572      	cmp	r2, lr
 8003226:	7059      	strb	r1, [r3, #1]
 8003228:	7098      	strb	r0, [r3, #2]
 800322a:	4613      	mov	r3, r2
 800322c:	dbed      	blt.n	800320a <ss_get_commands+0x12>
 800322e:	eb05 0545 	add.w	r5, r5, r5, lsl #1
 8003232:	466a      	mov	r2, sp
 8003234:	b2e9      	uxtb	r1, r5
 8003236:	2072      	movs	r0, #114	@ 0x72
 8003238:	f7ff ffc0 	bl	80031bc <simpleserial_put.part.0>
 800323c:	2000      	movs	r0, #0
 800323e:	b019      	add	sp, #100	@ 0x64
 8003240:	bd30      	pop	{r4, r5, pc}
 8003242:	bf00      	nop
 8003244:	20000a20 	.word	0x20000a20

08003248 <ss_num_commands>:
 8003248:	b538      	push	{r3, r4, r5, lr}
 800324a:	4b0a      	ldr	r3, [pc, #40]	@ (8003274 <ss_num_commands+0x2c>)
 800324c:	4d0a      	ldr	r5, [pc, #40]	@ (8003278 <ss_num_commands+0x30>)
 800324e:	781c      	ldrb	r4, [r3, #0]
 8003250:	2072      	movs	r0, #114	@ 0x72
 8003252:	f7ff fa4d 	bl	80026f0 <putch>
 8003256:	0923      	lsrs	r3, r4, #4
 8003258:	f004 040f 	and.w	r4, r4, #15
 800325c:	5ce8      	ldrb	r0, [r5, r3]
 800325e:	f7ff fa47 	bl	80026f0 <putch>
 8003262:	5d28      	ldrb	r0, [r5, r4]
 8003264:	f7ff fa44 	bl	80026f0 <putch>
 8003268:	200a      	movs	r0, #10
 800326a:	f7ff fa41 	bl	80026f0 <putch>
 800326e:	2000      	movs	r0, #0
 8003270:	bd38      	pop	{r3, r4, r5, pc}
 8003272:	bf00      	nop
 8003274:	20000a20 	.word	0x20000a20
 8003278:	08003608 	.word	0x08003608

0800327c <hex_decode>:
 800327c:	2800      	cmp	r0, #0
 800327e:	dd4c      	ble.n	800331a <hex_decode+0x9e>
 8003280:	b500      	push	{lr}
 8003282:	eb01 0e40 	add.w	lr, r1, r0, lsl #1
 8003286:	e00e      	b.n	80032a6 <hex_decode+0x2a>
 8003288:	7013      	strb	r3, [r2, #0]
 800328a:	f1ac 0330 	sub.w	r3, ip, #48	@ 0x30
 800328e:	b2db      	uxtb	r3, r3
 8003290:	2b09      	cmp	r3, #9
 8003292:	d81b      	bhi.n	80032cc <hex_decode+0x50>
 8003294:	7810      	ldrb	r0, [r2, #0]
 8003296:	ea40 1303 	orr.w	r3, r0, r3, lsl #4
 800329a:	7013      	strb	r3, [r2, #0]
 800329c:	3102      	adds	r1, #2
 800329e:	4571      	cmp	r1, lr
 80032a0:	f102 0201 	add.w	r2, r2, #1
 80032a4:	d021      	beq.n	80032ea <hex_decode+0x6e>
 80032a6:	7848      	ldrb	r0, [r1, #1]
 80032a8:	f891 c000 	ldrb.w	ip, [r1]
 80032ac:	f1a0 0330 	sub.w	r3, r0, #48	@ 0x30
 80032b0:	b2db      	uxtb	r3, r3
 80032b2:	2b09      	cmp	r3, #9
 80032b4:	d9e8      	bls.n	8003288 <hex_decode+0xc>
 80032b6:	f1a0 0341 	sub.w	r3, r0, #65	@ 0x41
 80032ba:	2b05      	cmp	r3, #5
 80032bc:	d818      	bhi.n	80032f0 <hex_decode+0x74>
 80032be:	f1ac 0330 	sub.w	r3, ip, #48	@ 0x30
 80032c2:	b2db      	uxtb	r3, r3
 80032c4:	3837      	subs	r0, #55	@ 0x37
 80032c6:	2b09      	cmp	r3, #9
 80032c8:	7010      	strb	r0, [r2, #0]
 80032ca:	d9e3      	bls.n	8003294 <hex_decode+0x18>
 80032cc:	f1ac 0341 	sub.w	r3, ip, #65	@ 0x41
 80032d0:	2b05      	cmp	r3, #5
 80032d2:	d814      	bhi.n	80032fe <hex_decode+0x82>
 80032d4:	7813      	ldrb	r3, [r2, #0]
 80032d6:	f1ac 0c37 	sub.w	ip, ip, #55	@ 0x37
 80032da:	3102      	adds	r1, #2
 80032dc:	ea43 130c 	orr.w	r3, r3, ip, lsl #4
 80032e0:	4571      	cmp	r1, lr
 80032e2:	7013      	strb	r3, [r2, #0]
 80032e4:	f102 0201 	add.w	r2, r2, #1
 80032e8:	d1dd      	bne.n	80032a6 <hex_decode+0x2a>
 80032ea:	2000      	movs	r0, #0
 80032ec:	f85d fb04 	ldr.w	pc, [sp], #4
 80032f0:	f1a0 0361 	sub.w	r3, r0, #97	@ 0x61
 80032f4:	2b05      	cmp	r3, #5
 80032f6:	d80d      	bhi.n	8003314 <hex_decode+0x98>
 80032f8:	3857      	subs	r0, #87	@ 0x57
 80032fa:	7010      	strb	r0, [r2, #0]
 80032fc:	e7c5      	b.n	800328a <hex_decode+0xe>
 80032fe:	f1ac 0361 	sub.w	r3, ip, #97	@ 0x61
 8003302:	2b05      	cmp	r3, #5
 8003304:	d806      	bhi.n	8003314 <hex_decode+0x98>
 8003306:	7813      	ldrb	r3, [r2, #0]
 8003308:	f1ac 0c57 	sub.w	ip, ip, #87	@ 0x57
 800330c:	ea43 130c 	orr.w	r3, r3, ip, lsl #4
 8003310:	7013      	strb	r3, [r2, #0]
 8003312:	e7c3      	b.n	800329c <hex_decode+0x20>
 8003314:	2001      	movs	r0, #1
 8003316:	f85d fb04 	ldr.w	pc, [sp], #4
 800331a:	2000      	movs	r0, #0
 800331c:	4770      	bx	lr
 800331e:	bf00      	nop

08003320 <simpleserial_init>:
 8003320:	4b16      	ldr	r3, [pc, #88]	@ (800337c <simpleserial_init+0x5c>)
 8003322:	681a      	ldr	r2, [r3, #0]
 8003324:	2a1f      	cmp	r2, #31
 8003326:	dc27      	bgt.n	8003378 <simpleserial_init+0x58>
 8003328:	4815      	ldr	r0, [pc, #84]	@ (8003380 <simpleserial_init+0x60>)
 800332a:	b410      	push	{r4}
 800332c:	eb03 1102 	add.w	r1, r3, r2, lsl #4
 8003330:	2400      	movs	r4, #0
 8003332:	e9c1 4002 	strd	r4, r0, [r1, #8]
 8003336:	1c50      	adds	r0, r2, #1
 8003338:	f04f 0c76 	mov.w	ip, #118	@ 0x76
 800333c:	2820      	cmp	r0, #32
 800333e:	f881 c004 	strb.w	ip, [r1, #4]
 8003342:	740c      	strb	r4, [r1, #16]
 8003344:	6018      	str	r0, [r3, #0]
 8003346:	d015      	beq.n	8003374 <simpleserial_init+0x54>
 8003348:	eb03 1000 	add.w	r0, r3, r0, lsl #4
 800334c:	2177      	movs	r1, #119	@ 0x77
 800334e:	7101      	strb	r1, [r0, #4]
 8003350:	490c      	ldr	r1, [pc, #48]	@ (8003384 <simpleserial_init+0x64>)
 8003352:	7404      	strb	r4, [r0, #16]
 8003354:	e9c0 4102 	strd	r4, r1, [r0, #8]
 8003358:	1c91      	adds	r1, r2, #2
 800335a:	2920      	cmp	r1, #32
 800335c:	6019      	str	r1, [r3, #0]
 800335e:	d009      	beq.n	8003374 <simpleserial_init+0x54>
 8003360:	eb03 1101 	add.w	r1, r3, r1, lsl #4
 8003364:	2079      	movs	r0, #121	@ 0x79
 8003366:	7108      	strb	r0, [r1, #4]
 8003368:	4807      	ldr	r0, [pc, #28]	@ (8003388 <simpleserial_init+0x68>)
 800336a:	740c      	strb	r4, [r1, #16]
 800336c:	e9c1 4002 	strd	r4, r0, [r1, #8]
 8003370:	3203      	adds	r2, #3
 8003372:	601a      	str	r2, [r3, #0]
 8003374:	bc10      	pop	{r4}
 8003376:	4770      	bx	lr
 8003378:	4770      	bx	lr
 800337a:	bf00      	nop
 800337c:	20000a20 	.word	0x20000a20
 8003380:	080031b9 	.word	0x080031b9
 8003384:	080031f9 	.word	0x080031f9
 8003388:	08003249 	.word	0x08003249

0800338c <simpleserial_addcmd>:
 800338c:	b410      	push	{r4}
 800338e:	4c0c      	ldr	r4, [pc, #48]	@ (80033c0 <simpleserial_addcmd+0x34>)
 8003390:	6823      	ldr	r3, [r4, #0]
 8003392:	2b1f      	cmp	r3, #31
 8003394:	dc10      	bgt.n	80033b8 <simpleserial_addcmd+0x2c>
 8003396:	293f      	cmp	r1, #63	@ 0x3f
 8003398:	d80e      	bhi.n	80033b8 <simpleserial_addcmd+0x2c>
 800339a:	eb04 1c03 	add.w	ip, r4, r3, lsl #4
 800339e:	3301      	adds	r3, #1
 80033a0:	f88c 0004 	strb.w	r0, [ip, #4]
 80033a4:	2000      	movs	r0, #0
 80033a6:	f88c 0010 	strb.w	r0, [ip, #16]
 80033aa:	6023      	str	r3, [r4, #0]
 80033ac:	f8cc 1008 	str.w	r1, [ip, #8]
 80033b0:	bc10      	pop	{r4}
 80033b2:	f8cc 200c 	str.w	r2, [ip, #12]
 80033b6:	4770      	bx	lr
 80033b8:	2001      	movs	r0, #1
 80033ba:	bc10      	pop	{r4}
 80033bc:	4770      	bx	lr
 80033be:	bf00      	nop
 80033c0:	20000a20 	.word	0x20000a20

080033c4 <simpleserial_get>:
 80033c4:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
 80033c8:	4e37      	ldr	r6, [pc, #220]	@ (80034a8 <simpleserial_get+0xe4>)
 80033ca:	b0b0      	sub	sp, #192	@ 0xc0
 80033cc:	f7ff f97c 	bl	80026c8 <getch>
 80033d0:	6831      	ldr	r1, [r6, #0]
 80033d2:	2900      	cmp	r1, #0
 80033d4:	f04f 0300 	mov.w	r3, #0
 80033d8:	dd08      	ble.n	80033ec <simpleserial_get+0x28>
 80033da:	1d34      	adds	r4, r6, #4
 80033dc:	e002      	b.n	80033e4 <simpleserial_get+0x20>
 80033de:	3301      	adds	r3, #1
 80033e0:	428b      	cmp	r3, r1
 80033e2:	d022      	beq.n	800342a <simpleserial_get+0x66>
 80033e4:	011a      	lsls	r2, r3, #4
 80033e6:	5ca2      	ldrb	r2, [r4, r2]
 80033e8:	4282      	cmp	r2, r0
 80033ea:	d1f8      	bne.n	80033de <simpleserial_get+0x1a>
 80033ec:	428b      	cmp	r3, r1
 80033ee:	d01c      	beq.n	800342a <simpleserial_get+0x66>
 80033f0:	eb06 1503 	add.w	r5, r6, r3, lsl #4
 80033f4:	011c      	lsls	r4, r3, #4
 80033f6:	7c2b      	ldrb	r3, [r5, #16]
 80033f8:	07db      	lsls	r3, r3, #31
 80033fa:	d419      	bmi.n	8003430 <simpleserial_get+0x6c>
 80033fc:	68ab      	ldr	r3, [r5, #8]
 80033fe:	005b      	lsls	r3, r3, #1
 8003400:	d02c      	beq.n	800345c <simpleserial_get+0x98>
 8003402:	af10      	add	r7, sp, #64	@ 0x40
 8003404:	2500      	movs	r5, #0
 8003406:	eb06 0804 	add.w	r8, r6, r4
 800340a:	e008      	b.n	800341e <simpleserial_get+0x5a>
 800340c:	280d      	cmp	r0, #13
 800340e:	d00c      	beq.n	800342a <simpleserial_get+0x66>
 8003410:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8003414:	f807 0b01 	strb.w	r0, [r7], #1
 8003418:	ebb5 0f43 	cmp.w	r5, r3, lsl #1
 800341c:	d21e      	bcs.n	800345c <simpleserial_get+0x98>
 800341e:	f7ff f953 	bl	80026c8 <getch>
 8003422:	280a      	cmp	r0, #10
 8003424:	f105 0501 	add.w	r5, r5, #1
 8003428:	d1f0      	bne.n	800340c <simpleserial_get+0x48>
 800342a:	b030      	add	sp, #192	@ 0xc0
 800342c:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 8003430:	2300      	movs	r3, #0
 8003432:	f88d 3000 	strb.w	r3, [sp]
 8003436:	f7ff f947 	bl	80026c8 <getch>
 800343a:	f88d 0040 	strb.w	r0, [sp, #64]	@ 0x40
 800343e:	f7ff f943 	bl	80026c8 <getch>
 8003442:	466a      	mov	r2, sp
 8003444:	f88d 0041 	strb.w	r0, [sp, #65]	@ 0x41
 8003448:	a910      	add	r1, sp, #64	@ 0x40
 800344a:	2001      	movs	r0, #1
 800344c:	f7ff ff16 	bl	800327c <hex_decode>
 8003450:	2800      	cmp	r0, #0
 8003452:	d1ea      	bne.n	800342a <simpleserial_get+0x66>
 8003454:	f89d 3000 	ldrb.w	r3, [sp]
 8003458:	60ab      	str	r3, [r5, #8]
 800345a:	e7d0      	b.n	80033fe <simpleserial_get+0x3a>
 800345c:	f7ff f934 	bl	80026c8 <getch>
 8003460:	280a      	cmp	r0, #10
 8003462:	d001      	beq.n	8003468 <simpleserial_get+0xa4>
 8003464:	280d      	cmp	r0, #13
 8003466:	d1e0      	bne.n	800342a <simpleserial_get+0x66>
 8003468:	4426      	add	r6, r4
 800346a:	466a      	mov	r2, sp
 800346c:	68b4      	ldr	r4, [r6, #8]
 800346e:	a910      	add	r1, sp, #64	@ 0x40
 8003470:	4620      	mov	r0, r4
 8003472:	f7ff ff03 	bl	800327c <hex_decode>
 8003476:	2800      	cmp	r0, #0
 8003478:	d1d7      	bne.n	800342a <simpleserial_get+0x66>
 800347a:	b2e1      	uxtb	r1, r4
 800347c:	68f3      	ldr	r3, [r6, #12]
 800347e:	4d0b      	ldr	r5, [pc, #44]	@ (80034ac <simpleserial_get+0xe8>)
 8003480:	4668      	mov	r0, sp
 8003482:	4798      	blx	r3
 8003484:	4604      	mov	r4, r0
 8003486:	207a      	movs	r0, #122	@ 0x7a
 8003488:	f7ff f932 	bl	80026f0 <putch>
 800348c:	f3c4 1307 	ubfx	r3, r4, #4, #8
 8003490:	f004 040f 	and.w	r4, r4, #15
 8003494:	5ce8      	ldrb	r0, [r5, r3]
 8003496:	f7ff f92b 	bl	80026f0 <putch>
 800349a:	5d28      	ldrb	r0, [r5, r4]
 800349c:	f7ff f928 	bl	80026f0 <putch>
 80034a0:	200a      	movs	r0, #10
 80034a2:	f7ff f925 	bl	80026f0 <putch>
 80034a6:	e7c0      	b.n	800342a <simpleserial_get+0x66>
 80034a8:	20000a20 	.word	0x20000a20
 80034ac:	08003608 	.word	0x08003608

080034b0 <simpleserial_put>:
 80034b0:	b10a      	cbz	r2, 80034b6 <simpleserial_put+0x6>
 80034b2:	f7ff be83 	b.w	80031bc <simpleserial_put.part.0>
 80034b6:	4770      	bx	lr

080034b8 <Reset_Handler>:
 80034b8:	2100      	movs	r1, #0
 80034ba:	e003      	b.n	80034c4 <LoopCopyDataInit>

080034bc <CopyDataInit>:
 80034bc:	4b0b      	ldr	r3, [pc, #44]	@ (80034ec <LoopForever+0x2>)
 80034be:	585b      	ldr	r3, [r3, r1]
 80034c0:	5043      	str	r3, [r0, r1]
 80034c2:	3104      	adds	r1, #4

080034c4 <LoopCopyDataInit>:
 80034c4:	480a      	ldr	r0, [pc, #40]	@ (80034f0 <LoopForever+0x6>)
 80034c6:	4b0b      	ldr	r3, [pc, #44]	@ (80034f4 <LoopForever+0xa>)
 80034c8:	1842      	adds	r2, r0, r1
 80034ca:	429a      	cmp	r2, r3
 80034cc:	d3f6      	bcc.n	80034bc <CopyDataInit>
 80034ce:	4a0a      	ldr	r2, [pc, #40]	@ (80034f8 <LoopForever+0xe>)
 80034d0:	e002      	b.n	80034d8 <LoopFillZerobss>

080034d2 <FillZerobss>:
 80034d2:	2300      	movs	r3, #0
 80034d4:	6013      	str	r3, [r2, #0]
 80034d6:	3204      	adds	r2, #4

080034d8 <LoopFillZerobss>:
 80034d8:	4b08      	ldr	r3, [pc, #32]	@ (80034fc <LoopForever+0x12>)
 80034da:	429a      	cmp	r2, r3
 80034dc:	d3f9      	bcc.n	80034d2 <FillZerobss>
 80034de:	f3af 8000 	nop.w
 80034e2:	f7fc ff2f 	bl	8000344 <__libc_init_array>
 80034e6:	f7fd fd01 	bl	8000eec <main>

080034ea <LoopForever>:
 80034ea:	e7fe      	b.n	80034ea <LoopForever>
 80034ec:	0800362c 	.word	0x0800362c
 80034f0:	20000000 	.word	0x20000000
 80034f4:	20000538 	.word	0x20000538
 80034f8:	20000538 	.word	0x20000538
 80034fc:	20000f2c 	.word	0x20000f2c

08003500 <BusFault_Handler>:
 8003500:	e7fe      	b.n	8003500 <BusFault_Handler>
	...

08003504 <register_fini>:
 8003504:	4b02      	ldr	r3, [pc, #8]	@ (8003510 <register_fini+0xc>)
 8003506:	b113      	cbz	r3, 800350e <register_fini+0xa>
 8003508:	4802      	ldr	r0, [pc, #8]	@ (8003514 <register_fini+0x10>)
 800350a:	f7fc bfc9 	b.w	80004a0 <atexit>
 800350e:	4770      	bx	lr
 8003510:	00000000 	.word	0x00000000
 8003514:	080003a1 	.word	0x080003a1

08003518 <_init>:
 8003518:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 800351a:	bf00      	nop
 800351c:	bcf8      	pop	{r3, r4, r5, r6, r7}
 800351e:	bc08      	pop	{r3}
 8003520:	469e      	mov	lr, r3
 8003522:	4770      	bx	lr

08003524 <_fini>:
 8003524:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 8003526:	bf00      	nop
 8003528:	bcf8      	pop	{r3, r4, r5, r6, r7}
 800352a:	bc08      	pop	{r3}
 800352c:	469e      	mov	lr, r3
 800352e:	4770      	bx	lr
