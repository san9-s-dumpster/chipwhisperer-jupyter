
/home/ubuntu/Desktop/work/chipwhisperer-new/jupyter/courses/custom/mlkem-samplentt-power-lab/firmware/fls/samplentt-fls-CW308_STM32F4.elf:     file format elf32-littlearm


Disassembly of section .text:

08000188 <deregister_tm_clones>:
 8000188:	4803      	ldr	r0, [pc, #12]	@ (8000198 <deregister_tm_clones+0x10>)
 800018a:	4b04      	ldr	r3, [pc, #16]	@ (800019c <deregister_tm_clones+0x14>)
 800018c:	4283      	cmp	r3, r0
 800018e:	d002      	beq.n	8000196 <deregister_tm_clones+0xe>
 8000190:	4b03      	ldr	r3, [pc, #12]	@ (80001a0 <deregister_tm_clones+0x18>)
 8000192:	b103      	cbz	r3, 8000196 <deregister_tm_clones+0xe>
 8000194:	4718      	bx	r3
 8000196:	4770      	bx	lr
 8000198:	20000538 	.word	0x20000538
 800019c:	20000538 	.word	0x20000538
 80001a0:	00000000 	.word	0x00000000

080001a4 <register_tm_clones>:
 80001a4:	4805      	ldr	r0, [pc, #20]	@ (80001bc <register_tm_clones+0x18>)
 80001a6:	4b06      	ldr	r3, [pc, #24]	@ (80001c0 <register_tm_clones+0x1c>)
 80001a8:	1a1b      	subs	r3, r3, r0
 80001aa:	0fd9      	lsrs	r1, r3, #31
 80001ac:	eb01 01a3 	add.w	r1, r1, r3, asr #2
 80001b0:	1049      	asrs	r1, r1, #1
 80001b2:	d002      	beq.n	80001ba <register_tm_clones+0x16>
 80001b4:	4b03      	ldr	r3, [pc, #12]	@ (80001c4 <register_tm_clones+0x20>)
 80001b6:	b103      	cbz	r3, 80001ba <register_tm_clones+0x16>
 80001b8:	4718      	bx	r3
 80001ba:	4770      	bx	lr
 80001bc:	20000538 	.word	0x20000538
 80001c0:	20000538 	.word	0x20000538
 80001c4:	00000000 	.word	0x00000000

080001c8 <__do_global_dtors_aux>:
 80001c8:	b510      	push	{r4, lr}
 80001ca:	4c06      	ldr	r4, [pc, #24]	@ (80001e4 <__do_global_dtors_aux+0x1c>)
 80001cc:	7823      	ldrb	r3, [r4, #0]
 80001ce:	b943      	cbnz	r3, 80001e2 <__do_global_dtors_aux+0x1a>
 80001d0:	f7ff ffda 	bl	8000188 <deregister_tm_clones>
 80001d4:	4b04      	ldr	r3, [pc, #16]	@ (80001e8 <__do_global_dtors_aux+0x20>)
 80001d6:	b113      	cbz	r3, 80001de <__do_global_dtors_aux+0x16>
 80001d8:	4804      	ldr	r0, [pc, #16]	@ (80001ec <__do_global_dtors_aux+0x24>)
 80001da:	f3af 8000 	nop.w
 80001de:	2301      	movs	r3, #1
 80001e0:	7023      	strb	r3, [r4, #0]
 80001e2:	bd10      	pop	{r4, pc}
 80001e4:	20000538 	.word	0x20000538
 80001e8:	00000000 	.word	0x00000000
 80001ec:	08003564 	.word	0x08003564

080001f0 <frame_dummy>:
 80001f0:	b508      	push	{r3, lr}
 80001f2:	4b04      	ldr	r3, [pc, #16]	@ (8000204 <frame_dummy+0x14>)
 80001f4:	b11b      	cbz	r3, 80001fe <frame_dummy+0xe>
 80001f6:	4904      	ldr	r1, [pc, #16]	@ (8000208 <frame_dummy+0x18>)
 80001f8:	4804      	ldr	r0, [pc, #16]	@ (800020c <frame_dummy+0x1c>)
 80001fa:	f3af 8000 	nop.w
 80001fe:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
 8000202:	e7cf      	b.n	80001a4 <register_tm_clones>
 8000204:	00000000 	.word	0x00000000
 8000208:	2000053c 	.word	0x2000053c
 800020c:	08003564 	.word	0x08003564

08000210 <memcpy>:
 8000210:	4684      	mov	ip, r0
 8000212:	ea41 0300 	orr.w	r3, r1, r0
 8000216:	f013 0303 	ands.w	r3, r3, #3
 800021a:	d16d      	bne.n	80002f8 <memcpy+0xe8>
 800021c:	3a40      	subs	r2, #64	@ 0x40
 800021e:	d341      	bcc.n	80002a4 <memcpy+0x94>
 8000220:	f851 3b04 	ldr.w	r3, [r1], #4
 8000224:	f840 3b04 	str.w	r3, [r0], #4
 8000228:	f851 3b04 	ldr.w	r3, [r1], #4
 800022c:	f840 3b04 	str.w	r3, [r0], #4
 8000230:	f851 3b04 	ldr.w	r3, [r1], #4
 8000234:	f840 3b04 	str.w	r3, [r0], #4
 8000238:	f851 3b04 	ldr.w	r3, [r1], #4
 800023c:	f840 3b04 	str.w	r3, [r0], #4
 8000240:	f851 3b04 	ldr.w	r3, [r1], #4
 8000244:	f840 3b04 	str.w	r3, [r0], #4
 8000248:	f851 3b04 	ldr.w	r3, [r1], #4
 800024c:	f840 3b04 	str.w	r3, [r0], #4
 8000250:	f851 3b04 	ldr.w	r3, [r1], #4
 8000254:	f840 3b04 	str.w	r3, [r0], #4
 8000258:	f851 3b04 	ldr.w	r3, [r1], #4
 800025c:	f840 3b04 	str.w	r3, [r0], #4
 8000260:	f851 3b04 	ldr.w	r3, [r1], #4
 8000264:	f840 3b04 	str.w	r3, [r0], #4
 8000268:	f851 3b04 	ldr.w	r3, [r1], #4
 800026c:	f840 3b04 	str.w	r3, [r0], #4
 8000270:	f851 3b04 	ldr.w	r3, [r1], #4
 8000274:	f840 3b04 	str.w	r3, [r0], #4
 8000278:	f851 3b04 	ldr.w	r3, [r1], #4
 800027c:	f840 3b04 	str.w	r3, [r0], #4
 8000280:	f851 3b04 	ldr.w	r3, [r1], #4
 8000284:	f840 3b04 	str.w	r3, [r0], #4
 8000288:	f851 3b04 	ldr.w	r3, [r1], #4
 800028c:	f840 3b04 	str.w	r3, [r0], #4
 8000290:	f851 3b04 	ldr.w	r3, [r1], #4
 8000294:	f840 3b04 	str.w	r3, [r0], #4
 8000298:	f851 3b04 	ldr.w	r3, [r1], #4
 800029c:	f840 3b04 	str.w	r3, [r0], #4
 80002a0:	3a40      	subs	r2, #64	@ 0x40
 80002a2:	d2bd      	bcs.n	8000220 <memcpy+0x10>
 80002a4:	3230      	adds	r2, #48	@ 0x30
 80002a6:	d311      	bcc.n	80002cc <memcpy+0xbc>
 80002a8:	f851 3b04 	ldr.w	r3, [r1], #4
 80002ac:	f840 3b04 	str.w	r3, [r0], #4
 80002b0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002b4:	f840 3b04 	str.w	r3, [r0], #4
 80002b8:	f851 3b04 	ldr.w	r3, [r1], #4
 80002bc:	f840 3b04 	str.w	r3, [r0], #4
 80002c0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002c4:	f840 3b04 	str.w	r3, [r0], #4
 80002c8:	3a10      	subs	r2, #16
 80002ca:	d2ed      	bcs.n	80002a8 <memcpy+0x98>
 80002cc:	320c      	adds	r2, #12
 80002ce:	d305      	bcc.n	80002dc <memcpy+0xcc>
 80002d0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002d4:	f840 3b04 	str.w	r3, [r0], #4
 80002d8:	3a04      	subs	r2, #4
 80002da:	d2f9      	bcs.n	80002d0 <memcpy+0xc0>
 80002dc:	3204      	adds	r2, #4
 80002de:	d008      	beq.n	80002f2 <memcpy+0xe2>
 80002e0:	07d2      	lsls	r2, r2, #31
 80002e2:	bf1c      	itt	ne
 80002e4:	f811 3b01 	ldrbne.w	r3, [r1], #1
 80002e8:	f800 3b01 	strbne.w	r3, [r0], #1
 80002ec:	d301      	bcc.n	80002f2 <memcpy+0xe2>
 80002ee:	880b      	ldrh	r3, [r1, #0]
 80002f0:	8003      	strh	r3, [r0, #0]
 80002f2:	4660      	mov	r0, ip
 80002f4:	4770      	bx	lr
 80002f6:	bf00      	nop
 80002f8:	2a08      	cmp	r2, #8
 80002fa:	d313      	bcc.n	8000324 <memcpy+0x114>
 80002fc:	078b      	lsls	r3, r1, #30
 80002fe:	d08d      	beq.n	800021c <memcpy+0xc>
 8000300:	f010 0303 	ands.w	r3, r0, #3
 8000304:	d08a      	beq.n	800021c <memcpy+0xc>
 8000306:	f1c3 0304 	rsb	r3, r3, #4
 800030a:	1ad2      	subs	r2, r2, r3
 800030c:	07db      	lsls	r3, r3, #31
 800030e:	bf1c      	itt	ne
 8000310:	f811 3b01 	ldrbne.w	r3, [r1], #1
 8000314:	f800 3b01 	strbne.w	r3, [r0], #1
 8000318:	d380      	bcc.n	800021c <memcpy+0xc>
 800031a:	f831 3b02 	ldrh.w	r3, [r1], #2
 800031e:	f820 3b02 	strh.w	r3, [r0], #2
 8000322:	e77b      	b.n	800021c <memcpy+0xc>
 8000324:	3a04      	subs	r2, #4
 8000326:	d3d9      	bcc.n	80002dc <memcpy+0xcc>
 8000328:	3a01      	subs	r2, #1
 800032a:	f811 3b01 	ldrb.w	r3, [r1], #1
 800032e:	f800 3b01 	strb.w	r3, [r0], #1
 8000332:	d2f9      	bcs.n	8000328 <memcpy+0x118>
 8000334:	780b      	ldrb	r3, [r1, #0]
 8000336:	7003      	strb	r3, [r0, #0]
 8000338:	784b      	ldrb	r3, [r1, #1]
 800033a:	7043      	strb	r3, [r0, #1]
 800033c:	788b      	ldrb	r3, [r1, #2]
 800033e:	7083      	strb	r3, [r0, #2]
 8000340:	4660      	mov	r0, ip
 8000342:	4770      	bx	lr

08000344 <__libc_init_array>:
 8000344:	b570      	push	{r4, r5, r6, lr}
 8000346:	4b0f      	ldr	r3, [pc, #60]	@ (8000384 <__libc_init_array+0x40>)
 8000348:	4d0f      	ldr	r5, [pc, #60]	@ (8000388 <__libc_init_array+0x44>)
 800034a:	42ab      	cmp	r3, r5
 800034c:	eba3 0605 	sub.w	r6, r3, r5
 8000350:	d007      	beq.n	8000362 <__libc_init_array+0x1e>
 8000352:	10b6      	asrs	r6, r6, #2
 8000354:	2400      	movs	r4, #0
 8000356:	f855 3b04 	ldr.w	r3, [r5], #4
 800035a:	3401      	adds	r4, #1
 800035c:	4798      	blx	r3
 800035e:	42a6      	cmp	r6, r4
 8000360:	d8f9      	bhi.n	8000356 <__libc_init_array+0x12>
 8000362:	f003 f8ff 	bl	8003564 <_init>
 8000366:	4d09      	ldr	r5, [pc, #36]	@ (800038c <__libc_init_array+0x48>)
 8000368:	4b09      	ldr	r3, [pc, #36]	@ (8000390 <__libc_init_array+0x4c>)
 800036a:	1b5e      	subs	r6, r3, r5
 800036c:	42ab      	cmp	r3, r5
 800036e:	ea4f 06a6 	mov.w	r6, r6, asr #2
 8000372:	d006      	beq.n	8000382 <__libc_init_array+0x3e>
 8000374:	2400      	movs	r4, #0
 8000376:	f855 3b04 	ldr.w	r3, [r5], #4
 800037a:	3401      	adds	r4, #1
 800037c:	4798      	blx	r3
 800037e:	42a6      	cmp	r6, r4
 8000380:	d8f9      	bhi.n	8000376 <__libc_init_array+0x32>
 8000382:	bd70      	pop	{r4, r5, r6, pc}
 8000384:	08003670 	.word	0x08003670
 8000388:	08003670 	.word	0x08003670
 800038c:	08003670 	.word	0x08003670
 8000390:	08003678 	.word	0x08003678

08000394 <__errno>:
 8000394:	4b01      	ldr	r3, [pc, #4]	@ (800039c <__errno+0x8>)
 8000396:	6818      	ldr	r0, [r3, #0]
 8000398:	4770      	bx	lr
 800039a:	bf00      	nop
 800039c:	20000000 	.word	0x20000000

080003a0 <__libc_fini_array>:
 80003a0:	b538      	push	{r3, r4, r5, lr}
 80003a2:	4d07      	ldr	r5, [pc, #28]	@ (80003c0 <__libc_fini_array+0x20>)
 80003a4:	4c07      	ldr	r4, [pc, #28]	@ (80003c4 <__libc_fini_array+0x24>)
 80003a6:	1b2c      	subs	r4, r5, r4
 80003a8:	10a4      	asrs	r4, r4, #2
 80003aa:	d005      	beq.n	80003b8 <__libc_fini_array+0x18>
 80003ac:	3c01      	subs	r4, #1
 80003ae:	f855 3d04 	ldr.w	r3, [r5, #-4]!
 80003b2:	4798      	blx	r3
 80003b4:	2c00      	cmp	r4, #0
 80003b6:	d1f9      	bne.n	80003ac <__libc_fini_array+0xc>
 80003b8:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
 80003bc:	f003 b8d8 	b.w	8003570 <_fini>
 80003c0:	0800367c 	.word	0x0800367c
 80003c4:	08003678 	.word	0x08003678

080003c8 <malloc>:
 80003c8:	4b02      	ldr	r3, [pc, #8]	@ (80003d4 <malloc+0xc>)
 80003ca:	4601      	mov	r1, r0
 80003cc:	6818      	ldr	r0, [r3, #0]
 80003ce:	f000 b86d 	b.w	80004ac <_malloc_r>
 80003d2:	bf00      	nop
 80003d4:	20000000 	.word	0x20000000

080003d8 <free>:
 80003d8:	4b02      	ldr	r3, [pc, #8]	@ (80003e4 <free+0xc>)
 80003da:	4601      	mov	r1, r0
 80003dc:	6818      	ldr	r0, [r3, #0]
 80003de:	f000 bb9b 	b.w	8000b18 <_free_r>
 80003e2:	bf00      	nop
 80003e4:	20000000 	.word	0x20000000

080003e8 <memset>:
 80003e8:	0783      	lsls	r3, r0, #30
 80003ea:	b530      	push	{r4, r5, lr}
 80003ec:	d046      	beq.n	800047c <memset+0x94>
 80003ee:	1884      	adds	r4, r0, r2
 80003f0:	4684      	mov	ip, r0
 80003f2:	e004      	b.n	80003fe <memset+0x16>
 80003f4:	f803 1b01 	strb.w	r1, [r3], #1
 80003f8:	079d      	lsls	r5, r3, #30
 80003fa:	d004      	beq.n	8000406 <memset+0x1e>
 80003fc:	469c      	mov	ip, r3
 80003fe:	45a4      	cmp	ip, r4
 8000400:	4663      	mov	r3, ip
 8000402:	d1f7      	bne.n	80003f4 <memset+0xc>
 8000404:	bd30      	pop	{r4, r5, pc}
 8000406:	3a01      	subs	r2, #1
 8000408:	4402      	add	r2, r0
 800040a:	eba2 020c 	sub.w	r2, r2, ip
 800040e:	2a03      	cmp	r2, #3
 8000410:	d929      	bls.n	8000466 <memset+0x7e>
 8000412:	b2cc      	uxtb	r4, r1
 8000414:	eb04 2404 	add.w	r4, r4, r4, lsl #8
 8000418:	2a0f      	cmp	r2, #15
 800041a:	eb04 4404 	add.w	r4, r4, r4, lsl #16
 800041e:	d92f      	bls.n	8000480 <memset+0x98>
 8000420:	f1a2 0c10 	sub.w	ip, r2, #16
 8000424:	f02c 0c0f 	bic.w	ip, ip, #15
 8000428:	f103 0510 	add.w	r5, r3, #16
 800042c:	44ac      	add	ip, r5
 800042e:	e9c3 4400 	strd	r4, r4, [r3]
 8000432:	e9c3 4402 	strd	r4, r4, [r3, #8]
 8000436:	3310      	adds	r3, #16
 8000438:	4563      	cmp	r3, ip
 800043a:	d1f8      	bne.n	800042e <memset+0x46>
 800043c:	f012 0f0c 	tst.w	r2, #12
 8000440:	f002 0e0f 	and.w	lr, r2, #15
 8000444:	d018      	beq.n	8000478 <memset+0x90>
 8000446:	f02e 0c03 	bic.w	ip, lr, #3
 800044a:	449c      	add	ip, r3
 800044c:	f1ae 0504 	sub.w	r5, lr, #4
 8000450:	461a      	mov	r2, r3
 8000452:	f842 4b04 	str.w	r4, [r2], #4
 8000456:	4562      	cmp	r2, ip
 8000458:	d1fb      	bne.n	8000452 <memset+0x6a>
 800045a:	f025 0403 	bic.w	r4, r5, #3
 800045e:	3304      	adds	r3, #4
 8000460:	f00e 0203 	and.w	r2, lr, #3
 8000464:	4423      	add	r3, r4
 8000466:	2a00      	cmp	r2, #0
 8000468:	d0cc      	beq.n	8000404 <memset+0x1c>
 800046a:	b2c9      	uxtb	r1, r1
 800046c:	441a      	add	r2, r3
 800046e:	f803 1b01 	strb.w	r1, [r3], #1
 8000472:	4293      	cmp	r3, r2
 8000474:	d1fb      	bne.n	800046e <memset+0x86>
 8000476:	bd30      	pop	{r4, r5, pc}
 8000478:	4672      	mov	r2, lr
 800047a:	e7f4      	b.n	8000466 <memset+0x7e>
 800047c:	4603      	mov	r3, r0
 800047e:	e7c6      	b.n	800040e <memset+0x26>
 8000480:	4696      	mov	lr, r2
 8000482:	e7e0      	b.n	8000446 <memset+0x5e>

08000484 <exit>:
 8000484:	b508      	push	{r3, lr}
 8000486:	2100      	movs	r1, #0
 8000488:	4604      	mov	r4, r0
 800048a:	f000 fc3d 	bl	8000d08 <__call_exitprocs>
 800048e:	4b03      	ldr	r3, [pc, #12]	@ (800049c <exit+0x18>)
 8000490:	681b      	ldr	r3, [r3, #0]
 8000492:	b103      	cbz	r3, 8000496 <exit+0x12>
 8000494:	4798      	blx	r3
 8000496:	4620      	mov	r0, r4
 8000498:	f000 fcd2 	bl	8000e40 <_exit>
 800049c:	20000d5c 	.word	0x20000d5c

080004a0 <atexit>:
 80004a0:	2300      	movs	r3, #0
 80004a2:	4601      	mov	r1, r0
 80004a4:	461a      	mov	r2, r3
 80004a6:	4618      	mov	r0, r3
 80004a8:	f000 bc86 	b.w	8000db8 <__register_exitproc>

080004ac <_malloc_r>:
 80004ac:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 80004b0:	f101 050b 	add.w	r5, r1, #11
 80004b4:	2d16      	cmp	r5, #22
 80004b6:	b083      	sub	sp, #12
 80004b8:	4606      	mov	r6, r0
 80004ba:	d823      	bhi.n	8000504 <_malloc_r+0x58>
 80004bc:	2910      	cmp	r1, #16
 80004be:	f200 80b4 	bhi.w	800062a <_malloc_r+0x17e>
 80004c2:	f000 fcab 	bl	8000e1c <__malloc_lock>
 80004c6:	2510      	movs	r5, #16
 80004c8:	2318      	movs	r3, #24
 80004ca:	2002      	movs	r0, #2
 80004cc:	4fc6      	ldr	r7, [pc, #792]	@ (80007e8 <_malloc_r+0x33c>)
 80004ce:	443b      	add	r3, r7
 80004d0:	f1a3 0208 	sub.w	r2, r3, #8
 80004d4:	685c      	ldr	r4, [r3, #4]
 80004d6:	4294      	cmp	r4, r2
 80004d8:	f000 816c 	beq.w	80007b4 <_malloc_r+0x308>
 80004dc:	6863      	ldr	r3, [r4, #4]
 80004de:	68e2      	ldr	r2, [r4, #12]
 80004e0:	68a1      	ldr	r1, [r4, #8]
 80004e2:	f023 0303 	bic.w	r3, r3, #3
 80004e6:	60ca      	str	r2, [r1, #12]
 80004e8:	4423      	add	r3, r4
 80004ea:	4630      	mov	r0, r6
 80004ec:	6091      	str	r1, [r2, #8]
 80004ee:	685a      	ldr	r2, [r3, #4]
 80004f0:	f042 0201 	orr.w	r2, r2, #1
 80004f4:	605a      	str	r2, [r3, #4]
 80004f6:	f000 fc93 	bl	8000e20 <__malloc_unlock>
 80004fa:	3408      	adds	r4, #8
 80004fc:	4620      	mov	r0, r4
 80004fe:	b003      	add	sp, #12
 8000500:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000504:	f035 0507 	bics.w	r5, r5, #7
 8000508:	f100 808f 	bmi.w	800062a <_malloc_r+0x17e>
 800050c:	42a9      	cmp	r1, r5
 800050e:	f200 808c 	bhi.w	800062a <_malloc_r+0x17e>
 8000512:	f000 fc83 	bl	8000e1c <__malloc_lock>
 8000516:	f5b5 7ffc 	cmp.w	r5, #504	@ 0x1f8
 800051a:	f0c0 81b9 	bcc.w	8000890 <_malloc_r+0x3e4>
 800051e:	ea5f 2e55 	movs.w	lr, r5, lsr #9
 8000522:	f000 8089 	beq.w	8000638 <_malloc_r+0x18c>
 8000526:	f1be 0f04 	cmp.w	lr, #4
 800052a:	f200 8171 	bhi.w	8000810 <_malloc_r+0x364>
 800052e:	ea4f 1e95 	mov.w	lr, r5, lsr #6
 8000532:	f10e 0039 	add.w	r0, lr, #57	@ 0x39
 8000536:	b203      	sxth	r3, r0
 8000538:	f10e 0e38 	add.w	lr, lr, #56	@ 0x38
 800053c:	00db      	lsls	r3, r3, #3
 800053e:	4faa      	ldr	r7, [pc, #680]	@ (80007e8 <_malloc_r+0x33c>)
 8000540:	443b      	add	r3, r7
 8000542:	f1a3 0c08 	sub.w	ip, r3, #8
 8000546:	685c      	ldr	r4, [r3, #4]
 8000548:	45a4      	cmp	ip, r4
 800054a:	d107      	bne.n	800055c <_malloc_r+0xb0>
 800054c:	e00d      	b.n	800056a <_malloc_r+0xbe>
 800054e:	2a00      	cmp	r2, #0
 8000550:	68e1      	ldr	r1, [r4, #12]
 8000552:	f280 8129 	bge.w	80007a8 <_malloc_r+0x2fc>
 8000556:	458c      	cmp	ip, r1
 8000558:	d007      	beq.n	800056a <_malloc_r+0xbe>
 800055a:	460c      	mov	r4, r1
 800055c:	6863      	ldr	r3, [r4, #4]
 800055e:	f023 0303 	bic.w	r3, r3, #3
 8000562:	1b5a      	subs	r2, r3, r5
 8000564:	2a0f      	cmp	r2, #15
 8000566:	ddf2      	ble.n	800054e <_malloc_r+0xa2>
 8000568:	4670      	mov	r0, lr
 800056a:	f8df 8280 	ldr.w	r8, [pc, #640]	@ 80007ec <_malloc_r+0x340>
 800056e:	693c      	ldr	r4, [r7, #16]
 8000570:	4544      	cmp	r4, r8
 8000572:	f000 8106 	beq.w	8000782 <_malloc_r+0x2d6>
 8000576:	6863      	ldr	r3, [r4, #4]
 8000578:	f023 0c03 	bic.w	ip, r3, #3
 800057c:	ebac 0305 	sub.w	r3, ip, r5
 8000580:	2b0f      	cmp	r3, #15
 8000582:	f300 818a 	bgt.w	800089a <_malloc_r+0x3ee>
 8000586:	2b00      	cmp	r3, #0
 8000588:	e9c7 8804 	strd	r8, r8, [r7, #16]
 800058c:	f280 8174 	bge.w	8000878 <_malloc_r+0x3cc>
 8000590:	f5bc 7f00 	cmp.w	ip, #512	@ 0x200
 8000594:	f8d7 e004 	ldr.w	lr, [r7, #4]
 8000598:	f080 8112 	bcs.w	80007c0 <_malloc_r+0x314>
 800059c:	ea4f 03dc 	mov.w	r3, ip, lsr #3
 80005a0:	3301      	adds	r3, #1
 80005a2:	b219      	sxth	r1, r3
 80005a4:	ea4f 1c5c 	mov.w	ip, ip, lsr #5
 80005a8:	2301      	movs	r3, #1
 80005aa:	fa03 f30c 	lsl.w	r3, r3, ip
 80005ae:	f857 2031 	ldr.w	r2, [r7, r1, lsl #3]
 80005b2:	60a2      	str	r2, [r4, #8]
 80005b4:	ea4e 0e03 	orr.w	lr, lr, r3
 80005b8:	eb07 03c1 	add.w	r3, r7, r1, lsl #3
 80005bc:	3b08      	subs	r3, #8
 80005be:	60e3      	str	r3, [r4, #12]
 80005c0:	f8c7 e004 	str.w	lr, [r7, #4]
 80005c4:	f847 4031 	str.w	r4, [r7, r1, lsl #3]
 80005c8:	60d4      	str	r4, [r2, #12]
 80005ca:	1083      	asrs	r3, r0, #2
 80005cc:	f04f 0c01 	mov.w	ip, #1
 80005d0:	fa0c fc03 	lsl.w	ip, ip, r3
 80005d4:	45f4      	cmp	ip, lr
 80005d6:	d835      	bhi.n	8000644 <_malloc_r+0x198>
 80005d8:	ea1c 0f0e 	tst.w	ip, lr
 80005dc:	d108      	bne.n	80005f0 <_malloc_r+0x144>
 80005de:	f020 0003 	bic.w	r0, r0, #3
 80005e2:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 80005e6:	ea1c 0f0e 	tst.w	ip, lr
 80005ea:	f100 0004 	add.w	r0, r0, #4
 80005ee:	d0f8      	beq.n	80005e2 <_malloc_r+0x136>
 80005f0:	eb07 0ac0 	add.w	sl, r7, r0, lsl #3
 80005f4:	46d6      	mov	lr, sl
 80005f6:	4681      	mov	r9, r0
 80005f8:	f8de 300c 	ldr.w	r3, [lr, #12]
 80005fc:	e00b      	b.n	8000616 <_malloc_r+0x16a>
 80005fe:	6859      	ldr	r1, [r3, #4]
 8000600:	f021 0103 	bic.w	r1, r1, #3
 8000604:	1b4a      	subs	r2, r1, r5
 8000606:	2a0f      	cmp	r2, #15
 8000608:	461c      	mov	r4, r3
 800060a:	68db      	ldr	r3, [r3, #12]
 800060c:	f300 8110 	bgt.w	8000830 <_malloc_r+0x384>
 8000610:	2a00      	cmp	r2, #0
 8000612:	f280 8124 	bge.w	800085e <_malloc_r+0x3b2>
 8000616:	459e      	cmp	lr, r3
 8000618:	d1f1      	bne.n	80005fe <_malloc_r+0x152>
 800061a:	f109 0901 	add.w	r9, r9, #1
 800061e:	f019 0f03 	tst.w	r9, #3
 8000622:	f10e 0e08 	add.w	lr, lr, #8
 8000626:	d1e7      	bne.n	80005f8 <_malloc_r+0x14c>
 8000628:	e162      	b.n	80008f0 <_malloc_r+0x444>
 800062a:	230c      	movs	r3, #12
 800062c:	6033      	str	r3, [r6, #0]
 800062e:	2400      	movs	r4, #0
 8000630:	4620      	mov	r0, r4
 8000632:	b003      	add	sp, #12
 8000634:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000638:	f44f 7300 	mov.w	r3, #512	@ 0x200
 800063c:	2040      	movs	r0, #64	@ 0x40
 800063e:	f04f 0e3f 	mov.w	lr, #63	@ 0x3f
 8000642:	e77c      	b.n	800053e <_malloc_r+0x92>
 8000644:	68bc      	ldr	r4, [r7, #8]
 8000646:	6863      	ldr	r3, [r4, #4]
 8000648:	f023 0903 	bic.w	r9, r3, #3
 800064c:	45a9      	cmp	r9, r5
 800064e:	d304      	bcc.n	800065a <_malloc_r+0x1ae>
 8000650:	eba9 0305 	sub.w	r3, r9, r5
 8000654:	2b0f      	cmp	r3, #15
 8000656:	f300 8097 	bgt.w	8000788 <_malloc_r+0x2dc>
 800065a:	f8df b194 	ldr.w	fp, [pc, #404]	@ 80007f0 <_malloc_r+0x344>
 800065e:	f8db 2000 	ldr.w	r2, [fp]
 8000662:	eb04 0309 	add.w	r3, r4, r9
 8000666:	3210      	adds	r2, #16
 8000668:	2008      	movs	r0, #8
 800066a:	eb02 0805 	add.w	r8, r2, r5
 800066e:	9300      	str	r3, [sp, #0]
 8000670:	f000 fbd8 	bl	8000e24 <sysconf>
 8000674:	f8d7 1408 	ldr.w	r1, [r7, #1032]	@ 0x408
 8000678:	3101      	adds	r1, #1
 800067a:	4602      	mov	r2, r0
 800067c:	d005      	beq.n	800068a <_malloc_r+0x1de>
 800067e:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 8000682:	4480      	add	r8, r0
 8000684:	4241      	negs	r1, r0
 8000686:	ea01 0808 	and.w	r8, r1, r8
 800068a:	4641      	mov	r1, r8
 800068c:	4630      	mov	r0, r6
 800068e:	9200      	str	r2, [sp, #0]
 8000690:	f000 f9d4 	bl	8000a3c <_sbrk_r>
 8000694:	f1b0 3fff 	cmp.w	r0, #4294967295	@ 0xffffffff
 8000698:	9a00      	ldr	r2, [sp, #0]
 800069a:	4682      	mov	sl, r0
 800069c:	f000 8119 	beq.w	80008d2 <_malloc_r+0x426>
 80006a0:	eb04 0309 	add.w	r3, r4, r9
 80006a4:	4283      	cmp	r3, r0
 80006a6:	f200 8112 	bhi.w	80008ce <_malloc_r+0x422>
 80006aa:	f8db 1004 	ldr.w	r1, [fp, #4]
 80006ae:	4441      	add	r1, r8
 80006b0:	f8cb 1004 	str.w	r1, [fp, #4]
 80006b4:	f102 3cff 	add.w	ip, r2, #4294967295	@ 0xffffffff
 80006b8:	f000 816d 	beq.w	8000996 <_malloc_r+0x4ea>
 80006bc:	f8d7 0408 	ldr.w	r0, [r7, #1032]	@ 0x408
 80006c0:	3001      	adds	r0, #1
 80006c2:	f000 8174 	beq.w	80009ae <_malloc_r+0x502>
 80006c6:	eb04 0309 	add.w	r3, r4, r9
 80006ca:	ebaa 0303 	sub.w	r3, sl, r3
 80006ce:	4419      	add	r1, r3
 80006d0:	f8cb 1004 	str.w	r1, [fp, #4]
 80006d4:	f01a 0307 	ands.w	r3, sl, #7
 80006d8:	9300      	str	r3, [sp, #0]
 80006da:	f000 812e 	beq.w	800093a <_malloc_r+0x48e>
 80006de:	f1c3 0108 	rsb	r1, r3, #8
 80006e2:	448a      	add	sl, r1
 80006e4:	44d0      	add	r8, sl
 80006e6:	440a      	add	r2, r1
 80006e8:	ea08 010c 	and.w	r1, r8, ip
 80006ec:	1a52      	subs	r2, r2, r1
 80006ee:	ea02 010c 	and.w	r1, r2, ip
 80006f2:	4630      	mov	r0, r6
 80006f4:	9101      	str	r1, [sp, #4]
 80006f6:	f000 f9a1 	bl	8000a3c <_sbrk_r>
 80006fa:	1c42      	adds	r2, r0, #1
 80006fc:	f000 8174 	beq.w	80009e8 <_malloc_r+0x53c>
 8000700:	9901      	ldr	r1, [sp, #4]
 8000702:	eba0 000a 	sub.w	r0, r0, sl
 8000706:	eb00 0801 	add.w	r8, r0, r1
 800070a:	f8db 2004 	ldr.w	r2, [fp, #4]
 800070e:	f8c7 a008 	str.w	sl, [r7, #8]
 8000712:	f048 0001 	orr.w	r0, r8, #1
 8000716:	4411      	add	r1, r2
 8000718:	42bc      	cmp	r4, r7
 800071a:	f8ca 0004 	str.w	r0, [sl, #4]
 800071e:	f8cb 1004 	str.w	r1, [fp, #4]
 8000722:	d015      	beq.n	8000750 <_malloc_r+0x2a4>
 8000724:	f1b9 0f0f 	cmp.w	r9, #15
 8000728:	f240 8144 	bls.w	80009b4 <_malloc_r+0x508>
 800072c:	6862      	ldr	r2, [r4, #4]
 800072e:	f1a9 000c 	sub.w	r0, r9, #12
 8000732:	f020 0007 	bic.w	r0, r0, #7
 8000736:	f002 0201 	and.w	r2, r2, #1
 800073a:	4302      	orrs	r2, r0
 800073c:	6062      	str	r2, [r4, #4]
 800073e:	2305      	movs	r3, #5
 8000740:	1822      	adds	r2, r4, r0
 8000742:	280f      	cmp	r0, #15
 8000744:	e9c2 3301 	strd	r3, r3, [r2, #4]
 8000748:	f200 8156 	bhi.w	80009f8 <_malloc_r+0x54c>
 800074c:	f8da 0004 	ldr.w	r0, [sl, #4]
 8000750:	f8db 202c 	ldr.w	r2, [fp, #44]	@ 0x2c
 8000754:	428a      	cmp	r2, r1
 8000756:	f8db 2030 	ldr.w	r2, [fp, #48]	@ 0x30
 800075a:	bf38      	it	cc
 800075c:	f8cb 102c 	strcc.w	r1, [fp, #44]	@ 0x2c
 8000760:	428a      	cmp	r2, r1
 8000762:	bf38      	it	cc
 8000764:	f8cb 1030 	strcc.w	r1, [fp, #48]	@ 0x30
 8000768:	4654      	mov	r4, sl
 800076a:	f020 0803 	bic.w	r8, r0, #3
 800076e:	45a8      	cmp	r8, r5
 8000770:	eba8 0305 	sub.w	r3, r8, r5
 8000774:	d301      	bcc.n	800077a <_malloc_r+0x2ce>
 8000776:	2b0f      	cmp	r3, #15
 8000778:	dc06      	bgt.n	8000788 <_malloc_r+0x2dc>
 800077a:	4630      	mov	r0, r6
 800077c:	f000 fb50 	bl	8000e20 <__malloc_unlock>
 8000780:	e755      	b.n	800062e <_malloc_r+0x182>
 8000782:	f8d7 e004 	ldr.w	lr, [r7, #4]
 8000786:	e720      	b.n	80005ca <_malloc_r+0x11e>
 8000788:	1962      	adds	r2, r4, r5
 800078a:	f043 0301 	orr.w	r3, r3, #1
 800078e:	f045 0501 	orr.w	r5, r5, #1
 8000792:	6065      	str	r5, [r4, #4]
 8000794:	4630      	mov	r0, r6
 8000796:	60ba      	str	r2, [r7, #8]
 8000798:	6053      	str	r3, [r2, #4]
 800079a:	f000 fb41 	bl	8000e20 <__malloc_unlock>
 800079e:	3408      	adds	r4, #8
 80007a0:	4620      	mov	r0, r4
 80007a2:	b003      	add	sp, #12
 80007a4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 80007a8:	68a2      	ldr	r2, [r4, #8]
 80007aa:	4423      	add	r3, r4
 80007ac:	60d1      	str	r1, [r2, #12]
 80007ae:	4630      	mov	r0, r6
 80007b0:	608a      	str	r2, [r1, #8]
 80007b2:	e69c      	b.n	80004ee <_malloc_r+0x42>
 80007b4:	68dc      	ldr	r4, [r3, #12]
 80007b6:	42a3      	cmp	r3, r4
 80007b8:	f47f ae90 	bne.w	80004dc <_malloc_r+0x30>
 80007bc:	3002      	adds	r0, #2
 80007be:	e6d4      	b.n	800056a <_malloc_r+0xbe>
 80007c0:	f5bc 6f20 	cmp.w	ip, #2560	@ 0xa00
 80007c4:	ea4f 225c 	mov.w	r2, ip, lsr #9
 80007c8:	d379      	bcc.n	80008be <_malloc_r+0x412>
 80007ca:	2a14      	cmp	r2, #20
 80007cc:	f200 80c5 	bhi.w	800095a <_malloc_r+0x4ae>
 80007d0:	f102 035c 	add.w	r3, r2, #92	@ 0x5c
 80007d4:	b21b      	sxth	r3, r3
 80007d6:	325b      	adds	r2, #91	@ 0x5b
 80007d8:	00db      	lsls	r3, r3, #3
 80007da:	18f9      	adds	r1, r7, r3
 80007dc:	58fb      	ldr	r3, [r7, r3]
 80007de:	3908      	subs	r1, #8
 80007e0:	4299      	cmp	r1, r3
 80007e2:	d10a      	bne.n	80007fa <_malloc_r+0x34e>
 80007e4:	e09f      	b.n	8000926 <_malloc_r+0x47a>
 80007e6:	bf00      	nop
 80007e8:	20000128 	.word	0x20000128
 80007ec:	20000130 	.word	0x20000130
 80007f0:	20000d60 	.word	0x20000d60
 80007f4:	689b      	ldr	r3, [r3, #8]
 80007f6:	4299      	cmp	r1, r3
 80007f8:	d004      	beq.n	8000804 <_malloc_r+0x358>
 80007fa:	685a      	ldr	r2, [r3, #4]
 80007fc:	f022 0203 	bic.w	r2, r2, #3
 8000800:	4562      	cmp	r2, ip
 8000802:	d8f7      	bhi.n	80007f4 <_malloc_r+0x348>
 8000804:	68d9      	ldr	r1, [r3, #12]
 8000806:	e9c4 3102 	strd	r3, r1, [r4, #8]
 800080a:	608c      	str	r4, [r1, #8]
 800080c:	60dc      	str	r4, [r3, #12]
 800080e:	e6dc      	b.n	80005ca <_malloc_r+0x11e>
 8000810:	f1be 0f14 	cmp.w	lr, #20
 8000814:	d960      	bls.n	80008d8 <_malloc_r+0x42c>
 8000816:	f1be 0f54 	cmp.w	lr, #84	@ 0x54
 800081a:	f200 80a8 	bhi.w	800096e <_malloc_r+0x4c2>
 800081e:	ea4f 3e15 	mov.w	lr, r5, lsr #12
 8000822:	f10e 006f 	add.w	r0, lr, #111	@ 0x6f
 8000826:	b203      	sxth	r3, r0
 8000828:	f10e 0e6e 	add.w	lr, lr, #110	@ 0x6e
 800082c:	00db      	lsls	r3, r3, #3
 800082e:	e686      	b.n	800053e <_malloc_r+0x92>
 8000830:	f8d4 c008 	ldr.w	ip, [r4, #8]
 8000834:	4630      	mov	r0, r6
 8000836:	1966      	adds	r6, r4, r5
 8000838:	f045 0501 	orr.w	r5, r5, #1
 800083c:	6065      	str	r5, [r4, #4]
 800083e:	f8cc 300c 	str.w	r3, [ip, #12]
 8000842:	f8c3 c008 	str.w	ip, [r3, #8]
 8000846:	f042 0301 	orr.w	r3, r2, #1
 800084a:	e9c7 6604 	strd	r6, r6, [r7, #16]
 800084e:	e9c6 8802 	strd	r8, r8, [r6, #8]
 8000852:	6073      	str	r3, [r6, #4]
 8000854:	5062      	str	r2, [r4, r1]
 8000856:	f000 fae3 	bl	8000e20 <__malloc_unlock>
 800085a:	3408      	adds	r4, #8
 800085c:	e6e8      	b.n	8000630 <_malloc_r+0x184>
 800085e:	4421      	add	r1, r4
 8000860:	4630      	mov	r0, r6
 8000862:	684a      	ldr	r2, [r1, #4]
 8000864:	f042 0201 	orr.w	r2, r2, #1
 8000868:	604a      	str	r2, [r1, #4]
 800086a:	f854 2f08 	ldr.w	r2, [r4, #8]!
 800086e:	60d3      	str	r3, [r2, #12]
 8000870:	609a      	str	r2, [r3, #8]
 8000872:	f000 fad5 	bl	8000e20 <__malloc_unlock>
 8000876:	e6db      	b.n	8000630 <_malloc_r+0x184>
 8000878:	44a4      	add	ip, r4
 800087a:	4630      	mov	r0, r6
 800087c:	f8dc 3004 	ldr.w	r3, [ip, #4]
 8000880:	f043 0301 	orr.w	r3, r3, #1
 8000884:	f8cc 3004 	str.w	r3, [ip, #4]
 8000888:	f000 faca 	bl	8000e20 <__malloc_unlock>
 800088c:	3408      	adds	r4, #8
 800088e:	e6cf      	b.n	8000630 <_malloc_r+0x184>
 8000890:	08e8      	lsrs	r0, r5, #3
 8000892:	1c43      	adds	r3, r0, #1
 8000894:	b21b      	sxth	r3, r3
 8000896:	00db      	lsls	r3, r3, #3
 8000898:	e618      	b.n	80004cc <_malloc_r+0x20>
 800089a:	1962      	adds	r2, r4, r5
 800089c:	f043 0101 	orr.w	r1, r3, #1
 80008a0:	f045 0501 	orr.w	r5, r5, #1
 80008a4:	6065      	str	r5, [r4, #4]
 80008a6:	4630      	mov	r0, r6
 80008a8:	e9c7 2204 	strd	r2, r2, [r7, #16]
 80008ac:	e9c2 8802 	strd	r8, r8, [r2, #8]
 80008b0:	6051      	str	r1, [r2, #4]
 80008b2:	f844 300c 	str.w	r3, [r4, ip]
 80008b6:	f000 fab3 	bl	8000e20 <__malloc_unlock>
 80008ba:	3408      	adds	r4, #8
 80008bc:	e6b8      	b.n	8000630 <_malloc_r+0x184>
 80008be:	ea4f 129c 	mov.w	r2, ip, lsr #6
 80008c2:	f102 0339 	add.w	r3, r2, #57	@ 0x39
 80008c6:	b21b      	sxth	r3, r3
 80008c8:	3238      	adds	r2, #56	@ 0x38
 80008ca:	00db      	lsls	r3, r3, #3
 80008cc:	e785      	b.n	80007da <_malloc_r+0x32e>
 80008ce:	42bc      	cmp	r4, r7
 80008d0:	d059      	beq.n	8000986 <_malloc_r+0x4da>
 80008d2:	68bc      	ldr	r4, [r7, #8]
 80008d4:	6860      	ldr	r0, [r4, #4]
 80008d6:	e748      	b.n	800076a <_malloc_r+0x2be>
 80008d8:	f10e 005c 	add.w	r0, lr, #92	@ 0x5c
 80008dc:	b203      	sxth	r3, r0
 80008de:	f10e 0e5b 	add.w	lr, lr, #91	@ 0x5b
 80008e2:	00db      	lsls	r3, r3, #3
 80008e4:	e62b      	b.n	800053e <_malloc_r+0x92>
 80008e6:	f85a 3908 	ldr.w	r3, [sl], #-8
 80008ea:	4553      	cmp	r3, sl
 80008ec:	f040 80a3 	bne.w	8000a36 <_malloc_r+0x58a>
 80008f0:	f010 0f03 	tst.w	r0, #3
 80008f4:	f100 30ff 	add.w	r0, r0, #4294967295	@ 0xffffffff
 80008f8:	d1f5      	bne.n	80008e6 <_malloc_r+0x43a>
 80008fa:	687b      	ldr	r3, [r7, #4]
 80008fc:	ea23 030c 	bic.w	r3, r3, ip
 8000900:	607b      	str	r3, [r7, #4]
 8000902:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 8000906:	459c      	cmp	ip, r3
 8000908:	f63f ae9c 	bhi.w	8000644 <_malloc_r+0x198>
 800090c:	f1bc 0f00 	cmp.w	ip, #0
 8000910:	d104      	bne.n	800091c <_malloc_r+0x470>
 8000912:	e697      	b.n	8000644 <_malloc_r+0x198>
 8000914:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 8000918:	f109 0904 	add.w	r9, r9, #4
 800091c:	ea1c 0f03 	tst.w	ip, r3
 8000920:	d0f8      	beq.n	8000914 <_malloc_r+0x468>
 8000922:	4648      	mov	r0, r9
 8000924:	e664      	b.n	80005f0 <_malloc_r+0x144>
 8000926:	1092      	asrs	r2, r2, #2
 8000928:	f04f 0c01 	mov.w	ip, #1
 800092c:	fa0c f202 	lsl.w	r2, ip, r2
 8000930:	ea4e 0e02 	orr.w	lr, lr, r2
 8000934:	f8c7 e004 	str.w	lr, [r7, #4]
 8000938:	e765      	b.n	8000806 <_malloc_r+0x35a>
 800093a:	eb0a 0108 	add.w	r1, sl, r8
 800093e:	ea01 010c 	and.w	r1, r1, ip
 8000942:	1a52      	subs	r2, r2, r1
 8000944:	ea02 010c 	and.w	r1, r2, ip
 8000948:	4630      	mov	r0, r6
 800094a:	9101      	str	r1, [sp, #4]
 800094c:	f000 f876 	bl	8000a3c <_sbrk_r>
 8000950:	1c43      	adds	r3, r0, #1
 8000952:	f47f aed5 	bne.w	8000700 <_malloc_r+0x254>
 8000956:	9900      	ldr	r1, [sp, #0]
 8000958:	e6d7      	b.n	800070a <_malloc_r+0x25e>
 800095a:	2a54      	cmp	r2, #84	@ 0x54
 800095c:	d82e      	bhi.n	80009bc <_malloc_r+0x510>
 800095e:	ea4f 321c 	mov.w	r2, ip, lsr #12
 8000962:	f102 036f 	add.w	r3, r2, #111	@ 0x6f
 8000966:	b21b      	sxth	r3, r3
 8000968:	326e      	adds	r2, #110	@ 0x6e
 800096a:	00db      	lsls	r3, r3, #3
 800096c:	e735      	b.n	80007da <_malloc_r+0x32e>
 800096e:	f5be 7faa 	cmp.w	lr, #340	@ 0x154
 8000972:	d82e      	bhi.n	80009d2 <_malloc_r+0x526>
 8000974:	ea4f 3ed5 	mov.w	lr, r5, lsr #15
 8000978:	f10e 0078 	add.w	r0, lr, #120	@ 0x78
 800097c:	b203      	sxth	r3, r0
 800097e:	f10e 0e77 	add.w	lr, lr, #119	@ 0x77
 8000982:	00db      	lsls	r3, r3, #3
 8000984:	e5db      	b.n	800053e <_malloc_r+0x92>
 8000986:	f8db 1004 	ldr.w	r1, [fp, #4]
 800098a:	4441      	add	r1, r8
 800098c:	f8cb 1004 	str.w	r1, [fp, #4]
 8000990:	f102 3cff 	add.w	ip, r2, #4294967295	@ 0xffffffff
 8000994:	e692      	b.n	80006bc <_malloc_r+0x210>
 8000996:	ea10 0f0c 	tst.w	r0, ip
 800099a:	f47f ae8f 	bne.w	80006bc <_malloc_r+0x210>
 800099e:	f8d7 a008 	ldr.w	sl, [r7, #8]
 80009a2:	44c8      	add	r8, r9
 80009a4:	f048 0001 	orr.w	r0, r8, #1
 80009a8:	f8ca 0004 	str.w	r0, [sl, #4]
 80009ac:	e6d0      	b.n	8000750 <_malloc_r+0x2a4>
 80009ae:	f8c7 a408 	str.w	sl, [r7, #1032]	@ 0x408
 80009b2:	e68f      	b.n	80006d4 <_malloc_r+0x228>
 80009b4:	2301      	movs	r3, #1
 80009b6:	f8ca 3004 	str.w	r3, [sl, #4]
 80009ba:	e6de      	b.n	800077a <_malloc_r+0x2ce>
 80009bc:	f5b2 7faa 	cmp.w	r2, #340	@ 0x154
 80009c0:	d824      	bhi.n	8000a0c <_malloc_r+0x560>
 80009c2:	ea4f 32dc 	mov.w	r2, ip, lsr #15
 80009c6:	f102 0378 	add.w	r3, r2, #120	@ 0x78
 80009ca:	b21b      	sxth	r3, r3
 80009cc:	3277      	adds	r2, #119	@ 0x77
 80009ce:	00db      	lsls	r3, r3, #3
 80009d0:	e703      	b.n	80007da <_malloc_r+0x32e>
 80009d2:	f240 5354 	movw	r3, #1364	@ 0x554
 80009d6:	459e      	cmp	lr, r3
 80009d8:	d823      	bhi.n	8000a22 <_malloc_r+0x576>
 80009da:	0cab      	lsrs	r3, r5, #18
 80009dc:	f103 007d 	add.w	r0, r3, #125	@ 0x7d
 80009e0:	f103 0e7c 	add.w	lr, r3, #124	@ 0x7c
 80009e4:	00c3      	lsls	r3, r0, #3
 80009e6:	e5aa      	b.n	800053e <_malloc_r+0x92>
 80009e8:	9b00      	ldr	r3, [sp, #0]
 80009ea:	f1a3 0208 	sub.w	r2, r3, #8
 80009ee:	4490      	add	r8, r2
 80009f0:	eba8 080a 	sub.w	r8, r8, sl
 80009f4:	2100      	movs	r1, #0
 80009f6:	e688      	b.n	800070a <_malloc_r+0x25e>
 80009f8:	f104 0108 	add.w	r1, r4, #8
 80009fc:	4630      	mov	r0, r6
 80009fe:	f000 f88b 	bl	8000b18 <_free_r>
 8000a02:	f8db 1004 	ldr.w	r1, [fp, #4]
 8000a06:	f8d7 a008 	ldr.w	sl, [r7, #8]
 8000a0a:	e69f      	b.n	800074c <_malloc_r+0x2a0>
 8000a0c:	f240 5354 	movw	r3, #1364	@ 0x554
 8000a10:	429a      	cmp	r2, r3
 8000a12:	d80c      	bhi.n	8000a2e <_malloc_r+0x582>
 8000a14:	ea4f 429c 	mov.w	r2, ip, lsr #18
 8000a18:	f102 037d 	add.w	r3, r2, #125	@ 0x7d
 8000a1c:	00db      	lsls	r3, r3, #3
 8000a1e:	327c      	adds	r2, #124	@ 0x7c
 8000a20:	e6db      	b.n	80007da <_malloc_r+0x32e>
 8000a22:	f44f 737e 	mov.w	r3, #1016	@ 0x3f8
 8000a26:	207f      	movs	r0, #127	@ 0x7f
 8000a28:	f04f 0e7e 	mov.w	lr, #126	@ 0x7e
 8000a2c:	e587      	b.n	800053e <_malloc_r+0x92>
 8000a2e:	f44f 737e 	mov.w	r3, #1016	@ 0x3f8
 8000a32:	227e      	movs	r2, #126	@ 0x7e
 8000a34:	e6d1      	b.n	80007da <_malloc_r+0x32e>
 8000a36:	687b      	ldr	r3, [r7, #4]
 8000a38:	e763      	b.n	8000902 <_malloc_r+0x456>
 8000a3a:	bf00      	nop

08000a3c <_sbrk_r>:
 8000a3c:	b538      	push	{r3, r4, r5, lr}
 8000a3e:	4d07      	ldr	r5, [pc, #28]	@ (8000a5c <_sbrk_r+0x20>)
 8000a40:	2200      	movs	r2, #0
 8000a42:	4604      	mov	r4, r0
 8000a44:	4608      	mov	r0, r1
 8000a46:	602a      	str	r2, [r5, #0]
 8000a48:	f002 fba0 	bl	800318c <_sbrk>
 8000a4c:	1c43      	adds	r3, r0, #1
 8000a4e:	d000      	beq.n	8000a52 <_sbrk_r+0x16>
 8000a50:	bd38      	pop	{r3, r4, r5, pc}
 8000a52:	682b      	ldr	r3, [r5, #0]
 8000a54:	2b00      	cmp	r3, #0
 8000a56:	d0fb      	beq.n	8000a50 <_sbrk_r+0x14>
 8000a58:	6023      	str	r3, [r4, #0]
 8000a5a:	bd38      	pop	{r3, r4, r5, pc}
 8000a5c:	20000f28 	.word	0x20000f28

08000a60 <_malloc_trim_r>:
 8000a60:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
 8000a64:	4606      	mov	r6, r0
 8000a66:	2008      	movs	r0, #8
 8000a68:	4689      	mov	r9, r1
 8000a6a:	f000 f9db 	bl	8000e24 <sysconf>
 8000a6e:	f8df 809c 	ldr.w	r8, [pc, #156]	@ 8000b0c <_malloc_trim_r+0xac>
 8000a72:	4605      	mov	r5, r0
 8000a74:	4630      	mov	r0, r6
 8000a76:	f000 f9d1 	bl	8000e1c <__malloc_lock>
 8000a7a:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000a7e:	685f      	ldr	r7, [r3, #4]
 8000a80:	f027 0703 	bic.w	r7, r7, #3
 8000a84:	f1a7 0411 	sub.w	r4, r7, #17
 8000a88:	eba4 0409 	sub.w	r4, r4, r9
 8000a8c:	442c      	add	r4, r5
 8000a8e:	fbb4 f4f5 	udiv	r4, r4, r5
 8000a92:	3c01      	subs	r4, #1
 8000a94:	fb05 f404 	mul.w	r4, r5, r4
 8000a98:	42a5      	cmp	r5, r4
 8000a9a:	dc08      	bgt.n	8000aae <_malloc_trim_r+0x4e>
 8000a9c:	2100      	movs	r1, #0
 8000a9e:	4630      	mov	r0, r6
 8000aa0:	f7ff ffcc 	bl	8000a3c <_sbrk_r>
 8000aa4:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000aa8:	443b      	add	r3, r7
 8000aaa:	4298      	cmp	r0, r3
 8000aac:	d005      	beq.n	8000aba <_malloc_trim_r+0x5a>
 8000aae:	4630      	mov	r0, r6
 8000ab0:	f000 f9b6 	bl	8000e20 <__malloc_unlock>
 8000ab4:	2000      	movs	r0, #0
 8000ab6:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
 8000aba:	4261      	negs	r1, r4
 8000abc:	4630      	mov	r0, r6
 8000abe:	f7ff ffbd 	bl	8000a3c <_sbrk_r>
 8000ac2:	3001      	adds	r0, #1
 8000ac4:	d00f      	beq.n	8000ae6 <_malloc_trim_r+0x86>
 8000ac6:	4a12      	ldr	r2, [pc, #72]	@ (8000b10 <_malloc_trim_r+0xb0>)
 8000ac8:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000acc:	1b3f      	subs	r7, r7, r4
 8000ace:	f047 0701 	orr.w	r7, r7, #1
 8000ad2:	605f      	str	r7, [r3, #4]
 8000ad4:	6813      	ldr	r3, [r2, #0]
 8000ad6:	4630      	mov	r0, r6
 8000ad8:	1b1b      	subs	r3, r3, r4
 8000ada:	6013      	str	r3, [r2, #0]
 8000adc:	f000 f9a0 	bl	8000e20 <__malloc_unlock>
 8000ae0:	2001      	movs	r0, #1
 8000ae2:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
 8000ae6:	2100      	movs	r1, #0
 8000ae8:	4630      	mov	r0, r6
 8000aea:	f7ff ffa7 	bl	8000a3c <_sbrk_r>
 8000aee:	f8d8 2008 	ldr.w	r2, [r8, #8]
 8000af2:	1a83      	subs	r3, r0, r2
 8000af4:	2b0f      	cmp	r3, #15
 8000af6:	ddda      	ble.n	8000aae <_malloc_trim_r+0x4e>
 8000af8:	f043 0301 	orr.w	r3, r3, #1
 8000afc:	6053      	str	r3, [r2, #4]
 8000afe:	4b05      	ldr	r3, [pc, #20]	@ (8000b14 <_malloc_trim_r+0xb4>)
 8000b00:	4903      	ldr	r1, [pc, #12]	@ (8000b10 <_malloc_trim_r+0xb0>)
 8000b02:	681b      	ldr	r3, [r3, #0]
 8000b04:	1ac0      	subs	r0, r0, r3
 8000b06:	6008      	str	r0, [r1, #0]
 8000b08:	e7d1      	b.n	8000aae <_malloc_trim_r+0x4e>
 8000b0a:	bf00      	nop
 8000b0c:	20000128 	.word	0x20000128
 8000b10:	20000d64 	.word	0x20000d64
 8000b14:	20000530 	.word	0x20000530

08000b18 <_free_r>:
 8000b18:	2900      	cmp	r1, #0
 8000b1a:	d05b      	beq.n	8000bd4 <_free_r+0xbc>
 8000b1c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 8000b1e:	460c      	mov	r4, r1
 8000b20:	4607      	mov	r7, r0
 8000b22:	f000 f97b 	bl	8000e1c <__malloc_lock>
 8000b26:	f854 cc04 	ldr.w	ip, [r4, #-4]
 8000b2a:	4d74      	ldr	r5, [pc, #464]	@ (8000cfc <_free_r+0x1e4>)
 8000b2c:	f1a4 0208 	sub.w	r2, r4, #8
 8000b30:	f02c 0301 	bic.w	r3, ip, #1
 8000b34:	18d1      	adds	r1, r2, r3
 8000b36:	68a8      	ldr	r0, [r5, #8]
 8000b38:	684e      	ldr	r6, [r1, #4]
 8000b3a:	4288      	cmp	r0, r1
 8000b3c:	f026 0603 	bic.w	r6, r6, #3
 8000b40:	f00c 0e01 	and.w	lr, ip, #1
 8000b44:	d07e      	beq.n	8000c44 <_free_r+0x12c>
 8000b46:	1988      	adds	r0, r1, r6
 8000b48:	604e      	str	r6, [r1, #4]
 8000b4a:	6840      	ldr	r0, [r0, #4]
 8000b4c:	f000 0001 	and.w	r0, r0, #1
 8000b50:	f1be 0f00 	cmp.w	lr, #0
 8000b54:	d12f      	bne.n	8000bb6 <_free_r+0x9e>
 8000b56:	f854 4c08 	ldr.w	r4, [r4, #-8]
 8000b5a:	1b12      	subs	r2, r2, r4
 8000b5c:	4423      	add	r3, r4
 8000b5e:	6894      	ldr	r4, [r2, #8]
 8000b60:	f105 0c08 	add.w	ip, r5, #8
 8000b64:	4564      	cmp	r4, ip
 8000b66:	d062      	beq.n	8000c2e <_free_r+0x116>
 8000b68:	f8d2 e00c 	ldr.w	lr, [r2, #12]
 8000b6c:	f8c4 e00c 	str.w	lr, [r4, #12]
 8000b70:	f8ce 4008 	str.w	r4, [lr, #8]
 8000b74:	2800      	cmp	r0, #0
 8000b76:	d07f      	beq.n	8000c78 <_free_r+0x160>
 8000b78:	f043 0001 	orr.w	r0, r3, #1
 8000b7c:	6050      	str	r0, [r2, #4]
 8000b7e:	600b      	str	r3, [r1, #0]
 8000b80:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
 8000b84:	d22f      	bcs.n	8000be6 <_free_r+0xce>
 8000b86:	08d9      	lsrs	r1, r3, #3
 8000b88:	6868      	ldr	r0, [r5, #4]
 8000b8a:	095c      	lsrs	r4, r3, #5
 8000b8c:	3101      	adds	r1, #1
 8000b8e:	2301      	movs	r3, #1
 8000b90:	b209      	sxth	r1, r1
 8000b92:	40a3      	lsls	r3, r4
 8000b94:	4303      	orrs	r3, r0
 8000b96:	606b      	str	r3, [r5, #4]
 8000b98:	f855 0031 	ldr.w	r0, [r5, r1, lsl #3]
 8000b9c:	6090      	str	r0, [r2, #8]
 8000b9e:	eb05 03c1 	add.w	r3, r5, r1, lsl #3
 8000ba2:	3b08      	subs	r3, #8
 8000ba4:	60d3      	str	r3, [r2, #12]
 8000ba6:	f845 2031 	str.w	r2, [r5, r1, lsl #3]
 8000baa:	60c2      	str	r2, [r0, #12]
 8000bac:	4638      	mov	r0, r7
 8000bae:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
 8000bb2:	f000 b935 	b.w	8000e20 <__malloc_unlock>
 8000bb6:	b970      	cbnz	r0, 8000bd6 <_free_r+0xbe>
 8000bb8:	4433      	add	r3, r6
 8000bba:	f105 0c08 	add.w	ip, r5, #8
 8000bbe:	6888      	ldr	r0, [r1, #8]
 8000bc0:	4560      	cmp	r0, ip
 8000bc2:	f043 0401 	orr.w	r4, r3, #1
 8000bc6:	d071      	beq.n	8000cac <_free_r+0x194>
 8000bc8:	68c9      	ldr	r1, [r1, #12]
 8000bca:	60c1      	str	r1, [r0, #12]
 8000bcc:	6088      	str	r0, [r1, #8]
 8000bce:	6054      	str	r4, [r2, #4]
 8000bd0:	50d3      	str	r3, [r2, r3]
 8000bd2:	e7d5      	b.n	8000b80 <_free_r+0x68>
 8000bd4:	4770      	bx	lr
 8000bd6:	f04c 0101 	orr.w	r1, ip, #1
 8000bda:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
 8000bde:	f844 1c04 	str.w	r1, [r4, #-4]
 8000be2:	50d3      	str	r3, [r2, r3]
 8000be4:	d3cf      	bcc.n	8000b86 <_free_r+0x6e>
 8000be6:	f5b3 6f20 	cmp.w	r3, #2560	@ 0xa00
 8000bea:	ea4f 2053 	mov.w	r0, r3, lsr #9
 8000bee:	d245      	bcs.n	8000c7c <_free_r+0x164>
 8000bf0:	0998      	lsrs	r0, r3, #6
 8000bf2:	f100 0139 	add.w	r1, r0, #57	@ 0x39
 8000bf6:	b209      	sxth	r1, r1
 8000bf8:	f100 0438 	add.w	r4, r0, #56	@ 0x38
 8000bfc:	00c9      	lsls	r1, r1, #3
 8000bfe:	1868      	adds	r0, r5, r1
 8000c00:	5869      	ldr	r1, [r5, r1]
 8000c02:	3808      	subs	r0, #8
 8000c04:	4288      	cmp	r0, r1
 8000c06:	d103      	bne.n	8000c10 <_free_r+0xf8>
 8000c08:	e057      	b.n	8000cba <_free_r+0x1a2>
 8000c0a:	6889      	ldr	r1, [r1, #8]
 8000c0c:	4288      	cmp	r0, r1
 8000c0e:	d004      	beq.n	8000c1a <_free_r+0x102>
 8000c10:	684c      	ldr	r4, [r1, #4]
 8000c12:	f024 0403 	bic.w	r4, r4, #3
 8000c16:	429c      	cmp	r4, r3
 8000c18:	d8f7      	bhi.n	8000c0a <_free_r+0xf2>
 8000c1a:	68c8      	ldr	r0, [r1, #12]
 8000c1c:	e9c2 1002 	strd	r1, r0, [r2, #8]
 8000c20:	6082      	str	r2, [r0, #8]
 8000c22:	4638      	mov	r0, r7
 8000c24:	60ca      	str	r2, [r1, #12]
 8000c26:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
 8000c2a:	f000 b8f9 	b.w	8000e20 <__malloc_unlock>
 8000c2e:	bb88      	cbnz	r0, 8000c94 <_free_r+0x17c>
 8000c30:	441e      	add	r6, r3
 8000c32:	e9d1 1302 	ldrd	r1, r3, [r1, #8]
 8000c36:	60cb      	str	r3, [r1, #12]
 8000c38:	6099      	str	r1, [r3, #8]
 8000c3a:	f046 0301 	orr.w	r3, r6, #1
 8000c3e:	6053      	str	r3, [r2, #4]
 8000c40:	5196      	str	r6, [r2, r6]
 8000c42:	e7b3      	b.n	8000bac <_free_r+0x94>
 8000c44:	441e      	add	r6, r3
 8000c46:	f1be 0f00 	cmp.w	lr, #0
 8000c4a:	d107      	bne.n	8000c5c <_free_r+0x144>
 8000c4c:	f854 3c08 	ldr.w	r3, [r4, #-8]
 8000c50:	1ad2      	subs	r2, r2, r3
 8000c52:	441e      	add	r6, r3
 8000c54:	e9d2 1302 	ldrd	r1, r3, [r2, #8]
 8000c58:	60cb      	str	r3, [r1, #12]
 8000c5a:	6099      	str	r1, [r3, #8]
 8000c5c:	f046 0301 	orr.w	r3, r6, #1
 8000c60:	6053      	str	r3, [r2, #4]
 8000c62:	4b27      	ldr	r3, [pc, #156]	@ (8000d00 <_free_r+0x1e8>)
 8000c64:	60aa      	str	r2, [r5, #8]
 8000c66:	681b      	ldr	r3, [r3, #0]
 8000c68:	42b3      	cmp	r3, r6
 8000c6a:	d89f      	bhi.n	8000bac <_free_r+0x94>
 8000c6c:	4b25      	ldr	r3, [pc, #148]	@ (8000d04 <_free_r+0x1ec>)
 8000c6e:	4638      	mov	r0, r7
 8000c70:	6819      	ldr	r1, [r3, #0]
 8000c72:	f7ff fef5 	bl	8000a60 <_malloc_trim_r>
 8000c76:	e799      	b.n	8000bac <_free_r+0x94>
 8000c78:	4433      	add	r3, r6
 8000c7a:	e7a0      	b.n	8000bbe <_free_r+0xa6>
 8000c7c:	2814      	cmp	r0, #20
 8000c7e:	d90e      	bls.n	8000c9e <_free_r+0x186>
 8000c80:	2854      	cmp	r0, #84	@ 0x54
 8000c82:	d821      	bhi.n	8000cc8 <_free_r+0x1b0>
 8000c84:	0b18      	lsrs	r0, r3, #12
 8000c86:	f100 016f 	add.w	r1, r0, #111	@ 0x6f
 8000c8a:	b209      	sxth	r1, r1
 8000c8c:	f100 046e 	add.w	r4, r0, #110	@ 0x6e
 8000c90:	00c9      	lsls	r1, r1, #3
 8000c92:	e7b4      	b.n	8000bfe <_free_r+0xe6>
 8000c94:	f043 0001 	orr.w	r0, r3, #1
 8000c98:	6050      	str	r0, [r2, #4]
 8000c9a:	600b      	str	r3, [r1, #0]
 8000c9c:	e786      	b.n	8000bac <_free_r+0x94>
 8000c9e:	f100 015c 	add.w	r1, r0, #92	@ 0x5c
 8000ca2:	b209      	sxth	r1, r1
 8000ca4:	f100 045b 	add.w	r4, r0, #91	@ 0x5b
 8000ca8:	00c9      	lsls	r1, r1, #3
 8000caa:	e7a8      	b.n	8000bfe <_free_r+0xe6>
 8000cac:	e9c5 2204 	strd	r2, r2, [r5, #16]
 8000cb0:	e9c2 cc02 	strd	ip, ip, [r2, #8]
 8000cb4:	6054      	str	r4, [r2, #4]
 8000cb6:	50d3      	str	r3, [r2, r3]
 8000cb8:	e778      	b.n	8000bac <_free_r+0x94>
 8000cba:	686e      	ldr	r6, [r5, #4]
 8000cbc:	10a4      	asrs	r4, r4, #2
 8000cbe:	2301      	movs	r3, #1
 8000cc0:	40a3      	lsls	r3, r4
 8000cc2:	4333      	orrs	r3, r6
 8000cc4:	606b      	str	r3, [r5, #4]
 8000cc6:	e7a9      	b.n	8000c1c <_free_r+0x104>
 8000cc8:	f5b0 7faa 	cmp.w	r0, #340	@ 0x154
 8000ccc:	d807      	bhi.n	8000cde <_free_r+0x1c6>
 8000cce:	0bd8      	lsrs	r0, r3, #15
 8000cd0:	f100 0178 	add.w	r1, r0, #120	@ 0x78
 8000cd4:	b209      	sxth	r1, r1
 8000cd6:	f100 0477 	add.w	r4, r0, #119	@ 0x77
 8000cda:	00c9      	lsls	r1, r1, #3
 8000cdc:	e78f      	b.n	8000bfe <_free_r+0xe6>
 8000cde:	f240 5154 	movw	r1, #1364	@ 0x554
 8000ce2:	4288      	cmp	r0, r1
 8000ce4:	d806      	bhi.n	8000cf4 <_free_r+0x1dc>
 8000ce6:	0c98      	lsrs	r0, r3, #18
 8000ce8:	f100 017d 	add.w	r1, r0, #125	@ 0x7d
 8000cec:	f100 047c 	add.w	r4, r0, #124	@ 0x7c
 8000cf0:	00c9      	lsls	r1, r1, #3
 8000cf2:	e784      	b.n	8000bfe <_free_r+0xe6>
 8000cf4:	f44f 717e 	mov.w	r1, #1016	@ 0x3f8
 8000cf8:	247e      	movs	r4, #126	@ 0x7e
 8000cfa:	e780      	b.n	8000bfe <_free_r+0xe6>
 8000cfc:	20000128 	.word	0x20000128
 8000d00:	20000534 	.word	0x20000534
 8000d04:	20000d60 	.word	0x20000d60

08000d08 <__call_exitprocs>:
 8000d08:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8000d0c:	4f29      	ldr	r7, [pc, #164]	@ (8000db4 <__call_exitprocs+0xac>)
 8000d0e:	b083      	sub	sp, #12
 8000d10:	683e      	ldr	r6, [r7, #0]
 8000d12:	9001      	str	r0, [sp, #4]
 8000d14:	b1b6      	cbz	r6, 8000d44 <__call_exitprocs+0x3c>
 8000d16:	468b      	mov	fp, r1
 8000d18:	f04f 0900 	mov.w	r9, #0
 8000d1c:	f04f 0801 	mov.w	r8, #1
 8000d20:	6874      	ldr	r4, [r6, #4]
 8000d22:	1e65      	subs	r5, r4, #1
 8000d24:	d40e      	bmi.n	8000d44 <__call_exitprocs+0x3c>
 8000d26:	3401      	adds	r4, #1
 8000d28:	eb06 0484 	add.w	r4, r6, r4, lsl #2
 8000d2c:	f1bb 0f00 	cmp.w	fp, #0
 8000d30:	d00b      	beq.n	8000d4a <__call_exitprocs+0x42>
 8000d32:	f8d4 3100 	ldr.w	r3, [r4, #256]	@ 0x100
 8000d36:	455b      	cmp	r3, fp
 8000d38:	d007      	beq.n	8000d4a <__call_exitprocs+0x42>
 8000d3a:	3d01      	subs	r5, #1
 8000d3c:	1c6a      	adds	r2, r5, #1
 8000d3e:	f1a4 0404 	sub.w	r4, r4, #4
 8000d42:	d1f6      	bne.n	8000d32 <__call_exitprocs+0x2a>
 8000d44:	b003      	add	sp, #12
 8000d46:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000d4a:	6873      	ldr	r3, [r6, #4]
 8000d4c:	6822      	ldr	r2, [r4, #0]
 8000d4e:	3b01      	subs	r3, #1
 8000d50:	42ab      	cmp	r3, r5
 8000d52:	bf0c      	ite	eq
 8000d54:	6075      	streq	r5, [r6, #4]
 8000d56:	f8c4 9000 	strne.w	r9, [r4]
 8000d5a:	b17a      	cbz	r2, 8000d7c <__call_exitprocs+0x74>
 8000d5c:	f8d6 1188 	ldr.w	r1, [r6, #392]	@ 0x188
 8000d60:	f8d6 a004 	ldr.w	sl, [r6, #4]
 8000d64:	fa08 fc05 	lsl.w	ip, r8, r5
 8000d68:	ea1c 0f01 	tst.w	ip, r1
 8000d6c:	d10e      	bne.n	8000d8c <__call_exitprocs+0x84>
 8000d6e:	4790      	blx	r2
 8000d70:	6871      	ldr	r1, [r6, #4]
 8000d72:	683a      	ldr	r2, [r7, #0]
 8000d74:	4551      	cmp	r1, sl
 8000d76:	d116      	bne.n	8000da6 <__call_exitprocs+0x9e>
 8000d78:	42b2      	cmp	r2, r6
 8000d7a:	d114      	bne.n	8000da6 <__call_exitprocs+0x9e>
 8000d7c:	3d01      	subs	r5, #1
 8000d7e:	1c6b      	adds	r3, r5, #1
 8000d80:	f1a4 0404 	sub.w	r4, r4, #4
 8000d84:	d1d2      	bne.n	8000d2c <__call_exitprocs+0x24>
 8000d86:	b003      	add	sp, #12
 8000d88:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000d8c:	f8d6 318c 	ldr.w	r3, [r6, #396]	@ 0x18c
 8000d90:	f8d4 1080 	ldr.w	r1, [r4, #128]	@ 0x80
 8000d94:	ea1c 0f03 	tst.w	ip, r3
 8000d98:	d109      	bne.n	8000dae <__call_exitprocs+0xa6>
 8000d9a:	9801      	ldr	r0, [sp, #4]
 8000d9c:	4790      	blx	r2
 8000d9e:	6871      	ldr	r1, [r6, #4]
 8000da0:	683a      	ldr	r2, [r7, #0]
 8000da2:	4551      	cmp	r1, sl
 8000da4:	d0e8      	beq.n	8000d78 <__call_exitprocs+0x70>
 8000da6:	2a00      	cmp	r2, #0
 8000da8:	d0cc      	beq.n	8000d44 <__call_exitprocs+0x3c>
 8000daa:	4616      	mov	r6, r2
 8000dac:	e7b8      	b.n	8000d20 <__call_exitprocs+0x18>
 8000dae:	4608      	mov	r0, r1
 8000db0:	4790      	blx	r2
 8000db2:	e7dd      	b.n	8000d70 <__call_exitprocs+0x68>
 8000db4:	20000d94 	.word	0x20000d94

08000db8 <__register_exitproc>:
 8000db8:	b470      	push	{r4, r5, r6}
 8000dba:	4d16      	ldr	r5, [pc, #88]	@ (8000e14 <__register_exitproc+0x5c>)
 8000dbc:	682c      	ldr	r4, [r5, #0]
 8000dbe:	b31c      	cbz	r4, 8000e08 <__register_exitproc+0x50>
 8000dc0:	6865      	ldr	r5, [r4, #4]
 8000dc2:	2d1f      	cmp	r5, #31
 8000dc4:	dc23      	bgt.n	8000e0e <__register_exitproc+0x56>
 8000dc6:	b938      	cbnz	r0, 8000dd8 <__register_exitproc+0x20>
 8000dc8:	1cab      	adds	r3, r5, #2
 8000dca:	3501      	adds	r5, #1
 8000dcc:	6065      	str	r5, [r4, #4]
 8000dce:	f844 1023 	str.w	r1, [r4, r3, lsl #2]
 8000dd2:	2000      	movs	r0, #0
 8000dd4:	bc70      	pop	{r4, r5, r6}
 8000dd6:	4770      	bx	lr
 8000dd8:	eb04 0c85 	add.w	ip, r4, r5, lsl #2
 8000ddc:	2802      	cmp	r0, #2
 8000dde:	f8cc 2088 	str.w	r2, [ip, #136]	@ 0x88
 8000de2:	f8d4 6188 	ldr.w	r6, [r4, #392]	@ 0x188
 8000de6:	f04f 0201 	mov.w	r2, #1
 8000dea:	fa02 f205 	lsl.w	r2, r2, r5
 8000dee:	ea46 0602 	orr.w	r6, r6, r2
 8000df2:	f8c4 6188 	str.w	r6, [r4, #392]	@ 0x188
 8000df6:	f8cc 3108 	str.w	r3, [ip, #264]	@ 0x108
 8000dfa:	d1e5      	bne.n	8000dc8 <__register_exitproc+0x10>
 8000dfc:	f8d4 318c 	ldr.w	r3, [r4, #396]	@ 0x18c
 8000e00:	4313      	orrs	r3, r2
 8000e02:	f8c4 318c 	str.w	r3, [r4, #396]	@ 0x18c
 8000e06:	e7df      	b.n	8000dc8 <__register_exitproc+0x10>
 8000e08:	4c03      	ldr	r4, [pc, #12]	@ (8000e18 <__register_exitproc+0x60>)
 8000e0a:	602c      	str	r4, [r5, #0]
 8000e0c:	e7d8      	b.n	8000dc0 <__register_exitproc+0x8>
 8000e0e:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 8000e12:	e7df      	b.n	8000dd4 <__register_exitproc+0x1c>
 8000e14:	20000d94 	.word	0x20000d94
 8000e18:	20000d98 	.word	0x20000d98

08000e1c <__malloc_lock>:
 8000e1c:	4770      	bx	lr
 8000e1e:	bf00      	nop

08000e20 <__malloc_unlock>:
 8000e20:	4770      	bx	lr
 8000e22:	bf00      	nop

08000e24 <sysconf>:
 8000e24:	2808      	cmp	r0, #8
 8000e26:	d102      	bne.n	8000e2e <sysconf+0xa>
 8000e28:	f44f 5080 	mov.w	r0, #4096	@ 0x1000
 8000e2c:	4770      	bx	lr
 8000e2e:	b508      	push	{r3, lr}
 8000e30:	f7ff fab0 	bl	8000394 <__errno>
 8000e34:	2316      	movs	r3, #22
 8000e36:	6003      	str	r3, [r0, #0]
 8000e38:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 8000e3c:	bd08      	pop	{r3, pc}
 8000e3e:	bf00      	nop

08000e40 <_exit>:
 8000e40:	e7fe      	b.n	8000e40 <_exit>
 8000e42:	bf00      	nop

08000e44 <identity>:
 8000e44:	b109      	cbz	r1, 8000e4a <identity+0x6>
 8000e46:	2001      	movs	r0, #1
 8000e48:	4770      	bx	lr
 8000e4a:	b530      	push	{r4, r5, lr}
 8000e4c:	4d0a      	ldr	r5, [pc, #40]	@ (8000e78 <identity+0x34>)
 8000e4e:	460c      	mov	r4, r1
 8000e50:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
 8000e52:	b087      	sub	sp, #28
 8000e54:	46ec      	mov	ip, sp
 8000e56:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 8000e5a:	e895 0003 	ldmia.w	r5, {r0, r1}
 8000e5e:	f84c 0b04 	str.w	r0, [ip], #4
 8000e62:	466a      	mov	r2, sp
 8000e64:	f88c 1000 	strb.w	r1, [ip]
 8000e68:	2069      	movs	r0, #105	@ 0x69
 8000e6a:	2115      	movs	r1, #21
 8000e6c:	f002 fb46 	bl	80034fc <simpleserial_put>
 8000e70:	4620      	mov	r0, r4
 8000e72:	b007      	add	sp, #28
 8000e74:	bd30      	pop	{r4, r5, pc}
 8000e76:	bf00      	nop
 8000e78:	08003650 	.word	0x08003650

08000e7c <sample>:
 8000e7c:	2922      	cmp	r1, #34	@ 0x22
 8000e7e:	d001      	beq.n	8000e84 <sample+0x8>
 8000e80:	2001      	movs	r0, #1
 8000e82:	4770      	bx	lr
 8000e84:	b510      	push	{r4, lr}
 8000e86:	f44f 7200 	mov.w	r2, #512	@ 0x200
 8000e8a:	2100      	movs	r1, #0
 8000e8c:	4604      	mov	r4, r0
 8000e8e:	4813      	ldr	r0, [pc, #76]	@ (8000edc <sample+0x60>)
 8000e90:	f7ff faaa 	bl	80003e8 <memset>
 8000e94:	f001 fc2e 	bl	80026f4 <trigger_high>
 8000e98:	4810      	ldr	r0, [pc, #64]	@ (8000edc <sample+0x60>)
 8000e9a:	4621      	mov	r1, r4
 8000e9c:	f000 f840 	bl	8000f20 <algorithmA1>
 8000ea0:	f001 fc30 	bl	8002704 <trigger_low>
 8000ea4:	490e      	ldr	r1, [pc, #56]	@ (8000ee0 <sample+0x64>)
 8000ea6:	f201 2302 	addw	r3, r1, #514	@ 0x202
 8000eaa:	f201 4002 	addw	r0, r1, #1026	@ 0x402
 8000eae:	f931 2f02 	ldrsh.w	r2, [r1, #2]!
 8000eb2:	701a      	strb	r2, [r3, #0]
 8000eb4:	f3c2 2207 	ubfx	r2, r2, #8, #8
 8000eb8:	705a      	strb	r2, [r3, #1]
 8000eba:	3302      	adds	r3, #2
 8000ebc:	4283      	cmp	r3, r0
 8000ebe:	d1f6      	bne.n	8000eae <sample+0x32>
 8000ec0:	4908      	ldr	r1, [pc, #32]	@ (8000ee4 <sample+0x68>)
 8000ec2:	f44f 7200 	mov.w	r2, #512	@ 0x200
 8000ec6:	1888      	adds	r0, r1, r2
 8000ec8:	f001 fb34 	bl	8002534 <sha3_256>
 8000ecc:	4a06      	ldr	r2, [pc, #24]	@ (8000ee8 <sample+0x6c>)
 8000ece:	2120      	movs	r1, #32
 8000ed0:	2072      	movs	r0, #114	@ 0x72
 8000ed2:	f002 fb13 	bl	80034fc <simpleserial_put>
 8000ed6:	2000      	movs	r0, #0
 8000ed8:	bd10      	pop	{r4, pc}
 8000eda:	bf00      	nop
 8000edc:	20000558 	.word	0x20000558
 8000ee0:	20000556 	.word	0x20000556
 8000ee4:	20000758 	.word	0x20000758
 8000ee8:	20000958 	.word	0x20000958

08000eec <main>:
 8000eec:	b508      	push	{r3, lr}
 8000eee:	f001 fb5f 	bl	80025b0 <platform_init>
 8000ef2:	f001 fb9d 	bl	8002630 <init_uart>
 8000ef6:	f001 fbdb 	bl	80026b0 <trigger_setup>
 8000efa:	f002 fa37 	bl	800336c <simpleserial_init>
 8000efe:	4a06      	ldr	r2, [pc, #24]	@ (8000f18 <main+0x2c>)
 8000f00:	2122      	movs	r1, #34	@ 0x22
 8000f02:	2070      	movs	r0, #112	@ 0x70
 8000f04:	f002 fa68 	bl	80033d8 <simpleserial_addcmd>
 8000f08:	4a04      	ldr	r2, [pc, #16]	@ (8000f1c <main+0x30>)
 8000f0a:	2100      	movs	r1, #0
 8000f0c:	2069      	movs	r0, #105	@ 0x69
 8000f0e:	f002 fa63 	bl	80033d8 <simpleserial_addcmd>
 8000f12:	f002 fa7d 	bl	8003410 <simpleserial_get>
 8000f16:	e7fc      	b.n	8000f12 <main+0x26>
 8000f18:	08000e7d 	.word	0x08000e7d
 8000f1c:	08000e45 	.word	0x08000e45

08000f20 <algorithmA1>:
 8000f20:	e92d 47f0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, lr}
 8000f24:	b082      	sub	sp, #8
 8000f26:	460c      	mov	r4, r1
 8000f28:	4605      	mov	r5, r0
 8000f2a:	a801      	add	r0, sp, #4
 8000f2c:	f001 fab0 	bl	8002490 <shake128_inc_init>
 8000f30:	4621      	mov	r1, r4
 8000f32:	2222      	movs	r2, #34	@ 0x22
 8000f34:	a801      	add	r0, sp, #4
 8000f36:	f001 fabf 	bl	80024b8 <shake128_inc_absorb>
 8000f3a:	a801      	add	r0, sp, #4
 8000f3c:	f001 fac2 	bl	80024c4 <shake128_inc_finalize>
 8000f40:	f44f 748c 	mov.w	r4, #280	@ 0x118
 8000f44:	2600      	movs	r6, #0
 8000f46:	3d02      	subs	r5, #2
 8000f48:	aa01      	add	r2, sp, #4
 8000f4a:	2103      	movs	r1, #3
 8000f4c:	4668      	mov	r0, sp
 8000f4e:	f001 fae9 	bl	8002524 <shake128_inc_squeeze>
 8000f52:	f89d 0002 	ldrb.w	r0, [sp, #2]
 8000f56:	f89d 3001 	ldrb.w	r3, [sp, #1]
 8000f5a:	f8bd 9000 	ldrh.w	r9, [sp]
 8000f5e:	0100      	lsls	r0, r0, #4
 8000f60:	ea40 1013 	orr.w	r0, r0, r3, lsr #4
 8000f64:	f3c9 090b 	ubfx	r9, r9, #0, #12
 8000f68:	f46f 6350 	mvn.w	r3, #3328	@ 0xd00
 8000f6c:	f46f 6250 	mvn.w	r2, #3328	@ 0xd00
 8000f70:	eb09 0803 	add.w	r8, r9, r3
 8000f74:	eb00 0c02 	add.w	ip, r0, r2
 8000f78:	f04f 0e00 	mov.w	lr, #0
 8000f7c:	ea4f 78e8 	mov.w	r8, r8, asr #31
 8000f80:	ea4f 7cec 	mov.w	ip, ip, asr #31
 8000f84:	4629      	mov	r1, r5
 8000f86:	462f      	mov	r7, r5
 8000f88:	ea86 030e 	eor.w	r3, r6, lr
 8000f8c:	f937 2f02 	ldrsh.w	r2, [r7, #2]!
 8000f90:	f3c3 030e 	ubfx	r3, r3, #0, #15
 8000f94:	425b      	negs	r3, r3
 8000f96:	ea82 0a09 	eor.w	sl, r2, r9
 8000f9a:	13db      	asrs	r3, r3, #15
 8000f9c:	f10e 0e01 	add.w	lr, lr, #1
 8000fa0:	ea2a 0303 	bic.w	r3, sl, r3
 8000fa4:	405a      	eors	r2, r3
 8000fa6:	f5be 7f80 	cmp.w	lr, #256	@ 0x100
 8000faa:	803a      	strh	r2, [r7, #0]
 8000fac:	d1ec      	bne.n	8000f88 <algorithmA1+0x68>
 8000fae:	f008 0701 	and.w	r7, r8, #1
 8000fb2:	4437      	add	r7, r6
 8000fb4:	b2bf      	uxth	r7, r7
 8000fb6:	2600      	movs	r6, #0
 8000fb8:	ea87 0306 	eor.w	r3, r7, r6
 8000fbc:	f931 2f02 	ldrsh.w	r2, [r1, #2]!
 8000fc0:	f3c3 030e 	ubfx	r3, r3, #0, #15
 8000fc4:	425b      	negs	r3, r3
 8000fc6:	ea80 0e02 	eor.w	lr, r0, r2
 8000fca:	13db      	asrs	r3, r3, #15
 8000fcc:	ea2e 0303 	bic.w	r3, lr, r3
 8000fd0:	3601      	adds	r6, #1
 8000fd2:	405a      	eors	r2, r3
 8000fd4:	f5b6 7f80 	cmp.w	r6, #256	@ 0x100
 8000fd8:	800a      	strh	r2, [r1, #0]
 8000fda:	d1ed      	bne.n	8000fb8 <algorithmA1+0x98>
 8000fdc:	f00c 0c01 	and.w	ip, ip, #1
 8000fe0:	4467      	add	r7, ip
 8000fe2:	3c01      	subs	r4, #1
 8000fe4:	b2be      	uxth	r6, r7
 8000fe6:	d1af      	bne.n	8000f48 <algorithmA1+0x28>
 8000fe8:	a801      	add	r0, sp, #4
 8000fea:	f001 fa9f 	bl	800252c <shake128_inc_ctx_release>
 8000fee:	b002      	add	sp, #8
 8000ff0:	e8bd 87f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, pc}

08000ff4 <KeccakF1600_StatePermute>:
 8000ff4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8000ff8:	b0bf      	sub	sp, #252	@ 0xfc
 8000ffa:	6803      	ldr	r3, [r0, #0]
 8000ffc:	9304      	str	r3, [sp, #16]
 8000ffe:	6843      	ldr	r3, [r0, #4]
 8001000:	9305      	str	r3, [sp, #20]
 8001002:	6883      	ldr	r3, [r0, #8]
 8001004:	9306      	str	r3, [sp, #24]
 8001006:	68c3      	ldr	r3, [r0, #12]
 8001008:	9303      	str	r3, [sp, #12]
 800100a:	4b35      	ldr	r3, [pc, #212]	@ (80010e0 <KeccakF1600_StatePermute+0xec>)
 800100c:	9301      	str	r3, [sp, #4]
 800100e:	6903      	ldr	r3, [r0, #16]
 8001010:	9307      	str	r3, [sp, #28]
 8001012:	6943      	ldr	r3, [r0, #20]
 8001014:	9308      	str	r3, [sp, #32]
 8001016:	6983      	ldr	r3, [r0, #24]
 8001018:	9309      	str	r3, [sp, #36]	@ 0x24
 800101a:	69c3      	ldr	r3, [r0, #28]
 800101c:	930a      	str	r3, [sp, #40]	@ 0x28
 800101e:	6a03      	ldr	r3, [r0, #32]
 8001020:	930b      	str	r3, [sp, #44]	@ 0x2c
 8001022:	6a43      	ldr	r3, [r0, #36]	@ 0x24
 8001024:	930c      	str	r3, [sp, #48]	@ 0x30
 8001026:	6a83      	ldr	r3, [r0, #40]	@ 0x28
 8001028:	930d      	str	r3, [sp, #52]	@ 0x34
 800102a:	6ac3      	ldr	r3, [r0, #44]	@ 0x2c
 800102c:	930e      	str	r3, [sp, #56]	@ 0x38
 800102e:	6b03      	ldr	r3, [r0, #48]	@ 0x30
 8001030:	930f      	str	r3, [sp, #60]	@ 0x3c
 8001032:	6b43      	ldr	r3, [r0, #52]	@ 0x34
 8001034:	9310      	str	r3, [sp, #64]	@ 0x40
 8001036:	6b83      	ldr	r3, [r0, #56]	@ 0x38
 8001038:	9311      	str	r3, [sp, #68]	@ 0x44
 800103a:	6bc3      	ldr	r3, [r0, #60]	@ 0x3c
 800103c:	9312      	str	r3, [sp, #72]	@ 0x48
 800103e:	6c03      	ldr	r3, [r0, #64]	@ 0x40
 8001040:	9313      	str	r3, [sp, #76]	@ 0x4c
 8001042:	6c43      	ldr	r3, [r0, #68]	@ 0x44
 8001044:	9314      	str	r3, [sp, #80]	@ 0x50
 8001046:	6c83      	ldr	r3, [r0, #72]	@ 0x48
 8001048:	9315      	str	r3, [sp, #84]	@ 0x54
 800104a:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
 800104c:	9316      	str	r3, [sp, #88]	@ 0x58
 800104e:	e9d0 9314 	ldrd	r9, r3, [r0, #80]	@ 0x50
 8001052:	9317      	str	r3, [sp, #92]	@ 0x5c
 8001054:	6d83      	ldr	r3, [r0, #88]	@ 0x58
 8001056:	9318      	str	r3, [sp, #96]	@ 0x60
 8001058:	6dc3      	ldr	r3, [r0, #92]	@ 0x5c
 800105a:	9319      	str	r3, [sp, #100]	@ 0x64
 800105c:	6e03      	ldr	r3, [r0, #96]	@ 0x60
 800105e:	931a      	str	r3, [sp, #104]	@ 0x68
 8001060:	6e43      	ldr	r3, [r0, #100]	@ 0x64
 8001062:	931b      	str	r3, [sp, #108]	@ 0x6c
 8001064:	6e83      	ldr	r3, [r0, #104]	@ 0x68
 8001066:	931c      	str	r3, [sp, #112]	@ 0x70
 8001068:	6ec3      	ldr	r3, [r0, #108]	@ 0x6c
 800106a:	931d      	str	r3, [sp, #116]	@ 0x74
 800106c:	6f03      	ldr	r3, [r0, #112]	@ 0x70
 800106e:	931e      	str	r3, [sp, #120]	@ 0x78
 8001070:	6f43      	ldr	r3, [r0, #116]	@ 0x74
 8001072:	931f      	str	r3, [sp, #124]	@ 0x7c
 8001074:	6f83      	ldr	r3, [r0, #120]	@ 0x78
 8001076:	9320      	str	r3, [sp, #128]	@ 0x80
 8001078:	6fc3      	ldr	r3, [r0, #124]	@ 0x7c
 800107a:	9321      	str	r3, [sp, #132]	@ 0x84
 800107c:	f8d0 3080 	ldr.w	r3, [r0, #128]	@ 0x80
 8001080:	9322      	str	r3, [sp, #136]	@ 0x88
 8001082:	f8d0 3084 	ldr.w	r3, [r0, #132]	@ 0x84
 8001086:	9323      	str	r3, [sp, #140]	@ 0x8c
 8001088:	f8d0 3088 	ldr.w	r3, [r0, #136]	@ 0x88
 800108c:	9324      	str	r3, [sp, #144]	@ 0x90
 800108e:	f8d0 308c 	ldr.w	r3, [r0, #140]	@ 0x8c
 8001092:	9325      	str	r3, [sp, #148]	@ 0x94
 8001094:	f8d0 3090 	ldr.w	r3, [r0, #144]	@ 0x90
 8001098:	9326      	str	r3, [sp, #152]	@ 0x98
 800109a:	f8d0 3094 	ldr.w	r3, [r0, #148]	@ 0x94
 800109e:	9327      	str	r3, [sp, #156]	@ 0x9c
 80010a0:	f8d0 3098 	ldr.w	r3, [r0, #152]	@ 0x98
 80010a4:	9328      	str	r3, [sp, #160]	@ 0xa0
 80010a6:	f8d0 309c 	ldr.w	r3, [r0, #156]	@ 0x9c
 80010aa:	9329      	str	r3, [sp, #164]	@ 0xa4
 80010ac:	f8d0 30a8 	ldr.w	r3, [r0, #168]	@ 0xa8
 80010b0:	932a      	str	r3, [sp, #168]	@ 0xa8
 80010b2:	e9d0 832b 	ldrd	r8, r3, [r0, #172]	@ 0xac
 80010b6:	932b      	str	r3, [sp, #172]	@ 0xac
 80010b8:	f8d0 30b4 	ldr.w	r3, [r0, #180]	@ 0xb4
 80010bc:	932c      	str	r3, [sp, #176]	@ 0xb0
 80010be:	f8d0 30b8 	ldr.w	r3, [r0, #184]	@ 0xb8
 80010c2:	932d      	str	r3, [sp, #180]	@ 0xb4
 80010c4:	f8d0 30bc 	ldr.w	r3, [r0, #188]	@ 0xbc
 80010c8:	932e      	str	r3, [sp, #184]	@ 0xb8
 80010ca:	f8d0 30c0 	ldr.w	r3, [r0, #192]	@ 0xc0
 80010ce:	e9d0 6a28 	ldrd	r6, sl, [r0, #160]	@ 0xa0
 80010d2:	932f      	str	r3, [sp, #188]	@ 0xbc
 80010d4:	f8d0 30c4 	ldr.w	r3, [r0, #196]	@ 0xc4
 80010d8:	9330      	str	r3, [sp, #192]	@ 0xc0
 80010da:	903d      	str	r0, [sp, #244]	@ 0xf4
 80010dc:	46cb      	mov	fp, r9
 80010de:	e001      	b.n	80010e4 <KeccakF1600_StatePermute+0xf0>
 80010e0:	08003580 	.word	0x08003580
 80010e4:	9a0d      	ldr	r2, [sp, #52]	@ 0x34
 80010e6:	9b04      	ldr	r3, [sp, #16]
 80010e8:	9905      	ldr	r1, [sp, #20]
 80010ea:	980e      	ldr	r0, [sp, #56]	@ 0x38
 80010ec:	9c06      	ldr	r4, [sp, #24]
 80010ee:	9d0f      	ldr	r5, [sp, #60]	@ 0x3c
 80010f0:	f8dd c060 	ldr.w	ip, [sp, #96]	@ 0x60
 80010f4:	4053      	eors	r3, r2
 80010f6:	9a20      	ldr	r2, [sp, #128]	@ 0x80
 80010f8:	ea83 030b 	eor.w	r3, r3, fp
 80010fc:	4053      	eors	r3, r2
 80010fe:	ea83 0706 	eor.w	r7, r3, r6
 8001102:	ea81 0300 	eor.w	r3, r1, r0
 8001106:	9917      	ldr	r1, [sp, #92]	@ 0x5c
 8001108:	9821      	ldr	r0, [sp, #132]	@ 0x84
 800110a:	9733      	str	r7, [sp, #204]	@ 0xcc
 800110c:	404b      	eors	r3, r1
 800110e:	4043      	eors	r3, r0
 8001110:	ea83 000a 	eor.w	r0, r3, sl
 8001114:	ea84 0e05 	eor.w	lr, r4, r5
 8001118:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 800111a:	9d03      	ldr	r5, [sp, #12]
 800111c:	9f10      	ldr	r7, [sp, #64]	@ 0x40
 800111e:	9a23      	ldr	r2, [sp, #140]	@ 0x8c
 8001120:	9c2a      	ldr	r4, [sp, #168]	@ 0xa8
 8001122:	9907      	ldr	r1, [sp, #28]
 8001124:	9034      	str	r0, [sp, #208]	@ 0xd0
 8001126:	ea8e 0e0c 	eor.w	lr, lr, ip
 800112a:	ea8e 0e03 	eor.w	lr, lr, r3
 800112e:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8001130:	9811      	ldr	r0, [sp, #68]	@ 0x44
 8001132:	ea85 0c07 	eor.w	ip, r5, r7
 8001136:	ea8c 0c03 	eor.w	ip, ip, r3
 800113a:	9f08      	ldr	r7, [sp, #32]
 800113c:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 800113e:	9d24      	ldr	r5, [sp, #144]	@ 0x90
 8001140:	ea8c 0c02 	eor.w	ip, ip, r2
 8001144:	9a12      	ldr	r2, [sp, #72]	@ 0x48
 8001146:	ea8e 0e04 	eor.w	lr, lr, r4
 800114a:	ea81 0400 	eor.w	r4, r1, r0
 800114e:	991b      	ldr	r1, [sp, #108]	@ 0x6c
 8001150:	9825      	ldr	r0, [sp, #148]	@ 0x94
 8001152:	405c      	eors	r4, r3
 8001154:	407a      	eors	r2, r7
 8001156:	9b2b      	ldr	r3, [sp, #172]	@ 0xac
 8001158:	9f09      	ldr	r7, [sp, #36]	@ 0x24
 800115a:	406c      	eors	r4, r5
 800115c:	404a      	eors	r2, r1
 800115e:	9d2c      	ldr	r5, [sp, #176]	@ 0xb0
 8001160:	9913      	ldr	r1, [sp, #76]	@ 0x4c
 8001162:	405c      	eors	r4, r3
 8001164:	4042      	eors	r2, r0
 8001166:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
 8001168:	406a      	eors	r2, r5
 800116a:	ea87 0501 	eor.w	r5, r7, r1
 800116e:	9926      	ldr	r1, [sp, #152]	@ 0x98
 8001170:	982d      	ldr	r0, [sp, #180]	@ 0xb4
 8001172:	9f0a      	ldr	r7, [sp, #40]	@ 0x28
 8001174:	f8dd 9050 	ldr.w	r9, [sp, #80]	@ 0x50
 8001178:	405d      	eors	r5, r3
 800117a:	404d      	eors	r5, r1
 800117c:	9b1d      	ldr	r3, [sp, #116]	@ 0x74
 800117e:	9927      	ldr	r1, [sp, #156]	@ 0x9c
 8001180:	4045      	eors	r5, r0
 8001182:	ea87 0009 	eor.w	r0, r7, r9
 8001186:	4058      	eors	r0, r3
 8001188:	9b2e      	ldr	r3, [sp, #184]	@ 0xb8
 800118a:	9f0b      	ldr	r7, [sp, #44]	@ 0x2c
 800118c:	f8dd 9054 	ldr.w	r9, [sp, #84]	@ 0x54
 8001190:	4048      	eors	r0, r1
 8001192:	4043      	eors	r3, r0
 8001194:	9302      	str	r3, [sp, #8]
 8001196:	9b1e      	ldr	r3, [sp, #120]	@ 0x78
 8001198:	ea87 0109 	eor.w	r1, r7, r9
 800119c:	4059      	eors	r1, r3
 800119e:	9b28      	ldr	r3, [sp, #160]	@ 0xa0
 80011a0:	9f0c      	ldr	r7, [sp, #48]	@ 0x30
 80011a2:	f8dd 9058 	ldr.w	r9, [sp, #88]	@ 0x58
 80011a6:	4059      	eors	r1, r3
 80011a8:	9b2f      	ldr	r3, [sp, #188]	@ 0xbc
 80011aa:	ea8c 0c08 	eor.w	ip, ip, r8
 80011ae:	4059      	eors	r1, r3
 80011b0:	ea87 0309 	eor.w	r3, r7, r9
 80011b4:	ea4f 094e 	mov.w	r9, lr, lsl #1
 80011b8:	ea49 79dc 	orr.w	r9, r9, ip, lsr #31
 80011bc:	ea89 0901 	eor.w	r9, r9, r1
 80011c0:	ea89 0606 	eor.w	r6, r9, r6
 80011c4:	9635      	str	r6, [sp, #212]	@ 0xd4
 80011c6:	9e04      	ldr	r6, [sp, #16]
 80011c8:	9f1f      	ldr	r7, [sp, #124]	@ 0x7c
 80011ca:	ea89 0606 	eor.w	r6, r9, r6
 80011ce:	9631      	str	r6, [sp, #196]	@ 0xc4
 80011d0:	9e0d      	ldr	r6, [sp, #52]	@ 0x34
 80011d2:	ea89 0606 	eor.w	r6, r9, r6
 80011d6:	407b      	eors	r3, r7
 80011d8:	9637      	str	r6, [sp, #220]	@ 0xdc
 80011da:	9f29      	ldr	r7, [sp, #164]	@ 0xa4
 80011dc:	9e20      	ldr	r6, [sp, #128]	@ 0x80
 80011de:	407b      	eors	r3, r7
 80011e0:	ea89 0606 	eor.w	r6, r9, r6
 80011e4:	9f30      	ldr	r7, [sp, #192]	@ 0xc0
 80011e6:	9632      	str	r6, [sp, #200]	@ 0xc8
 80011e8:	ea4f 064c 	mov.w	r6, ip, lsl #1
 80011ec:	407b      	eors	r3, r7
 80011ee:	ea89 0b0b 	eor.w	fp, r9, fp
 80011f2:	ea46 76de 	orr.w	r6, r6, lr, lsr #31
 80011f6:	f8dd 905c 	ldr.w	r9, [sp, #92]	@ 0x5c
 80011fa:	405e      	eors	r6, r3
 80011fc:	ea86 0909 	eor.w	r9, r6, r9
 8001200:	f8cd 905c 	str.w	r9, [sp, #92]	@ 0x5c
 8001204:	ea86 090a 	eor.w	r9, r6, sl
 8001208:	f8cd 90d8 	str.w	r9, [sp, #216]	@ 0xd8
 800120c:	f8dd 9014 	ldr.w	r9, [sp, #20]
 8001210:	f8dd a038 	ldr.w	sl, [sp, #56]	@ 0x38
 8001214:	ea86 0909 	eor.w	r9, r6, r9
 8001218:	f8cd 9034 	str.w	r9, [sp, #52]	@ 0x34
 800121c:	ea86 090a 	eor.w	r9, r6, sl
 8001220:	f8dd a084 	ldr.w	sl, [sp, #132]	@ 0x84
 8001224:	f8cd 90e0 	str.w	r9, [sp, #224]	@ 0xe0
 8001228:	ea86 060a 	eor.w	r6, r6, sl
 800122c:	963a      	str	r6, [sp, #232]	@ 0xe8
 800122e:	9f33      	ldr	r7, [sp, #204]	@ 0xcc
 8001230:	f8dd 903c 	ldr.w	r9, [sp, #60]	@ 0x3c
 8001234:	f8dd a018 	ldr.w	sl, [sp, #24]
 8001238:	9834      	ldr	r0, [sp, #208]	@ 0xd0
 800123a:	0066      	lsls	r6, r4, #1
 800123c:	ea46 76d2 	orr.w	r6, r6, r2, lsr #31
 8001240:	407e      	eors	r6, r7
 8001242:	ea86 0909 	eor.w	r9, r6, r9
 8001246:	f8cd 9014 	str.w	r9, [sp, #20]
 800124a:	f8dd 9088 	ldr.w	r9, [sp, #136]	@ 0x88
 800124e:	ea86 0909 	eor.w	r9, r6, r9
 8001252:	f8cd 9038 	str.w	r9, [sp, #56]	@ 0x38
 8001256:	ea86 090a 	eor.w	r9, r6, sl
 800125a:	f8dd a060 	ldr.w	sl, [sp, #96]	@ 0x60
 800125e:	f8cd 9080 	str.w	r9, [sp, #128]	@ 0x80
 8001262:	ea86 0a0a 	eor.w	sl, r6, sl
 8001266:	f8cd a0cc 	str.w	sl, [sp, #204]	@ 0xcc
 800126a:	f8dd a0a8 	ldr.w	sl, [sp, #168]	@ 0xa8
 800126e:	f8dd 9040 	ldr.w	r9, [sp, #64]	@ 0x40
 8001272:	ea86 060a 	eor.w	r6, r6, sl
 8001276:	963b      	str	r6, [sp, #236]	@ 0xec
 8001278:	0056      	lsls	r6, r2, #1
 800127a:	f8dd a08c 	ldr.w	sl, [sp, #140]	@ 0x8c
 800127e:	ea46 76d4 	orr.w	r6, r6, r4, lsr #31
 8001282:	4046      	eors	r6, r0
 8001284:	ea86 0a0a 	eor.w	sl, r6, sl
 8001288:	f8cd a03c 	str.w	sl, [sp, #60]	@ 0x3c
 800128c:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001290:	ea86 0a0a 	eor.w	sl, r6, sl
 8001294:	ea86 0808 	eor.w	r8, r6, r8
 8001298:	f8cd a00c 	str.w	sl, [sp, #12]
 800129c:	f8dd a064 	ldr.w	sl, [sp, #100]	@ 0x64
 80012a0:	f8cd 80f0 	str.w	r8, [sp, #240]	@ 0xf0
 80012a4:	f8dd 8008 	ldr.w	r8, [sp, #8]
 80012a8:	ea86 0909 	eor.w	r9, r6, r9
 80012ac:	ea86 0a0a 	eor.w	sl, r6, sl
 80012b0:	006e      	lsls	r6, r5, #1
 80012b2:	ea46 76d8 	orr.w	r6, r6, r8, lsr #31
 80012b6:	ea86 060e 	eor.w	r6, r6, lr
 80012ba:	f8dd e0ac 	ldr.w	lr, [sp, #172]	@ 0xac
 80012be:	f8cd a0a8 	str.w	sl, [sp, #168]	@ 0xa8
 80012c2:	f8dd a044 	ldr.w	sl, [sp, #68]	@ 0x44
 80012c6:	f8dd 8068 	ldr.w	r8, [sp, #104]	@ 0x68
 80012ca:	ea86 0e0e 	eor.w	lr, r6, lr
 80012ce:	f8cd e060 	str.w	lr, [sp, #96]	@ 0x60
 80012d2:	ea86 0e0a 	eor.w	lr, r6, sl
 80012d6:	f8cd e068 	str.w	lr, [sp, #104]	@ 0x68
 80012da:	f8dd e090 	ldr.w	lr, [sp, #144]	@ 0x90
 80012de:	ea86 0e0e 	eor.w	lr, r6, lr
 80012e2:	f8cd e0ac 	str.w	lr, [sp, #172]	@ 0xac
 80012e6:	f8dd e01c 	ldr.w	lr, [sp, #28]
 80012ea:	ea86 0808 	eor.w	r8, r6, r8
 80012ee:	ea86 0e0e 	eor.w	lr, r6, lr
 80012f2:	9e02      	ldr	r6, [sp, #8]
 80012f4:	f8cd e0d0 	str.w	lr, [sp, #208]	@ 0xd0
 80012f8:	0076      	lsls	r6, r6, #1
 80012fa:	ea46 76d5 	orr.w	r6, r6, r5, lsr #31
 80012fe:	ea86 060c 	eor.w	r6, r6, ip
 8001302:	f8dd c06c 	ldr.w	ip, [sp, #108]	@ 0x6c
 8001306:	f8dd e0b0 	ldr.w	lr, [sp, #176]	@ 0xb0
 800130a:	f8dd a048 	ldr.w	sl, [sp, #72]	@ 0x48
 800130e:	ea86 0a0a 	eor.w	sl, r6, sl
 8001312:	f8cd a010 	str.w	sl, [sp, #16]
 8001316:	f8dd a094 	ldr.w	sl, [sp, #148]	@ 0x94
 800131a:	ea86 0e0e 	eor.w	lr, r6, lr
 800131e:	f8cd e064 	str.w	lr, [sp, #100]	@ 0x64
 8001322:	ea86 0e0a 	eor.w	lr, r6, sl
 8001326:	f8cd e0b0 	str.w	lr, [sp, #176]	@ 0xb0
 800132a:	f8dd e020 	ldr.w	lr, [sp, #32]
 800132e:	f8dd a028 	ldr.w	sl, [sp, #40]	@ 0x28
 8001332:	ea86 0c0c 	eor.w	ip, r6, ip
 8001336:	ea86 060e 	eor.w	r6, r6, lr
 800133a:	9639      	str	r6, [sp, #228]	@ 0xe4
 800133c:	004e      	lsls	r6, r1, #1
 800133e:	ea46 76d3 	orr.w	r6, r6, r3, lsr #31
 8001342:	4066      	eors	r6, r4
 8001344:	9c26      	ldr	r4, [sp, #152]	@ 0x98
 8001346:	005b      	lsls	r3, r3, #1
 8001348:	ea86 0e04 	eor.w	lr, r6, r4
 800134c:	ea43 73d1 	orr.w	r3, r3, r1, lsr #31
 8001350:	9c27      	ldr	r4, [sp, #156]	@ 0x9c
 8001352:	4053      	eors	r3, r2
 8001354:	ea83 0204 	eor.w	r2, r3, r4
 8001358:	9207      	str	r2, [sp, #28]
 800135a:	9a09      	ldr	r2, [sp, #36]	@ 0x24
 800135c:	ea86 0402 	eor.w	r4, r6, r2
 8001360:	9a1c      	ldr	r2, [sp, #112]	@ 0x70
 8001362:	4072      	eors	r2, r6
 8001364:	921b      	str	r2, [sp, #108]	@ 0x6c
 8001366:	9a2d      	ldr	r2, [sp, #180]	@ 0xb4
 8001368:	ea83 010a 	eor.w	r1, r3, sl
 800136c:	f8dd a074 	ldr.w	sl, [sp, #116]	@ 0x74
 8001370:	4072      	eors	r2, r6
 8001372:	ea83 0a0a 	eor.w	sl, r3, sl
 8001376:	9226      	str	r2, [sp, #152]	@ 0x98
 8001378:	9a13      	ldr	r2, [sp, #76]	@ 0x4c
 800137a:	f8cd a070 	str.w	sl, [sp, #112]	@ 0x70
 800137e:	f8dd a0b8 	ldr.w	sl, [sp, #184]	@ 0xb8
 8001382:	4072      	eors	r2, r6
 8001384:	9222      	str	r2, [sp, #136]	@ 0x88
 8001386:	ea83 020a 	eor.w	r2, r3, sl
 800138a:	9227      	str	r2, [sp, #156]	@ 0x9c
 800138c:	9a14      	ldr	r2, [sp, #80]	@ 0x50
 800138e:	463e      	mov	r6, r7
 8001390:	405a      	eors	r2, r3
 8001392:	ea4f 0a47 	mov.w	sl, r7, lsl #1
 8001396:	9b02      	ldr	r3, [sp, #8]
 8001398:	922d      	str	r2, [sp, #180]	@ 0xb4
 800139a:	0047      	lsls	r7, r0, #1
 800139c:	9a16      	ldr	r2, [sp, #88]	@ 0x58
 800139e:	ea4a 7ad0 	orr.w	sl, sl, r0, lsr #31
 80013a2:	ea47 77d6 	orr.w	r7, r7, r6, lsr #31
 80013a6:	ea8a 0a05 	eor.w	sl, sl, r5
 80013aa:	405f      	eors	r7, r3
 80013ac:	9d2f      	ldr	r5, [sp, #188]	@ 0xbc
 80013ae:	ea87 0302 	eor.w	r3, r7, r2
 80013b2:	9a28      	ldr	r2, [sp, #160]	@ 0xa0
 80013b4:	ea8a 0605 	eor.w	r6, sl, r5
 80013b8:	9d30      	ldr	r5, [sp, #192]	@ 0xc0
 80013ba:	ea8a 0202 	eor.w	r2, sl, r2
 80013be:	ea87 0005 	eor.w	r0, r7, r5
 80013c2:	9214      	str	r2, [sp, #80]	@ 0x50
 80013c4:	9d15      	ldr	r5, [sp, #84]	@ 0x54
 80013c6:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 80013c8:	407a      	eors	r2, r7
 80013ca:	9215      	str	r2, [sp, #84]	@ 0x54
 80013cc:	9a0b      	ldr	r2, [sp, #44]	@ 0x2c
 80013ce:	ea8a 0202 	eor.w	r2, sl, r2
 80013d2:	9224      	str	r2, [sp, #144]	@ 0x90
 80013d4:	9a1e      	ldr	r2, [sp, #120]	@ 0x78
 80013d6:	ea8a 0505 	eor.w	r5, sl, r5
 80013da:	ea8a 0a02 	eor.w	sl, sl, r2
 80013de:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
 80013e0:	f8cd a08c 	str.w	sl, [sp, #140]	@ 0x8c
 80013e4:	ea87 0a02 	eor.w	sl, r7, r2
 80013e8:	9a1f      	ldr	r2, [sp, #124]	@ 0x7c
 80013ea:	f8cd a094 	str.w	sl, [sp, #148]	@ 0x94
 80013ee:	f8dd a004 	ldr.w	sl, [sp, #4]
 80013f2:	4057      	eors	r7, r2
 80013f4:	9728      	str	r7, [sp, #160]	@ 0xa0
 80013f6:	9a31      	ldr	r2, [sp, #196]	@ 0xc4
 80013f8:	f8da 7000 	ldr.w	r7, [sl]
 80013fc:	4057      	eors	r7, r2
 80013fe:	9709      	str	r7, [sp, #36]	@ 0x24
 8001400:	9a0d      	ldr	r2, [sp, #52]	@ 0x34
 8001402:	f8da 7004 	ldr.w	r7, [sl, #4]
 8001406:	4057      	eors	r7, r2
 8001408:	9a05      	ldr	r2, [sp, #20]
 800140a:	970a      	str	r7, [sp, #40]	@ 0x28
 800140c:	0d17      	lsrs	r7, r2, #20
 800140e:	ea47 3709 	orr.w	r7, r7, r9, lsl #12
 8001412:	ea4f 5919 	mov.w	r9, r9, lsr #20
 8001416:	ea49 3902 	orr.w	r9, r9, r2, lsl #12
 800141a:	f8cd 9018 	str.w	r9, [sp, #24]
 800141e:	ea4f 3986 	mov.w	r9, r6, lsl #14
 8001422:	ea49 4990 	orr.w	r9, r9, r0, lsr #18
 8001426:	0380      	lsls	r0, r0, #14
 8001428:	ea40 4096 	orr.w	r0, r0, r6, lsr #18
 800142c:	ea4f 5a58 	mov.w	sl, r8, lsr #21
 8001430:	0726      	lsls	r6, r4, #28
 8001432:	ea4a 2acc 	orr.w	sl, sl, ip, lsl #11
 8001436:	ea46 1611 	orr.w	r6, r6, r1, lsr #4
 800143a:	9a07      	ldr	r2, [sp, #28]
 800143c:	900b      	str	r0, [sp, #44]	@ 0x2c
 800143e:	ea4f 5c5c 	mov.w	ip, ip, lsr #21
 8001442:	0709      	lsls	r1, r1, #28
 8001444:	ea41 1014 	orr.w	r0, r1, r4, lsr #4
 8001448:	ea4c 28c8 	orr.w	r8, ip, r8, lsl #11
 800144c:	052c      	lsls	r4, r5, #20
 800144e:	ea4f 5c4e 	mov.w	ip, lr, lsl #21
 8001452:	ea4c 2cd2 	orr.w	ip, ip, r2, lsr #11
 8001456:	ea44 3413 	orr.w	r4, r4, r3, lsr #12
 800145a:	0552      	lsls	r2, r2, #21
 800145c:	051b      	lsls	r3, r3, #20
 800145e:	ea42 22de 	orr.w	r2, r2, lr, lsr #11
 8001462:	ea43 3e15 	orr.w	lr, r3, r5, lsr #12
 8001466:	9d17      	ldr	r5, [sp, #92]	@ 0x5c
 8001468:	f8cd e048 	str.w	lr, [sp, #72]	@ 0x48
 800146c:	f8dd e03c 	ldr.w	lr, [sp, #60]	@ 0x3c
 8001470:	f8cd 8020 	str.w	r8, [sp, #32]
 8001474:	00eb      	lsls	r3, r5, #3
 8001476:	ea4f 08cb 	mov.w	r8, fp, lsl #3
 800147a:	ea48 7855 	orr.w	r8, r8, r5, lsr #29
 800147e:	990e      	ldr	r1, [sp, #56]	@ 0x38
 8001480:	9410      	str	r4, [sp, #64]	@ 0x40
 8001482:	ea43 755b 	orr.w	r5, r3, fp, lsr #29
 8001486:	4673      	mov	r3, lr
 8001488:	9c18      	ldr	r4, [sp, #96]	@ 0x60
 800148a:	9513      	str	r5, [sp, #76]	@ 0x4c
 800148c:	0cdb      	lsrs	r3, r3, #19
 800148e:	ea43 3341 	orr.w	r3, r3, r1, lsl #13
 8001492:	0ccd      	lsrs	r5, r1, #19
 8001494:	9919      	ldr	r1, [sp, #100]	@ 0x64
 8001496:	9011      	str	r0, [sp, #68]	@ 0x44
 8001498:	ea45 354e 	orr.w	r5, r5, lr, lsl #13
 800149c:	ea4f 0ed4 	mov.w	lr, r4, lsr #3
 80014a0:	ea4e 7e41 	orr.w	lr, lr, r1, lsl #29
 80014a4:	08c9      	lsrs	r1, r1, #3
 80014a6:	ea41 7144 	orr.w	r1, r1, r4, lsl #29
 80014aa:	9c20      	ldr	r4, [sp, #128]	@ 0x80
 80014ac:	9803      	ldr	r0, [sp, #12]
 80014ae:	ea4f 0b44 	mov.w	fp, r4, lsl #1
 80014b2:	ea4b 70d0 	orr.w	r0, fp, r0, lsr #31
 80014b6:	f8dd b00c 	ldr.w	fp, [sp, #12]
 80014ba:	901e      	str	r0, [sp, #120]	@ 0x78
 80014bc:	ea4f 0b4b 	mov.w	fp, fp, lsl #1
 80014c0:	ea4b 7bd4 	orr.w	fp, fp, r4, lsr #31
 80014c4:	9c1a      	ldr	r4, [sp, #104]	@ 0x68
 80014c6:	9804      	ldr	r0, [sp, #16]
 80014c8:	f8cd b07c 	str.w	fp, [sp, #124]	@ 0x7c
 80014cc:	ea4f 1b84 	mov.w	fp, r4, lsl #6
 80014d0:	ea4b 6090 	orr.w	r0, fp, r0, lsr #26
 80014d4:	9002      	str	r0, [sp, #8]
 80014d6:	9804      	ldr	r0, [sp, #16]
 80014d8:	ea4f 1b80 	mov.w	fp, r0, lsl #6
 80014dc:	ea4b 6094 	orr.w	r0, fp, r4, lsr #26
 80014e0:	9c1b      	ldr	r4, [sp, #108]	@ 0x6c
 80014e2:	9004      	str	r0, [sp, #16]
 80014e4:	981c      	ldr	r0, [sp, #112]	@ 0x70
 80014e6:	ea4f 6b44 	mov.w	fp, r4, lsl #25
 80014ea:	ea4b 1bd0 	orr.w	fp, fp, r0, lsr #7
 80014ee:	f8cd b068 	str.w	fp, [sp, #104]	@ 0x68
 80014f2:	ea4f 6b40 	mov.w	fp, r0, lsl #25
 80014f6:	ea4b 10d4 	orr.w	r0, fp, r4, lsr #7
 80014fa:	9c14      	ldr	r4, [sp, #80]	@ 0x50
 80014fc:	901b      	str	r0, [sp, #108]	@ 0x6c
 80014fe:	9815      	ldr	r0, [sp, #84]	@ 0x54
 8001500:	ea4f 2b04 	mov.w	fp, r4, lsl #8
 8001504:	ea4b 6b10 	orr.w	fp, fp, r0, lsr #24
 8001508:	f8cd b014 	str.w	fp, [sp, #20]
 800150c:	ea4f 2b00 	mov.w	fp, r0, lsl #8
 8001510:	ea4b 6014 	orr.w	r0, fp, r4, lsr #24
 8001514:	9003      	str	r0, [sp, #12]
 8001516:	9835      	ldr	r0, [sp, #212]	@ 0xd4
 8001518:	9c36      	ldr	r4, [sp, #216]	@ 0xd8
 800151a:	ea4f 4b80 	mov.w	fp, r0, lsl #18
 800151e:	ea4b 3b94 	orr.w	fp, fp, r4, lsr #14
 8001522:	f8cd b070 	str.w	fp, [sp, #112]	@ 0x70
 8001526:	ea4f 4b84 	mov.w	fp, r4, lsl #18
 800152a:	9c09      	ldr	r4, [sp, #36]	@ 0x24
 800152c:	ea4b 3090 	orr.w	r0, fp, r0, lsr #14
 8001530:	ea2a 0b07 	bic.w	fp, sl, r7
 8001534:	ea84 040b 	eor.w	r4, r4, fp
 8001538:	901d      	str	r0, [sp, #116]	@ 0x74
 800153a:	f8dd b018 	ldr.w	fp, [sp, #24]
 800153e:	9808      	ldr	r0, [sp, #32]
 8001540:	9407      	str	r4, [sp, #28]
 8001542:	9c0a      	ldr	r4, [sp, #40]	@ 0x28
 8001544:	ea20 0b0b 	bic.w	fp, r0, fp
 8001548:	ea84 040b 	eor.w	r4, r4, fp
 800154c:	ea2c 0b0a 	bic.w	fp, ip, sl
 8001550:	9408      	str	r4, [sp, #32]
 8001552:	ea8b 0407 	eor.w	r4, fp, r7
 8001556:	f8dd b0c4 	ldr.w	fp, [sp, #196]	@ 0xc4
 800155a:	9409      	str	r4, [sp, #36]	@ 0x24
 800155c:	ea27 070b 	bic.w	r7, r7, fp
 8001560:	ea2b 0b09 	bic.w	fp, fp, r9
 8001564:	ea8b 040c 	eor.w	r4, fp, ip
 8001568:	ea29 0c0c 	bic.w	ip, r9, ip
 800156c:	ea8c 0c0a 	eor.w	ip, ip, sl
 8001570:	f8cd c028 	str.w	ip, [sp, #40]	@ 0x28
 8001574:	ea87 0c09 	eor.w	ip, r7, r9
 8001578:	940c      	str	r4, [sp, #48]	@ 0x30
 800157a:	f8cd c038 	str.w	ip, [sp, #56]	@ 0x38
 800157e:	f8dd 9018 	ldr.w	r9, [sp, #24]
 8001582:	9c10      	ldr	r4, [sp, #64]	@ 0x40
 8001584:	f8dd b07c 	ldr.w	fp, [sp, #124]	@ 0x7c
 8001588:	ea22 0700 	bic.w	r7, r2, r0
 800158c:	ea87 0c09 	eor.w	ip, r7, r9
 8001590:	4682      	mov	sl, r0
 8001592:	f8cd c018 	str.w	ip, [sp, #24]
 8001596:	980b      	ldr	r0, [sp, #44]	@ 0x2c
 8001598:	f8dd c034 	ldr.w	ip, [sp, #52]	@ 0x34
 800159c:	ea29 070c 	bic.w	r7, r9, ip
 80015a0:	ea2c 0c00 	bic.w	ip, ip, r0
 80015a4:	ea8c 0c02 	eor.w	ip, ip, r2
 80015a8:	ea20 0202 	bic.w	r2, r0, r2
 80015ac:	ea82 090a 	eor.w	r9, r2, sl
 80015b0:	4047      	eors	r7, r0
 80015b2:	ea28 0204 	bic.w	r2, r8, r4
 80015b6:	970f      	str	r7, [sp, #60]	@ 0x3c
 80015b8:	ea82 0706 	eor.w	r7, r2, r6
 80015bc:	f8cd c034 	str.w	ip, [sp, #52]	@ 0x34
 80015c0:	9710      	str	r7, [sp, #64]	@ 0x40
 80015c2:	e9dd 7c12 	ldrd	r7, ip, [sp, #72]	@ 0x48
 80015c6:	9811      	ldr	r0, [sp, #68]	@ 0x44
 80015c8:	f8cd 902c 	str.w	r9, [sp, #44]	@ 0x2c
 80015cc:	ea2c 0207 	bic.w	r2, ip, r7
 80015d0:	4042      	eors	r2, r0
 80015d2:	9211      	str	r2, [sp, #68]	@ 0x44
 80015d4:	ea25 0208 	bic.w	r2, r5, r8
 80015d8:	ea82 0904 	eor.w	r9, r2, r4
 80015dc:	ea24 0406 	bic.w	r4, r4, r6
 80015e0:	ea26 060e 	bic.w	r6, r6, lr
 80015e4:	ea86 0a05 	eor.w	sl, r6, r5
 80015e8:	ea2e 0505 	bic.w	r5, lr, r5
 80015ec:	ea23 020c 	bic.w	r2, r3, ip
 80015f0:	ea85 0508 	eor.w	r5, r5, r8
 80015f4:	9e02      	ldr	r6, [sp, #8]
 80015f6:	f8dd 8078 	ldr.w	r8, [sp, #120]	@ 0x78
 80015fa:	9514      	str	r5, [sp, #80]	@ 0x50
 80015fc:	ea84 0e0e 	eor.w	lr, r4, lr
 8001600:	ea82 0507 	eor.w	r5, r2, r7
 8001604:	ea27 0200 	bic.w	r2, r7, r0
 8001608:	ea20 0001 	bic.w	r0, r0, r1
 800160c:	9f1c      	ldr	r7, [sp, #112]	@ 0x70
 800160e:	f8cd e060 	str.w	lr, [sp, #96]	@ 0x60
 8001612:	ea80 0e03 	eor.w	lr, r0, r3
 8001616:	ea21 0303 	bic.w	r3, r1, r3
 800161a:	ea83 0c0c 	eor.w	ip, r3, ip
 800161e:	ea26 0308 	bic.w	r3, r6, r8
 8001622:	9513      	str	r5, [sp, #76]	@ 0x4c
 8001624:	ea83 0507 	eor.w	r5, r3, r7
 8001628:	f8cd c054 	str.w	ip, [sp, #84]	@ 0x54
 800162c:	9520      	str	r5, [sp, #128]	@ 0x80
 800162e:	ea82 0c01 	eor.w	ip, r2, r1
 8001632:	9d04      	ldr	r5, [sp, #16]
 8001634:	f8cd c064 	str.w	ip, [sp, #100]	@ 0x64
 8001638:	f8dd c074 	ldr.w	ip, [sp, #116]	@ 0x74
 800163c:	9f25      	ldr	r7, [sp, #148]	@ 0x94
 800163e:	f8cd 9048 	str.w	r9, [sp, #72]	@ 0x48
 8001642:	ea25 030b 	bic.w	r3, r5, fp
 8001646:	9d24      	ldr	r5, [sp, #144]	@ 0x90
 8001648:	f8cd a058 	str.w	sl, [sp, #88]	@ 0x58
 800164c:	ea83 000c 	eor.w	r0, r3, ip
 8001650:	9b37      	ldr	r3, [sp, #220]	@ 0xdc
 8001652:	f8cd e05c 	str.w	lr, [sp, #92]	@ 0x5c
 8001656:	9021      	str	r0, [sp, #132]	@ 0x84
 8001658:	ea4f 6ec5 	mov.w	lr, r5, lsl #27
 800165c:	9938      	ldr	r1, [sp, #224]	@ 0xe0
 800165e:	f8dd 90cc 	ldr.w	r9, [sp, #204]	@ 0xcc
 8001662:	9c27      	ldr	r4, [sp, #156]	@ 0x9c
 8001664:	ea4e 1e57 	orr.w	lr, lr, r7, lsr #5
 8001668:	06f8      	lsls	r0, r7, #27
 800166a:	0f1f      	lsrs	r7, r3, #28
 800166c:	ea47 1701 	orr.w	r7, r7, r1, lsl #4
 8001670:	0f0a      	lsrs	r2, r1, #28
 8001672:	992a      	ldr	r1, [sp, #168]	@ 0xa8
 8001674:	ea40 1055 	orr.w	r0, r0, r5, lsr #5
 8001678:	028d      	lsls	r5, r1, #10
 800167a:	ea45 5599 	orr.w	r5, r5, r9, lsr #22
 800167e:	ea4f 2a89 	mov.w	sl, r9, lsl #10
 8001682:	f8dd 90ac 	ldr.w	r9, [sp, #172]	@ 0xac
 8001686:	ea4a 5a91 	orr.w	sl, sl, r1, lsr #22
 800168a:	992c      	ldr	r1, [sp, #176]	@ 0xb0
 800168c:	ea42 1203 	orr.w	r2, r2, r3, lsl #4
 8001690:	ea4f 3cc9 	mov.w	ip, r9, lsl #15
 8001694:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 8001696:	ea4c 4c51 	orr.w	ip, ip, r1, lsr #17
 800169a:	03c9      	lsls	r1, r1, #15
 800169c:	ea41 4159 	orr.w	r1, r1, r9, lsr #17
 80016a0:	ea4f 2913 	mov.w	r9, r3, lsr #8
 80016a4:	ea49 6904 	orr.w	r9, r9, r4, lsl #24
 80016a8:	0a24      	lsrs	r4, r4, #8
 80016aa:	ea44 6403 	orr.w	r4, r4, r3, lsl #24
 80016ae:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 80016b0:	ea23 0306 	bic.w	r3, r3, r6
 80016b4:	9e1c      	ldr	r6, [sp, #112]	@ 0x70
 80016b6:	ea83 0308 	eor.w	r3, r3, r8
 80016ba:	931e      	str	r3, [sp, #120]	@ 0x78
 80016bc:	ea28 0306 	bic.w	r3, r8, r6
 80016c0:	f8dd 8014 	ldr.w	r8, [sp, #20]
 80016c4:	ea26 0608 	bic.w	r6, r6, r8
 80016c8:	f8dd 8068 	ldr.w	r8, [sp, #104]	@ 0x68
 80016cc:	ea86 0608 	eor.w	r6, r6, r8
 80016d0:	961c      	str	r6, [sp, #112]	@ 0x70
 80016d2:	9e05      	ldr	r6, [sp, #20]
 80016d4:	ea26 0608 	bic.w	r6, r6, r8
 80016d8:	f8dd 8008 	ldr.w	r8, [sp, #8]
 80016dc:	ea86 0808 	eor.w	r8, r6, r8
 80016e0:	f8cd 8068 	str.w	r8, [sp, #104]	@ 0x68
 80016e4:	f8dd 8014 	ldr.w	r8, [sp, #20]
 80016e8:	9e1b      	ldr	r6, [sp, #108]	@ 0x6c
 80016ea:	ea83 0808 	eor.w	r8, r3, r8
 80016ee:	f8cd 807c 	str.w	r8, [sp, #124]	@ 0x7c
 80016f2:	f8dd 8010 	ldr.w	r8, [sp, #16]
 80016f6:	ea26 0308 	bic.w	r3, r6, r8
 80016fa:	9e1d      	ldr	r6, [sp, #116]	@ 0x74
 80016fc:	f8dd 800c 	ldr.w	r8, [sp, #12]
 8001700:	ea83 030b 	eor.w	r3, r3, fp
 8001704:	9305      	str	r3, [sp, #20]
 8001706:	ea2b 0306 	bic.w	r3, fp, r6
 800170a:	f8dd b06c 	ldr.w	fp, [sp, #108]	@ 0x6c
 800170e:	ea26 0608 	bic.w	r6, r6, r8
 8001712:	ea86 060b 	eor.w	r6, r6, fp
 8001716:	961b      	str	r6, [sp, #108]	@ 0x6c
 8001718:	ea28 060b 	bic.w	r6, r8, fp
 800171c:	f8dd 8010 	ldr.w	r8, [sp, #16]
 8001720:	ea86 0b08 	eor.w	fp, r6, r8
 8001724:	9e34      	ldr	r6, [sp, #208]	@ 0xd0
 8001726:	f8dd 800c 	ldr.w	r8, [sp, #12]
 800172a:	f8cd b010 	str.w	fp, [sp, #16]
 800172e:	f8dd b0e4 	ldr.w	fp, [sp, #228]	@ 0xe4
 8001732:	ea83 0808 	eor.w	r8, r3, r8
 8001736:	08b3      	lsrs	r3, r6, #2
 8001738:	f8cd 8074 	str.w	r8, [sp, #116]	@ 0x74
 800173c:	ea43 788b 	orr.w	r8, r3, fp, lsl #30
 8001740:	465b      	mov	r3, fp
 8001742:	089b      	lsrs	r3, r3, #2
 8001744:	ea43 7686 	orr.w	r6, r3, r6, lsl #30
 8001748:	f8cd 8008 	str.w	r8, [sp, #8]
 800174c:	962c      	str	r6, [sp, #176]	@ 0xb0
 800174e:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 8001750:	f8dd b0b4 	ldr.w	fp, [sp, #180]	@ 0xb4
 8001754:	0a5e      	lsrs	r6, r3, #9
 8001756:	ea46 56cb 	orr.w	r6, r6, fp, lsl #23
 800175a:	465b      	mov	r3, fp
 800175c:	f8dd b088 	ldr.w	fp, [sp, #136]	@ 0x88
 8001760:	0a5b      	lsrs	r3, r3, #9
 8001762:	ea43 58cb 	orr.w	r8, r3, fp, lsl #23
 8001766:	9b23      	ldr	r3, [sp, #140]	@ 0x8c
 8001768:	f8dd b0a0 	ldr.w	fp, [sp, #160]	@ 0xa0
 800176c:	f8cd 80b4 	str.w	r8, [sp, #180]	@ 0xb4
 8001770:	0e5b      	lsrs	r3, r3, #25
 8001772:	ea43 18cb 	orr.w	r8, r3, fp, lsl #7
 8001776:	465b      	mov	r3, fp
 8001778:	f8dd b08c 	ldr.w	fp, [sp, #140]	@ 0x8c
 800177c:	f8cd 800c 	str.w	r8, [sp, #12]
 8001780:	0e5b      	lsrs	r3, r3, #25
 8001782:	ea43 1bcb 	orr.w	fp, r3, fp, lsl #7
 8001786:	9b32      	ldr	r3, [sp, #200]	@ 0xc8
 8001788:	f8dd 80e8 	ldr.w	r8, [sp, #232]	@ 0xe8
 800178c:	f8cd b0b8 	str.w	fp, [sp, #184]	@ 0xb8
 8001790:	0ddb      	lsrs	r3, r3, #23
 8001792:	f8dd b0c8 	ldr.w	fp, [sp, #200]	@ 0xc8
 8001796:	ea43 2348 	orr.w	r3, r3, r8, lsl #9
 800179a:	ea4f 58d8 	mov.w	r8, r8, lsr #23
 800179e:	9330      	str	r3, [sp, #192]	@ 0xc0
 80017a0:	ea48 234b 	orr.w	r3, r8, fp, lsl #9
 80017a4:	932f      	str	r3, [sp, #188]	@ 0xbc
 80017a6:	9b3b      	ldr	r3, [sp, #236]	@ 0xec
 80017a8:	f8dd b0f0 	ldr.w	fp, [sp, #240]	@ 0xf0
 80017ac:	ea4f 0883 	mov.w	r8, r3, lsl #2
 80017b0:	ea48 789b 	orr.w	r8, r8, fp, lsr #30
 80017b4:	ea4f 0b8b 	mov.w	fp, fp, lsl #2
 80017b8:	ea4b 7b93 	orr.w	fp, fp, r3, lsr #30
 80017bc:	f8cd b0d0 	str.w	fp, [sp, #208]	@ 0xd0
 80017c0:	ea2a 0b07 	bic.w	fp, sl, r7
 80017c4:	ea8b 0b0e 	eor.w	fp, fp, lr
 80017c8:	465b      	mov	r3, fp
 80017ca:	ea25 0b02 	bic.w	fp, r5, r2
 80017ce:	ea8b 0b00 	eor.w	fp, fp, r0
 80017d2:	f8cd b08c 	str.w	fp, [sp, #140]	@ 0x8c
 80017d6:	ea2c 0b0a 	bic.w	fp, ip, sl
 80017da:	ea8b 0b07 	eor.w	fp, fp, r7
 80017de:	ea27 070e 	bic.w	r7, r7, lr
 80017e2:	ea2e 0e09 	bic.w	lr, lr, r9
 80017e6:	ea8e 0e0c 	eor.w	lr, lr, ip
 80017ea:	ea29 0c0c 	bic.w	ip, r9, ip
 80017ee:	ea8c 0a0a 	eor.w	sl, ip, sl
 80017f2:	f8cd e0a0 	str.w	lr, [sp, #160]	@ 0xa0
 80017f6:	ea87 0e09 	eor.w	lr, r7, r9
 80017fa:	ea21 0705 	bic.w	r7, r1, r5
 80017fe:	f8cd a098 	str.w	sl, [sp, #152]	@ 0x98
 8001802:	ea87 0a02 	eor.w	sl, r7, r2
 8001806:	ea22 0200 	bic.w	r2, r2, r0
 800180a:	ea20 0004 	bic.w	r0, r0, r4
 800180e:	4048      	eors	r0, r1
 8001810:	ea24 0101 	bic.w	r1, r4, r1
 8001814:	4069      	eors	r1, r5
 8001816:	f8cd e0a8 	str.w	lr, [sp, #168]	@ 0xa8
 800181a:	9d07      	ldr	r5, [sp, #28]
 800181c:	f8dd e040 	ldr.w	lr, [sp, #64]	@ 0x40
 8001820:	9127      	str	r1, [sp, #156]	@ 0x9c
 8001822:	ea82 0104 	eor.w	r1, r2, r4
 8001826:	912b      	str	r1, [sp, #172]	@ 0xac
 8001828:	991e      	ldr	r1, [sp, #120]	@ 0x78
 800182a:	f8dd 9020 	ldr.w	r9, [sp, #32]
 800182e:	9f05      	ldr	r7, [sp, #20]
 8001830:	9029      	str	r0, [sp, #164]	@ 0xa4
 8001832:	ea85 0e0e 	eor.w	lr, r5, lr
 8001836:	9d11      	ldr	r5, [sp, #68]	@ 0x44
 8001838:	9322      	str	r3, [sp, #136]	@ 0x88
 800183a:	ea8e 0e01 	eor.w	lr, lr, r1
 800183e:	f8cd b090 	str.w	fp, [sp, #144]	@ 0x90
 8001842:	f8dd b08c 	ldr.w	fp, [sp, #140]	@ 0x8c
 8001846:	9909      	ldr	r1, [sp, #36]	@ 0x24
 8001848:	9812      	ldr	r0, [sp, #72]	@ 0x48
 800184a:	9a1a      	ldr	r2, [sp, #104]	@ 0x68
 800184c:	f8cd a094 	str.w	sl, [sp, #148]	@ 0x94
 8001850:	ea89 0c05 	eor.w	ip, r9, r5
 8001854:	ea8c 0c07 	eor.w	ip, ip, r7
 8001858:	ea81 0500 	eor.w	r5, r1, r0
 800185c:	9f13      	ldr	r7, [sp, #76]	@ 0x4c
 800185e:	9806      	ldr	r0, [sp, #24]
 8001860:	9924      	ldr	r1, [sp, #144]	@ 0x90
 8001862:	f8dd 9054 	ldr.w	r9, [sp, #84]	@ 0x54
 8001866:	ea8e 0e03 	eor.w	lr, lr, r3
 800186a:	4055      	eors	r5, r2
 800186c:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 800186e:	ea80 0207 	eor.w	r2, r0, r7
 8001872:	9804      	ldr	r0, [sp, #16]
 8001874:	9f0a      	ldr	r7, [sp, #40]	@ 0x28
 8001876:	4042      	eors	r2, r0
 8001878:	ea87 0403 	eor.w	r4, r7, r3
 800187c:	9f1c      	ldr	r7, [sp, #112]	@ 0x70
 800187e:	981f      	ldr	r0, [sp, #124]	@ 0x7c
 8001880:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8001882:	404d      	eors	r5, r1
 8001884:	ea82 0a0a 	eor.w	sl, r2, sl
 8001888:	990b      	ldr	r1, [sp, #44]	@ 0x2c
 800188a:	9a26      	ldr	r2, [sp, #152]	@ 0x98
 800188c:	407c      	eors	r4, r7
 800188e:	4054      	eors	r4, r2
 8001890:	ea81 0209 	eor.w	r2, r1, r9
 8001894:	991b      	ldr	r1, [sp, #108]	@ 0x6c
 8001896:	f8dd 909c 	ldr.w	r9, [sp, #156]	@ 0x9c
 800189a:	9f0c      	ldr	r7, [sp, #48]	@ 0x30
 800189c:	9431      	str	r4, [sp, #196]	@ 0xc4
 800189e:	9c16      	ldr	r4, [sp, #88]	@ 0x58
 80018a0:	404a      	eors	r2, r1
 80018a2:	ea8c 0c0b 	eor.w	ip, ip, fp
 80018a6:	4067      	eors	r7, r4
 80018a8:	ea82 0b09 	eor.w	fp, r2, r9
 80018ac:	9c17      	ldr	r4, [sp, #92]	@ 0x5c
 80018ae:	9a28      	ldr	r2, [sp, #160]	@ 0xa0
 80018b0:	f8dd 9034 	ldr.w	r9, [sp, #52]	@ 0x34
 80018b4:	4047      	eors	r7, r0
 80018b6:	981d      	ldr	r0, [sp, #116]	@ 0x74
 80018b8:	4057      	eors	r7, r2
 80018ba:	ea89 0104 	eor.w	r1, r9, r4
 80018be:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 80018c0:	f8dd 9060 	ldr.w	r9, [sp, #96]	@ 0x60
 80018c4:	9c20      	ldr	r4, [sp, #128]	@ 0x80
 80018c6:	4041      	eors	r1, r0
 80018c8:	4051      	eors	r1, r2
 80018ca:	9a0e      	ldr	r2, [sp, #56]	@ 0x38
 80018cc:	ea89 0004 	eor.w	r0, r9, r4
 80018d0:	4050      	eors	r0, r2
 80018d2:	9c21      	ldr	r4, [sp, #132]	@ 0x84
 80018d4:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 80018d6:	4050      	eors	r0, r2
 80018d8:	ea83 0204 	eor.w	r2, r3, r4
 80018dc:	9b0f      	ldr	r3, [sp, #60]	@ 0x3c
 80018de:	405a      	eors	r2, r3
 80018e0:	9b2b      	ldr	r3, [sp, #172]	@ 0xac
 80018e2:	4053      	eors	r3, r2
 80018e4:	9a03      	ldr	r2, [sp, #12]
 80018e6:	9336      	str	r3, [sp, #216]	@ 0xd8
 80018e8:	9b02      	ldr	r3, [sp, #8]
 80018ea:	ea22 0906 	bic.w	r9, r2, r6
 80018ee:	ea89 0903 	eor.w	r9, r9, r3
 80018f2:	ea8e 0e09 	eor.w	lr, lr, r9
 80018f6:	f8cd e0cc 	str.w	lr, [sp, #204]	@ 0xcc
 80018fa:	e9dd 4e2d 	ldrd	r4, lr, [sp, #180]	@ 0xb4
 80018fe:	ea2e 0e04 	bic.w	lr, lr, r4
 8001902:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 8001904:	ea8e 0e04 	eor.w	lr, lr, r4
 8001908:	4614      	mov	r4, r2
 800190a:	9a30      	ldr	r2, [sp, #192]	@ 0xc0
 800190c:	ea8c 0c0e 	eor.w	ip, ip, lr
 8001910:	f8cd c0d4 	str.w	ip, [sp, #212]	@ 0xd4
 8001914:	ea22 0c04 	bic.w	ip, r2, r4
 8001918:	ea8c 0c06 	eor.w	ip, ip, r6
 800191c:	ea26 0603 	bic.w	r6, r6, r3
 8001920:	ea23 0308 	bic.w	r3, r3, r8
 8001924:	4053      	eors	r3, r2
 8001926:	f8cd c0c0 	str.w	ip, [sp, #192]	@ 0xc0
 800192a:	469c      	mov	ip, r3
 800192c:	ea28 0302 	bic.w	r3, r8, r2
 8001930:	4063      	eors	r3, r4
 8001932:	9c30      	ldr	r4, [sp, #192]	@ 0xc0
 8001934:	9a34      	ldr	r2, [sp, #208]	@ 0xd0
 8001936:	4065      	eors	r5, r4
 8001938:	9c31      	ldr	r4, [sp, #196]	@ 0xc4
 800193a:	f8cd c0c4 	str.w	ip, [sp, #196]	@ 0xc4
 800193e:	405c      	eors	r4, r3
 8001940:	ea86 0808 	eor.w	r8, r6, r8
 8001944:	4646      	mov	r6, r8
 8001946:	9402      	str	r4, [sp, #8]
 8001948:	ea87 080c 	eor.w	r8, r7, ip
 800194c:	e9dd 472e 	ldrd	r4, r7, [sp, #184]	@ 0xb8
 8001950:	4070      	eors	r0, r6
 8001952:	9632      	str	r6, [sp, #200]	@ 0xc8
 8001954:	9e2d      	ldr	r6, [sp, #180]	@ 0xb4
 8001956:	f8cd 800c 	str.w	r8, [sp, #12]
 800195a:	ea27 0704 	bic.w	r7, r7, r4
 800195e:	4077      	eors	r7, r6
 8001960:	46b4      	mov	ip, r6
 8001962:	9e2c      	ldr	r6, [sp, #176]	@ 0xb0
 8001964:	ea2c 0806 	bic.w	r8, ip, r6
 8001968:	f8dd c0bc 	ldr.w	ip, [sp, #188]	@ 0xbc
 800196c:	ea26 0602 	bic.w	r6, r6, r2
 8001970:	ea86 060c 	eor.w	r6, r6, ip
 8001974:	962c      	str	r6, [sp, #176]	@ 0xb0
 8001976:	ea22 060c 	bic.w	r6, r2, ip
 800197a:	4066      	eors	r6, r4
 800197c:	ea88 0802 	eor.w	r8, r8, r2
 8001980:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 8001982:	9a36      	ldr	r2, [sp, #216]	@ 0xd8
 8001984:	ea8a 0a07 	eor.w	sl, sl, r7
 8001988:	46c4      	mov	ip, r8
 800198a:	ea8b 0806 	eor.w	r8, fp, r6
 800198e:	ea4f 0b45 	mov.w	fp, r5, lsl #1
 8001992:	4061      	eors	r1, r4
 8001994:	f8cd c0b4 	str.w	ip, [sp, #180]	@ 0xb4
 8001998:	4664      	mov	r4, ip
 800199a:	ea4b 7bda 	orr.w	fp, fp, sl, lsr #31
 800199e:	f8dd c078 	ldr.w	ip, [sp, #120]	@ 0x78
 80019a2:	ea8b 0b00 	eor.w	fp, fp, r0
 80019a6:	4062      	eors	r2, r4
 80019a8:	ea8c 040b 	eor.w	r4, ip, fp
 80019ac:	f8dd c040 	ldr.w	ip, [sp, #64]	@ 0x40
 80019b0:	941e      	str	r4, [sp, #120]	@ 0x78
 80019b2:	ea89 040b 	eor.w	r4, r9, fp
 80019b6:	ea8c 090b 	eor.w	r9, ip, fp
 80019ba:	942e      	str	r4, [sp, #184]	@ 0xb8
 80019bc:	f8cd 90d0 	str.w	r9, [sp, #208]	@ 0xd0
 80019c0:	f8dd c088 	ldr.w	ip, [sp, #136]	@ 0x88
 80019c4:	9c02      	ldr	r4, [sp, #8]
 80019c6:	ea8c 0c0b 	eor.w	ip, ip, fp
 80019ca:	f8cd c0e4 	str.w	ip, [sp, #228]	@ 0xe4
 80019ce:	f8dd c01c 	ldr.w	ip, [sp, #28]
 80019d2:	ea4f 094a 	mov.w	r9, sl, lsl #1
 80019d6:	ea8c 0c0b 	eor.w	ip, ip, fp
 80019da:	f8cd c01c 	str.w	ip, [sp, #28]
 80019de:	ea49 79d5 	orr.w	r9, r9, r5, lsr #31
 80019e2:	f8dd c014 	ldr.w	ip, [sp, #20]
 80019e6:	ea89 0902 	eor.w	r9, r9, r2
 80019ea:	ea8c 0c09 	eor.w	ip, ip, r9
 80019ee:	ea8e 0e09 	eor.w	lr, lr, r9
 80019f2:	f8cd c088 	str.w	ip, [sp, #136]	@ 0x88
 80019f6:	f8dd c044 	ldr.w	ip, [sp, #68]	@ 0x44
 80019fa:	f8cd e0bc 	str.w	lr, [sp, #188]	@ 0xbc
 80019fe:	f8dd e08c 	ldr.w	lr, [sp, #140]	@ 0x8c
 8001a02:	ea8c 0c09 	eor.w	ip, ip, r9
 8001a06:	f8cd c0d8 	str.w	ip, [sp, #216]	@ 0xd8
 8001a0a:	ea8e 0c09 	eor.w	ip, lr, r9
 8001a0e:	f8dd e020 	ldr.w	lr, [sp, #32]
 8001a12:	f8cd c0e8 	str.w	ip, [sp, #232]	@ 0xe8
 8001a16:	ea8e 0e09 	eor.w	lr, lr, r9
 8001a1a:	f8dd c0cc 	ldr.w	ip, [sp, #204]	@ 0xcc
 8001a1e:	f8cd e020 	str.w	lr, [sp, #32]
 8001a22:	ea4f 0e44 	mov.w	lr, r4, lsl #1
 8001a26:	f8dd 9090 	ldr.w	r9, [sp, #144]	@ 0x90
 8001a2a:	ea4e 7ed8 	orr.w	lr, lr, r8, lsr #31
 8001a2e:	ea8e 0e0c 	eor.w	lr, lr, ip
 8001a32:	ea89 090e 	eor.w	r9, r9, lr
 8001a36:	f8cd 908c 	str.w	r9, [sp, #140]	@ 0x8c
 8001a3a:	f8dd 9024 	ldr.w	r9, [sp, #36]	@ 0x24
 8001a3e:	f8dd c048 	ldr.w	ip, [sp, #72]	@ 0x48
 8001a42:	ea89 090e 	eor.w	r9, r9, lr
 8001a46:	ea8c 0b0e 	eor.w	fp, ip, lr
 8001a4a:	f8cd 9014 	str.w	r9, [sp, #20]
 8001a4e:	f8dd 90c0 	ldr.w	r9, [sp, #192]	@ 0xc0
 8001a52:	f8cd b040 	str.w	fp, [sp, #64]	@ 0x40
 8001a56:	f8dd b068 	ldr.w	fp, [sp, #104]	@ 0x68
 8001a5a:	f8dd c04c 	ldr.w	ip, [sp, #76]	@ 0x4c
 8001a5e:	ea89 090e 	eor.w	r9, r9, lr
 8001a62:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001a66:	f8cd 90ec 	str.w	r9, [sp, #236]	@ 0xec
 8001a6a:	ea4f 0e48 	mov.w	lr, r8, lsl #1
 8001a6e:	f8dd 90d4 	ldr.w	r9, [sp, #212]	@ 0xd4
 8001a72:	f8cd b0dc 	str.w	fp, [sp, #220]	@ 0xdc
 8001a76:	ea4e 7ed4 	orr.w	lr, lr, r4, lsr #31
 8001a7a:	f8dd b094 	ldr.w	fp, [sp, #148]	@ 0x94
 8001a7e:	ea8e 0e09 	eor.w	lr, lr, r9
 8001a82:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001a86:	f8cd b024 	str.w	fp, [sp, #36]	@ 0x24
 8001a8a:	f8dd b018 	ldr.w	fp, [sp, #24]
 8001a8e:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001a92:	f8cd b090 	str.w	fp, [sp, #144]	@ 0x90
 8001a96:	f8dd b010 	ldr.w	fp, [sp, #16]
 8001a9a:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001a9e:	f8cd b0c0 	str.w	fp, [sp, #192]	@ 0xc0
 8001aa2:	9c03      	ldr	r4, [sp, #12]
 8001aa4:	f8dd b028 	ldr.w	fp, [sp, #40]	@ 0x28
 8001aa8:	ea87 070e 	eor.w	r7, r7, lr
 8001aac:	973c      	str	r7, [sp, #240]	@ 0xf0
 8001aae:	0067      	lsls	r7, r4, #1
 8001ab0:	ea47 77d1 	orr.w	r7, r7, r1, lsr #31
 8001ab4:	406f      	eors	r7, r5
 8001ab6:	ea8c 0c0e 	eor.w	ip, ip, lr
 8001aba:	f8dd e050 	ldr.w	lr, [sp, #80]	@ 0x50
 8001abe:	9d1c      	ldr	r5, [sp, #112]	@ 0x70
 8001ac0:	407b      	eors	r3, r7
 8001ac2:	9313      	str	r3, [sp, #76]	@ 0x4c
 8001ac4:	ea8e 0307 	eor.w	r3, lr, r7
 8001ac8:	931c      	str	r3, [sp, #112]	@ 0x70
 8001aca:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 8001acc:	f8dd e030 	ldr.w	lr, [sp, #48]	@ 0x30
 8001ad0:	407b      	eors	r3, r7
 8001ad2:	9326      	str	r3, [sp, #152]	@ 0x98
 8001ad4:	004b      	lsls	r3, r1, #1
 8001ad6:	ea43 73d4 	orr.w	r3, r3, r4, lsr #31
 8001ada:	ea83 030a 	eor.w	r3, r3, sl
 8001ade:	405e      	eors	r6, r3
 8001ae0:	961a      	str	r6, [sp, #104]	@ 0x68
 8001ae2:	9e15      	ldr	r6, [sp, #84]	@ 0x54
 8001ae4:	f8dd a06c 	ldr.w	sl, [sp, #108]	@ 0x6c
 8001ae8:	9c02      	ldr	r4, [sp, #8]
 8001aea:	405e      	eors	r6, r3
 8001aec:	9615      	str	r6, [sp, #84]	@ 0x54
 8001aee:	9e27      	ldr	r6, [sp, #156]	@ 0x9c
 8001af0:	405e      	eors	r6, r3
 8001af2:	9627      	str	r6, [sp, #156]	@ 0x9c
 8001af4:	9e0b      	ldr	r6, [sp, #44]	@ 0x2c
 8001af6:	407d      	eors	r5, r7
 8001af8:	ea8b 0707 	eor.w	r7, fp, r7
 8001afc:	9735      	str	r7, [sp, #212]	@ 0xd4
 8001afe:	ea8a 0703 	eor.w	r7, sl, r3
 8001b02:	4073      	eors	r3, r6
 8001b04:	9338      	str	r3, [sp, #224]	@ 0xe0
 8001b06:	0043      	lsls	r3, r0, #1
 8001b08:	f8dd a0a0 	ldr.w	sl, [sp, #160]	@ 0xa0
 8001b0c:	f8dd b034 	ldr.w	fp, [sp, #52]	@ 0x34
 8001b10:	ea43 73d2 	orr.w	r3, r3, r2, lsr #31
 8001b14:	0052      	lsls	r2, r2, #1
 8001b16:	4063      	eors	r3, r4
 8001b18:	ea42 72d0 	orr.w	r2, r2, r0, lsr #31
 8001b1c:	ea82 0208 	eor.w	r2, r2, r8
 8001b20:	ea8a 0803 	eor.w	r8, sl, r3
 8001b24:	f8dd a0a4 	ldr.w	sl, [sp, #164]	@ 0xa4
 8001b28:	981d      	ldr	r0, [sp, #116]	@ 0x74
 8001b2a:	ea8a 0602 	eor.w	r6, sl, r2
 8001b2e:	f8dd a07c 	ldr.w	sl, [sp, #124]	@ 0x7c
 8001b32:	ea8a 0a03 	eor.w	sl, sl, r3
 8001b36:	f8cd a02c 	str.w	sl, [sp, #44]	@ 0x2c
 8001b3a:	ea80 0a02 	eor.w	sl, r0, r2
 8001b3e:	f8cd a074 	str.w	sl, [sp, #116]	@ 0x74
 8001b42:	f8dd a0c4 	ldr.w	sl, [sp, #196]	@ 0xc4
 8001b46:	ea8b 0402 	eor.w	r4, fp, r2
 8001b4a:	ea8a 0003 	eor.w	r0, sl, r3
 8001b4e:	f8dd b058 	ldr.w	fp, [sp, #88]	@ 0x58
 8001b52:	f8dd a0b0 	ldr.w	sl, [sp, #176]	@ 0xb0
 8001b56:	9028      	str	r0, [sp, #160]	@ 0xa0
 8001b58:	ea8e 0e03 	eor.w	lr, lr, r3
 8001b5c:	ea8b 0003 	eor.w	r0, fp, r3
 8001b60:	ea8a 0302 	eor.w	r3, sl, r2
 8001b64:	9031      	str	r0, [sp, #196]	@ 0xc4
 8001b66:	9329      	str	r3, [sp, #164]	@ 0xa4
 8001b68:	9833      	ldr	r0, [sp, #204]	@ 0xcc
 8001b6a:	f8dd b05c 	ldr.w	fp, [sp, #92]	@ 0x5c
 8001b6e:	0043      	lsls	r3, r0, #1
 8001b70:	ea8b 0b02 	eor.w	fp, fp, r2
 8001b74:	9a03      	ldr	r2, [sp, #12]
 8001b76:	f8cd b0b0 	str.w	fp, [sp, #176]	@ 0xb0
 8001b7a:	ea43 73d9 	orr.w	r3, r3, r9, lsr #31
 8001b7e:	4053      	eors	r3, r2
 8001b80:	9a32      	ldr	r2, [sp, #200]	@ 0xc8
 8001b82:	ea4f 0b49 	mov.w	fp, r9, lsl #1
 8001b86:	ea82 0a03 	eor.w	sl, r2, r3
 8001b8a:	ea4b 7bd0 	orr.w	fp, fp, r0, lsr #31
 8001b8e:	9a2d      	ldr	r2, [sp, #180]	@ 0xb4
 8001b90:	9819      	ldr	r0, [sp, #100]	@ 0x64
 8001b92:	f8dd 9060 	ldr.w	r9, [sp, #96]	@ 0x60
 8001b96:	ea8b 0b01 	eor.w	fp, fp, r1
 8001b9a:	ea82 020b 	eor.w	r2, r2, fp
 8001b9e:	9202      	str	r2, [sp, #8]
 8001ba0:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 8001ba2:	405a      	eors	r2, r3
 8001ba4:	921f      	str	r2, [sp, #124]	@ 0x7c
 8001ba6:	9a2b      	ldr	r2, [sp, #172]	@ 0xac
 8001ba8:	ea82 010b 	eor.w	r1, r2, fp
 8001bac:	9a0e      	ldr	r2, [sp, #56]	@ 0x38
 8001bae:	405a      	eors	r2, r3
 8001bb0:	9225      	str	r2, [sp, #148]	@ 0x94
 8001bb2:	9a20      	ldr	r2, [sp, #128]	@ 0x80
 8001bb4:	405a      	eors	r2, r3
 8001bb6:	9232      	str	r2, [sp, #200]	@ 0xc8
 8001bb8:	9a0f      	ldr	r2, [sp, #60]	@ 0x3c
 8001bba:	ea82 020b 	eor.w	r2, r2, fp
 8001bbe:	9220      	str	r2, [sp, #128]	@ 0x80
 8001bc0:	9a21      	ldr	r2, [sp, #132]	@ 0x84
 8001bc2:	ea80 000b 	eor.w	r0, r0, fp
 8001bc6:	ea82 020b 	eor.w	r2, r2, fp
 8001bca:	f8dd b004 	ldr.w	fp, [sp, #4]
 8001bce:	9233      	str	r2, [sp, #204]	@ 0xcc
 8001bd0:	ea89 0903 	eor.w	r9, r9, r3
 8001bd4:	9a07      	ldr	r2, [sp, #28]
 8001bd6:	f8db 3008 	ldr.w	r3, [fp, #8]
 8001bda:	4053      	eors	r3, r2
 8001bdc:	f10b 0210 	add.w	r2, fp, #16
 8001be0:	9304      	str	r3, [sp, #16]
 8001be2:	9201      	str	r2, [sp, #4]
 8001be4:	f8db 300c 	ldr.w	r3, [fp, #12]
 8001be8:	9a10      	ldr	r2, [sp, #64]	@ 0x40
 8001bea:	f8dd b020 	ldr.w	fp, [sp, #32]
 8001bee:	ea8b 0b03 	eor.w	fp, fp, r3
 8001bf2:	0d13      	lsrs	r3, r2, #20
 8001bf4:	f8cd b018 	str.w	fp, [sp, #24]
 8001bf8:	ea43 3b0c 	orr.w	fp, r3, ip, lsl #12
 8001bfc:	0d6b      	lsrs	r3, r5, #21
 8001bfe:	ea43 23c7 	orr.w	r3, r3, r7, lsl #11
 8001c02:	9303      	str	r3, [sp, #12]
 8001c04:	ea4f 5348 	mov.w	r3, r8, lsl #21
 8001c08:	ea43 23d6 	orr.w	r3, r3, r6, lsr #11
 8001c0c:	ea4f 5c1c 	mov.w	ip, ip, lsr #20
 8001c10:	0d7f      	lsrs	r7, r7, #21
 8001c12:	0576      	lsls	r6, r6, #21
 8001c14:	ea4c 3c02 	orr.w	ip, ip, r2, lsl #12
 8001c18:	ea47 27c5 	orr.w	r7, r7, r5, lsl #11
 8001c1c:	ea46 26d8 	orr.w	r6, r6, r8, lsr #11
 8001c20:	f8cd c028 	str.w	ip, [sp, #40]	@ 0x28
 8001c24:	970c      	str	r7, [sp, #48]	@ 0x30
 8001c26:	960d      	str	r6, [sp, #52]	@ 0x34
 8001c28:	9a02      	ldr	r2, [sp, #8]
 8001c2a:	9f22      	ldr	r7, [sp, #136]	@ 0x88
 8001c2c:	ea4f 760e 	mov.w	r6, lr, lsl #28
 8001c30:	ea46 1814 	orr.w	r8, r6, r4, lsr #4
 8001c34:	ea4f 358a 	mov.w	r5, sl, lsl #14
 8001c38:	0724      	lsls	r4, r4, #28
 8001c3a:	ea45 4592 	orr.w	r5, r5, r2, lsr #18
 8001c3e:	ea44 1e1e 	orr.w	lr, r4, lr, lsr #4
 8001c42:	0392      	lsls	r2, r2, #14
 8001c44:	ea4f 5409 	mov.w	r4, r9, lsl #20
 8001c48:	ea42 429a 	orr.w	r2, r2, sl, lsr #18
 8001c4c:	ea44 3a10 	orr.w	sl, r4, r0, lsr #12
 8001c50:	9c1e      	ldr	r4, [sp, #120]	@ 0x78
 8001c52:	f8cd 8038 	str.w	r8, [sp, #56]	@ 0x38
 8001c56:	0500      	lsls	r0, r0, #20
 8001c58:	f8dd 8024 	ldr.w	r8, [sp, #36]	@ 0x24
 8001c5c:	f8cd e03c 	str.w	lr, [sp, #60]	@ 0x3c
 8001c60:	ea40 3919 	orr.w	r9, r0, r9, lsr #12
 8001c64:	00e0      	lsls	r0, r4, #3
 8001c66:	ea40 7657 	orr.w	r6, r0, r7, lsr #29
 8001c6a:	00f8      	lsls	r0, r7, #3
 8001c6c:	ea40 7754 	orr.w	r7, r0, r4, lsr #29
 8001c70:	9c23      	ldr	r4, [sp, #140]	@ 0x8c
 8001c72:	9602      	str	r6, [sp, #8]
 8001c74:	4640      	mov	r0, r8
 8001c76:	0cc0      	lsrs	r0, r0, #19
 8001c78:	ea40 3e44 	orr.w	lr, r0, r4, lsl #13
 8001c7c:	0ce6      	lsrs	r6, r4, #19
 8001c7e:	9c13      	ldr	r4, [sp, #76]	@ 0x4c
 8001c80:	981a      	ldr	r0, [sp, #104]	@ 0x68
 8001c82:	9710      	str	r7, [sp, #64]	@ 0x40
 8001c84:	08e7      	lsrs	r7, r4, #3
 8001c86:	ea47 7740 	orr.w	r7, r7, r0, lsl #29
 8001c8a:	08c0      	lsrs	r0, r0, #3
 8001c8c:	ea40 7044 	orr.w	r0, r0, r4, lsl #29
 8001c90:	9c05      	ldr	r4, [sp, #20]
 8001c92:	f8cd 9048 	str.w	r9, [sp, #72]	@ 0x48
 8001c96:	ea46 3648 	orr.w	r6, r6, r8, lsl #13
 8001c9a:	f8dd 8090 	ldr.w	r8, [sp, #144]	@ 0x90
 8001c9e:	f8dd 9014 	ldr.w	r9, [sp, #20]
 8001ca2:	9016      	str	r0, [sp, #88]	@ 0x58
 8001ca4:	0064      	lsls	r4, r4, #1
 8001ca6:	ea44 70d8 	orr.w	r0, r4, r8, lsr #31
 8001caa:	4644      	mov	r4, r8
 8001cac:	0064      	lsls	r4, r4, #1
 8001cae:	ea44 78d9 	orr.w	r8, r4, r9, lsr #31
 8001cb2:	9017      	str	r0, [sp, #92]	@ 0x5c
 8001cb4:	981c      	ldr	r0, [sp, #112]	@ 0x70
 8001cb6:	f8cd 8060 	str.w	r8, [sp, #96]	@ 0x60
 8001cba:	f8dd 8054 	ldr.w	r8, [sp, #84]	@ 0x54
 8001cbe:	f8cd e050 	str.w	lr, [sp, #80]	@ 0x50
 8001cc2:	0184      	lsls	r4, r0, #6
 8001cc4:	ea44 6998 	orr.w	r9, r4, r8, lsr #26
 8001cc8:	4644      	mov	r4, r8
 8001cca:	01a4      	lsls	r4, r4, #6
 8001ccc:	ea44 6c90 	orr.w	ip, r4, r0, lsr #26
 8001cd0:	980b      	ldr	r0, [sp, #44]	@ 0x2c
 8001cd2:	f8dd 8074 	ldr.w	r8, [sp, #116]	@ 0x74
 8001cd6:	f8cd 9068 	str.w	r9, [sp, #104]	@ 0x68
 8001cda:	0644      	lsls	r4, r0, #25
 8001cdc:	f8dd 907c 	ldr.w	r9, [sp, #124]	@ 0x7c
 8001ce0:	f8cd c06c 	str.w	ip, [sp, #108]	@ 0x6c
 8001ce4:	ea44 1ed8 	orr.w	lr, r4, r8, lsr #7
 8001ce8:	f8cd e070 	str.w	lr, [sp, #112]	@ 0x70
 8001cec:	4644      	mov	r4, r8
 8001cee:	f8dd e0bc 	ldr.w	lr, [sp, #188]	@ 0xbc
 8001cf2:	f8cd a044 	str.w	sl, [sp, #68]	@ 0x44
 8001cf6:	ea4f 2c09 	mov.w	ip, r9, lsl #8
 8001cfa:	ea4c 6c11 	orr.w	ip, ip, r1, lsr #24
 8001cfe:	0664      	lsls	r4, r4, #25
 8001d00:	0209      	lsls	r1, r1, #8
 8001d02:	ea44 18d0 	orr.w	r8, r4, r0, lsr #7
 8001d06:	ea41 6919 	orr.w	r9, r1, r9, lsr #24
 8001d0a:	9c2e      	ldr	r4, [sp, #184]	@ 0xb8
 8001d0c:	f8cd 9074 	str.w	r9, [sp, #116]	@ 0x74
 8001d10:	4671      	mov	r1, lr
 8001d12:	0489      	lsls	r1, r1, #18
 8001d14:	ea4f 4984 	mov.w	r9, r4, lsl #18
 8001d18:	ea41 3494 	orr.w	r4, r1, r4, lsr #14
 8001d1c:	f8cd 8064 	str.w	r8, [sp, #100]	@ 0x64
 8001d20:	941f      	str	r4, [sp, #124]	@ 0x7c
 8001d22:	9c25      	ldr	r4, [sp, #148]	@ 0x94
 8001d24:	f8dd 8080 	ldr.w	r8, [sp, #128]	@ 0x80
 8001d28:	9826      	ldr	r0, [sp, #152]	@ 0x98
 8001d2a:	06e1      	lsls	r1, r4, #27
 8001d2c:	ea49 399e 	orr.w	r9, r9, lr, lsr #14
 8001d30:	ea41 1e58 	orr.w	lr, r1, r8, lsr #5
 8001d34:	4641      	mov	r1, r8
 8001d36:	06c9      	lsls	r1, r1, #27
 8001d38:	ea41 1454 	orr.w	r4, r1, r4, lsr #5
 8001d3c:	9421      	str	r4, [sp, #132]	@ 0x84
 8001d3e:	9c34      	ldr	r4, [sp, #208]	@ 0xd0
 8001d40:	f8cd e080 	str.w	lr, [sp, #128]	@ 0x80
 8001d44:	f8dd e0d8 	ldr.w	lr, [sp, #216]	@ 0xd8
 8001d48:	0f21      	lsrs	r1, r4, #28
 8001d4a:	ea41 180e 	orr.w	r8, r1, lr, lsl #4
 8001d4e:	4671      	mov	r1, lr
 8001d50:	0f09      	lsrs	r1, r1, #28
 8001d52:	ea41 1404 	orr.w	r4, r1, r4, lsl #4
 8001d56:	9423      	str	r4, [sp, #140]	@ 0x8c
 8001d58:	9c37      	ldr	r4, [sp, #220]	@ 0xdc
 8001d5a:	f8cd 8088 	str.w	r8, [sp, #136]	@ 0x88
 8001d5e:	f8dd 80c0 	ldr.w	r8, [sp, #192]	@ 0xc0
 8001d62:	02a1      	lsls	r1, r4, #10
 8001d64:	ea41 5e98 	orr.w	lr, r1, r8, lsr #22
 8001d68:	4641      	mov	r1, r8
 8001d6a:	0289      	lsls	r1, r1, #10
 8001d6c:	ea41 5494 	orr.w	r4, r1, r4, lsr #22
 8001d70:	9927      	ldr	r1, [sp, #156]	@ 0x9c
 8001d72:	9425      	str	r4, [sp, #148]	@ 0x94
 8001d74:	03c4      	lsls	r4, r0, #15
 8001d76:	ea44 4451 	orr.w	r4, r4, r1, lsr #17
 8001d7a:	03c9      	lsls	r1, r1, #15
 8001d7c:	ea41 4150 	orr.w	r1, r1, r0, lsr #17
 8001d80:	f8cd e090 	str.w	lr, [sp, #144]	@ 0x90
 8001d84:	f8dd e0a0 	ldr.w	lr, [sp, #160]	@ 0xa0
 8001d88:	9127      	str	r1, [sp, #156]	@ 0x9c
 8001d8a:	9929      	ldr	r1, [sp, #164]	@ 0xa4
 8001d8c:	9835      	ldr	r0, [sp, #212]	@ 0xd4
 8001d8e:	ea4f 281e 	mov.w	r8, lr, lsr #8
 8001d92:	ea48 6801 	orr.w	r8, r8, r1, lsl #24
 8001d96:	0a09      	lsrs	r1, r1, #8
 8001d98:	ea41 610e 	orr.w	r1, r1, lr, lsl #24
 8001d9c:	f8dd e0e0 	ldr.w	lr, [sp, #224]	@ 0xe0
 8001da0:	9129      	str	r1, [sp, #164]	@ 0xa4
 8001da2:	0881      	lsrs	r1, r0, #2
 8001da4:	ea41 718e 	orr.w	r1, r1, lr, lsl #30
 8001da8:	912a      	str	r1, [sp, #168]	@ 0xa8
 8001daa:	4671      	mov	r1, lr
 8001dac:	0889      	lsrs	r1, r1, #2
 8001dae:	ea41 7180 	orr.w	r1, r1, r0, lsl #30
 8001db2:	9831      	ldr	r0, [sp, #196]	@ 0xc4
 8001db4:	f8dd e0b0 	ldr.w	lr, [sp, #176]	@ 0xb0
 8001db8:	912b      	str	r1, [sp, #172]	@ 0xac
 8001dba:	0a41      	lsrs	r1, r0, #9
 8001dbc:	ea41 5ace 	orr.w	sl, r1, lr, lsl #23
 8001dc0:	4671      	mov	r1, lr
 8001dc2:	0a49      	lsrs	r1, r1, #9
 8001dc4:	ea41 51c0 	orr.w	r1, r1, r0, lsl #23
 8001dc8:	9832      	ldr	r0, [sp, #200]	@ 0xc8
 8001dca:	f8cd a0b0 	str.w	sl, [sp, #176]	@ 0xb0
 8001dce:	f8dd a0cc 	ldr.w	sl, [sp, #204]	@ 0xcc
 8001dd2:	912d      	str	r1, [sp, #180]	@ 0xb4
 8001dd4:	0e41      	lsrs	r1, r0, #25
 8001dd6:	ea41 1eca 	orr.w	lr, r1, sl, lsl #7
 8001dda:	4651      	mov	r1, sl
 8001ddc:	0e49      	lsrs	r1, r1, #25
 8001dde:	f8dd a0e8 	ldr.w	sl, [sp, #232]	@ 0xe8
 8001de2:	f8cd e0b8 	str.w	lr, [sp, #184]	@ 0xb8
 8001de6:	ea41 11c0 	orr.w	r1, r1, r0, lsl #7
 8001dea:	9839      	ldr	r0, [sp, #228]	@ 0xe4
 8001dec:	912f      	str	r1, [sp, #188]	@ 0xbc
 8001dee:	ea4f 5eda 	mov.w	lr, sl, lsr #23
 8001df2:	0dc1      	lsrs	r1, r0, #23
 8001df4:	ea41 214a 	orr.w	r1, r1, sl, lsl #9
 8001df8:	ea4e 2a40 	orr.w	sl, lr, r0, lsl #9
 8001dfc:	f8cd a0c0 	str.w	sl, [sp, #192]	@ 0xc0
 8001e00:	983b      	ldr	r0, [sp, #236]	@ 0xec
 8001e02:	f8dd a0f0 	ldr.w	sl, [sp, #240]	@ 0xf0
 8001e06:	ea4f 0e80 	mov.w	lr, r0, lsl #2
 8001e0a:	ea4e 7e9a 	orr.w	lr, lr, sl, lsr #30
 8001e0e:	ea4f 0a8a 	mov.w	sl, sl, lsl #2
 8001e12:	ea4a 7a90 	orr.w	sl, sl, r0, lsr #30
 8001e16:	f8cd a0c4 	str.w	sl, [sp, #196]	@ 0xc4
 8001e1a:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001e1e:	9804      	ldr	r0, [sp, #16]
 8001e20:	ea2a 0a0b 	bic.w	sl, sl, fp
 8001e24:	ea80 000a 	eor.w	r0, r0, sl
 8001e28:	9004      	str	r0, [sp, #16]
 8001e2a:	f8dd a028 	ldr.w	sl, [sp, #40]	@ 0x28
 8001e2e:	980c      	ldr	r0, [sp, #48]	@ 0x30
 8001e30:	ea20 0a0a 	bic.w	sl, r0, sl
 8001e34:	9806      	ldr	r0, [sp, #24]
 8001e36:	ea80 000a 	eor.w	r0, r0, sl
 8001e3a:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001e3e:	9005      	str	r0, [sp, #20]
 8001e40:	ea23 0a0a 	bic.w	sl, r3, sl
 8001e44:	ea8a 000b 	eor.w	r0, sl, fp
 8001e48:	9006      	str	r0, [sp, #24]
 8001e4a:	9807      	ldr	r0, [sp, #28]
 8001e4c:	ea2b 0a00 	bic.w	sl, fp, r0
 8001e50:	ea20 0b05 	bic.w	fp, r0, r5
 8001e54:	ea8b 0b03 	eor.w	fp, fp, r3
 8001e58:	f8cd b024 	str.w	fp, [sp, #36]	@ 0x24
 8001e5c:	f8dd b00c 	ldr.w	fp, [sp, #12]
 8001e60:	980e      	ldr	r0, [sp, #56]	@ 0x38
 8001e62:	ea25 0303 	bic.w	r3, r5, r3
 8001e66:	ea83 030b 	eor.w	r3, r3, fp
 8001e6a:	9307      	str	r3, [sp, #28]
 8001e6c:	ea8a 0305 	eor.w	r3, sl, r5
 8001e70:	e9dd ab0c 	ldrd	sl, fp, [sp, #48]	@ 0x30
 8001e74:	9d0a      	ldr	r5, [sp, #40]	@ 0x28
 8001e76:	930b      	str	r3, [sp, #44]	@ 0x2c
 8001e78:	ea2b 030a 	bic.w	r3, fp, sl
 8001e7c:	406b      	eors	r3, r5
 8001e7e:	9303      	str	r3, [sp, #12]
 8001e80:	9b08      	ldr	r3, [sp, #32]
 8001e82:	ea25 0503 	bic.w	r5, r5, r3
 8001e86:	ea23 0302 	bic.w	r3, r3, r2
 8001e8a:	ea83 030b 	eor.w	r3, r3, fp
 8001e8e:	930a      	str	r3, [sp, #40]	@ 0x28
 8001e90:	ea22 030b 	bic.w	r3, r2, fp
 8001e94:	ea83 030a 	eor.w	r3, r3, sl
 8001e98:	9308      	str	r3, [sp, #32]
 8001e9a:	f8dd a044 	ldr.w	sl, [sp, #68]	@ 0x44
 8001e9e:	f8dd b048 	ldr.w	fp, [sp, #72]	@ 0x48
 8001ea2:	ea85 0302 	eor.w	r3, r5, r2
 8001ea6:	9a02      	ldr	r2, [sp, #8]
 8001ea8:	930c      	str	r3, [sp, #48]	@ 0x30
 8001eaa:	ea22 030a 	bic.w	r3, r2, sl
 8001eae:	4043      	eors	r3, r0
 8001eb0:	930d      	str	r3, [sp, #52]	@ 0x34
 8001eb2:	9b10      	ldr	r3, [sp, #64]	@ 0x40
 8001eb4:	9d0f      	ldr	r5, [sp, #60]	@ 0x3c
 8001eb6:	ea23 030b 	bic.w	r3, r3, fp
 8001eba:	406b      	eors	r3, r5
 8001ebc:	930e      	str	r3, [sp, #56]	@ 0x38
 8001ebe:	ea26 0302 	bic.w	r3, r6, r2
 8001ec2:	ea83 030a 	eor.w	r3, r3, sl
 8001ec6:	ea20 0207 	bic.w	r2, r0, r7
 8001eca:	930f      	str	r3, [sp, #60]	@ 0x3c
 8001ecc:	ea2a 0300 	bic.w	r3, sl, r0
 8001ed0:	9802      	ldr	r0, [sp, #8]
 8001ed2:	f8dd a070 	ldr.w	sl, [sp, #112]	@ 0x70
 8001ed6:	4072      	eors	r2, r6
 8001ed8:	ea27 0606 	bic.w	r6, r7, r6
 8001edc:	9213      	str	r2, [sp, #76]	@ 0x4c
 8001ede:	ea86 0200 	eor.w	r2, r6, r0
 8001ee2:	9e14      	ldr	r6, [sp, #80]	@ 0x50
 8001ee4:	9810      	ldr	r0, [sp, #64]	@ 0x40
 8001ee6:	9211      	str	r2, [sp, #68]	@ 0x44
 8001ee8:	407b      	eors	r3, r7
 8001eea:	9315      	str	r3, [sp, #84]	@ 0x54
 8001eec:	9f16      	ldr	r7, [sp, #88]	@ 0x58
 8001eee:	ea26 0300 	bic.w	r3, r6, r0
 8001ef2:	ea83 030b 	eor.w	r3, r3, fp
 8001ef6:	9310      	str	r3, [sp, #64]	@ 0x40
 8001ef8:	ea25 0307 	bic.w	r3, r5, r7
 8001efc:	4073      	eors	r3, r6
 8001efe:	9314      	str	r3, [sp, #80]	@ 0x50
 8001f00:	ea27 0306 	bic.w	r3, r7, r6
 8001f04:	4043      	eors	r3, r0
 8001f06:	9e1a      	ldr	r6, [sp, #104]	@ 0x68
 8001f08:	9312      	str	r3, [sp, #72]	@ 0x48
 8001f0a:	ea2b 0205 	bic.w	r2, fp, r5
 8001f0e:	463b      	mov	r3, r7
 8001f10:	9817      	ldr	r0, [sp, #92]	@ 0x5c
 8001f12:	9f1b      	ldr	r7, [sp, #108]	@ 0x6c
 8001f14:	9d18      	ldr	r5, [sp, #96]	@ 0x60
 8001f16:	4053      	eors	r3, r2
 8001f18:	9316      	str	r3, [sp, #88]	@ 0x58
 8001f1a:	ea2a 0306 	bic.w	r3, sl, r6
 8001f1e:	ea83 0b00 	eor.w	fp, r3, r0
 8001f22:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8001f24:	ea23 0307 	bic.w	r3, r3, r7
 8001f28:	406b      	eors	r3, r5
 8001f2a:	9317      	str	r3, [sp, #92]	@ 0x5c
 8001f2c:	ea2c 030a 	bic.w	r3, ip, sl
 8001f30:	ea20 0209 	bic.w	r2, r0, r9
 8001f34:	4073      	eors	r3, r6
 8001f36:	9318      	str	r3, [sp, #96]	@ 0x60
 8001f38:	ea26 0300 	bic.w	r3, r6, r0
 8001f3c:	ea82 060c 	eor.w	r6, r2, ip
 8001f40:	ea29 0c0c 	bic.w	ip, r9, ip
 8001f44:	961c      	str	r6, [sp, #112]	@ 0x70
 8001f46:	ea8c 060a 	eor.w	r6, ip, sl
 8001f4a:	9819      	ldr	r0, [sp, #100]	@ 0x64
 8001f4c:	961a      	str	r6, [sp, #104]	@ 0x68
 8001f4e:	9e1d      	ldr	r6, [sp, #116]	@ 0x74
 8001f50:	f8dd c090 	ldr.w	ip, [sp, #144]	@ 0x90
 8001f54:	ea83 0309 	eor.w	r3, r3, r9
 8001f58:	931e      	str	r3, [sp, #120]	@ 0x78
 8001f5a:	ea26 0300 	bic.w	r3, r6, r0
 8001f5e:	407b      	eors	r3, r7
 8001f60:	9319      	str	r3, [sp, #100]	@ 0x64
 8001f62:	ea27 0305 	bic.w	r3, r7, r5
 8001f66:	9f1f      	ldr	r7, [sp, #124]	@ 0x7c
 8001f68:	ea25 0207 	bic.w	r2, r5, r7
 8001f6c:	ea82 0906 	eor.w	r9, r2, r6
 8001f70:	ea27 0206 	bic.w	r2, r7, r6
 8001f74:	ea82 0600 	eor.w	r6, r2, r0
 8001f78:	407b      	eors	r3, r7
 8001f7a:	961b      	str	r6, [sp, #108]	@ 0x6c
 8001f7c:	9e22      	ldr	r6, [sp, #136]	@ 0x88
 8001f7e:	f8cd 9074 	str.w	r9, [sp, #116]	@ 0x74
 8001f82:	931f      	str	r3, [sp, #124]	@ 0x7c
 8001f84:	9820      	ldr	r0, [sp, #128]	@ 0x80
 8001f86:	9f23      	ldr	r7, [sp, #140]	@ 0x8c
 8001f88:	f8dd 9094 	ldr.w	r9, [sp, #148]	@ 0x94
 8001f8c:	9d21      	ldr	r5, [sp, #132]	@ 0x84
 8001f8e:	ea2c 0306 	bic.w	r3, ip, r6
 8001f92:	4043      	eors	r3, r0
 8001f94:	9320      	str	r3, [sp, #128]	@ 0x80
 8001f96:	ea29 0307 	bic.w	r3, r9, r7
 8001f9a:	406b      	eors	r3, r5
 8001f9c:	9321      	str	r3, [sp, #132]	@ 0x84
 8001f9e:	ea24 030c 	bic.w	r3, r4, ip
 8001fa2:	4073      	eors	r3, r6
 8001fa4:	ea20 0208 	bic.w	r2, r0, r8
 8001fa8:	9322      	str	r3, [sp, #136]	@ 0x88
 8001faa:	ea26 0300 	bic.w	r3, r6, r0
 8001fae:	9827      	ldr	r0, [sp, #156]	@ 0x9c
 8001fb0:	ea82 0604 	eor.w	r6, r2, r4
 8001fb4:	ea83 0308 	eor.w	r3, r3, r8
 8001fb8:	ea28 0404 	bic.w	r4, r8, r4
 8001fbc:	9626      	str	r6, [sp, #152]	@ 0x98
 8001fbe:	9328      	str	r3, [sp, #160]	@ 0xa0
 8001fc0:	ea84 060c 	eor.w	r6, r4, ip
 8001fc4:	ea20 0309 	bic.w	r3, r0, r9
 8001fc8:	9c29      	ldr	r4, [sp, #164]	@ 0xa4
 8001fca:	9624      	str	r6, [sp, #144]	@ 0x90
 8001fcc:	407b      	eors	r3, r7
 8001fce:	ea25 0204 	bic.w	r2, r5, r4
 8001fd2:	9323      	str	r3, [sp, #140]	@ 0x8c
 8001fd4:	ea27 0305 	bic.w	r3, r7, r5
 8001fd8:	9f2e      	ldr	r7, [sp, #184]	@ 0xb8
 8001fda:	f8dd c0bc 	ldr.w	ip, [sp, #188]	@ 0xbc
 8001fde:	9d2d      	ldr	r5, [sp, #180]	@ 0xb4
 8001fe0:	ea82 0600 	eor.w	r6, r2, r0
 8001fe4:	4063      	eors	r3, r4
 8001fe6:	ea24 0200 	bic.w	r2, r4, r0
 8001fea:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 8001fec:	9627      	str	r6, [sp, #156]	@ 0x9c
 8001fee:	9329      	str	r3, [sp, #164]	@ 0xa4
 8001ff0:	ea82 0609 	eor.w	r6, r2, r9
 8001ff4:	ea21 0307 	bic.w	r3, r1, r7
 8001ff8:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 8001ffa:	9625      	str	r6, [sp, #148]	@ 0x94
 8001ffc:	4063      	eors	r3, r4
 8001ffe:	ea27 0604 	bic.w	r6, r7, r4
 8002002:	4056      	eors	r6, r2
 8002004:	932a      	str	r3, [sp, #168]	@ 0xa8
 8002006:	ea24 0302 	bic.w	r3, r4, r2
 800200a:	ea22 020e 	bic.w	r2, r2, lr
 800200e:	ea82 0801 	eor.w	r8, r2, r1
 8002012:	ea2e 0101 	bic.w	r1, lr, r1
 8002016:	404f      	eors	r7, r1
 8002018:	9930      	ldr	r1, [sp, #192]	@ 0xc0
 800201a:	982b      	ldr	r0, [sp, #172]	@ 0xac
 800201c:	9c31      	ldr	r4, [sp, #196]	@ 0xc4
 800201e:	f8cd 80b4 	str.w	r8, [sp, #180]	@ 0xb4
 8002022:	ea83 030e 	eor.w	r3, r3, lr
 8002026:	932f      	str	r3, [sp, #188]	@ 0xbc
 8002028:	ea21 030c 	bic.w	r3, r1, ip
 800202c:	ea20 0204 	bic.w	r2, r0, r4
 8002030:	ea2c 0a05 	bic.w	sl, ip, r5
 8002034:	ea83 0805 	eor.w	r8, r3, r5
 8002038:	ea25 0300 	bic.w	r3, r5, r0
 800203c:	4063      	eors	r3, r4
 800203e:	ea8a 0a00 	eor.w	sl, sl, r0
 8002042:	ea82 0001 	eor.w	r0, r2, r1
 8002046:	ea24 0201 	bic.w	r2, r4, r1
 800204a:	ea82 010c 	eor.w	r1, r2, ip
 800204e:	9330      	str	r3, [sp, #192]	@ 0xc0
 8002050:	9a01      	ldr	r2, [sp, #4]
 8002052:	4b3b      	ldr	r3, [pc, #236]	@ (8002140 <KeccakF1600_StatePermute+0x114c>)
 8002054:	972b      	str	r7, [sp, #172]	@ 0xac
 8002056:	4293      	cmp	r3, r2
 8002058:	902e      	str	r0, [sp, #184]	@ 0xb8
 800205a:	912c      	str	r1, [sp, #176]	@ 0xb0
 800205c:	f47f a842 	bne.w	80010e4 <KeccakF1600_StatePermute+0xf0>
 8002060:	983d      	ldr	r0, [sp, #244]	@ 0xf4
 8002062:	9b04      	ldr	r3, [sp, #16]
 8002064:	6003      	str	r3, [r0, #0]
 8002066:	9b05      	ldr	r3, [sp, #20]
 8002068:	6043      	str	r3, [r0, #4]
 800206a:	9b06      	ldr	r3, [sp, #24]
 800206c:	6083      	str	r3, [r0, #8]
 800206e:	9b03      	ldr	r3, [sp, #12]
 8002070:	60c3      	str	r3, [r0, #12]
 8002072:	9b07      	ldr	r3, [sp, #28]
 8002074:	6103      	str	r3, [r0, #16]
 8002076:	9b08      	ldr	r3, [sp, #32]
 8002078:	6143      	str	r3, [r0, #20]
 800207a:	9b09      	ldr	r3, [sp, #36]	@ 0x24
 800207c:	6183      	str	r3, [r0, #24]
 800207e:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
 8002080:	61c3      	str	r3, [r0, #28]
 8002082:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
 8002084:	6203      	str	r3, [r0, #32]
 8002086:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
 8002088:	6243      	str	r3, [r0, #36]	@ 0x24
 800208a:	9b0d      	ldr	r3, [sp, #52]	@ 0x34
 800208c:	6283      	str	r3, [r0, #40]	@ 0x28
 800208e:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
 8002090:	62c3      	str	r3, [r0, #44]	@ 0x2c
 8002092:	9b0f      	ldr	r3, [sp, #60]	@ 0x3c
 8002094:	6303      	str	r3, [r0, #48]	@ 0x30
 8002096:	9b10      	ldr	r3, [sp, #64]	@ 0x40
 8002098:	6343      	str	r3, [r0, #52]	@ 0x34
 800209a:	9b11      	ldr	r3, [sp, #68]	@ 0x44
 800209c:	6383      	str	r3, [r0, #56]	@ 0x38
 800209e:	9b12      	ldr	r3, [sp, #72]	@ 0x48
 80020a0:	63c3      	str	r3, [r0, #60]	@ 0x3c
 80020a2:	9b13      	ldr	r3, [sp, #76]	@ 0x4c
 80020a4:	6403      	str	r3, [r0, #64]	@ 0x40
 80020a6:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 80020a8:	6443      	str	r3, [r0, #68]	@ 0x44
 80020aa:	9b15      	ldr	r3, [sp, #84]	@ 0x54
 80020ac:	6483      	str	r3, [r0, #72]	@ 0x48
 80020ae:	9b16      	ldr	r3, [sp, #88]	@ 0x58
 80020b0:	e9c0 3b13 	strd	r3, fp, [r0, #76]	@ 0x4c
 80020b4:	9b17      	ldr	r3, [sp, #92]	@ 0x5c
 80020b6:	6543      	str	r3, [r0, #84]	@ 0x54
 80020b8:	9b18      	ldr	r3, [sp, #96]	@ 0x60
 80020ba:	6583      	str	r3, [r0, #88]	@ 0x58
 80020bc:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 80020be:	65c3      	str	r3, [r0, #92]	@ 0x5c
 80020c0:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 80020c2:	6603      	str	r3, [r0, #96]	@ 0x60
 80020c4:	9b1b      	ldr	r3, [sp, #108]	@ 0x6c
 80020c6:	6643      	str	r3, [r0, #100]	@ 0x64
 80020c8:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
 80020ca:	6683      	str	r3, [r0, #104]	@ 0x68
 80020cc:	9b1d      	ldr	r3, [sp, #116]	@ 0x74
 80020ce:	66c3      	str	r3, [r0, #108]	@ 0x6c
 80020d0:	9b1e      	ldr	r3, [sp, #120]	@ 0x78
 80020d2:	6703      	str	r3, [r0, #112]	@ 0x70
 80020d4:	9b1f      	ldr	r3, [sp, #124]	@ 0x7c
 80020d6:	6743      	str	r3, [r0, #116]	@ 0x74
 80020d8:	9b20      	ldr	r3, [sp, #128]	@ 0x80
 80020da:	6783      	str	r3, [r0, #120]	@ 0x78
 80020dc:	9b21      	ldr	r3, [sp, #132]	@ 0x84
 80020de:	67c3      	str	r3, [r0, #124]	@ 0x7c
 80020e0:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 80020e2:	f8c0 3080 	str.w	r3, [r0, #128]	@ 0x80
 80020e6:	9b23      	ldr	r3, [sp, #140]	@ 0x8c
 80020e8:	f8c0 3084 	str.w	r3, [r0, #132]	@ 0x84
 80020ec:	9b24      	ldr	r3, [sp, #144]	@ 0x90
 80020ee:	f8c0 3088 	str.w	r3, [r0, #136]	@ 0x88
 80020f2:	9b25      	ldr	r3, [sp, #148]	@ 0x94
 80020f4:	f8c0 308c 	str.w	r3, [r0, #140]	@ 0x8c
 80020f8:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 80020fa:	f8c0 3090 	str.w	r3, [r0, #144]	@ 0x90
 80020fe:	9b27      	ldr	r3, [sp, #156]	@ 0x9c
 8002100:	f8c0 3094 	str.w	r3, [r0, #148]	@ 0x94
 8002104:	9b28      	ldr	r3, [sp, #160]	@ 0xa0
 8002106:	f8c0 3098 	str.w	r3, [r0, #152]	@ 0x98
 800210a:	9b29      	ldr	r3, [sp, #164]	@ 0xa4
 800210c:	f8c0 a0a4 	str.w	sl, [r0, #164]	@ 0xa4
 8002110:	e9c0 3627 	strd	r3, r6, [r0, #156]	@ 0x9c
 8002114:	9b2a      	ldr	r3, [sp, #168]	@ 0xa8
 8002116:	f8c0 70b0 	str.w	r7, [r0, #176]	@ 0xb0
 800211a:	e9c0 382a 	strd	r3, r8, [r0, #168]	@ 0xa8
 800211e:	9b2d      	ldr	r3, [sp, #180]	@ 0xb4
 8002120:	f8c0 30b8 	str.w	r3, [r0, #184]	@ 0xb8
 8002124:	9b2e      	ldr	r3, [sp, #184]	@ 0xb8
 8002126:	f8c0 30bc 	str.w	r3, [r0, #188]	@ 0xbc
 800212a:	9b2f      	ldr	r3, [sp, #188]	@ 0xbc
 800212c:	f8c0 30c0 	str.w	r3, [r0, #192]	@ 0xc0
 8002130:	9b30      	ldr	r3, [sp, #192]	@ 0xc0
 8002132:	f8c0 10b4 	str.w	r1, [r0, #180]	@ 0xb4
 8002136:	f8c0 30c4 	str.w	r3, [r0, #196]	@ 0xc4
 800213a:	b03f      	add	sp, #252	@ 0xfc
 800213c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8002140:	08003640 	.word	0x08003640

08002144 <keccak_absorb>:
 8002144:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002148:	b0b7      	sub	sp, #220	@ 0xdc
 800214a:	460d      	mov	r5, r1
 800214c:	461e      	mov	r6, r3
 800214e:	4617      	mov	r7, r2
 8002150:	2100      	movs	r1, #0
 8002152:	22c8      	movs	r2, #200	@ 0xc8
 8002154:	f89d 9100 	ldrb.w	r9, [sp, #256]	@ 0x100
 8002158:	4683      	mov	fp, r0
 800215a:	f7fe f945 	bl	80003e8 <memset>
 800215e:	42ae      	cmp	r6, r5
 8002160:	ea4f 04d5 	mov.w	r4, r5, lsr #3
 8002164:	f1ab 0a08 	sub.w	sl, fp, #8
 8002168:	bf28      	it	cs
 800216a:	f8cd 900c 	strcs.w	r9, [sp, #12]
 800216e:	d339      	bcc.n	80021e4 <keccak_absorb+0xa0>
 8002170:	4650      	mov	r0, sl
 8002172:	46b9      	mov	r9, r7
 8002174:	f04f 0800 	mov.w	r8, #0
 8002178:	465a      	mov	r2, fp
 800217a:	e9cd 8901 	strd	r8, r9, [sp, #4]
 800217e:	2300      	movs	r3, #0
 8002180:	46cb      	mov	fp, r9
 8002182:	469e      	mov	lr, r3
 8002184:	469c      	mov	ip, r3
 8002186:	f81b 1b01 	ldrb.w	r1, [fp], #1
 800218a:	f1a3 0820 	sub.w	r8, r3, #32
 800218e:	f1c3 0920 	rsb	r9, r3, #32
 8002192:	fa01 f808 	lsl.w	r8, r1, r8
 8002196:	fa21 f909 	lsr.w	r9, r1, r9
 800219a:	4099      	lsls	r1, r3
 800219c:	3308      	adds	r3, #8
 800219e:	ea48 0809 	orr.w	r8, r8, r9
 80021a2:	2b40      	cmp	r3, #64	@ 0x40
 80021a4:	ea48 0c0c 	orr.w	ip, r8, ip
 80021a8:	ea41 0e0e 	orr.w	lr, r1, lr
 80021ac:	d1eb      	bne.n	8002186 <keccak_absorb+0x42>
 80021ae:	f850 3f08 	ldr.w	r3, [r0, #8]!
 80021b2:	e9dd 8901 	ldrd	r8, r9, [sp, #4]
 80021b6:	ea83 030e 	eor.w	r3, r3, lr
 80021ba:	6003      	str	r3, [r0, #0]
 80021bc:	6843      	ldr	r3, [r0, #4]
 80021be:	f108 0801 	add.w	r8, r8, #1
 80021c2:	ea83 030c 	eor.w	r3, r3, ip
 80021c6:	45a0      	cmp	r8, r4
 80021c8:	f109 0908 	add.w	r9, r9, #8
 80021cc:	6043      	str	r3, [r0, #4]
 80021ce:	d3d4      	bcc.n	800217a <keccak_absorb+0x36>
 80021d0:	4610      	mov	r0, r2
 80021d2:	1b76      	subs	r6, r6, r5
 80021d4:	4693      	mov	fp, r2
 80021d6:	f7fe ff0d 	bl	8000ff4 <KeccakF1600_StatePermute>
 80021da:	42b5      	cmp	r5, r6
 80021dc:	442f      	add	r7, r5
 80021de:	d9c7      	bls.n	8002170 <keccak_absorb+0x2c>
 80021e0:	f8dd 900c 	ldr.w	r9, [sp, #12]
 80021e4:	462a      	mov	r2, r5
 80021e6:	2100      	movs	r1, #0
 80021e8:	a804      	add	r0, sp, #16
 80021ea:	f7fe f8fd 	bl	80003e8 <memset>
 80021ee:	b126      	cbz	r6, 80021fa <keccak_absorb+0xb6>
 80021f0:	4639      	mov	r1, r7
 80021f2:	4632      	mov	r2, r6
 80021f4:	a804      	add	r0, sp, #16
 80021f6:	f7fe f80b 	bl	8000210 <memcpy>
 80021fa:	446e      	add	r6, sp
 80021fc:	eb0d 0305 	add.w	r3, sp, r5
 8002200:	f886 9010 	strb.w	r9, [r6, #16]
 8002204:	7bda      	ldrb	r2, [r3, #15]
 8002206:	f062 027f 	orn	r2, r2, #127	@ 0x7f
 800220a:	46d4      	mov	ip, sl
 800220c:	f10d 0e10 	add.w	lr, sp, #16
 8002210:	73da      	strb	r2, [r3, #15]
 8002212:	f04f 0800 	mov.w	r8, #0
 8002216:	2300      	movs	r3, #0
 8002218:	4677      	mov	r7, lr
 800221a:	461e      	mov	r6, r3
 800221c:	461d      	mov	r5, r3
 800221e:	f817 1b01 	ldrb.w	r1, [r7], #1
 8002222:	f1a3 0220 	sub.w	r2, r3, #32
 8002226:	f1c3 0020 	rsb	r0, r3, #32
 800222a:	fa01 f202 	lsl.w	r2, r1, r2
 800222e:	fa21 f000 	lsr.w	r0, r1, r0
 8002232:	4099      	lsls	r1, r3
 8002234:	3308      	adds	r3, #8
 8002236:	4302      	orrs	r2, r0
 8002238:	2b40      	cmp	r3, #64	@ 0x40
 800223a:	ea46 0601 	orr.w	r6, r6, r1
 800223e:	ea45 0502 	orr.w	r5, r5, r2
 8002242:	d1ec      	bne.n	800221e <keccak_absorb+0xda>
 8002244:	f85c 2f08 	ldr.w	r2, [ip, #8]!
 8002248:	f8dc 3004 	ldr.w	r3, [ip, #4]
 800224c:	f108 0801 	add.w	r8, r8, #1
 8002250:	4072      	eors	r2, r6
 8002252:	406b      	eors	r3, r5
 8002254:	45a0      	cmp	r8, r4
 8002256:	e9cc 2300 	strd	r2, r3, [ip]
 800225a:	f10e 0e08 	add.w	lr, lr, #8
 800225e:	d3da      	bcc.n	8002216 <keccak_absorb+0xd2>
 8002260:	b037      	add	sp, #220	@ 0xdc
 8002262:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8002266:	bf00      	nop

08002268 <keccak_inc_absorb>:
 8002268:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
 800226c:	f8d0 40c8 	ldr.w	r4, [r0, #200]	@ 0xc8
 8002270:	460e      	mov	r6, r1
 8002272:	f8d0 10cc 	ldr.w	r1, [r0, #204]	@ 0xcc
 8002276:	4690      	mov	r8, r2
 8002278:	191a      	adds	r2, r3, r4
 800227a:	461f      	mov	r7, r3
 800227c:	f141 0300 	adc.w	r3, r1, #0
 8002280:	42b2      	cmp	r2, r6
 8002282:	f173 0300 	sbcs.w	r3, r3, #0
 8002286:	4605      	mov	r5, r0
 8002288:	d345      	bcc.n	8002316 <keccak_inc_absorb+0xae>
 800228a:	42a6      	cmp	r6, r4
 800228c:	d10c      	bne.n	80022a8 <keccak_inc_absorb+0x40>
 800228e:	2200      	movs	r2, #0
 8002290:	2300      	movs	r3, #0
 8002292:	1bbf      	subs	r7, r7, r6
 8002294:	4427      	add	r7, r4
 8002296:	e9c5 2332 	strd	r2, r3, [r5, #200]	@ 0xc8
 800229a:	4628      	mov	r0, r5
 800229c:	f7fe feaa 	bl	8000ff4 <KeccakF1600_StatePermute>
 80022a0:	2400      	movs	r4, #0
 80022a2:	42b7      	cmp	r7, r6
 80022a4:	4621      	mov	r1, r4
 80022a6:	d336      	bcc.n	8002316 <keccak_inc_absorb+0xae>
 80022a8:	f04f 0c00 	mov.w	ip, #0
 80022ac:	f108 32ff 	add.w	r2, r8, #4294967295	@ 0xffffffff
 80022b0:	4663      	mov	r3, ip
 80022b2:	eb14 040c 	adds.w	r4, r4, ip
 80022b6:	eb43 0101 	adc.w	r1, r3, r1
 80022ba:	08e0      	lsrs	r0, r4, #3
 80022bc:	ea40 7041 	orr.w	r0, r0, r1, lsl #29
 80022c0:	f004 0407 	and.w	r4, r4, #7
 80022c4:	f812 ef01 	ldrb.w	lr, [r2, #1]!
 80022c8:	f855 1030 	ldr.w	r1, [r5, r0, lsl #3]
 80022cc:	00e4      	lsls	r4, r4, #3
 80022ce:	eb05 0ac0 	add.w	sl, r5, r0, lsl #3
 80022d2:	f1a4 0920 	sub.w	r9, r4, #32
 80022d6:	f1c4 0b20 	rsb	fp, r4, #32
 80022da:	fa0e f909 	lsl.w	r9, lr, r9
 80022de:	fa2e fb0b 	lsr.w	fp, lr, fp
 80022e2:	fa0e fe04 	lsl.w	lr, lr, r4
 80022e6:	ea81 010e 	eor.w	r1, r1, lr
 80022ea:	f8da e004 	ldr.w	lr, [sl, #4]
 80022ee:	f845 1030 	str.w	r1, [r5, r0, lsl #3]
 80022f2:	ea49 040b 	orr.w	r4, r9, fp
 80022f6:	ea8e 0404 	eor.w	r4, lr, r4
 80022fa:	f8ca 4004 	str.w	r4, [sl, #4]
 80022fe:	e9d5 4132 	ldrd	r4, r1, [r5, #200]	@ 0xc8
 8002302:	f11c 0c01 	adds.w	ip, ip, #1
 8002306:	eba6 0004 	sub.w	r0, r6, r4
 800230a:	f143 0300 	adc.w	r3, r3, #0
 800230e:	4560      	cmp	r0, ip
 8002310:	d8cf      	bhi.n	80022b2 <keccak_inc_absorb+0x4a>
 8002312:	4480      	add	r8, r0
 8002314:	e7bb      	b.n	800228e <keccak_inc_absorb+0x26>
 8002316:	b38f      	cbz	r7, 800237c <keccak_inc_absorb+0x114>
 8002318:	1e7e      	subs	r6, r7, #1
 800231a:	2300      	movs	r3, #0
 800231c:	4446      	add	r6, r8
 800231e:	4618      	mov	r0, r3
 8002320:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 8002324:	191c      	adds	r4, r3, r4
 8002326:	eb40 0101 	adc.w	r1, r0, r1
 800232a:	ea4f 0cd4 	mov.w	ip, r4, lsr #3
 800232e:	ea4c 7c41 	orr.w	ip, ip, r1, lsl #29
 8002332:	f004 0407 	and.w	r4, r4, #7
 8002336:	f818 ef01 	ldrb.w	lr, [r8, #1]!
 800233a:	f855 103c 	ldr.w	r1, [r5, ip, lsl #3]
 800233e:	00e4      	lsls	r4, r4, #3
 8002340:	eb05 09cc 	add.w	r9, r5, ip, lsl #3
 8002344:	f1a4 0220 	sub.w	r2, r4, #32
 8002348:	f1c4 0a20 	rsb	sl, r4, #32
 800234c:	fa0e f202 	lsl.w	r2, lr, r2
 8002350:	fa2e fa0a 	lsr.w	sl, lr, sl
 8002354:	fa0e fe04 	lsl.w	lr, lr, r4
 8002358:	f8d9 4004 	ldr.w	r4, [r9, #4]
 800235c:	ea81 010e 	eor.w	r1, r1, lr
 8002360:	ea42 020a 	orr.w	r2, r2, sl
 8002364:	f845 103c 	str.w	r1, [r5, ip, lsl #3]
 8002368:	4062      	eors	r2, r4
 800236a:	3301      	adds	r3, #1
 800236c:	f8c9 2004 	str.w	r2, [r9, #4]
 8002370:	f140 0000 	adc.w	r0, r0, #0
 8002374:	45b0      	cmp	r8, r6
 8002376:	e9d5 4132 	ldrd	r4, r1, [r5, #200]	@ 0xc8
 800237a:	d1d3      	bne.n	8002324 <keccak_inc_absorb+0xbc>
 800237c:	193f      	adds	r7, r7, r4
 800237e:	f141 0100 	adc.w	r1, r1, #0
 8002382:	e9c5 7132 	strd	r7, r1, [r5, #200]	@ 0xc8
 8002386:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 800238a:	bf00      	nop

0800238c <keccak_inc_squeeze>:
 800238c:	2900      	cmp	r1, #0
 800238e:	d07e      	beq.n	800248e <keccak_inc_squeeze+0x102>
 8002390:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002394:	4691      	mov	r9, r2
 8002396:	1e45      	subs	r5, r0, #1
 8002398:	2200      	movs	r2, #0
 800239a:	461e      	mov	r6, r3
 800239c:	186f      	adds	r7, r5, r1
 800239e:	4614      	mov	r4, r2
 80023a0:	e027      	b.n	80023f2 <keccak_inc_squeeze+0x66>
 80023a2:	1af3      	subs	r3, r6, r3
 80023a4:	eb6e 0e4e 	sbc.w	lr, lr, lr, lsl #1
 80023a8:	189b      	adds	r3, r3, r2
 80023aa:	eb44 0e0e 	adc.w	lr, r4, lr
 80023ae:	ea4f 0ad3 	mov.w	sl, r3, lsr #3
 80023b2:	ea4a 7a4e 	orr.w	sl, sl, lr, lsl #29
 80023b6:	eb09 0eca 	add.w	lr, r9, sl, lsl #3
 80023ba:	f003 0307 	and.w	r3, r3, #7
 80023be:	f8de 8004 	ldr.w	r8, [lr, #4]
 80023c2:	f859 b03a 	ldr.w	fp, [r9, sl, lsl #3]
 80023c6:	00db      	lsls	r3, r3, #3
 80023c8:	f1c3 0a20 	rsb	sl, r3, #32
 80023cc:	f1a3 0e20 	sub.w	lr, r3, #32
 80023d0:	fa08 fa0a 	lsl.w	sl, r8, sl
 80023d4:	fa2b f303 	lsr.w	r3, fp, r3
 80023d8:	ea43 030a 	orr.w	r3, r3, sl
 80023dc:	fa28 fe0e 	lsr.w	lr, r8, lr
 80023e0:	ea43 030e 	orr.w	r3, r3, lr
 80023e4:	f805 3f01 	strb.w	r3, [r5, #1]!
 80023e8:	3201      	adds	r2, #1
 80023ea:	f144 0400 	adc.w	r4, r4, #0
 80023ee:	42bd      	cmp	r5, r7
 80023f0:	d048      	beq.n	8002484 <keccak_inc_squeeze+0xf8>
 80023f2:	e9d9 3e32 	ldrd	r3, lr, [r9, #200]	@ 0xc8
 80023f6:	429a      	cmp	r2, r3
 80023f8:	eb74 080e 	sbcs.w	r8, r4, lr
 80023fc:	4694      	mov	ip, r2
 80023fe:	d3d0      	bcc.n	80023a2 <keccak_inc_squeeze+0x16>
 8002400:	1a9b      	subs	r3, r3, r2
 8002402:	eb6e 0404 	sbc.w	r4, lr, r4
 8002406:	ebb1 070c 	subs.w	r7, r1, ip
 800240a:	e9c9 3432 	strd	r3, r4, [r9, #200]	@ 0xc8
 800240e:	eb00 080c 	add.w	r8, r0, ip
 8002412:	d030      	beq.n	8002476 <keccak_inc_squeeze+0xea>
 8002414:	2400      	movs	r4, #0
 8002416:	2500      	movs	r5, #0
 8002418:	4648      	mov	r0, r9
 800241a:	f7fe fdeb 	bl	8000ff4 <KeccakF1600_StatePermute>
 800241e:	f04f 0e00 	mov.w	lr, #0
 8002422:	f108 30ff 	add.w	r0, r8, #4294967295	@ 0xffffffff
 8002426:	e001      	b.n	800242c <keccak_inc_squeeze+0xa0>
 8002428:	4576      	cmp	r6, lr
 800242a:	d026      	beq.n	800247a <keccak_inc_squeeze+0xee>
 800242c:	f02e 0307 	bic.w	r3, lr, #7
 8002430:	ea4f 01de 	mov.w	r1, lr, lsr #3
 8002434:	444b      	add	r3, r9
 8002436:	f00e 0c07 	and.w	ip, lr, #7
 800243a:	685a      	ldr	r2, [r3, #4]
 800243c:	f859 1031 	ldr.w	r1, [r9, r1, lsl #3]
 8002440:	ea4f 0ccc 	mov.w	ip, ip, lsl #3
 8002444:	f1cc 0a20 	rsb	sl, ip, #32
 8002448:	f1ac 0320 	sub.w	r3, ip, #32
 800244c:	fa02 fa0a 	lsl.w	sl, r2, sl
 8002450:	fa21 fc0c 	lsr.w	ip, r1, ip
 8002454:	ea4c 0c0a 	orr.w	ip, ip, sl
 8002458:	fa22 f303 	lsr.w	r3, r2, r3
 800245c:	f10e 0e01 	add.w	lr, lr, #1
 8002460:	ea4c 0c03 	orr.w	ip, ip, r3
 8002464:	45be      	cmp	lr, r7
 8002466:	f800 cf01 	strb.w	ip, [r0, #1]!
 800246a:	d1dd      	bne.n	8002428 <keccak_inc_squeeze+0x9c>
 800246c:	eba6 060e 	sub.w	r6, r6, lr
 8002470:	2300      	movs	r3, #0
 8002472:	e9c9 6332 	strd	r6, r3, [r9, #200]	@ 0xc8
 8002476:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 800247a:	e9c9 4532 	strd	r4, r5, [r9, #200]	@ 0xc8
 800247e:	44b0      	add	r8, r6
 8002480:	1bbf      	subs	r7, r7, r6
 8002482:	e7c9      	b.n	8002418 <keccak_inc_squeeze+0x8c>
 8002484:	e9d9 3e32 	ldrd	r3, lr, [r9, #200]	@ 0xc8
 8002488:	f10c 0c01 	add.w	ip, ip, #1
 800248c:	e7b8      	b.n	8002400 <keccak_inc_squeeze+0x74>
 800248e:	4770      	bx	lr

08002490 <shake128_inc_init>:
 8002490:	b538      	push	{r3, r4, r5, lr}
 8002492:	4605      	mov	r5, r0
 8002494:	20d0      	movs	r0, #208	@ 0xd0
 8002496:	f7fd ff97 	bl	80003c8 <malloc>
 800249a:	6028      	str	r0, [r5, #0]
 800249c:	b148      	cbz	r0, 80024b2 <shake128_inc_init+0x22>
 800249e:	22c8      	movs	r2, #200	@ 0xc8
 80024a0:	2100      	movs	r1, #0
 80024a2:	4604      	mov	r4, r0
 80024a4:	f7fd ffa0 	bl	80003e8 <memset>
 80024a8:	2200      	movs	r2, #0
 80024aa:	2300      	movs	r3, #0
 80024ac:	e9c4 2332 	strd	r2, r3, [r4, #200]	@ 0xc8
 80024b0:	bd38      	pop	{r3, r4, r5, pc}
 80024b2:	206f      	movs	r0, #111	@ 0x6f
 80024b4:	f7fd ffe6 	bl	8000484 <exit>

080024b8 <shake128_inc_absorb>:
 80024b8:	4613      	mov	r3, r2
 80024ba:	6800      	ldr	r0, [r0, #0]
 80024bc:	460a      	mov	r2, r1
 80024be:	21a8      	movs	r1, #168	@ 0xa8
 80024c0:	f7ff bed2 	b.w	8002268 <keccak_inc_absorb>

080024c4 <shake128_inc_finalize>:
 80024c4:	6803      	ldr	r3, [r0, #0]
 80024c6:	e9d3 2132 	ldrd	r2, r1, [r3, #200]	@ 0xc8
 80024ca:	08d0      	lsrs	r0, r2, #3
 80024cc:	f002 0207 	and.w	r2, r2, #7
 80024d0:	ea40 7041 	orr.w	r0, r0, r1, lsl #29
 80024d4:	00d2      	lsls	r2, r2, #3
 80024d6:	b510      	push	{r4, lr}
 80024d8:	f04f 0c1f 	mov.w	ip, #31
 80024dc:	f1a2 0120 	sub.w	r1, r2, #32
 80024e0:	f1c2 0420 	rsb	r4, r2, #32
 80024e4:	eb03 0ec0 	add.w	lr, r3, r0, lsl #3
 80024e8:	fa2c f404 	lsr.w	r4, ip, r4
 80024ec:	fa0c f101 	lsl.w	r1, ip, r1
 80024f0:	fa0c fc02 	lsl.w	ip, ip, r2
 80024f4:	f853 2030 	ldr.w	r2, [r3, r0, lsl #3]
 80024f8:	4321      	orrs	r1, r4
 80024fa:	ea82 040c 	eor.w	r4, r2, ip
 80024fe:	f8de 2004 	ldr.w	r2, [lr, #4]
 8002502:	f843 4030 	str.w	r4, [r3, r0, lsl #3]
 8002506:	404a      	eors	r2, r1
 8002508:	f8ce 2004 	str.w	r2, [lr, #4]
 800250c:	f8d3 20a4 	ldr.w	r2, [r3, #164]	@ 0xa4
 8002510:	2000      	movs	r0, #0
 8002512:	2100      	movs	r1, #0
 8002514:	f102 4200 	add.w	r2, r2, #2147483648	@ 0x80000000
 8002518:	e9c3 0132 	strd	r0, r1, [r3, #200]	@ 0xc8
 800251c:	f8c3 20a4 	str.w	r2, [r3, #164]	@ 0xa4
 8002520:	bd10      	pop	{r4, pc}
 8002522:	bf00      	nop

08002524 <shake128_inc_squeeze>:
 8002524:	6812      	ldr	r2, [r2, #0]
 8002526:	23a8      	movs	r3, #168	@ 0xa8
 8002528:	f7ff bf30 	b.w	800238c <keccak_inc_squeeze>

0800252c <shake128_inc_ctx_release>:
 800252c:	6800      	ldr	r0, [r0, #0]
 800252e:	f7fd bf53 	b.w	80003d8 <free>
 8002532:	bf00      	nop

08002534 <sha3_256>:
 8002534:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
 8002538:	b0d6      	sub	sp, #344	@ 0x158
 800253a:	4613      	mov	r3, r2
 800253c:	2206      	movs	r2, #6
 800253e:	9200      	str	r2, [sp, #0]
 8002540:	4606      	mov	r6, r0
 8002542:	460a      	mov	r2, r1
 8002544:	a824      	add	r0, sp, #144	@ 0x90
 8002546:	2188      	movs	r1, #136	@ 0x88
 8002548:	f7ff fdfc 	bl	8002144 <keccak_absorb>
 800254c:	a824      	add	r0, sp, #144	@ 0x90
 800254e:	f7fe fd51 	bl	8000ff4 <KeccakF1600_StatePermute>
 8002552:	af02      	add	r7, sp, #8
 8002554:	f10d 0e88 	add.w	lr, sp, #136	@ 0x88
 8002558:	f50d 7888 	add.w	r8, sp, #272	@ 0x110
 800255c:	f85e 5f08 	ldr.w	r5, [lr, #8]!
 8002560:	f8de 4004 	ldr.w	r4, [lr, #4]
 8002564:	46bc      	mov	ip, r7
 8002566:	2300      	movs	r3, #0
 8002568:	f1c3 0020 	rsb	r0, r3, #32
 800256c:	f1a3 0120 	sub.w	r1, r3, #32
 8002570:	fa25 f203 	lsr.w	r2, r5, r3
 8002574:	fa04 f000 	lsl.w	r0, r4, r0
 8002578:	4302      	orrs	r2, r0
 800257a:	fa24 f101 	lsr.w	r1, r4, r1
 800257e:	3308      	adds	r3, #8
 8002580:	430a      	orrs	r2, r1
 8002582:	2b40      	cmp	r3, #64	@ 0x40
 8002584:	f80c 2b01 	strb.w	r2, [ip], #1
 8002588:	d1ee      	bne.n	8002568 <sha3_256+0x34>
 800258a:	45f0      	cmp	r8, lr
 800258c:	f107 0708 	add.w	r7, r7, #8
 8002590:	d1e4      	bne.n	800255c <sha3_256+0x28>
 8002592:	ac02      	add	r4, sp, #8
 8002594:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
 8002596:	6030      	str	r0, [r6, #0]
 8002598:	6071      	str	r1, [r6, #4]
 800259a:	60b2      	str	r2, [r6, #8]
 800259c:	60f3      	str	r3, [r6, #12]
 800259e:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
 80025a0:	6130      	str	r0, [r6, #16]
 80025a2:	6171      	str	r1, [r6, #20]
 80025a4:	61b2      	str	r2, [r6, #24]
 80025a6:	61f3      	str	r3, [r6, #28]
 80025a8:	b056      	add	sp, #344	@ 0x158
 80025aa:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 80025ae:	bf00      	nop

080025b0 <platform_init>:
 80025b0:	b5f0      	push	{r4, r5, r6, r7, lr}
 80025b2:	b093      	sub	sp, #76	@ 0x4c
 80025b4:	2603      	movs	r6, #3
 80025b6:	f44f 27a0 	mov.w	r7, #327680	@ 0x50000
 80025ba:	2302      	movs	r3, #2
 80025bc:	e9cd 6706 	strd	r6, r7, [sp, #24]
 80025c0:	2501      	movs	r5, #1
 80025c2:	f44f 0180 	mov.w	r1, #4194304	@ 0x400000
 80025c6:	930c      	str	r3, [sp, #48]	@ 0x30
 80025c8:	220c      	movs	r2, #12
 80025ca:	23c4      	movs	r3, #196	@ 0xc4
 80025cc:	2604      	movs	r6, #4
 80025ce:	2707      	movs	r7, #7
 80025d0:	a806      	add	r0, sp, #24
 80025d2:	e9cd 120d 	strd	r1, r2, [sp, #52]	@ 0x34
 80025d6:	e9cd 6710 	strd	r6, r7, [sp, #64]	@ 0x40
 80025da:	9509      	str	r5, [sp, #36]	@ 0x24
 80025dc:	930f      	str	r3, [sp, #60]	@ 0x3c
 80025de:	f000 f8bf 	bl	8002760 <HAL_RCC_OscConfig>
 80025e2:	b100      	cbz	r0, 80025e6 <platform_init+0x36>
 80025e4:	e7fe      	b.n	80025e4 <platform_init+0x34>
 80025e6:	4604      	mov	r4, r0
 80025e8:	230f      	movs	r3, #15
 80025ea:	4601      	mov	r1, r0
 80025ec:	a801      	add	r0, sp, #4
 80025ee:	e9cd 3501 	strd	r3, r5, [sp, #4]
 80025f2:	e9cd 4403 	strd	r4, r4, [sp, #12]
 80025f6:	9405      	str	r4, [sp, #20]
 80025f8:	f000 fabe 	bl	8002b78 <HAL_RCC_ClockConfig>
 80025fc:	4b09      	ldr	r3, [pc, #36]	@ (8002624 <platform_init+0x74>)
 80025fe:	9400      	str	r4, [sp, #0]
 8002600:	6b5a      	ldr	r2, [r3, #52]	@ 0x34
 8002602:	4809      	ldr	r0, [pc, #36]	@ (8002628 <platform_init+0x78>)
 8002604:	4909      	ldr	r1, [pc, #36]	@ (800262c <platform_init+0x7c>)
 8002606:	f042 0240 	orr.w	r2, r2, #64	@ 0x40
 800260a:	635a      	str	r2, [r3, #52]	@ 0x34
 800260c:	6b5b      	ldr	r3, [r3, #52]	@ 0x34
 800260e:	6001      	str	r1, [r0, #0]
 8002610:	f003 0340 	and.w	r3, r3, #64	@ 0x40
 8002614:	9300      	str	r3, [sp, #0]
 8002616:	9b00      	ldr	r3, [sp, #0]
 8002618:	7144      	strb	r4, [r0, #5]
 800261a:	f000 fdd5 	bl	80031c8 <HAL_RNG_Init>
 800261e:	b013      	add	sp, #76	@ 0x4c
 8002620:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002622:	bf00      	nop
 8002624:	40023800 	.word	0x40023800
 8002628:	20000978 	.word	0x20000978
 800262c:	50060800 	.word	0x50060800

08002630 <init_uart>:
 8002630:	b530      	push	{r4, r5, lr}
 8002632:	2302      	movs	r3, #2
 8002634:	b089      	sub	sp, #36	@ 0x24
 8002636:	2207      	movs	r2, #7
 8002638:	f44f 60c0 	mov.w	r0, #1536	@ 0x600
 800263c:	e9cd 0303 	strd	r0, r3, [sp, #12]
 8002640:	e9cd 3206 	strd	r3, r2, [sp, #24]
 8002644:	4d16      	ldr	r5, [pc, #88]	@ (80026a0 <init_uart+0x70>)
 8002646:	4817      	ldr	r0, [pc, #92]	@ (80026a4 <init_uart+0x74>)
 8002648:	2400      	movs	r4, #0
 800264a:	2101      	movs	r1, #1
 800264c:	9401      	str	r4, [sp, #4]
 800264e:	9105      	str	r1, [sp, #20]
 8002650:	6b2b      	ldr	r3, [r5, #48]	@ 0x30
 8002652:	430b      	orrs	r3, r1
 8002654:	632b      	str	r3, [r5, #48]	@ 0x30
 8002656:	6b2b      	ldr	r3, [r5, #48]	@ 0x30
 8002658:	f003 0301 	and.w	r3, r3, #1
 800265c:	a903      	add	r1, sp, #12
 800265e:	9301      	str	r3, [sp, #4]
 8002660:	9b01      	ldr	r3, [sp, #4]
 8002662:	f000 fb47 	bl	8002cf4 <HAL_GPIO_Init>
 8002666:	9402      	str	r4, [sp, #8]
 8002668:	6c6a      	ldr	r2, [r5, #68]	@ 0x44
 800266a:	4b0f      	ldr	r3, [pc, #60]	@ (80026a8 <init_uart+0x78>)
 800266c:	490f      	ldr	r1, [pc, #60]	@ (80026ac <init_uart+0x7c>)
 800266e:	f44f 4016 	mov.w	r0, #38400	@ 0x9600
 8002672:	f042 0210 	orr.w	r2, r2, #16
 8002676:	6158      	str	r0, [r3, #20]
 8002678:	646a      	str	r2, [r5, #68]	@ 0x44
 800267a:	6c6a      	ldr	r2, [r5, #68]	@ 0x44
 800267c:	6119      	str	r1, [r3, #16]
 800267e:	f002 0210 	and.w	r2, r2, #16
 8002682:	210c      	movs	r1, #12
 8002684:	9202      	str	r2, [sp, #8]
 8002686:	f103 0010 	add.w	r0, r3, #16
 800268a:	e9c3 4406 	strd	r4, r4, [r3, #24]
 800268e:	e9c3 4108 	strd	r4, r1, [r3, #32]
 8002692:	9a02      	ldr	r2, [sp, #8]
 8002694:	629c      	str	r4, [r3, #40]	@ 0x28
 8002696:	f000 fc4f 	bl	8002f38 <HAL_UART_Init>
 800269a:	b009      	add	sp, #36	@ 0x24
 800269c:	bd30      	pop	{r4, r5, pc}
 800269e:	bf00      	nop
 80026a0:	40023800 	.word	0x40023800
 80026a4:	40020000 	.word	0x40020000
 80026a8:	20000978 	.word	0x20000978
 80026ac:	40011000 	.word	0x40011000

080026b0 <trigger_setup>:
 80026b0:	b530      	push	{r4, r5, lr}
 80026b2:	b089      	sub	sp, #36	@ 0x24
 80026b4:	4b0d      	ldr	r3, [pc, #52]	@ (80026ec <trigger_setup+0x3c>)
 80026b6:	480e      	ldr	r0, [pc, #56]	@ (80026f0 <trigger_setup+0x40>)
 80026b8:	2200      	movs	r2, #0
 80026ba:	9201      	str	r2, [sp, #4]
 80026bc:	6b1a      	ldr	r2, [r3, #48]	@ 0x30
 80026be:	f042 0201 	orr.w	r2, r2, #1
 80026c2:	631a      	str	r2, [r3, #48]	@ 0x30
 80026c4:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
 80026c6:	f003 0301 	and.w	r3, r3, #1
 80026ca:	9301      	str	r3, [sp, #4]
 80026cc:	2200      	movs	r2, #0
 80026ce:	f44f 5480 	mov.w	r4, #4096	@ 0x1000
 80026d2:	2501      	movs	r5, #1
 80026d4:	2302      	movs	r3, #2
 80026d6:	a902      	add	r1, sp, #8
 80026d8:	e9cd 2304 	strd	r2, r3, [sp, #16]
 80026dc:	e9cd 4502 	strd	r4, r5, [sp, #8]
 80026e0:	9b01      	ldr	r3, [sp, #4]
 80026e2:	f000 fb07 	bl	8002cf4 <HAL_GPIO_Init>
 80026e6:	b009      	add	sp, #36	@ 0x24
 80026e8:	bd30      	pop	{r4, r5, pc}
 80026ea:	bf00      	nop
 80026ec:	40023800 	.word	0x40023800
 80026f0:	40020000 	.word	0x40020000

080026f4 <trigger_high>:
 80026f4:	4802      	ldr	r0, [pc, #8]	@ (8002700 <trigger_high+0xc>)
 80026f6:	2201      	movs	r2, #1
 80026f8:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
 80026fc:	f000 bc18 	b.w	8002f30 <HAL_GPIO_WritePin>
 8002700:	40020000 	.word	0x40020000

08002704 <trigger_low>:
 8002704:	4802      	ldr	r0, [pc, #8]	@ (8002710 <trigger_low+0xc>)
 8002706:	2200      	movs	r2, #0
 8002708:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
 800270c:	f000 bc10 	b.w	8002f30 <HAL_GPIO_WritePin>
 8002710:	40020000 	.word	0x40020000

08002714 <getch>:
 8002714:	b500      	push	{lr}
 8002716:	b083      	sub	sp, #12
 8002718:	4807      	ldr	r0, [pc, #28]	@ (8002738 <getch+0x24>)
 800271a:	f241 3388 	movw	r3, #5000	@ 0x1388
 800271e:	2201      	movs	r2, #1
 8002720:	f10d 0107 	add.w	r1, sp, #7
 8002724:	f000 fce0 	bl	80030e8 <HAL_UART_Receive>
 8002728:	2800      	cmp	r0, #0
 800272a:	d1f5      	bne.n	8002718 <getch+0x4>
 800272c:	f89d 0007 	ldrb.w	r0, [sp, #7]
 8002730:	b003      	add	sp, #12
 8002732:	f85d fb04 	ldr.w	pc, [sp], #4
 8002736:	bf00      	nop
 8002738:	20000988 	.word	0x20000988

0800273c <putch>:
 800273c:	b500      	push	{lr}
 800273e:	b083      	sub	sp, #12
 8002740:	4684      	mov	ip, r0
 8002742:	f241 3388 	movw	r3, #5000	@ 0x1388
 8002746:	2201      	movs	r2, #1
 8002748:	f10d 0107 	add.w	r1, sp, #7
 800274c:	4803      	ldr	r0, [pc, #12]	@ (800275c <putch+0x20>)
 800274e:	f88d c007 	strb.w	ip, [sp, #7]
 8002752:	f000 fc6d 	bl	8003030 <HAL_UART_Transmit>
 8002756:	b003      	add	sp, #12
 8002758:	f85d fb04 	ldr.w	pc, [sp], #4
 800275c:	20000988 	.word	0x20000988

08002760 <HAL_RCC_OscConfig>:
 8002760:	b4f0      	push	{r4, r5, r6, r7}
 8002762:	6805      	ldr	r5, [r0, #0]
 8002764:	07ea      	lsls	r2, r5, #31
 8002766:	b082      	sub	sp, #8
 8002768:	d53a      	bpl.n	80027e0 <HAL_RCC_OscConfig+0x80>
 800276a:	4aa4      	ldr	r2, [pc, #656]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 800276c:	6893      	ldr	r3, [r2, #8]
 800276e:	f003 030c 	and.w	r3, r3, #12
 8002772:	2b04      	cmp	r3, #4
 8002774:	f000 80fd 	beq.w	8002972 <HAL_RCC_OscConfig+0x212>
 8002778:	6893      	ldr	r3, [r2, #8]
 800277a:	f003 030c 	and.w	r3, r3, #12
 800277e:	2b08      	cmp	r3, #8
 8002780:	f000 80f3 	beq.w	800296a <HAL_RCC_OscConfig+0x20a>
 8002784:	4a9e      	ldr	r2, [pc, #632]	@ (8002a00 <HAL_RCC_OscConfig+0x2a0>)
 8002786:	6841      	ldr	r1, [r0, #4]
 8002788:	6816      	ldr	r6, [r2, #0]
 800278a:	f5b1 3f80 	cmp.w	r1, #65536	@ 0x10000
 800278e:	f106 0301 	add.w	r3, r6, #1
 8002792:	f000 813f 	beq.w	8002a14 <HAL_RCC_OscConfig+0x2b4>
 8002796:	f5b1 2fa0 	cmp.w	r1, #327680	@ 0x50000
 800279a:	f000 8180 	beq.w	8002a9e <HAL_RCC_OscConfig+0x33e>
 800279e:	f8df c25c 	ldr.w	ip, [pc, #604]	@ 80029fc <HAL_RCC_OscConfig+0x29c>
 80027a2:	f8dc 4000 	ldr.w	r4, [ip]
 80027a6:	f424 3480 	bic.w	r4, r4, #65536	@ 0x10000
 80027aa:	f8cc 4000 	str.w	r4, [ip]
 80027ae:	f8dc 4000 	ldr.w	r4, [ip]
 80027b2:	f424 2480 	bic.w	r4, r4, #262144	@ 0x40000
 80027b6:	f8cc 4000 	str.w	r4, [ip]
 80027ba:	2900      	cmp	r1, #0
 80027bc:	f040 812f 	bne.w	8002a1e <HAL_RCC_OscConfig+0x2be>
 80027c0:	4f90      	ldr	r7, [pc, #576]	@ (8002a04 <HAL_RCC_OscConfig+0x2a4>)
 80027c2:	6013      	str	r3, [r2, #0]
 80027c4:	e004      	b.n	80027d0 <HAL_RCC_OscConfig+0x70>
 80027c6:	42bb      	cmp	r3, r7
 80027c8:	6011      	str	r1, [r2, #0]
 80027ca:	f200 80dd 	bhi.w	8002988 <HAL_RCC_OscConfig+0x228>
 80027ce:	460b      	mov	r3, r1
 80027d0:	f8dc 4000 	ldr.w	r4, [ip]
 80027d4:	03a4      	lsls	r4, r4, #14
 80027d6:	f103 0101 	add.w	r1, r3, #1
 80027da:	eba3 0306 	sub.w	r3, r3, r6
 80027de:	d4f2      	bmi.n	80027c6 <HAL_RCC_OscConfig+0x66>
 80027e0:	07ab      	lsls	r3, r5, #30
 80027e2:	d531      	bpl.n	8002848 <HAL_RCC_OscConfig+0xe8>
 80027e4:	4b85      	ldr	r3, [pc, #532]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 80027e6:	689a      	ldr	r2, [r3, #8]
 80027e8:	f012 0f0c 	tst.w	r2, #12
 80027ec:	f000 80d4 	beq.w	8002998 <HAL_RCC_OscConfig+0x238>
 80027f0:	689a      	ldr	r2, [r3, #8]
 80027f2:	f002 020c 	and.w	r2, r2, #12
 80027f6:	2a08      	cmp	r2, #8
 80027f8:	f000 80ca 	beq.w	8002990 <HAL_RCC_OscConfig+0x230>
 80027fc:	68c3      	ldr	r3, [r0, #12]
 80027fe:	2b00      	cmp	r3, #0
 8002800:	f000 811e 	beq.w	8002a40 <HAL_RCC_OscConfig+0x2e0>
 8002804:	4b80      	ldr	r3, [pc, #512]	@ (8002a08 <HAL_RCC_OscConfig+0x2a8>)
 8002806:	4a7e      	ldr	r2, [pc, #504]	@ (8002a00 <HAL_RCC_OscConfig+0x2a0>)
 8002808:	4d7c      	ldr	r5, [pc, #496]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 800280a:	2101      	movs	r1, #1
 800280c:	6019      	str	r1, [r3, #0]
 800280e:	6816      	ldr	r6, [r2, #0]
 8002810:	1873      	adds	r3, r6, r1
 8002812:	6013      	str	r3, [r2, #0]
 8002814:	e004      	b.n	8002820 <HAL_RCC_OscConfig+0xc0>
 8002816:	2b02      	cmp	r3, #2
 8002818:	6011      	str	r1, [r2, #0]
 800281a:	f200 80b5 	bhi.w	8002988 <HAL_RCC_OscConfig+0x228>
 800281e:	460b      	mov	r3, r1
 8002820:	682c      	ldr	r4, [r5, #0]
 8002822:	07a7      	lsls	r7, r4, #30
 8002824:	f103 0101 	add.w	r1, r3, #1
 8002828:	eba3 0306 	sub.w	r3, r3, r6
 800282c:	d5f3      	bpl.n	8002816 <HAL_RCC_OscConfig+0xb6>
 800282e:	6829      	ldr	r1, [r5, #0]
 8002830:	22f8      	movs	r2, #248	@ 0xf8
 8002832:	fa92 f2a2 	rbit	r2, r2
 8002836:	6903      	ldr	r3, [r0, #16]
 8002838:	fab2 f282 	clz	r2, r2
 800283c:	4093      	lsls	r3, r2
 800283e:	f021 02f8 	bic.w	r2, r1, #248	@ 0xf8
 8002842:	4313      	orrs	r3, r2
 8002844:	602b      	str	r3, [r5, #0]
 8002846:	6805      	ldr	r5, [r0, #0]
 8002848:	072b      	lsls	r3, r5, #28
 800284a:	d51d      	bpl.n	8002888 <HAL_RCC_OscConfig+0x128>
 800284c:	6944      	ldr	r4, [r0, #20]
 800284e:	4b6e      	ldr	r3, [pc, #440]	@ (8002a08 <HAL_RCC_OscConfig+0x2a8>)
 8002850:	4a6b      	ldr	r2, [pc, #428]	@ (8002a00 <HAL_RCC_OscConfig+0x2a0>)
 8002852:	2c00      	cmp	r4, #0
 8002854:	f000 80ab 	beq.w	80029ae <HAL_RCC_OscConfig+0x24e>
 8002858:	2101      	movs	r1, #1
 800285a:	f8c3 1e80 	str.w	r1, [r3, #3712]	@ 0xe80
 800285e:	6814      	ldr	r4, [r2, #0]
 8002860:	4e66      	ldr	r6, [pc, #408]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 8002862:	1863      	adds	r3, r4, r1
 8002864:	6013      	str	r3, [r2, #0]
 8002866:	3404      	adds	r4, #4
 8002868:	2500      	movs	r5, #0
 800286a:	e005      	b.n	8002878 <HAL_RCC_OscConfig+0x118>
 800286c:	3301      	adds	r3, #1
 800286e:	42a3      	cmp	r3, r4
 8002870:	f04f 0501 	mov.w	r5, #1
 8002874:	f000 8087 	beq.w	8002986 <HAL_RCC_OscConfig+0x226>
 8002878:	6f71      	ldr	r1, [r6, #116]	@ 0x74
 800287a:	078f      	lsls	r7, r1, #30
 800287c:	d5f6      	bpl.n	800286c <HAL_RCC_OscConfig+0x10c>
 800287e:	2d00      	cmp	r5, #0
 8002880:	f000 816d 	beq.w	8002b5e <HAL_RCC_OscConfig+0x3fe>
 8002884:	6805      	ldr	r5, [r0, #0]
 8002886:	6013      	str	r3, [r2, #0]
 8002888:	076b      	lsls	r3, r5, #29
 800288a:	d54a      	bpl.n	8002922 <HAL_RCC_OscConfig+0x1c2>
 800288c:	4b5b      	ldr	r3, [pc, #364]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 800288e:	4d5f      	ldr	r5, [pc, #380]	@ (8002a0c <HAL_RCC_OscConfig+0x2ac>)
 8002890:	2400      	movs	r4, #0
 8002892:	9401      	str	r4, [sp, #4]
 8002894:	6c1a      	ldr	r2, [r3, #64]	@ 0x40
 8002896:	f042 5280 	orr.w	r2, r2, #268435456	@ 0x10000000
 800289a:	641a      	str	r2, [r3, #64]	@ 0x40
 800289c:	6c1b      	ldr	r3, [r3, #64]	@ 0x40
 800289e:	4a58      	ldr	r2, [pc, #352]	@ (8002a00 <HAL_RCC_OscConfig+0x2a0>)
 80028a0:	f003 5380 	and.w	r3, r3, #268435456	@ 0x10000000
 80028a4:	9301      	str	r3, [sp, #4]
 80028a6:	9b01      	ldr	r3, [sp, #4]
 80028a8:	682b      	ldr	r3, [r5, #0]
 80028aa:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
 80028ae:	602b      	str	r3, [r5, #0]
 80028b0:	6813      	ldr	r3, [r2, #0]
 80028b2:	1c5e      	adds	r6, r3, #1
 80028b4:	f103 0c04 	add.w	ip, r3, #4
 80028b8:	6016      	str	r6, [r2, #0]
 80028ba:	4633      	mov	r3, r6
 80028bc:	e004      	b.n	80028c8 <HAL_RCC_OscConfig+0x168>
 80028be:	3301      	adds	r3, #1
 80028c0:	4563      	cmp	r3, ip
 80028c2:	f04f 0401 	mov.w	r4, #1
 80028c6:	d05e      	beq.n	8002986 <HAL_RCC_OscConfig+0x226>
 80028c8:	6829      	ldr	r1, [r5, #0]
 80028ca:	05cf      	lsls	r7, r1, #23
 80028cc:	d5f7      	bpl.n	80028be <HAL_RCC_OscConfig+0x15e>
 80028ce:	2c00      	cmp	r4, #0
 80028d0:	f000 80ef 	beq.w	8002ab2 <HAL_RCC_OscConfig+0x352>
 80028d4:	6013      	str	r3, [r2, #0]
 80028d6:	6884      	ldr	r4, [r0, #8]
 80028d8:	2c01      	cmp	r4, #1
 80028da:	f103 0601 	add.w	r6, r3, #1
 80028de:	f000 80c4 	beq.w	8002a6a <HAL_RCC_OscConfig+0x30a>
 80028e2:	2c05      	cmp	r4, #5
 80028e4:	f000 8131 	beq.w	8002b4a <HAL_RCC_OscConfig+0x3ea>
 80028e8:	4d44      	ldr	r5, [pc, #272]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 80028ea:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 80028ec:	f021 0101 	bic.w	r1, r1, #1
 80028f0:	6729      	str	r1, [r5, #112]	@ 0x70
 80028f2:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 80028f4:	f021 0104 	bic.w	r1, r1, #4
 80028f8:	6729      	str	r1, [r5, #112]	@ 0x70
 80028fa:	2c00      	cmp	r4, #0
 80028fc:	f040 80ba 	bne.w	8002a74 <HAL_RCC_OscConfig+0x314>
 8002900:	f503 539c 	add.w	r3, r3, #4992	@ 0x1380
 8002904:	6016      	str	r6, [r2, #0]
 8002906:	330a      	adds	r3, #10
 8002908:	e005      	b.n	8002916 <HAL_RCC_OscConfig+0x1b6>
 800290a:	3601      	adds	r6, #1
 800290c:	429e      	cmp	r6, r3
 800290e:	f04f 0401 	mov.w	r4, #1
 8002912:	f000 8118 	beq.w	8002b46 <HAL_RCC_OscConfig+0x3e6>
 8002916:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 8002918:	078f      	lsls	r7, r1, #30
 800291a:	d4f6      	bmi.n	800290a <HAL_RCC_OscConfig+0x1aa>
 800291c:	2c00      	cmp	r4, #0
 800291e:	f040 80bc 	bne.w	8002a9a <HAL_RCC_OscConfig+0x33a>
 8002922:	6983      	ldr	r3, [r0, #24]
 8002924:	b1eb      	cbz	r3, 8002962 <HAL_RCC_OscConfig+0x202>
 8002926:	4e35      	ldr	r6, [pc, #212]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 8002928:	68b2      	ldr	r2, [r6, #8]
 800292a:	f002 020c 	and.w	r2, r2, #12
 800292e:	2a08      	cmp	r2, #8
 8002930:	d039      	beq.n	80029a6 <HAL_RCC_OscConfig+0x246>
 8002932:	2b02      	cmp	r3, #2
 8002934:	4b34      	ldr	r3, [pc, #208]	@ (8002a08 <HAL_RCC_OscConfig+0x2a8>)
 8002936:	4a32      	ldr	r2, [pc, #200]	@ (8002a00 <HAL_RCC_OscConfig+0x2a0>)
 8002938:	f04f 0100 	mov.w	r1, #0
 800293c:	6619      	str	r1, [r3, #96]	@ 0x60
 800293e:	f000 80ba 	beq.w	8002ab6 <HAL_RCC_OscConfig+0x356>
 8002942:	6814      	ldr	r4, [r2, #0]
 8002944:	4d32      	ldr	r5, [pc, #200]	@ (8002a10 <HAL_RCC_OscConfig+0x2b0>)
 8002946:	1c63      	adds	r3, r4, #1
 8002948:	6013      	str	r3, [r2, #0]
 800294a:	e003      	b.n	8002954 <HAL_RCC_OscConfig+0x1f4>
 800294c:	42ab      	cmp	r3, r5
 800294e:	6011      	str	r1, [r2, #0]
 8002950:	d81a      	bhi.n	8002988 <HAL_RCC_OscConfig+0x228>
 8002952:	460b      	mov	r3, r1
 8002954:	6830      	ldr	r0, [r6, #0]
 8002956:	0180      	lsls	r0, r0, #6
 8002958:	f103 0101 	add.w	r1, r3, #1
 800295c:	eba3 0304 	sub.w	r3, r3, r4
 8002960:	d4f4      	bmi.n	800294c <HAL_RCC_OscConfig+0x1ec>
 8002962:	2000      	movs	r0, #0
 8002964:	b002      	add	sp, #8
 8002966:	bcf0      	pop	{r4, r5, r6, r7}
 8002968:	4770      	bx	lr
 800296a:	6853      	ldr	r3, [r2, #4]
 800296c:	025f      	lsls	r7, r3, #9
 800296e:	f57f af09 	bpl.w	8002784 <HAL_RCC_OscConfig+0x24>
 8002972:	4b22      	ldr	r3, [pc, #136]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 8002974:	681b      	ldr	r3, [r3, #0]
 8002976:	039e      	lsls	r6, r3, #14
 8002978:	f57f af32 	bpl.w	80027e0 <HAL_RCC_OscConfig+0x80>
 800297c:	6843      	ldr	r3, [r0, #4]
 800297e:	2b00      	cmp	r3, #0
 8002980:	f47f af2e 	bne.w	80027e0 <HAL_RCC_OscConfig+0x80>
 8002984:	e00f      	b.n	80029a6 <HAL_RCC_OscConfig+0x246>
 8002986:	6013      	str	r3, [r2, #0]
 8002988:	2003      	movs	r0, #3
 800298a:	b002      	add	sp, #8
 800298c:	bcf0      	pop	{r4, r5, r6, r7}
 800298e:	4770      	bx	lr
 8002990:	685b      	ldr	r3, [r3, #4]
 8002992:	025a      	lsls	r2, r3, #9
 8002994:	f53f af32 	bmi.w	80027fc <HAL_RCC_OscConfig+0x9c>
 8002998:	4b18      	ldr	r3, [pc, #96]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 800299a:	681b      	ldr	r3, [r3, #0]
 800299c:	079b      	lsls	r3, r3, #30
 800299e:	d51c      	bpl.n	80029da <HAL_RCC_OscConfig+0x27a>
 80029a0:	68c3      	ldr	r3, [r0, #12]
 80029a2:	2b01      	cmp	r3, #1
 80029a4:	d019      	beq.n	80029da <HAL_RCC_OscConfig+0x27a>
 80029a6:	2001      	movs	r0, #1
 80029a8:	b002      	add	sp, #8
 80029aa:	bcf0      	pop	{r4, r5, r6, r7}
 80029ac:	4770      	bx	lr
 80029ae:	f8c3 4e80 	str.w	r4, [r3, #3712]	@ 0xe80
 80029b2:	6815      	ldr	r5, [r2, #0]
 80029b4:	4e11      	ldr	r6, [pc, #68]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 80029b6:	1c6b      	adds	r3, r5, #1
 80029b8:	6013      	str	r3, [r2, #0]
 80029ba:	3504      	adds	r5, #4
 80029bc:	e004      	b.n	80029c8 <HAL_RCC_OscConfig+0x268>
 80029be:	3301      	adds	r3, #1
 80029c0:	42ab      	cmp	r3, r5
 80029c2:	f04f 0401 	mov.w	r4, #1
 80029c6:	d0de      	beq.n	8002986 <HAL_RCC_OscConfig+0x226>
 80029c8:	6f71      	ldr	r1, [r6, #116]	@ 0x74
 80029ca:	0789      	lsls	r1, r1, #30
 80029cc:	d4f7      	bmi.n	80029be <HAL_RCC_OscConfig+0x25e>
 80029ce:	6805      	ldr	r5, [r0, #0]
 80029d0:	2c00      	cmp	r4, #0
 80029d2:	f43f af59 	beq.w	8002888 <HAL_RCC_OscConfig+0x128>
 80029d6:	6013      	str	r3, [r2, #0]
 80029d8:	e756      	b.n	8002888 <HAL_RCC_OscConfig+0x128>
 80029da:	4c08      	ldr	r4, [pc, #32]	@ (80029fc <HAL_RCC_OscConfig+0x29c>)
 80029dc:	22f8      	movs	r2, #248	@ 0xf8
 80029de:	6821      	ldr	r1, [r4, #0]
 80029e0:	fa92 f2a2 	rbit	r2, r2
 80029e4:	6903      	ldr	r3, [r0, #16]
 80029e6:	fab2 f282 	clz	r2, r2
 80029ea:	f021 01f8 	bic.w	r1, r1, #248	@ 0xf8
 80029ee:	4093      	lsls	r3, r2
 80029f0:	430b      	orrs	r3, r1
 80029f2:	6023      	str	r3, [r4, #0]
 80029f4:	072b      	lsls	r3, r5, #28
 80029f6:	f57f af47 	bpl.w	8002888 <HAL_RCC_OscConfig+0x128>
 80029fa:	e727      	b.n	800284c <HAL_RCC_OscConfig+0xec>
 80029fc:	40023800 	.word	0x40023800
 8002a00:	20000a18 	.word	0x20000a18
 8002a04:	05f5e100 	.word	0x05f5e100
 8002a08:	42470000 	.word	0x42470000
 8002a0c:	40007000 	.word	0x40007000
 8002a10:	001e8480 	.word	0x001e8480
 8002a14:	4c53      	ldr	r4, [pc, #332]	@ (8002b64 <HAL_RCC_OscConfig+0x404>)
 8002a16:	6821      	ldr	r1, [r4, #0]
 8002a18:	f441 3180 	orr.w	r1, r1, #65536	@ 0x10000
 8002a1c:	6021      	str	r1, [r4, #0]
 8002a1e:	4f51      	ldr	r7, [pc, #324]	@ (8002b64 <HAL_RCC_OscConfig+0x404>)
 8002a20:	f8df c144 	ldr.w	ip, [pc, #324]	@ 8002b68 <HAL_RCC_OscConfig+0x408>
 8002a24:	6013      	str	r3, [r2, #0]
 8002a26:	e003      	b.n	8002a30 <HAL_RCC_OscConfig+0x2d0>
 8002a28:	4563      	cmp	r3, ip
 8002a2a:	6011      	str	r1, [r2, #0]
 8002a2c:	d8ac      	bhi.n	8002988 <HAL_RCC_OscConfig+0x228>
 8002a2e:	460b      	mov	r3, r1
 8002a30:	683c      	ldr	r4, [r7, #0]
 8002a32:	03a4      	lsls	r4, r4, #14
 8002a34:	f103 0101 	add.w	r1, r3, #1
 8002a38:	eba3 0306 	sub.w	r3, r3, r6
 8002a3c:	d5f4      	bpl.n	8002a28 <HAL_RCC_OscConfig+0x2c8>
 8002a3e:	e6cf      	b.n	80027e0 <HAL_RCC_OscConfig+0x80>
 8002a40:	494a      	ldr	r1, [pc, #296]	@ (8002b6c <HAL_RCC_OscConfig+0x40c>)
 8002a42:	4a4b      	ldr	r2, [pc, #300]	@ (8002b70 <HAL_RCC_OscConfig+0x410>)
 8002a44:	600b      	str	r3, [r1, #0]
 8002a46:	6815      	ldr	r5, [r2, #0]
 8002a48:	4e46      	ldr	r6, [pc, #280]	@ (8002b64 <HAL_RCC_OscConfig+0x404>)
 8002a4a:	1c6b      	adds	r3, r5, #1
 8002a4c:	6013      	str	r3, [r2, #0]
 8002a4e:	e003      	b.n	8002a58 <HAL_RCC_OscConfig+0x2f8>
 8002a50:	2b02      	cmp	r3, #2
 8002a52:	6011      	str	r1, [r2, #0]
 8002a54:	d898      	bhi.n	8002988 <HAL_RCC_OscConfig+0x228>
 8002a56:	460b      	mov	r3, r1
 8002a58:	6834      	ldr	r4, [r6, #0]
 8002a5a:	07a4      	lsls	r4, r4, #30
 8002a5c:	f103 0101 	add.w	r1, r3, #1
 8002a60:	eba3 0305 	sub.w	r3, r3, r5
 8002a64:	d4f4      	bmi.n	8002a50 <HAL_RCC_OscConfig+0x2f0>
 8002a66:	6805      	ldr	r5, [r0, #0]
 8002a68:	e6ee      	b.n	8002848 <HAL_RCC_OscConfig+0xe8>
 8002a6a:	4c3e      	ldr	r4, [pc, #248]	@ (8002b64 <HAL_RCC_OscConfig+0x404>)
 8002a6c:	6f21      	ldr	r1, [r4, #112]	@ 0x70
 8002a6e:	f041 0101 	orr.w	r1, r1, #1
 8002a72:	6721      	str	r1, [r4, #112]	@ 0x70
 8002a74:	f503 539c 	add.w	r3, r3, #4992	@ 0x1380
 8002a78:	4c3a      	ldr	r4, [pc, #232]	@ (8002b64 <HAL_RCC_OscConfig+0x404>)
 8002a7a:	6016      	str	r6, [r2, #0]
 8002a7c:	330a      	adds	r3, #10
 8002a7e:	2500      	movs	r5, #0
 8002a80:	e005      	b.n	8002a8e <HAL_RCC_OscConfig+0x32e>
 8002a82:	3601      	adds	r6, #1
 8002a84:	42b3      	cmp	r3, r6
 8002a86:	f04f 0501 	mov.w	r5, #1
 8002a8a:	f43f af7c 	beq.w	8002986 <HAL_RCC_OscConfig+0x226>
 8002a8e:	6f21      	ldr	r1, [r4, #112]	@ 0x70
 8002a90:	0789      	lsls	r1, r1, #30
 8002a92:	d5f6      	bpl.n	8002a82 <HAL_RCC_OscConfig+0x322>
 8002a94:	2d00      	cmp	r5, #0
 8002a96:	f43f af44 	beq.w	8002922 <HAL_RCC_OscConfig+0x1c2>
 8002a9a:	6016      	str	r6, [r2, #0]
 8002a9c:	e741      	b.n	8002922 <HAL_RCC_OscConfig+0x1c2>
 8002a9e:	4931      	ldr	r1, [pc, #196]	@ (8002b64 <HAL_RCC_OscConfig+0x404>)
 8002aa0:	680c      	ldr	r4, [r1, #0]
 8002aa2:	f444 2480 	orr.w	r4, r4, #262144	@ 0x40000
 8002aa6:	600c      	str	r4, [r1, #0]
 8002aa8:	680c      	ldr	r4, [r1, #0]
 8002aaa:	f444 3480 	orr.w	r4, r4, #65536	@ 0x10000
 8002aae:	600c      	str	r4, [r1, #0]
 8002ab0:	e7b5      	b.n	8002a1e <HAL_RCC_OscConfig+0x2be>
 8002ab2:	4633      	mov	r3, r6
 8002ab4:	e70f      	b.n	80028d6 <HAL_RCC_OscConfig+0x176>
 8002ab6:	6815      	ldr	r5, [r2, #0]
 8002ab8:	4f2e      	ldr	r7, [pc, #184]	@ (8002b74 <HAL_RCC_OscConfig+0x414>)
 8002aba:	1c6b      	adds	r3, r5, #1
 8002abc:	6013      	str	r3, [r2, #0]
 8002abe:	e004      	b.n	8002aca <HAL_RCC_OscConfig+0x36a>
 8002ac0:	42bb      	cmp	r3, r7
 8002ac2:	6011      	str	r1, [r2, #0]
 8002ac4:	f63f af60 	bhi.w	8002988 <HAL_RCC_OscConfig+0x228>
 8002ac8:	460b      	mov	r3, r1
 8002aca:	6834      	ldr	r4, [r6, #0]
 8002acc:	01a4      	lsls	r4, r4, #6
 8002ace:	f103 0101 	add.w	r1, r3, #1
 8002ad2:	eba3 0305 	sub.w	r3, r3, r5
 8002ad6:	d4f3      	bmi.n	8002ac0 <HAL_RCC_OscConfig+0x360>
 8002ad8:	f647 75c0 	movw	r5, #32704	@ 0x7fc0
 8002adc:	fa95 f5a5 	rbit	r5, r5
 8002ae0:	f44f 3740 	mov.w	r7, #196608	@ 0x30000
 8002ae4:	fab5 f585 	clz	r5, r5
 8002ae8:	fa97 f7a7 	rbit	r7, r7
 8002aec:	f04f 6470 	mov.w	r4, #251658240	@ 0xf000000
 8002af0:	fab7 f787 	clz	r7, r7
 8002af4:	fa94 f4a4 	rbit	r4, r4
 8002af8:	6a83      	ldr	r3, [r0, #40]	@ 0x28
 8002afa:	0859      	lsrs	r1, r3, #1
 8002afc:	3901      	subs	r1, #1
 8002afe:	40b9      	lsls	r1, r7
 8002b00:	e9d0 3707 	ldrd	r3, r7, [r0, #28]
 8002b04:	433b      	orrs	r3, r7
 8002b06:	6a47      	ldr	r7, [r0, #36]	@ 0x24
 8002b08:	40af      	lsls	r7, r5
 8002b0a:	433b      	orrs	r3, r7
 8002b0c:	430b      	orrs	r3, r1
 8002b0e:	6ac1      	ldr	r1, [r0, #44]	@ 0x2c
 8002b10:	4816      	ldr	r0, [pc, #88]	@ (8002b6c <HAL_RCC_OscConfig+0x40c>)
 8002b12:	4d14      	ldr	r5, [pc, #80]	@ (8002b64 <HAL_RCC_OscConfig+0x404>)
 8002b14:	fab4 f484 	clz	r4, r4
 8002b18:	40a1      	lsls	r1, r4
 8002b1a:	430b      	orrs	r3, r1
 8002b1c:	6073      	str	r3, [r6, #4]
 8002b1e:	2301      	movs	r3, #1
 8002b20:	6603      	str	r3, [r0, #96]	@ 0x60
 8002b22:	6814      	ldr	r4, [r2, #0]
 8002b24:	4e13      	ldr	r6, [pc, #76]	@ (8002b74 <HAL_RCC_OscConfig+0x414>)
 8002b26:	18e3      	adds	r3, r4, r3
 8002b28:	6013      	str	r3, [r2, #0]
 8002b2a:	e004      	b.n	8002b36 <HAL_RCC_OscConfig+0x3d6>
 8002b2c:	42b3      	cmp	r3, r6
 8002b2e:	6011      	str	r1, [r2, #0]
 8002b30:	f63f af2a 	bhi.w	8002988 <HAL_RCC_OscConfig+0x228>
 8002b34:	460b      	mov	r3, r1
 8002b36:	6828      	ldr	r0, [r5, #0]
 8002b38:	0187      	lsls	r7, r0, #6
 8002b3a:	f103 0101 	add.w	r1, r3, #1
 8002b3e:	eba3 0304 	sub.w	r3, r3, r4
 8002b42:	d5f3      	bpl.n	8002b2c <HAL_RCC_OscConfig+0x3cc>
 8002b44:	e70d      	b.n	8002962 <HAL_RCC_OscConfig+0x202>
 8002b46:	6016      	str	r6, [r2, #0]
 8002b48:	e71e      	b.n	8002988 <HAL_RCC_OscConfig+0x228>
 8002b4a:	4906      	ldr	r1, [pc, #24]	@ (8002b64 <HAL_RCC_OscConfig+0x404>)
 8002b4c:	6f0c      	ldr	r4, [r1, #112]	@ 0x70
 8002b4e:	f044 0404 	orr.w	r4, r4, #4
 8002b52:	670c      	str	r4, [r1, #112]	@ 0x70
 8002b54:	6f0c      	ldr	r4, [r1, #112]	@ 0x70
 8002b56:	f044 0401 	orr.w	r4, r4, #1
 8002b5a:	670c      	str	r4, [r1, #112]	@ 0x70
 8002b5c:	e78a      	b.n	8002a74 <HAL_RCC_OscConfig+0x314>
 8002b5e:	6805      	ldr	r5, [r0, #0]
 8002b60:	e692      	b.n	8002888 <HAL_RCC_OscConfig+0x128>
 8002b62:	bf00      	nop
 8002b64:	40023800 	.word	0x40023800
 8002b68:	05f5e100 	.word	0x05f5e100
 8002b6c:	42470000 	.word	0x42470000
 8002b70:	20000a18 	.word	0x20000a18
 8002b74:	001e8480 	.word	0x001e8480

08002b78 <HAL_RCC_ClockConfig>:
 8002b78:	4a5b      	ldr	r2, [pc, #364]	@ (8002ce8 <HAL_RCC_ClockConfig+0x170>)
 8002b7a:	6813      	ldr	r3, [r2, #0]
 8002b7c:	f003 030f 	and.w	r3, r3, #15
 8002b80:	428b      	cmp	r3, r1
 8002b82:	d208      	bcs.n	8002b96 <HAL_RCC_ClockConfig+0x1e>
 8002b84:	b2cb      	uxtb	r3, r1
 8002b86:	7013      	strb	r3, [r2, #0]
 8002b88:	6813      	ldr	r3, [r2, #0]
 8002b8a:	f003 030f 	and.w	r3, r3, #15
 8002b8e:	428b      	cmp	r3, r1
 8002b90:	d001      	beq.n	8002b96 <HAL_RCC_ClockConfig+0x1e>
 8002b92:	2001      	movs	r0, #1
 8002b94:	4770      	bx	lr
 8002b96:	b5f0      	push	{r4, r5, r6, r7, lr}
 8002b98:	6804      	ldr	r4, [r0, #0]
 8002b9a:	07a5      	lsls	r5, r4, #30
 8002b9c:	d506      	bpl.n	8002bac <HAL_RCC_ClockConfig+0x34>
 8002b9e:	4a53      	ldr	r2, [pc, #332]	@ (8002cec <HAL_RCC_ClockConfig+0x174>)
 8002ba0:	6885      	ldr	r5, [r0, #8]
 8002ba2:	6893      	ldr	r3, [r2, #8]
 8002ba4:	f023 03f0 	bic.w	r3, r3, #240	@ 0xf0
 8002ba8:	432b      	orrs	r3, r5
 8002baa:	6093      	str	r3, [r2, #8]
 8002bac:	07e2      	lsls	r2, r4, #31
 8002bae:	d526      	bpl.n	8002bfe <HAL_RCC_ClockConfig+0x86>
 8002bb0:	6842      	ldr	r2, [r0, #4]
 8002bb2:	2a01      	cmp	r2, #1
 8002bb4:	d075      	beq.n	8002ca2 <HAL_RCC_ClockConfig+0x12a>
 8002bb6:	1e93      	subs	r3, r2, #2
 8002bb8:	4e4c      	ldr	r6, [pc, #304]	@ (8002cec <HAL_RCC_ClockConfig+0x174>)
 8002bba:	2b01      	cmp	r3, #1
 8002bbc:	6833      	ldr	r3, [r6, #0]
 8002bbe:	d943      	bls.n	8002c48 <HAL_RCC_ClockConfig+0xd0>
 8002bc0:	079d      	lsls	r5, r3, #30
 8002bc2:	d529      	bpl.n	8002c18 <HAL_RCC_ClockConfig+0xa0>
 8002bc4:	68b3      	ldr	r3, [r6, #8]
 8002bc6:	4d4a      	ldr	r5, [pc, #296]	@ (8002cf0 <HAL_RCC_ClockConfig+0x178>)
 8002bc8:	f023 0303 	bic.w	r3, r3, #3
 8002bcc:	4313      	orrs	r3, r2
 8002bce:	60b3      	str	r3, [r6, #8]
 8002bd0:	682f      	ldr	r7, [r5, #0]
 8002bd2:	1c7b      	adds	r3, r7, #1
 8002bd4:	f04f 0c00 	mov.w	ip, #0
 8002bd8:	f241 3e88 	movw	lr, #5000	@ 0x1388
 8002bdc:	602b      	str	r3, [r5, #0]
 8002bde:	e006      	b.n	8002bee <HAL_RCC_ClockConfig+0x76>
 8002be0:	3301      	adds	r3, #1
 8002be2:	1bda      	subs	r2, r3, r7
 8002be4:	3a01      	subs	r2, #1
 8002be6:	4572      	cmp	r2, lr
 8002be8:	f04f 0c01 	mov.w	ip, #1
 8002bec:	d878      	bhi.n	8002ce0 <HAL_RCC_ClockConfig+0x168>
 8002bee:	68b2      	ldr	r2, [r6, #8]
 8002bf0:	f012 0f0c 	tst.w	r2, #12
 8002bf4:	d1f4      	bne.n	8002be0 <HAL_RCC_ClockConfig+0x68>
 8002bf6:	f1bc 0f00 	cmp.w	ip, #0
 8002bfa:	d000      	beq.n	8002bfe <HAL_RCC_ClockConfig+0x86>
 8002bfc:	602b      	str	r3, [r5, #0]
 8002bfe:	4a3a      	ldr	r2, [pc, #232]	@ (8002ce8 <HAL_RCC_ClockConfig+0x170>)
 8002c00:	6813      	ldr	r3, [r2, #0]
 8002c02:	f003 030f 	and.w	r3, r3, #15
 8002c06:	428b      	cmp	r3, r1
 8002c08:	d909      	bls.n	8002c1e <HAL_RCC_ClockConfig+0xa6>
 8002c0a:	b2cb      	uxtb	r3, r1
 8002c0c:	7013      	strb	r3, [r2, #0]
 8002c0e:	6813      	ldr	r3, [r2, #0]
 8002c10:	f003 030f 	and.w	r3, r3, #15
 8002c14:	428b      	cmp	r3, r1
 8002c16:	d001      	beq.n	8002c1c <HAL_RCC_ClockConfig+0xa4>
 8002c18:	2001      	movs	r0, #1
 8002c1a:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002c1c:	6804      	ldr	r4, [r0, #0]
 8002c1e:	0762      	lsls	r2, r4, #29
 8002c20:	d506      	bpl.n	8002c30 <HAL_RCC_ClockConfig+0xb8>
 8002c22:	4a32      	ldr	r2, [pc, #200]	@ (8002cec <HAL_RCC_ClockConfig+0x174>)
 8002c24:	68c1      	ldr	r1, [r0, #12]
 8002c26:	6893      	ldr	r3, [r2, #8]
 8002c28:	f423 53e0 	bic.w	r3, r3, #7168	@ 0x1c00
 8002c2c:	430b      	orrs	r3, r1
 8002c2e:	6093      	str	r3, [r2, #8]
 8002c30:	0723      	lsls	r3, r4, #28
 8002c32:	d507      	bpl.n	8002c44 <HAL_RCC_ClockConfig+0xcc>
 8002c34:	4a2d      	ldr	r2, [pc, #180]	@ (8002cec <HAL_RCC_ClockConfig+0x174>)
 8002c36:	6901      	ldr	r1, [r0, #16]
 8002c38:	6893      	ldr	r3, [r2, #8]
 8002c3a:	f423 4360 	bic.w	r3, r3, #57344	@ 0xe000
 8002c3e:	ea43 03c1 	orr.w	r3, r3, r1, lsl #3
 8002c42:	6093      	str	r3, [r2, #8]
 8002c44:	2000      	movs	r0, #0
 8002c46:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002c48:	019f      	lsls	r7, r3, #6
 8002c4a:	d5e5      	bpl.n	8002c18 <HAL_RCC_ClockConfig+0xa0>
 8002c4c:	68b3      	ldr	r3, [r6, #8]
 8002c4e:	4d28      	ldr	r5, [pc, #160]	@ (8002cf0 <HAL_RCC_ClockConfig+0x178>)
 8002c50:	f023 0303 	bic.w	r3, r3, #3
 8002c54:	4313      	orrs	r3, r2
 8002c56:	60b3      	str	r3, [r6, #8]
 8002c58:	682f      	ldr	r7, [r5, #0]
 8002c5a:	2a02      	cmp	r2, #2
 8002c5c:	f107 0301 	add.w	r3, r7, #1
 8002c60:	602b      	str	r3, [r5, #0]
 8002c62:	f04f 0c00 	mov.w	ip, #0
 8002c66:	f241 3e88 	movw	lr, #5000	@ 0x1388
 8002c6a:	d007      	beq.n	8002c7c <HAL_RCC_ClockConfig+0x104>
 8002c6c:	e013      	b.n	8002c96 <HAL_RCC_ClockConfig+0x11e>
 8002c6e:	3301      	adds	r3, #1
 8002c70:	1bda      	subs	r2, r3, r7
 8002c72:	3a01      	subs	r2, #1
 8002c74:	4572      	cmp	r2, lr
 8002c76:	f04f 0c01 	mov.w	ip, #1
 8002c7a:	d831      	bhi.n	8002ce0 <HAL_RCC_ClockConfig+0x168>
 8002c7c:	68b2      	ldr	r2, [r6, #8]
 8002c7e:	f002 020c 	and.w	r2, r2, #12
 8002c82:	2a08      	cmp	r2, #8
 8002c84:	d1f3      	bne.n	8002c6e <HAL_RCC_ClockConfig+0xf6>
 8002c86:	e7b6      	b.n	8002bf6 <HAL_RCC_ClockConfig+0x7e>
 8002c88:	3301      	adds	r3, #1
 8002c8a:	1bda      	subs	r2, r3, r7
 8002c8c:	3a01      	subs	r2, #1
 8002c8e:	4572      	cmp	r2, lr
 8002c90:	f04f 0c01 	mov.w	ip, #1
 8002c94:	d824      	bhi.n	8002ce0 <HAL_RCC_ClockConfig+0x168>
 8002c96:	68b2      	ldr	r2, [r6, #8]
 8002c98:	f002 020c 	and.w	r2, r2, #12
 8002c9c:	2a0c      	cmp	r2, #12
 8002c9e:	d1f3      	bne.n	8002c88 <HAL_RCC_ClockConfig+0x110>
 8002ca0:	e7a9      	b.n	8002bf6 <HAL_RCC_ClockConfig+0x7e>
 8002ca2:	4f12      	ldr	r7, [pc, #72]	@ (8002cec <HAL_RCC_ClockConfig+0x174>)
 8002ca4:	683b      	ldr	r3, [r7, #0]
 8002ca6:	039b      	lsls	r3, r3, #14
 8002ca8:	d5b6      	bpl.n	8002c18 <HAL_RCC_ClockConfig+0xa0>
 8002caa:	68bb      	ldr	r3, [r7, #8]
 8002cac:	4d10      	ldr	r5, [pc, #64]	@ (8002cf0 <HAL_RCC_ClockConfig+0x178>)
 8002cae:	f023 0303 	bic.w	r3, r3, #3
 8002cb2:	f043 0301 	orr.w	r3, r3, #1
 8002cb6:	60bb      	str	r3, [r7, #8]
 8002cb8:	682e      	ldr	r6, [r5, #0]
 8002cba:	1c73      	adds	r3, r6, #1
 8002cbc:	f506 569c 	add.w	r6, r6, #4992	@ 0x1380
 8002cc0:	f04f 0c00 	mov.w	ip, #0
 8002cc4:	602b      	str	r3, [r5, #0]
 8002cc6:	360a      	adds	r6, #10
 8002cc8:	e004      	b.n	8002cd4 <HAL_RCC_ClockConfig+0x15c>
 8002cca:	3301      	adds	r3, #1
 8002ccc:	429e      	cmp	r6, r3
 8002cce:	f04f 0c01 	mov.w	ip, #1
 8002cd2:	d005      	beq.n	8002ce0 <HAL_RCC_ClockConfig+0x168>
 8002cd4:	68ba      	ldr	r2, [r7, #8]
 8002cd6:	f002 020c 	and.w	r2, r2, #12
 8002cda:	2a04      	cmp	r2, #4
 8002cdc:	d1f5      	bne.n	8002cca <HAL_RCC_ClockConfig+0x152>
 8002cde:	e78a      	b.n	8002bf6 <HAL_RCC_ClockConfig+0x7e>
 8002ce0:	602b      	str	r3, [r5, #0]
 8002ce2:	2003      	movs	r0, #3
 8002ce4:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002ce6:	bf00      	nop
 8002ce8:	40023c00 	.word	0x40023c00
 8002cec:	40023800 	.word	0x40023800
 8002cf0:	20000a18 	.word	0x20000a18

08002cf4 <HAL_GPIO_Init>:
 8002cf4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002cf8:	2300      	movs	r3, #0
 8002cfa:	680c      	ldr	r4, [r1, #0]
 8002cfc:	f8df b20c 	ldr.w	fp, [pc, #524]	@ 8002f0c <HAL_GPIO_Init+0x218>
 8002d00:	b085      	sub	sp, #20
 8002d02:	468a      	mov	sl, r1
 8002d04:	e003      	b.n	8002d0e <HAL_GPIO_Init+0x1a>
 8002d06:	3301      	adds	r3, #1
 8002d08:	2b10      	cmp	r3, #16
 8002d0a:	f000 80a2 	beq.w	8002e52 <HAL_GPIO_Init+0x15e>
 8002d0e:	2201      	movs	r2, #1
 8002d10:	fa02 f103 	lsl.w	r1, r2, r3
 8002d14:	ea31 0204 	bics.w	r2, r1, r4
 8002d18:	ea01 0704 	and.w	r7, r1, r4
 8002d1c:	d1f3      	bne.n	8002d06 <HAL_GPIO_Init+0x12>
 8002d1e:	f8da 2004 	ldr.w	r2, [sl, #4]
 8002d22:	f8da 5008 	ldr.w	r5, [sl, #8]
 8002d26:	005e      	lsls	r6, r3, #1
 8002d28:	fa05 fc06 	lsl.w	ip, r5, r6
 8002d2c:	f022 0810 	bic.w	r8, r2, #16
 8002d30:	2503      	movs	r5, #3
 8002d32:	40b5      	lsls	r5, r6
 8002d34:	f002 0e03 	and.w	lr, r2, #3
 8002d38:	f1b8 0f02 	cmp.w	r8, #2
 8002d3c:	ea6f 0505 	mvn.w	r5, r5
 8002d40:	fa0e fe06 	lsl.w	lr, lr, r6
 8002d44:	f000 8088 	beq.w	8002e58 <HAL_GPIO_Init+0x164>
 8002d48:	f8d0 9000 	ldr.w	r9, [r0]
 8002d4c:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 8002d50:	ea09 0905 	and.w	r9, r9, r5
 8002d54:	ea49 0e0e 	orr.w	lr, r9, lr
 8002d58:	f1b8 0f01 	cmp.w	r8, #1
 8002d5c:	f8c0 e000 	str.w	lr, [r0]
 8002d60:	f240 809a 	bls.w	8002e98 <HAL_GPIO_Init+0x1a4>
 8002d64:	68c1      	ldr	r1, [r0, #12]
 8002d66:	4029      	ands	r1, r5
 8002d68:	ea41 010c 	orr.w	r1, r1, ip
 8002d6c:	60c1      	str	r1, [r0, #12]
 8002d6e:	00d1      	lsls	r1, r2, #3
 8002d70:	d5c9      	bpl.n	8002d06 <HAL_GPIO_Init+0x12>
 8002d72:	4d67      	ldr	r5, [pc, #412]	@ (8002f10 <HAL_GPIO_Init+0x21c>)
 8002d74:	2100      	movs	r1, #0
 8002d76:	9103      	str	r1, [sp, #12]
 8002d78:	6c69      	ldr	r1, [r5, #68]	@ 0x44
 8002d7a:	f441 4180 	orr.w	r1, r1, #16384	@ 0x4000
 8002d7e:	6469      	str	r1, [r5, #68]	@ 0x44
 8002d80:	6c69      	ldr	r1, [r5, #68]	@ 0x44
 8002d82:	f401 4180 	and.w	r1, r1, #16384	@ 0x4000
 8002d86:	9103      	str	r1, [sp, #12]
 8002d88:	9903      	ldr	r1, [sp, #12]
 8002d8a:	f023 0103 	bic.w	r1, r3, #3
 8002d8e:	f101 4180 	add.w	r1, r1, #1073741824	@ 0x40000000
 8002d92:	f501 319c 	add.w	r1, r1, #79872	@ 0x13800
 8002d96:	f003 0603 	and.w	r6, r3, #3
 8002d9a:	688d      	ldr	r5, [r1, #8]
 8002d9c:	00b6      	lsls	r6, r6, #2
 8002d9e:	f04f 0c0f 	mov.w	ip, #15
 8002da2:	fa0c fc06 	lsl.w	ip, ip, r6
 8002da6:	ea25 050c 	bic.w	r5, r5, ip
 8002daa:	f8df c168 	ldr.w	ip, [pc, #360]	@ 8002f14 <HAL_GPIO_Init+0x220>
 8002dae:	4560      	cmp	r0, ip
 8002db0:	d028      	beq.n	8002e04 <HAL_GPIO_Init+0x110>
 8002db2:	f50c 6c80 	add.w	ip, ip, #1024	@ 0x400
 8002db6:	4560      	cmp	r0, ip
 8002db8:	f000 8084 	beq.w	8002ec4 <HAL_GPIO_Init+0x1d0>
 8002dbc:	f8df c158 	ldr.w	ip, [pc, #344]	@ 8002f18 <HAL_GPIO_Init+0x224>
 8002dc0:	4560      	cmp	r0, ip
 8002dc2:	f000 8085 	beq.w	8002ed0 <HAL_GPIO_Init+0x1dc>
 8002dc6:	f8df c154 	ldr.w	ip, [pc, #340]	@ 8002f1c <HAL_GPIO_Init+0x228>
 8002dca:	4560      	cmp	r0, ip
 8002dcc:	f000 8086 	beq.w	8002edc <HAL_GPIO_Init+0x1e8>
 8002dd0:	f8df c14c 	ldr.w	ip, [pc, #332]	@ 8002f20 <HAL_GPIO_Init+0x22c>
 8002dd4:	4560      	cmp	r0, ip
 8002dd6:	f000 8087 	beq.w	8002ee8 <HAL_GPIO_Init+0x1f4>
 8002dda:	f8df c148 	ldr.w	ip, [pc, #328]	@ 8002f24 <HAL_GPIO_Init+0x230>
 8002dde:	4560      	cmp	r0, ip
 8002de0:	f000 8088 	beq.w	8002ef4 <HAL_GPIO_Init+0x200>
 8002de4:	f8df c140 	ldr.w	ip, [pc, #320]	@ 8002f28 <HAL_GPIO_Init+0x234>
 8002de8:	4560      	cmp	r0, ip
 8002dea:	f000 8089 	beq.w	8002f00 <HAL_GPIO_Init+0x20c>
 8002dee:	f8df c13c 	ldr.w	ip, [pc, #316]	@ 8002f2c <HAL_GPIO_Init+0x238>
 8002df2:	4560      	cmp	r0, ip
 8002df4:	bf0c      	ite	eq
 8002df6:	f04f 0c07 	moveq.w	ip, #7
 8002dfa:	f04f 0c08 	movne.w	ip, #8
 8002dfe:	fa0c f606 	lsl.w	r6, ip, r6
 8002e02:	4335      	orrs	r5, r6
 8002e04:	608d      	str	r5, [r1, #8]
 8002e06:	f8db 1000 	ldr.w	r1, [fp]
 8002e0a:	43fd      	mvns	r5, r7
 8002e0c:	03d6      	lsls	r6, r2, #15
 8002e0e:	bf54      	ite	pl
 8002e10:	4029      	andpl	r1, r5
 8002e12:	4339      	orrmi	r1, r7
 8002e14:	f8cb 1000 	str.w	r1, [fp]
 8002e18:	f8db 1004 	ldr.w	r1, [fp, #4]
 8002e1c:	0396      	lsls	r6, r2, #14
 8002e1e:	bf54      	ite	pl
 8002e20:	4029      	andpl	r1, r5
 8002e22:	4339      	orrmi	r1, r7
 8002e24:	f8cb 1004 	str.w	r1, [fp, #4]
 8002e28:	f8db 1008 	ldr.w	r1, [fp, #8]
 8002e2c:	02d6      	lsls	r6, r2, #11
 8002e2e:	bf54      	ite	pl
 8002e30:	4029      	andpl	r1, r5
 8002e32:	4339      	orrmi	r1, r7
 8002e34:	f8cb 1008 	str.w	r1, [fp, #8]
 8002e38:	f8db 100c 	ldr.w	r1, [fp, #12]
 8002e3c:	0292      	lsls	r2, r2, #10
 8002e3e:	f103 0301 	add.w	r3, r3, #1
 8002e42:	bf54      	ite	pl
 8002e44:	4029      	andpl	r1, r5
 8002e46:	4339      	orrmi	r1, r7
 8002e48:	2b10      	cmp	r3, #16
 8002e4a:	f8cb 100c 	str.w	r1, [fp, #12]
 8002e4e:	f47f af5e 	bne.w	8002d0e <HAL_GPIO_Init+0x1a>
 8002e52:	b005      	add	sp, #20
 8002e54:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8002e58:	ea4f 09d3 	mov.w	r9, r3, lsr #3
 8002e5c:	eb00 0989 	add.w	r9, r0, r9, lsl #2
 8002e60:	f003 0807 	and.w	r8, r3, #7
 8002e64:	f8d9 7020 	ldr.w	r7, [r9, #32]
 8002e68:	9700      	str	r7, [sp, #0]
 8002e6a:	f8da 7010 	ldr.w	r7, [sl, #16]
 8002e6e:	ea4f 0888 	mov.w	r8, r8, lsl #2
 8002e72:	fa07 f708 	lsl.w	r7, r7, r8
 8002e76:	9701      	str	r7, [sp, #4]
 8002e78:	270f      	movs	r7, #15
 8002e7a:	fa07 f808 	lsl.w	r8, r7, r8
 8002e7e:	9f00      	ldr	r7, [sp, #0]
 8002e80:	ea27 0808 	bic.w	r8, r7, r8
 8002e84:	9f01      	ldr	r7, [sp, #4]
 8002e86:	ea47 0708 	orr.w	r7, r7, r8
 8002e8a:	f8c9 7020 	str.w	r7, [r9, #32]
 8002e8e:	6807      	ldr	r7, [r0, #0]
 8002e90:	402f      	ands	r7, r5
 8002e92:	ea47 070e 	orr.w	r7, r7, lr
 8002e96:	6007      	str	r7, [r0, #0]
 8002e98:	6887      	ldr	r7, [r0, #8]
 8002e9a:	ea07 0e05 	and.w	lr, r7, r5
 8002e9e:	f8da 700c 	ldr.w	r7, [sl, #12]
 8002ea2:	40b7      	lsls	r7, r6
 8002ea4:	ea47 070e 	orr.w	r7, r7, lr
 8002ea8:	6087      	str	r7, [r0, #8]
 8002eaa:	6846      	ldr	r6, [r0, #4]
 8002eac:	0912      	lsrs	r2, r2, #4
 8002eae:	409a      	lsls	r2, r3
 8002eb0:	ea26 0101 	bic.w	r1, r6, r1
 8002eb4:	430a      	orrs	r2, r1
 8002eb6:	6042      	str	r2, [r0, #4]
 8002eb8:	68c2      	ldr	r2, [r0, #12]
 8002eba:	402a      	ands	r2, r5
 8002ebc:	ea42 020c 	orr.w	r2, r2, ip
 8002ec0:	60c2      	str	r2, [r0, #12]
 8002ec2:	e720      	b.n	8002d06 <HAL_GPIO_Init+0x12>
 8002ec4:	f04f 0c01 	mov.w	ip, #1
 8002ec8:	fa0c f606 	lsl.w	r6, ip, r6
 8002ecc:	4335      	orrs	r5, r6
 8002ece:	e799      	b.n	8002e04 <HAL_GPIO_Init+0x110>
 8002ed0:	f04f 0c02 	mov.w	ip, #2
 8002ed4:	fa0c f606 	lsl.w	r6, ip, r6
 8002ed8:	4335      	orrs	r5, r6
 8002eda:	e793      	b.n	8002e04 <HAL_GPIO_Init+0x110>
 8002edc:	f04f 0c03 	mov.w	ip, #3
 8002ee0:	fa0c f606 	lsl.w	r6, ip, r6
 8002ee4:	4335      	orrs	r5, r6
 8002ee6:	e78d      	b.n	8002e04 <HAL_GPIO_Init+0x110>
 8002ee8:	f04f 0c04 	mov.w	ip, #4
 8002eec:	fa0c f606 	lsl.w	r6, ip, r6
 8002ef0:	4335      	orrs	r5, r6
 8002ef2:	e787      	b.n	8002e04 <HAL_GPIO_Init+0x110>
 8002ef4:	f04f 0c05 	mov.w	ip, #5
 8002ef8:	fa0c f606 	lsl.w	r6, ip, r6
 8002efc:	4335      	orrs	r5, r6
 8002efe:	e781      	b.n	8002e04 <HAL_GPIO_Init+0x110>
 8002f00:	f04f 0c06 	mov.w	ip, #6
 8002f04:	fa0c f606 	lsl.w	r6, ip, r6
 8002f08:	4335      	orrs	r5, r6
 8002f0a:	e77b      	b.n	8002e04 <HAL_GPIO_Init+0x110>
 8002f0c:	40013c00 	.word	0x40013c00
 8002f10:	40023800 	.word	0x40023800
 8002f14:	40020000 	.word	0x40020000
 8002f18:	40020800 	.word	0x40020800
 8002f1c:	40020c00 	.word	0x40020c00
 8002f20:	40021000 	.word	0x40021000
 8002f24:	40021400 	.word	0x40021400
 8002f28:	40021800 	.word	0x40021800
 8002f2c:	40021c00 	.word	0x40021c00

08002f30 <HAL_GPIO_WritePin>:
 8002f30:	b902      	cbnz	r2, 8002f34 <HAL_GPIO_WritePin+0x4>
 8002f32:	0409      	lsls	r1, r1, #16
 8002f34:	6181      	str	r1, [r0, #24]
 8002f36:	4770      	bx	lr

08002f38 <HAL_UART_Init>:
 8002f38:	2800      	cmp	r0, #0
 8002f3a:	d073      	beq.n	8003024 <HAL_UART_Init+0xec>
 8002f3c:	b430      	push	{r4, r5}
 8002f3e:	f890 2039 	ldrb.w	r2, [r0, #57]	@ 0x39
 8002f42:	4603      	mov	r3, r0
 8002f44:	f002 01ff 	and.w	r1, r2, #255	@ 0xff
 8002f48:	2a00      	cmp	r2, #0
 8002f4a:	d04f      	beq.n	8002fec <HAL_UART_Init+0xb4>
 8002f4c:	681a      	ldr	r2, [r3, #0]
 8002f4e:	68dc      	ldr	r4, [r3, #12]
 8002f50:	691d      	ldr	r5, [r3, #16]
 8002f52:	2124      	movs	r1, #36	@ 0x24
 8002f54:	f883 1039 	strb.w	r1, [r3, #57]	@ 0x39
 8002f58:	68d1      	ldr	r1, [r2, #12]
 8002f5a:	f421 5100 	bic.w	r1, r1, #8192	@ 0x2000
 8002f5e:	60d1      	str	r1, [r2, #12]
 8002f60:	6910      	ldr	r0, [r2, #16]
 8002f62:	6899      	ldr	r1, [r3, #8]
 8002f64:	f420 5040 	bic.w	r0, r0, #12288	@ 0x3000
 8002f68:	4320      	orrs	r0, r4
 8002f6a:	6110      	str	r0, [r2, #16]
 8002f6c:	68d0      	ldr	r0, [r2, #12]
 8002f6e:	69dc      	ldr	r4, [r3, #28]
 8002f70:	4329      	orrs	r1, r5
 8002f72:	695d      	ldr	r5, [r3, #20]
 8002f74:	f420 4016 	bic.w	r0, r0, #38400	@ 0x9600
 8002f78:	4329      	orrs	r1, r5
 8002f7a:	f020 000c 	bic.w	r0, r0, #12
 8002f7e:	4321      	orrs	r1, r4
 8002f80:	4301      	orrs	r1, r0
 8002f82:	60d1      	str	r1, [r2, #12]
 8002f84:	6951      	ldr	r1, [r2, #20]
 8002f86:	6998      	ldr	r0, [r3, #24]
 8002f88:	f421 7140 	bic.w	r1, r1, #768	@ 0x300
 8002f8c:	4301      	orrs	r1, r0
 8002f8e:	f5b4 4f00 	cmp.w	r4, #32768	@ 0x8000
 8002f92:	6858      	ldr	r0, [r3, #4]
 8002f94:	6151      	str	r1, [r2, #20]
 8002f96:	d02c      	beq.n	8002ff2 <HAL_UART_Init+0xba>
 8002f98:	4c23      	ldr	r4, [pc, #140]	@ (8003028 <HAL_UART_Init+0xf0>)
 8002f9a:	4924      	ldr	r1, [pc, #144]	@ (800302c <HAL_UART_Init+0xf4>)
 8002f9c:	0080      	lsls	r0, r0, #2
 8002f9e:	fbb1 f1f0 	udiv	r1, r1, r0
 8002fa2:	fba4 5001 	umull	r5, r0, r4, r1
 8002fa6:	0940      	lsrs	r0, r0, #5
 8002fa8:	2564      	movs	r5, #100	@ 0x64
 8002faa:	fb05 1110 	mls	r1, r5, r0, r1
 8002fae:	0109      	lsls	r1, r1, #4
 8002fb0:	3132      	adds	r1, #50	@ 0x32
 8002fb2:	fba4 4101 	umull	r4, r1, r4, r1
 8002fb6:	0100      	lsls	r0, r0, #4
 8002fb8:	eb00 1051 	add.w	r0, r0, r1, lsr #5
 8002fbc:	6090      	str	r0, [r2, #8]
 8002fbe:	6911      	ldr	r1, [r2, #16]
 8002fc0:	f421 4190 	bic.w	r1, r1, #18432	@ 0x4800
 8002fc4:	6111      	str	r1, [r2, #16]
 8002fc6:	6951      	ldr	r1, [r2, #20]
 8002fc8:	f021 012a 	bic.w	r1, r1, #42	@ 0x2a
 8002fcc:	6151      	str	r1, [r2, #20]
 8002fce:	68d1      	ldr	r1, [r2, #12]
 8002fd0:	2400      	movs	r4, #0
 8002fd2:	f04f 0c20 	mov.w	ip, #32
 8002fd6:	f441 5100 	orr.w	r1, r1, #8192	@ 0x2000
 8002fda:	60d1      	str	r1, [r2, #12]
 8002fdc:	63dc      	str	r4, [r3, #60]	@ 0x3c
 8002fde:	f883 c039 	strb.w	ip, [r3, #57]	@ 0x39
 8002fe2:	f883 c03a 	strb.w	ip, [r3, #58]	@ 0x3a
 8002fe6:	4620      	mov	r0, r4
 8002fe8:	bc30      	pop	{r4, r5}
 8002fea:	4770      	bx	lr
 8002fec:	f880 1038 	strb.w	r1, [r0, #56]	@ 0x38
 8002ff0:	e7ac      	b.n	8002f4c <HAL_UART_Init+0x14>
 8002ff2:	4d0d      	ldr	r5, [pc, #52]	@ (8003028 <HAL_UART_Init+0xf0>)
 8002ff4:	490d      	ldr	r1, [pc, #52]	@ (800302c <HAL_UART_Init+0xf4>)
 8002ff6:	0040      	lsls	r0, r0, #1
 8002ff8:	fbb1 f1f0 	udiv	r1, r1, r0
 8002ffc:	fba5 0401 	umull	r0, r4, r5, r1
 8003000:	0964      	lsrs	r4, r4, #5
 8003002:	2064      	movs	r0, #100	@ 0x64
 8003004:	fb00 1114 	mls	r1, r0, r4, r1
 8003008:	00c9      	lsls	r1, r1, #3
 800300a:	3132      	adds	r1, #50	@ 0x32
 800300c:	fba5 5101 	umull	r5, r1, r5, r1
 8003010:	f3c1 1042 	ubfx	r0, r1, #5, #3
 8003014:	0909      	lsrs	r1, r1, #4
 8003016:	eb00 1004 	add.w	r0, r0, r4, lsl #4
 800301a:	f401 71f8 	and.w	r1, r1, #496	@ 0x1f0
 800301e:	4401      	add	r1, r0
 8003020:	6091      	str	r1, [r2, #8]
 8003022:	e7cc      	b.n	8002fbe <HAL_UART_Init+0x86>
 8003024:	2001      	movs	r0, #1
 8003026:	4770      	bx	lr
 8003028:	51eb851f 	.word	0x51eb851f
 800302c:	0afb6e90 	.word	0x0afb6e90

08003030 <HAL_UART_Transmit>:
 8003030:	f890 3039 	ldrb.w	r3, [r0, #57]	@ 0x39
 8003034:	2b20      	cmp	r3, #32
 8003036:	d141      	bne.n	80030bc <HAL_UART_Transmit+0x8c>
 8003038:	2900      	cmp	r1, #0
 800303a:	d03d      	beq.n	80030b8 <HAL_UART_Transmit+0x88>
 800303c:	2a00      	cmp	r2, #0
 800303e:	d03b      	beq.n	80030b8 <HAL_UART_Transmit+0x88>
 8003040:	f890 3038 	ldrb.w	r3, [r0, #56]	@ 0x38
 8003044:	2b01      	cmp	r3, #1
 8003046:	d039      	beq.n	80030bc <HAL_UART_Transmit+0x8c>
 8003048:	b410      	push	{r4}
 800304a:	2321      	movs	r3, #33	@ 0x21
 800304c:	2400      	movs	r4, #0
 800304e:	63c4      	str	r4, [r0, #60]	@ 0x3c
 8003050:	f880 3039 	strb.w	r3, [r0, #57]	@ 0x39
 8003054:	84c2      	strh	r2, [r0, #38]	@ 0x26
 8003056:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 8003058:	6804      	ldr	r4, [r0, #0]
 800305a:	8482      	strh	r2, [r0, #36]	@ 0x24
 800305c:	f04f 0c01 	mov.w	ip, #1
 8003060:	b29b      	uxth	r3, r3
 8003062:	f880 c038 	strb.w	ip, [r0, #56]	@ 0x38
 8003066:	b1db      	cbz	r3, 80030a0 <HAL_UART_Transmit+0x70>
 8003068:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 800306a:	6882      	ldr	r2, [r0, #8]
 800306c:	3b01      	subs	r3, #1
 800306e:	b29b      	uxth	r3, r3
 8003070:	f5b2 5f80 	cmp.w	r2, #4096	@ 0x1000
 8003074:	84c3      	strh	r3, [r0, #38]	@ 0x26
 8003076:	d023      	beq.n	80030c0 <HAL_UART_Transmit+0x90>
 8003078:	6823      	ldr	r3, [r4, #0]
 800307a:	061a      	lsls	r2, r3, #24
 800307c:	d5fc      	bpl.n	8003078 <HAL_UART_Transmit+0x48>
 800307e:	f811 3b01 	ldrb.w	r3, [r1], #1
 8003082:	6063      	str	r3, [r4, #4]
 8003084:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 8003086:	b29b      	uxth	r3, r3
 8003088:	b153      	cbz	r3, 80030a0 <HAL_UART_Transmit+0x70>
 800308a:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 800308c:	3b01      	subs	r3, #1
 800308e:	b29b      	uxth	r3, r3
 8003090:	84c3      	strh	r3, [r0, #38]	@ 0x26
 8003092:	6823      	ldr	r3, [r4, #0]
 8003094:	061a      	lsls	r2, r3, #24
 8003096:	d5ef      	bpl.n	8003078 <HAL_UART_Transmit+0x48>
 8003098:	e7f1      	b.n	800307e <HAL_UART_Transmit+0x4e>
 800309a:	b29b      	uxth	r3, r3
 800309c:	3101      	adds	r1, #1
 800309e:	b9f3      	cbnz	r3, 80030de <HAL_UART_Transmit+0xae>
 80030a0:	6823      	ldr	r3, [r4, #0]
 80030a2:	065b      	lsls	r3, r3, #25
 80030a4:	d5fc      	bpl.n	80030a0 <HAL_UART_Transmit+0x70>
 80030a6:	2300      	movs	r3, #0
 80030a8:	2220      	movs	r2, #32
 80030aa:	f880 2039 	strb.w	r2, [r0, #57]	@ 0x39
 80030ae:	f880 3038 	strb.w	r3, [r0, #56]	@ 0x38
 80030b2:	bc10      	pop	{r4}
 80030b4:	4618      	mov	r0, r3
 80030b6:	4770      	bx	lr
 80030b8:	2001      	movs	r0, #1
 80030ba:	4770      	bx	lr
 80030bc:	2002      	movs	r0, #2
 80030be:	4770      	bx	lr
 80030c0:	6902      	ldr	r2, [r0, #16]
 80030c2:	6823      	ldr	r3, [r4, #0]
 80030c4:	061b      	lsls	r3, r3, #24
 80030c6:	d5fc      	bpl.n	80030c2 <HAL_UART_Transmit+0x92>
 80030c8:	880b      	ldrh	r3, [r1, #0]
 80030ca:	f3c3 0308 	ubfx	r3, r3, #0, #9
 80030ce:	6063      	str	r3, [r4, #4]
 80030d0:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 80030d2:	2a00      	cmp	r2, #0
 80030d4:	d1e1      	bne.n	800309a <HAL_UART_Transmit+0x6a>
 80030d6:	b29b      	uxth	r3, r3
 80030d8:	3102      	adds	r1, #2
 80030da:	2b00      	cmp	r3, #0
 80030dc:	d0e0      	beq.n	80030a0 <HAL_UART_Transmit+0x70>
 80030de:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 80030e0:	3b01      	subs	r3, #1
 80030e2:	b29b      	uxth	r3, r3
 80030e4:	84c3      	strh	r3, [r0, #38]	@ 0x26
 80030e6:	e7ec      	b.n	80030c2 <HAL_UART_Transmit+0x92>

080030e8 <HAL_UART_Receive>:
 80030e8:	f890 303a 	ldrb.w	r3, [r0, #58]	@ 0x3a
 80030ec:	2b20      	cmp	r3, #32
 80030ee:	d146      	bne.n	800317e <HAL_UART_Receive+0x96>
 80030f0:	2900      	cmp	r1, #0
 80030f2:	d03e      	beq.n	8003172 <HAL_UART_Receive+0x8a>
 80030f4:	2a00      	cmp	r2, #0
 80030f6:	d03c      	beq.n	8003172 <HAL_UART_Receive+0x8a>
 80030f8:	f890 3038 	ldrb.w	r3, [r0, #56]	@ 0x38
 80030fc:	2b01      	cmp	r3, #1
 80030fe:	d03e      	beq.n	800317e <HAL_UART_Receive+0x96>
 8003100:	b410      	push	{r4}
 8003102:	2322      	movs	r3, #34	@ 0x22
 8003104:	2400      	movs	r4, #0
 8003106:	63c4      	str	r4, [r0, #60]	@ 0x3c
 8003108:	f880 303a 	strb.w	r3, [r0, #58]	@ 0x3a
 800310c:	85c2      	strh	r2, [r0, #46]	@ 0x2e
 800310e:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 8003110:	8582      	strh	r2, [r0, #44]	@ 0x2c
 8003112:	f04f 0c01 	mov.w	ip, #1
 8003116:	b29b      	uxth	r3, r3
 8003118:	f880 c038 	strb.w	ip, [r0, #56]	@ 0x38
 800311c:	b1ab      	cbz	r3, 800314a <HAL_UART_Receive+0x62>
 800311e:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 8003120:	6802      	ldr	r2, [r0, #0]
 8003122:	3b01      	subs	r3, #1
 8003124:	b29b      	uxth	r3, r3
 8003126:	85c3      	strh	r3, [r0, #46]	@ 0x2e
 8003128:	6883      	ldr	r3, [r0, #8]
 800312a:	f5b3 5f80 	cmp.w	r3, #4096	@ 0x1000
 800312e:	d015      	beq.n	800315c <HAL_UART_Receive+0x74>
 8003130:	6813      	ldr	r3, [r2, #0]
 8003132:	069b      	lsls	r3, r3, #26
 8003134:	d5fc      	bpl.n	8003130 <HAL_UART_Receive+0x48>
 8003136:	6903      	ldr	r3, [r0, #16]
 8003138:	b9eb      	cbnz	r3, 8003176 <HAL_UART_Receive+0x8e>
 800313a:	6853      	ldr	r3, [r2, #4]
 800313c:	b2db      	uxtb	r3, r3
 800313e:	f801 3b01 	strb.w	r3, [r1], #1
 8003142:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 8003144:	b29b      	uxth	r3, r3
 8003146:	2b00      	cmp	r3, #0
 8003148:	d1e9      	bne.n	800311e <HAL_UART_Receive+0x36>
 800314a:	2300      	movs	r3, #0
 800314c:	2220      	movs	r2, #32
 800314e:	f880 203a 	strb.w	r2, [r0, #58]	@ 0x3a
 8003152:	f880 3038 	strb.w	r3, [r0, #56]	@ 0x38
 8003156:	bc10      	pop	{r4}
 8003158:	4618      	mov	r0, r3
 800315a:	4770      	bx	lr
 800315c:	6813      	ldr	r3, [r2, #0]
 800315e:	069c      	lsls	r4, r3, #26
 8003160:	d5fc      	bpl.n	800315c <HAL_UART_Receive+0x74>
 8003162:	6903      	ldr	r3, [r0, #16]
 8003164:	b96b      	cbnz	r3, 8003182 <HAL_UART_Receive+0x9a>
 8003166:	6853      	ldr	r3, [r2, #4]
 8003168:	f3c3 0308 	ubfx	r3, r3, #0, #9
 800316c:	f821 3b02 	strh.w	r3, [r1], #2
 8003170:	e7e7      	b.n	8003142 <HAL_UART_Receive+0x5a>
 8003172:	2001      	movs	r0, #1
 8003174:	4770      	bx	lr
 8003176:	6853      	ldr	r3, [r2, #4]
 8003178:	f003 037f 	and.w	r3, r3, #127	@ 0x7f
 800317c:	e7df      	b.n	800313e <HAL_UART_Receive+0x56>
 800317e:	2002      	movs	r0, #2
 8003180:	4770      	bx	lr
 8003182:	6853      	ldr	r3, [r2, #4]
 8003184:	b2db      	uxtb	r3, r3
 8003186:	f821 3b01 	strh.w	r3, [r1], #1
 800318a:	e7da      	b.n	8003142 <HAL_UART_Receive+0x5a>

0800318c <_sbrk>:
 800318c:	4a0b      	ldr	r2, [pc, #44]	@ (80031bc <_sbrk+0x30>)
 800318e:	b508      	push	{r3, lr}
 8003190:	4603      	mov	r3, r0
 8003192:	6810      	ldr	r0, [r2, #0]
 8003194:	b128      	cbz	r0, 80031a2 <_sbrk+0x16>
 8003196:	4403      	add	r3, r0
 8003198:	4669      	mov	r1, sp
 800319a:	428b      	cmp	r3, r1
 800319c:	d807      	bhi.n	80031ae <_sbrk+0x22>
 800319e:	6013      	str	r3, [r2, #0]
 80031a0:	bd08      	pop	{r3, pc}
 80031a2:	4807      	ldr	r0, [pc, #28]	@ (80031c0 <_sbrk+0x34>)
 80031a4:	6010      	str	r0, [r2, #0]
 80031a6:	4403      	add	r3, r0
 80031a8:	4669      	mov	r1, sp
 80031aa:	428b      	cmp	r3, r1
 80031ac:	d9f7      	bls.n	800319e <_sbrk+0x12>
 80031ae:	f7fd f8f1 	bl	8000394 <__errno>
 80031b2:	230c      	movs	r3, #12
 80031b4:	6003      	str	r3, [r0, #0]
 80031b6:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 80031ba:	bd08      	pop	{r3, pc}
 80031bc:	20000a1c 	.word	0x20000a1c
 80031c0:	20000f30 	.word	0x20000f30

080031c4 <HAL_RNG_MspInit>:
 80031c4:	4770      	bx	lr
 80031c6:	bf00      	nop

080031c8 <HAL_RNG_Init>:
 80031c8:	b1c0      	cbz	r0, 80031fc <HAL_RNG_Init+0x34>
 80031ca:	b510      	push	{r4, lr}
 80031cc:	7903      	ldrb	r3, [r0, #4]
 80031ce:	2b01      	cmp	r3, #1
 80031d0:	4604      	mov	r4, r0
 80031d2:	d015      	beq.n	8003200 <HAL_RNG_Init+0x38>
 80031d4:	7943      	ldrb	r3, [r0, #5]
 80031d6:	f003 02ff 	and.w	r2, r3, #255	@ 0xff
 80031da:	b15b      	cbz	r3, 80031f4 <HAL_RNG_Init+0x2c>
 80031dc:	6822      	ldr	r2, [r4, #0]
 80031de:	2302      	movs	r3, #2
 80031e0:	7163      	strb	r3, [r4, #5]
 80031e2:	6813      	ldr	r3, [r2, #0]
 80031e4:	2000      	movs	r0, #0
 80031e6:	f043 0304 	orr.w	r3, r3, #4
 80031ea:	2101      	movs	r1, #1
 80031ec:	6013      	str	r3, [r2, #0]
 80031ee:	7161      	strb	r1, [r4, #5]
 80031f0:	7120      	strb	r0, [r4, #4]
 80031f2:	bd10      	pop	{r4, pc}
 80031f4:	7102      	strb	r2, [r0, #4]
 80031f6:	f7ff ffe5 	bl	80031c4 <HAL_RNG_MspInit>
 80031fa:	e7ef      	b.n	80031dc <HAL_RNG_Init+0x14>
 80031fc:	2001      	movs	r0, #1
 80031fe:	4770      	bx	lr
 8003200:	2002      	movs	r0, #2
 8003202:	bd10      	pop	{r4, pc}

08003204 <check_version>:
 8003204:	2001      	movs	r0, #1
 8003206:	4770      	bx	lr

08003208 <simpleserial_put.part.0>:
 8003208:	b570      	push	{r4, r5, r6, lr}
 800320a:	460e      	mov	r6, r1
 800320c:	4614      	mov	r4, r2
 800320e:	f7ff fa95 	bl	800273c <putch>
 8003212:	b17e      	cbz	r6, 8003234 <simpleserial_put.part.0+0x2c>
 8003214:	4d0a      	ldr	r5, [pc, #40]	@ (8003240 <simpleserial_put.part.0+0x38>)
 8003216:	4426      	add	r6, r4
 8003218:	7823      	ldrb	r3, [r4, #0]
 800321a:	091b      	lsrs	r3, r3, #4
 800321c:	5ce8      	ldrb	r0, [r5, r3]
 800321e:	f7ff fa8d 	bl	800273c <putch>
 8003222:	f814 3b01 	ldrb.w	r3, [r4], #1
 8003226:	f003 030f 	and.w	r3, r3, #15
 800322a:	5ce8      	ldrb	r0, [r5, r3]
 800322c:	f7ff fa86 	bl	800273c <putch>
 8003230:	42a6      	cmp	r6, r4
 8003232:	d1f1      	bne.n	8003218 <simpleserial_put.part.0+0x10>
 8003234:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
 8003238:	200a      	movs	r0, #10
 800323a:	f7ff ba7f 	b.w	800273c <putch>
 800323e:	bf00      	nop
 8003240:	08003640 	.word	0x08003640

08003244 <ss_get_commands>:
 8003244:	b530      	push	{r4, r5, lr}
 8003246:	4c12      	ldr	r4, [pc, #72]	@ (8003290 <ss_get_commands+0x4c>)
 8003248:	6825      	ldr	r5, [r4, #0]
 800324a:	f015 0eff 	ands.w	lr, r5, #255	@ 0xff
 800324e:	b099      	sub	sp, #100	@ 0x64
 8003250:	d013      	beq.n	800327a <ss_get_commands+0x36>
 8003252:	2200      	movs	r2, #0
 8003254:	4613      	mov	r3, r2
 8003256:	eb04 1003 	add.w	r0, r4, r3, lsl #4
 800325a:	3201      	adds	r2, #1
 800325c:	eb03 0343 	add.w	r3, r3, r3, lsl #1
 8003260:	446b      	add	r3, sp
 8003262:	b2d2      	uxtb	r2, r2
 8003264:	f890 c004 	ldrb.w	ip, [r0, #4]
 8003268:	6881      	ldr	r1, [r0, #8]
 800326a:	7c00      	ldrb	r0, [r0, #16]
 800326c:	f883 c000 	strb.w	ip, [r3]
 8003270:	4572      	cmp	r2, lr
 8003272:	7059      	strb	r1, [r3, #1]
 8003274:	7098      	strb	r0, [r3, #2]
 8003276:	4613      	mov	r3, r2
 8003278:	dbed      	blt.n	8003256 <ss_get_commands+0x12>
 800327a:	eb05 0545 	add.w	r5, r5, r5, lsl #1
 800327e:	466a      	mov	r2, sp
 8003280:	b2e9      	uxtb	r1, r5
 8003282:	2072      	movs	r0, #114	@ 0x72
 8003284:	f7ff ffc0 	bl	8003208 <simpleserial_put.part.0>
 8003288:	2000      	movs	r0, #0
 800328a:	b019      	add	sp, #100	@ 0x64
 800328c:	bd30      	pop	{r4, r5, pc}
 800328e:	bf00      	nop
 8003290:	20000a20 	.word	0x20000a20

08003294 <ss_num_commands>:
 8003294:	b538      	push	{r3, r4, r5, lr}
 8003296:	4b0a      	ldr	r3, [pc, #40]	@ (80032c0 <ss_num_commands+0x2c>)
 8003298:	4d0a      	ldr	r5, [pc, #40]	@ (80032c4 <ss_num_commands+0x30>)
 800329a:	781c      	ldrb	r4, [r3, #0]
 800329c:	2072      	movs	r0, #114	@ 0x72
 800329e:	f7ff fa4d 	bl	800273c <putch>
 80032a2:	0923      	lsrs	r3, r4, #4
 80032a4:	f004 040f 	and.w	r4, r4, #15
 80032a8:	5ce8      	ldrb	r0, [r5, r3]
 80032aa:	f7ff fa47 	bl	800273c <putch>
 80032ae:	5d28      	ldrb	r0, [r5, r4]
 80032b0:	f7ff fa44 	bl	800273c <putch>
 80032b4:	200a      	movs	r0, #10
 80032b6:	f7ff fa41 	bl	800273c <putch>
 80032ba:	2000      	movs	r0, #0
 80032bc:	bd38      	pop	{r3, r4, r5, pc}
 80032be:	bf00      	nop
 80032c0:	20000a20 	.word	0x20000a20
 80032c4:	08003640 	.word	0x08003640

080032c8 <hex_decode>:
 80032c8:	2800      	cmp	r0, #0
 80032ca:	dd4c      	ble.n	8003366 <hex_decode+0x9e>
 80032cc:	b500      	push	{lr}
 80032ce:	eb01 0e40 	add.w	lr, r1, r0, lsl #1
 80032d2:	e00e      	b.n	80032f2 <hex_decode+0x2a>
 80032d4:	7013      	strb	r3, [r2, #0]
 80032d6:	f1ac 0330 	sub.w	r3, ip, #48	@ 0x30
 80032da:	b2db      	uxtb	r3, r3
 80032dc:	2b09      	cmp	r3, #9
 80032de:	d81b      	bhi.n	8003318 <hex_decode+0x50>
 80032e0:	7810      	ldrb	r0, [r2, #0]
 80032e2:	ea40 1303 	orr.w	r3, r0, r3, lsl #4
 80032e6:	7013      	strb	r3, [r2, #0]
 80032e8:	3102      	adds	r1, #2
 80032ea:	4571      	cmp	r1, lr
 80032ec:	f102 0201 	add.w	r2, r2, #1
 80032f0:	d021      	beq.n	8003336 <hex_decode+0x6e>
 80032f2:	7848      	ldrb	r0, [r1, #1]
 80032f4:	f891 c000 	ldrb.w	ip, [r1]
 80032f8:	f1a0 0330 	sub.w	r3, r0, #48	@ 0x30
 80032fc:	b2db      	uxtb	r3, r3
 80032fe:	2b09      	cmp	r3, #9
 8003300:	d9e8      	bls.n	80032d4 <hex_decode+0xc>
 8003302:	f1a0 0341 	sub.w	r3, r0, #65	@ 0x41
 8003306:	2b05      	cmp	r3, #5
 8003308:	d818      	bhi.n	800333c <hex_decode+0x74>
 800330a:	f1ac 0330 	sub.w	r3, ip, #48	@ 0x30
 800330e:	b2db      	uxtb	r3, r3
 8003310:	3837      	subs	r0, #55	@ 0x37
 8003312:	2b09      	cmp	r3, #9
 8003314:	7010      	strb	r0, [r2, #0]
 8003316:	d9e3      	bls.n	80032e0 <hex_decode+0x18>
 8003318:	f1ac 0341 	sub.w	r3, ip, #65	@ 0x41
 800331c:	2b05      	cmp	r3, #5
 800331e:	d814      	bhi.n	800334a <hex_decode+0x82>
 8003320:	7813      	ldrb	r3, [r2, #0]
 8003322:	f1ac 0c37 	sub.w	ip, ip, #55	@ 0x37
 8003326:	3102      	adds	r1, #2
 8003328:	ea43 130c 	orr.w	r3, r3, ip, lsl #4
 800332c:	4571      	cmp	r1, lr
 800332e:	7013      	strb	r3, [r2, #0]
 8003330:	f102 0201 	add.w	r2, r2, #1
 8003334:	d1dd      	bne.n	80032f2 <hex_decode+0x2a>
 8003336:	2000      	movs	r0, #0
 8003338:	f85d fb04 	ldr.w	pc, [sp], #4
 800333c:	f1a0 0361 	sub.w	r3, r0, #97	@ 0x61
 8003340:	2b05      	cmp	r3, #5
 8003342:	d80d      	bhi.n	8003360 <hex_decode+0x98>
 8003344:	3857      	subs	r0, #87	@ 0x57
 8003346:	7010      	strb	r0, [r2, #0]
 8003348:	e7c5      	b.n	80032d6 <hex_decode+0xe>
 800334a:	f1ac 0361 	sub.w	r3, ip, #97	@ 0x61
 800334e:	2b05      	cmp	r3, #5
 8003350:	d806      	bhi.n	8003360 <hex_decode+0x98>
 8003352:	7813      	ldrb	r3, [r2, #0]
 8003354:	f1ac 0c57 	sub.w	ip, ip, #87	@ 0x57
 8003358:	ea43 130c 	orr.w	r3, r3, ip, lsl #4
 800335c:	7013      	strb	r3, [r2, #0]
 800335e:	e7c3      	b.n	80032e8 <hex_decode+0x20>
 8003360:	2001      	movs	r0, #1
 8003362:	f85d fb04 	ldr.w	pc, [sp], #4
 8003366:	2000      	movs	r0, #0
 8003368:	4770      	bx	lr
 800336a:	bf00      	nop

0800336c <simpleserial_init>:
 800336c:	4b16      	ldr	r3, [pc, #88]	@ (80033c8 <simpleserial_init+0x5c>)
 800336e:	681a      	ldr	r2, [r3, #0]
 8003370:	2a1f      	cmp	r2, #31
 8003372:	dc27      	bgt.n	80033c4 <simpleserial_init+0x58>
 8003374:	4815      	ldr	r0, [pc, #84]	@ (80033cc <simpleserial_init+0x60>)
 8003376:	b410      	push	{r4}
 8003378:	eb03 1102 	add.w	r1, r3, r2, lsl #4
 800337c:	2400      	movs	r4, #0
 800337e:	e9c1 4002 	strd	r4, r0, [r1, #8]
 8003382:	1c50      	adds	r0, r2, #1
 8003384:	f04f 0c76 	mov.w	ip, #118	@ 0x76
 8003388:	2820      	cmp	r0, #32
 800338a:	f881 c004 	strb.w	ip, [r1, #4]
 800338e:	740c      	strb	r4, [r1, #16]
 8003390:	6018      	str	r0, [r3, #0]
 8003392:	d015      	beq.n	80033c0 <simpleserial_init+0x54>
 8003394:	eb03 1000 	add.w	r0, r3, r0, lsl #4
 8003398:	2177      	movs	r1, #119	@ 0x77
 800339a:	7101      	strb	r1, [r0, #4]
 800339c:	490c      	ldr	r1, [pc, #48]	@ (80033d0 <simpleserial_init+0x64>)
 800339e:	7404      	strb	r4, [r0, #16]
 80033a0:	e9c0 4102 	strd	r4, r1, [r0, #8]
 80033a4:	1c91      	adds	r1, r2, #2
 80033a6:	2920      	cmp	r1, #32
 80033a8:	6019      	str	r1, [r3, #0]
 80033aa:	d009      	beq.n	80033c0 <simpleserial_init+0x54>
 80033ac:	eb03 1101 	add.w	r1, r3, r1, lsl #4
 80033b0:	2079      	movs	r0, #121	@ 0x79
 80033b2:	7108      	strb	r0, [r1, #4]
 80033b4:	4807      	ldr	r0, [pc, #28]	@ (80033d4 <simpleserial_init+0x68>)
 80033b6:	740c      	strb	r4, [r1, #16]
 80033b8:	e9c1 4002 	strd	r4, r0, [r1, #8]
 80033bc:	3203      	adds	r2, #3
 80033be:	601a      	str	r2, [r3, #0]
 80033c0:	bc10      	pop	{r4}
 80033c2:	4770      	bx	lr
 80033c4:	4770      	bx	lr
 80033c6:	bf00      	nop
 80033c8:	20000a20 	.word	0x20000a20
 80033cc:	08003205 	.word	0x08003205
 80033d0:	08003245 	.word	0x08003245
 80033d4:	08003295 	.word	0x08003295

080033d8 <simpleserial_addcmd>:
 80033d8:	b410      	push	{r4}
 80033da:	4c0c      	ldr	r4, [pc, #48]	@ (800340c <simpleserial_addcmd+0x34>)
 80033dc:	6823      	ldr	r3, [r4, #0]
 80033de:	2b1f      	cmp	r3, #31
 80033e0:	dc10      	bgt.n	8003404 <simpleserial_addcmd+0x2c>
 80033e2:	293f      	cmp	r1, #63	@ 0x3f
 80033e4:	d80e      	bhi.n	8003404 <simpleserial_addcmd+0x2c>
 80033e6:	eb04 1c03 	add.w	ip, r4, r3, lsl #4
 80033ea:	3301      	adds	r3, #1
 80033ec:	f88c 0004 	strb.w	r0, [ip, #4]
 80033f0:	2000      	movs	r0, #0
 80033f2:	f88c 0010 	strb.w	r0, [ip, #16]
 80033f6:	6023      	str	r3, [r4, #0]
 80033f8:	f8cc 1008 	str.w	r1, [ip, #8]
 80033fc:	bc10      	pop	{r4}
 80033fe:	f8cc 200c 	str.w	r2, [ip, #12]
 8003402:	4770      	bx	lr
 8003404:	2001      	movs	r0, #1
 8003406:	bc10      	pop	{r4}
 8003408:	4770      	bx	lr
 800340a:	bf00      	nop
 800340c:	20000a20 	.word	0x20000a20

08003410 <simpleserial_get>:
 8003410:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
 8003414:	4e37      	ldr	r6, [pc, #220]	@ (80034f4 <simpleserial_get+0xe4>)
 8003416:	b0b0      	sub	sp, #192	@ 0xc0
 8003418:	f7ff f97c 	bl	8002714 <getch>
 800341c:	6831      	ldr	r1, [r6, #0]
 800341e:	2900      	cmp	r1, #0
 8003420:	f04f 0300 	mov.w	r3, #0
 8003424:	dd08      	ble.n	8003438 <simpleserial_get+0x28>
 8003426:	1d34      	adds	r4, r6, #4
 8003428:	e002      	b.n	8003430 <simpleserial_get+0x20>
 800342a:	3301      	adds	r3, #1
 800342c:	428b      	cmp	r3, r1
 800342e:	d022      	beq.n	8003476 <simpleserial_get+0x66>
 8003430:	011a      	lsls	r2, r3, #4
 8003432:	5ca2      	ldrb	r2, [r4, r2]
 8003434:	4282      	cmp	r2, r0
 8003436:	d1f8      	bne.n	800342a <simpleserial_get+0x1a>
 8003438:	428b      	cmp	r3, r1
 800343a:	d01c      	beq.n	8003476 <simpleserial_get+0x66>
 800343c:	eb06 1503 	add.w	r5, r6, r3, lsl #4
 8003440:	011c      	lsls	r4, r3, #4
 8003442:	7c2b      	ldrb	r3, [r5, #16]
 8003444:	07db      	lsls	r3, r3, #31
 8003446:	d419      	bmi.n	800347c <simpleserial_get+0x6c>
 8003448:	68ab      	ldr	r3, [r5, #8]
 800344a:	005b      	lsls	r3, r3, #1
 800344c:	d02c      	beq.n	80034a8 <simpleserial_get+0x98>
 800344e:	af10      	add	r7, sp, #64	@ 0x40
 8003450:	2500      	movs	r5, #0
 8003452:	eb06 0804 	add.w	r8, r6, r4
 8003456:	e008      	b.n	800346a <simpleserial_get+0x5a>
 8003458:	280d      	cmp	r0, #13
 800345a:	d00c      	beq.n	8003476 <simpleserial_get+0x66>
 800345c:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8003460:	f807 0b01 	strb.w	r0, [r7], #1
 8003464:	ebb5 0f43 	cmp.w	r5, r3, lsl #1
 8003468:	d21e      	bcs.n	80034a8 <simpleserial_get+0x98>
 800346a:	f7ff f953 	bl	8002714 <getch>
 800346e:	280a      	cmp	r0, #10
 8003470:	f105 0501 	add.w	r5, r5, #1
 8003474:	d1f0      	bne.n	8003458 <simpleserial_get+0x48>
 8003476:	b030      	add	sp, #192	@ 0xc0
 8003478:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 800347c:	2300      	movs	r3, #0
 800347e:	f88d 3000 	strb.w	r3, [sp]
 8003482:	f7ff f947 	bl	8002714 <getch>
 8003486:	f88d 0040 	strb.w	r0, [sp, #64]	@ 0x40
 800348a:	f7ff f943 	bl	8002714 <getch>
 800348e:	466a      	mov	r2, sp
 8003490:	f88d 0041 	strb.w	r0, [sp, #65]	@ 0x41
 8003494:	a910      	add	r1, sp, #64	@ 0x40
 8003496:	2001      	movs	r0, #1
 8003498:	f7ff ff16 	bl	80032c8 <hex_decode>
 800349c:	2800      	cmp	r0, #0
 800349e:	d1ea      	bne.n	8003476 <simpleserial_get+0x66>
 80034a0:	f89d 3000 	ldrb.w	r3, [sp]
 80034a4:	60ab      	str	r3, [r5, #8]
 80034a6:	e7d0      	b.n	800344a <simpleserial_get+0x3a>
 80034a8:	f7ff f934 	bl	8002714 <getch>
 80034ac:	280a      	cmp	r0, #10
 80034ae:	d001      	beq.n	80034b4 <simpleserial_get+0xa4>
 80034b0:	280d      	cmp	r0, #13
 80034b2:	d1e0      	bne.n	8003476 <simpleserial_get+0x66>
 80034b4:	4426      	add	r6, r4
 80034b6:	466a      	mov	r2, sp
 80034b8:	68b4      	ldr	r4, [r6, #8]
 80034ba:	a910      	add	r1, sp, #64	@ 0x40
 80034bc:	4620      	mov	r0, r4
 80034be:	f7ff ff03 	bl	80032c8 <hex_decode>
 80034c2:	2800      	cmp	r0, #0
 80034c4:	d1d7      	bne.n	8003476 <simpleserial_get+0x66>
 80034c6:	b2e1      	uxtb	r1, r4
 80034c8:	68f3      	ldr	r3, [r6, #12]
 80034ca:	4d0b      	ldr	r5, [pc, #44]	@ (80034f8 <simpleserial_get+0xe8>)
 80034cc:	4668      	mov	r0, sp
 80034ce:	4798      	blx	r3
 80034d0:	4604      	mov	r4, r0
 80034d2:	207a      	movs	r0, #122	@ 0x7a
 80034d4:	f7ff f932 	bl	800273c <putch>
 80034d8:	f3c4 1307 	ubfx	r3, r4, #4, #8
 80034dc:	f004 040f 	and.w	r4, r4, #15
 80034e0:	5ce8      	ldrb	r0, [r5, r3]
 80034e2:	f7ff f92b 	bl	800273c <putch>
 80034e6:	5d28      	ldrb	r0, [r5, r4]
 80034e8:	f7ff f928 	bl	800273c <putch>
 80034ec:	200a      	movs	r0, #10
 80034ee:	f7ff f925 	bl	800273c <putch>
 80034f2:	e7c0      	b.n	8003476 <simpleserial_get+0x66>
 80034f4:	20000a20 	.word	0x20000a20
 80034f8:	08003640 	.word	0x08003640

080034fc <simpleserial_put>:
 80034fc:	b10a      	cbz	r2, 8003502 <simpleserial_put+0x6>
 80034fe:	f7ff be83 	b.w	8003208 <simpleserial_put.part.0>
 8003502:	4770      	bx	lr

08003504 <Reset_Handler>:
 8003504:	2100      	movs	r1, #0
 8003506:	e003      	b.n	8003510 <LoopCopyDataInit>

08003508 <CopyDataInit>:
 8003508:	4b0b      	ldr	r3, [pc, #44]	@ (8003538 <LoopForever+0x2>)
 800350a:	585b      	ldr	r3, [r3, r1]
 800350c:	5043      	str	r3, [r0, r1]
 800350e:	3104      	adds	r1, #4

08003510 <LoopCopyDataInit>:
 8003510:	480a      	ldr	r0, [pc, #40]	@ (800353c <LoopForever+0x6>)
 8003512:	4b0b      	ldr	r3, [pc, #44]	@ (8003540 <LoopForever+0xa>)
 8003514:	1842      	adds	r2, r0, r1
 8003516:	429a      	cmp	r2, r3
 8003518:	d3f6      	bcc.n	8003508 <CopyDataInit>
 800351a:	4a0a      	ldr	r2, [pc, #40]	@ (8003544 <LoopForever+0xe>)
 800351c:	e002      	b.n	8003524 <LoopFillZerobss>

0800351e <FillZerobss>:
 800351e:	2300      	movs	r3, #0
 8003520:	6013      	str	r3, [r2, #0]
 8003522:	3204      	adds	r2, #4

08003524 <LoopFillZerobss>:
 8003524:	4b08      	ldr	r3, [pc, #32]	@ (8003548 <LoopForever+0x12>)
 8003526:	429a      	cmp	r2, r3
 8003528:	d3f9      	bcc.n	800351e <FillZerobss>
 800352a:	f3af 8000 	nop.w
 800352e:	f7fc ff09 	bl	8000344 <__libc_init_array>
 8003532:	f7fd fcdb 	bl	8000eec <main>

08003536 <LoopForever>:
 8003536:	e7fe      	b.n	8003536 <LoopForever>
 8003538:	0800367c 	.word	0x0800367c
 800353c:	20000000 	.word	0x20000000
 8003540:	20000538 	.word	0x20000538
 8003544:	20000538 	.word	0x20000538
 8003548:	20000f2c 	.word	0x20000f2c

0800354c <BusFault_Handler>:
 800354c:	e7fe      	b.n	800354c <BusFault_Handler>
	...

08003550 <register_fini>:
 8003550:	4b02      	ldr	r3, [pc, #8]	@ (800355c <register_fini+0xc>)
 8003552:	b113      	cbz	r3, 800355a <register_fini+0xa>
 8003554:	4802      	ldr	r0, [pc, #8]	@ (8003560 <register_fini+0x10>)
 8003556:	f7fc bfa3 	b.w	80004a0 <atexit>
 800355a:	4770      	bx	lr
 800355c:	00000000 	.word	0x00000000
 8003560:	080003a1 	.word	0x080003a1

08003564 <_init>:
 8003564:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 8003566:	bf00      	nop
 8003568:	bcf8      	pop	{r3, r4, r5, r6, r7}
 800356a:	bc08      	pop	{r3}
 800356c:	469e      	mov	lr, r3
 800356e:	4770      	bx	lr

08003570 <_fini>:
 8003570:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 8003572:	bf00      	nop
 8003574:	bcf8      	pop	{r3, r4, r5, r6, r7}
 8003576:	bc08      	pop	{r3}
 8003578:	469e      	mov	lr, r3
 800357a:	4770      	bx	lr
