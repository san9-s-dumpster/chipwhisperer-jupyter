
/home/ubuntu/Desktop/work/chipwhisperer-new/jupyter/courses/custom/mlkem-samplentt-power-lab/firmware/variable_time_calibration/samplentt-variable_time_calibration-CW308_STM32F4.elf:     file format elf32-littlearm


Disassembly of section .text:

08000188 <deregister_tm_clones>:
 8000188:	4803      	ldr	r0, [pc, #12]	@ (8000198 <deregister_tm_clones+0x10>)
 800018a:	4b04      	ldr	r3, [pc, #16]	@ (800019c <deregister_tm_clones+0x14>)
 800018c:	4283      	cmp	r3, r0
 800018e:	d002      	beq.n	8000196 <deregister_tm_clones+0xe>
 8000190:	4b03      	ldr	r3, [pc, #12]	@ (80001a0 <deregister_tm_clones+0x18>)
 8000192:	b103      	cbz	r3, 8000196 <deregister_tm_clones+0xe>
 8000194:	4718      	bx	r3
 8000196:	4770      	bx	lr
 8000198:	20000538 	.word	0x20000538
 800019c:	20000538 	.word	0x20000538
 80001a0:	00000000 	.word	0x00000000

080001a4 <register_tm_clones>:
 80001a4:	4805      	ldr	r0, [pc, #20]	@ (80001bc <register_tm_clones+0x18>)
 80001a6:	4b06      	ldr	r3, [pc, #24]	@ (80001c0 <register_tm_clones+0x1c>)
 80001a8:	1a1b      	subs	r3, r3, r0
 80001aa:	0fd9      	lsrs	r1, r3, #31
 80001ac:	eb01 01a3 	add.w	r1, r1, r3, asr #2
 80001b0:	1049      	asrs	r1, r1, #1
 80001b2:	d002      	beq.n	80001ba <register_tm_clones+0x16>
 80001b4:	4b03      	ldr	r3, [pc, #12]	@ (80001c4 <register_tm_clones+0x20>)
 80001b6:	b103      	cbz	r3, 80001ba <register_tm_clones+0x16>
 80001b8:	4718      	bx	r3
 80001ba:	4770      	bx	lr
 80001bc:	20000538 	.word	0x20000538
 80001c0:	20000538 	.word	0x20000538
 80001c4:	00000000 	.word	0x00000000

080001c8 <__do_global_dtors_aux>:
 80001c8:	b510      	push	{r4, lr}
 80001ca:	4c06      	ldr	r4, [pc, #24]	@ (80001e4 <__do_global_dtors_aux+0x1c>)
 80001cc:	7823      	ldrb	r3, [r4, #0]
 80001ce:	b943      	cbnz	r3, 80001e2 <__do_global_dtors_aux+0x1a>
 80001d0:	f7ff ffda 	bl	8000188 <deregister_tm_clones>
 80001d4:	4b04      	ldr	r3, [pc, #16]	@ (80001e8 <__do_global_dtors_aux+0x20>)
 80001d6:	b113      	cbz	r3, 80001de <__do_global_dtors_aux+0x16>
 80001d8:	4804      	ldr	r0, [pc, #16]	@ (80001ec <__do_global_dtors_aux+0x24>)
 80001da:	f3af 8000 	nop.w
 80001de:	2301      	movs	r3, #1
 80001e0:	7023      	strb	r3, [r4, #0]
 80001e2:	bd10      	pop	{r4, pc}
 80001e4:	20000538 	.word	0x20000538
 80001e8:	00000000 	.word	0x00000000
 80001ec:	08003644 	.word	0x08003644

080001f0 <frame_dummy>:
 80001f0:	b508      	push	{r3, lr}
 80001f2:	4b04      	ldr	r3, [pc, #16]	@ (8000204 <frame_dummy+0x14>)
 80001f4:	b11b      	cbz	r3, 80001fe <frame_dummy+0xe>
 80001f6:	4904      	ldr	r1, [pc, #16]	@ (8000208 <frame_dummy+0x18>)
 80001f8:	4804      	ldr	r0, [pc, #16]	@ (800020c <frame_dummy+0x1c>)
 80001fa:	f3af 8000 	nop.w
 80001fe:	e8bd 4008 	ldmia.w	sp!, {r3, lr}
 8000202:	e7cf      	b.n	80001a4 <register_tm_clones>
 8000204:	00000000 	.word	0x00000000
 8000208:	2000053c 	.word	0x2000053c
 800020c:	08003644 	.word	0x08003644

08000210 <memcpy>:
 8000210:	4684      	mov	ip, r0
 8000212:	ea41 0300 	orr.w	r3, r1, r0
 8000216:	f013 0303 	ands.w	r3, r3, #3
 800021a:	d16d      	bne.n	80002f8 <memcpy+0xe8>
 800021c:	3a40      	subs	r2, #64	@ 0x40
 800021e:	d341      	bcc.n	80002a4 <memcpy+0x94>
 8000220:	f851 3b04 	ldr.w	r3, [r1], #4
 8000224:	f840 3b04 	str.w	r3, [r0], #4
 8000228:	f851 3b04 	ldr.w	r3, [r1], #4
 800022c:	f840 3b04 	str.w	r3, [r0], #4
 8000230:	f851 3b04 	ldr.w	r3, [r1], #4
 8000234:	f840 3b04 	str.w	r3, [r0], #4
 8000238:	f851 3b04 	ldr.w	r3, [r1], #4
 800023c:	f840 3b04 	str.w	r3, [r0], #4
 8000240:	f851 3b04 	ldr.w	r3, [r1], #4
 8000244:	f840 3b04 	str.w	r3, [r0], #4
 8000248:	f851 3b04 	ldr.w	r3, [r1], #4
 800024c:	f840 3b04 	str.w	r3, [r0], #4
 8000250:	f851 3b04 	ldr.w	r3, [r1], #4
 8000254:	f840 3b04 	str.w	r3, [r0], #4
 8000258:	f851 3b04 	ldr.w	r3, [r1], #4
 800025c:	f840 3b04 	str.w	r3, [r0], #4
 8000260:	f851 3b04 	ldr.w	r3, [r1], #4
 8000264:	f840 3b04 	str.w	r3, [r0], #4
 8000268:	f851 3b04 	ldr.w	r3, [r1], #4
 800026c:	f840 3b04 	str.w	r3, [r0], #4
 8000270:	f851 3b04 	ldr.w	r3, [r1], #4
 8000274:	f840 3b04 	str.w	r3, [r0], #4
 8000278:	f851 3b04 	ldr.w	r3, [r1], #4
 800027c:	f840 3b04 	str.w	r3, [r0], #4
 8000280:	f851 3b04 	ldr.w	r3, [r1], #4
 8000284:	f840 3b04 	str.w	r3, [r0], #4
 8000288:	f851 3b04 	ldr.w	r3, [r1], #4
 800028c:	f840 3b04 	str.w	r3, [r0], #4
 8000290:	f851 3b04 	ldr.w	r3, [r1], #4
 8000294:	f840 3b04 	str.w	r3, [r0], #4
 8000298:	f851 3b04 	ldr.w	r3, [r1], #4
 800029c:	f840 3b04 	str.w	r3, [r0], #4
 80002a0:	3a40      	subs	r2, #64	@ 0x40
 80002a2:	d2bd      	bcs.n	8000220 <memcpy+0x10>
 80002a4:	3230      	adds	r2, #48	@ 0x30
 80002a6:	d311      	bcc.n	80002cc <memcpy+0xbc>
 80002a8:	f851 3b04 	ldr.w	r3, [r1], #4
 80002ac:	f840 3b04 	str.w	r3, [r0], #4
 80002b0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002b4:	f840 3b04 	str.w	r3, [r0], #4
 80002b8:	f851 3b04 	ldr.w	r3, [r1], #4
 80002bc:	f840 3b04 	str.w	r3, [r0], #4
 80002c0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002c4:	f840 3b04 	str.w	r3, [r0], #4
 80002c8:	3a10      	subs	r2, #16
 80002ca:	d2ed      	bcs.n	80002a8 <memcpy+0x98>
 80002cc:	320c      	adds	r2, #12
 80002ce:	d305      	bcc.n	80002dc <memcpy+0xcc>
 80002d0:	f851 3b04 	ldr.w	r3, [r1], #4
 80002d4:	f840 3b04 	str.w	r3, [r0], #4
 80002d8:	3a04      	subs	r2, #4
 80002da:	d2f9      	bcs.n	80002d0 <memcpy+0xc0>
 80002dc:	3204      	adds	r2, #4
 80002de:	d008      	beq.n	80002f2 <memcpy+0xe2>
 80002e0:	07d2      	lsls	r2, r2, #31
 80002e2:	bf1c      	itt	ne
 80002e4:	f811 3b01 	ldrbne.w	r3, [r1], #1
 80002e8:	f800 3b01 	strbne.w	r3, [r0], #1
 80002ec:	d301      	bcc.n	80002f2 <memcpy+0xe2>
 80002ee:	880b      	ldrh	r3, [r1, #0]
 80002f0:	8003      	strh	r3, [r0, #0]
 80002f2:	4660      	mov	r0, ip
 80002f4:	4770      	bx	lr
 80002f6:	bf00      	nop
 80002f8:	2a08      	cmp	r2, #8
 80002fa:	d313      	bcc.n	8000324 <memcpy+0x114>
 80002fc:	078b      	lsls	r3, r1, #30
 80002fe:	d08d      	beq.n	800021c <memcpy+0xc>
 8000300:	f010 0303 	ands.w	r3, r0, #3
 8000304:	d08a      	beq.n	800021c <memcpy+0xc>
 8000306:	f1c3 0304 	rsb	r3, r3, #4
 800030a:	1ad2      	subs	r2, r2, r3
 800030c:	07db      	lsls	r3, r3, #31
 800030e:	bf1c      	itt	ne
 8000310:	f811 3b01 	ldrbne.w	r3, [r1], #1
 8000314:	f800 3b01 	strbne.w	r3, [r0], #1
 8000318:	d380      	bcc.n	800021c <memcpy+0xc>
 800031a:	f831 3b02 	ldrh.w	r3, [r1], #2
 800031e:	f820 3b02 	strh.w	r3, [r0], #2
 8000322:	e77b      	b.n	800021c <memcpy+0xc>
 8000324:	3a04      	subs	r2, #4
 8000326:	d3d9      	bcc.n	80002dc <memcpy+0xcc>
 8000328:	3a01      	subs	r2, #1
 800032a:	f811 3b01 	ldrb.w	r3, [r1], #1
 800032e:	f800 3b01 	strb.w	r3, [r0], #1
 8000332:	d2f9      	bcs.n	8000328 <memcpy+0x118>
 8000334:	780b      	ldrb	r3, [r1, #0]
 8000336:	7003      	strb	r3, [r0, #0]
 8000338:	784b      	ldrb	r3, [r1, #1]
 800033a:	7043      	strb	r3, [r0, #1]
 800033c:	788b      	ldrb	r3, [r1, #2]
 800033e:	7083      	strb	r3, [r0, #2]
 8000340:	4660      	mov	r0, ip
 8000342:	4770      	bx	lr

08000344 <__libc_init_array>:
 8000344:	b570      	push	{r4, r5, r6, lr}
 8000346:	4b0f      	ldr	r3, [pc, #60]	@ (8000384 <__libc_init_array+0x40>)
 8000348:	4d0f      	ldr	r5, [pc, #60]	@ (8000388 <__libc_init_array+0x44>)
 800034a:	42ab      	cmp	r3, r5
 800034c:	eba3 0605 	sub.w	r6, r3, r5
 8000350:	d007      	beq.n	8000362 <__libc_init_array+0x1e>
 8000352:	10b6      	asrs	r6, r6, #2
 8000354:	2400      	movs	r4, #0
 8000356:	f855 3b04 	ldr.w	r3, [r5], #4
 800035a:	3401      	adds	r4, #1
 800035c:	4798      	blx	r3
 800035e:	42a6      	cmp	r6, r4
 8000360:	d8f9      	bhi.n	8000356 <__libc_init_array+0x12>
 8000362:	f003 f96f 	bl	8003644 <_init>
 8000366:	4d09      	ldr	r5, [pc, #36]	@ (800038c <__libc_init_array+0x48>)
 8000368:	4b09      	ldr	r3, [pc, #36]	@ (8000390 <__libc_init_array+0x4c>)
 800036a:	1b5e      	subs	r6, r3, r5
 800036c:	42ab      	cmp	r3, r5
 800036e:	ea4f 06a6 	mov.w	r6, r6, asr #2
 8000372:	d006      	beq.n	8000382 <__libc_init_array+0x3e>
 8000374:	2400      	movs	r4, #0
 8000376:	f855 3b04 	ldr.w	r3, [r5], #4
 800037a:	3401      	adds	r4, #1
 800037c:	4798      	blx	r3
 800037e:	42a6      	cmp	r6, r4
 8000380:	d8f9      	bhi.n	8000376 <__libc_init_array+0x32>
 8000382:	bd70      	pop	{r4, r5, r6, pc}
 8000384:	08003750 	.word	0x08003750
 8000388:	08003750 	.word	0x08003750
 800038c:	08003750 	.word	0x08003750
 8000390:	08003758 	.word	0x08003758

08000394 <__errno>:
 8000394:	4b01      	ldr	r3, [pc, #4]	@ (800039c <__errno+0x8>)
 8000396:	6818      	ldr	r0, [r3, #0]
 8000398:	4770      	bx	lr
 800039a:	bf00      	nop
 800039c:	20000000 	.word	0x20000000

080003a0 <__libc_fini_array>:
 80003a0:	b538      	push	{r3, r4, r5, lr}
 80003a2:	4d07      	ldr	r5, [pc, #28]	@ (80003c0 <__libc_fini_array+0x20>)
 80003a4:	4c07      	ldr	r4, [pc, #28]	@ (80003c4 <__libc_fini_array+0x24>)
 80003a6:	1b2c      	subs	r4, r5, r4
 80003a8:	10a4      	asrs	r4, r4, #2
 80003aa:	d005      	beq.n	80003b8 <__libc_fini_array+0x18>
 80003ac:	3c01      	subs	r4, #1
 80003ae:	f855 3d04 	ldr.w	r3, [r5, #-4]!
 80003b2:	4798      	blx	r3
 80003b4:	2c00      	cmp	r4, #0
 80003b6:	d1f9      	bne.n	80003ac <__libc_fini_array+0xc>
 80003b8:	e8bd 4038 	ldmia.w	sp!, {r3, r4, r5, lr}
 80003bc:	f003 b948 	b.w	8003650 <_fini>
 80003c0:	0800375c 	.word	0x0800375c
 80003c4:	08003758 	.word	0x08003758

080003c8 <malloc>:
 80003c8:	4b02      	ldr	r3, [pc, #8]	@ (80003d4 <malloc+0xc>)
 80003ca:	4601      	mov	r1, r0
 80003cc:	6818      	ldr	r0, [r3, #0]
 80003ce:	f000 b86d 	b.w	80004ac <_malloc_r>
 80003d2:	bf00      	nop
 80003d4:	20000000 	.word	0x20000000

080003d8 <free>:
 80003d8:	4b02      	ldr	r3, [pc, #8]	@ (80003e4 <free+0xc>)
 80003da:	4601      	mov	r1, r0
 80003dc:	6818      	ldr	r0, [r3, #0]
 80003de:	f000 bb9b 	b.w	8000b18 <_free_r>
 80003e2:	bf00      	nop
 80003e4:	20000000 	.word	0x20000000

080003e8 <memset>:
 80003e8:	0783      	lsls	r3, r0, #30
 80003ea:	b530      	push	{r4, r5, lr}
 80003ec:	d046      	beq.n	800047c <memset+0x94>
 80003ee:	1884      	adds	r4, r0, r2
 80003f0:	4684      	mov	ip, r0
 80003f2:	e004      	b.n	80003fe <memset+0x16>
 80003f4:	f803 1b01 	strb.w	r1, [r3], #1
 80003f8:	079d      	lsls	r5, r3, #30
 80003fa:	d004      	beq.n	8000406 <memset+0x1e>
 80003fc:	469c      	mov	ip, r3
 80003fe:	45a4      	cmp	ip, r4
 8000400:	4663      	mov	r3, ip
 8000402:	d1f7      	bne.n	80003f4 <memset+0xc>
 8000404:	bd30      	pop	{r4, r5, pc}
 8000406:	3a01      	subs	r2, #1
 8000408:	4402      	add	r2, r0
 800040a:	eba2 020c 	sub.w	r2, r2, ip
 800040e:	2a03      	cmp	r2, #3
 8000410:	d929      	bls.n	8000466 <memset+0x7e>
 8000412:	b2cc      	uxtb	r4, r1
 8000414:	eb04 2404 	add.w	r4, r4, r4, lsl #8
 8000418:	2a0f      	cmp	r2, #15
 800041a:	eb04 4404 	add.w	r4, r4, r4, lsl #16
 800041e:	d92f      	bls.n	8000480 <memset+0x98>
 8000420:	f1a2 0c10 	sub.w	ip, r2, #16
 8000424:	f02c 0c0f 	bic.w	ip, ip, #15
 8000428:	f103 0510 	add.w	r5, r3, #16
 800042c:	44ac      	add	ip, r5
 800042e:	e9c3 4400 	strd	r4, r4, [r3]
 8000432:	e9c3 4402 	strd	r4, r4, [r3, #8]
 8000436:	3310      	adds	r3, #16
 8000438:	4563      	cmp	r3, ip
 800043a:	d1f8      	bne.n	800042e <memset+0x46>
 800043c:	f012 0f0c 	tst.w	r2, #12
 8000440:	f002 0e0f 	and.w	lr, r2, #15
 8000444:	d018      	beq.n	8000478 <memset+0x90>
 8000446:	f02e 0c03 	bic.w	ip, lr, #3
 800044a:	449c      	add	ip, r3
 800044c:	f1ae 0504 	sub.w	r5, lr, #4
 8000450:	461a      	mov	r2, r3
 8000452:	f842 4b04 	str.w	r4, [r2], #4
 8000456:	4562      	cmp	r2, ip
 8000458:	d1fb      	bne.n	8000452 <memset+0x6a>
 800045a:	f025 0403 	bic.w	r4, r5, #3
 800045e:	3304      	adds	r3, #4
 8000460:	f00e 0203 	and.w	r2, lr, #3
 8000464:	4423      	add	r3, r4
 8000466:	2a00      	cmp	r2, #0
 8000468:	d0cc      	beq.n	8000404 <memset+0x1c>
 800046a:	b2c9      	uxtb	r1, r1
 800046c:	441a      	add	r2, r3
 800046e:	f803 1b01 	strb.w	r1, [r3], #1
 8000472:	4293      	cmp	r3, r2
 8000474:	d1fb      	bne.n	800046e <memset+0x86>
 8000476:	bd30      	pop	{r4, r5, pc}
 8000478:	4672      	mov	r2, lr
 800047a:	e7f4      	b.n	8000466 <memset+0x7e>
 800047c:	4603      	mov	r3, r0
 800047e:	e7c6      	b.n	800040e <memset+0x26>
 8000480:	4696      	mov	lr, r2
 8000482:	e7e0      	b.n	8000446 <memset+0x5e>

08000484 <exit>:
 8000484:	b508      	push	{r3, lr}
 8000486:	2100      	movs	r1, #0
 8000488:	4604      	mov	r4, r0
 800048a:	f000 fc3d 	bl	8000d08 <__call_exitprocs>
 800048e:	4b03      	ldr	r3, [pc, #12]	@ (800049c <exit+0x18>)
 8000490:	681b      	ldr	r3, [r3, #0]
 8000492:	b103      	cbz	r3, 8000496 <exit+0x12>
 8000494:	4798      	blx	r3
 8000496:	4620      	mov	r0, r4
 8000498:	f000 fcd2 	bl	8000e40 <_exit>
 800049c:	20000d7c 	.word	0x20000d7c

080004a0 <atexit>:
 80004a0:	2300      	movs	r3, #0
 80004a2:	4601      	mov	r1, r0
 80004a4:	461a      	mov	r2, r3
 80004a6:	4618      	mov	r0, r3
 80004a8:	f000 bc86 	b.w	8000db8 <__register_exitproc>

080004ac <_malloc_r>:
 80004ac:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 80004b0:	f101 050b 	add.w	r5, r1, #11
 80004b4:	2d16      	cmp	r5, #22
 80004b6:	b083      	sub	sp, #12
 80004b8:	4606      	mov	r6, r0
 80004ba:	d823      	bhi.n	8000504 <_malloc_r+0x58>
 80004bc:	2910      	cmp	r1, #16
 80004be:	f200 80b4 	bhi.w	800062a <_malloc_r+0x17e>
 80004c2:	f000 fcab 	bl	8000e1c <__malloc_lock>
 80004c6:	2510      	movs	r5, #16
 80004c8:	2318      	movs	r3, #24
 80004ca:	2002      	movs	r0, #2
 80004cc:	4fc6      	ldr	r7, [pc, #792]	@ (80007e8 <_malloc_r+0x33c>)
 80004ce:	443b      	add	r3, r7
 80004d0:	f1a3 0208 	sub.w	r2, r3, #8
 80004d4:	685c      	ldr	r4, [r3, #4]
 80004d6:	4294      	cmp	r4, r2
 80004d8:	f000 816c 	beq.w	80007b4 <_malloc_r+0x308>
 80004dc:	6863      	ldr	r3, [r4, #4]
 80004de:	68e2      	ldr	r2, [r4, #12]
 80004e0:	68a1      	ldr	r1, [r4, #8]
 80004e2:	f023 0303 	bic.w	r3, r3, #3
 80004e6:	60ca      	str	r2, [r1, #12]
 80004e8:	4423      	add	r3, r4
 80004ea:	4630      	mov	r0, r6
 80004ec:	6091      	str	r1, [r2, #8]
 80004ee:	685a      	ldr	r2, [r3, #4]
 80004f0:	f042 0201 	orr.w	r2, r2, #1
 80004f4:	605a      	str	r2, [r3, #4]
 80004f6:	f000 fc93 	bl	8000e20 <__malloc_unlock>
 80004fa:	3408      	adds	r4, #8
 80004fc:	4620      	mov	r0, r4
 80004fe:	b003      	add	sp, #12
 8000500:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000504:	f035 0507 	bics.w	r5, r5, #7
 8000508:	f100 808f 	bmi.w	800062a <_malloc_r+0x17e>
 800050c:	42a9      	cmp	r1, r5
 800050e:	f200 808c 	bhi.w	800062a <_malloc_r+0x17e>
 8000512:	f000 fc83 	bl	8000e1c <__malloc_lock>
 8000516:	f5b5 7ffc 	cmp.w	r5, #504	@ 0x1f8
 800051a:	f0c0 81b9 	bcc.w	8000890 <_malloc_r+0x3e4>
 800051e:	ea5f 2e55 	movs.w	lr, r5, lsr #9
 8000522:	f000 8089 	beq.w	8000638 <_malloc_r+0x18c>
 8000526:	f1be 0f04 	cmp.w	lr, #4
 800052a:	f200 8171 	bhi.w	8000810 <_malloc_r+0x364>
 800052e:	ea4f 1e95 	mov.w	lr, r5, lsr #6
 8000532:	f10e 0039 	add.w	r0, lr, #57	@ 0x39
 8000536:	b203      	sxth	r3, r0
 8000538:	f10e 0e38 	add.w	lr, lr, #56	@ 0x38
 800053c:	00db      	lsls	r3, r3, #3
 800053e:	4faa      	ldr	r7, [pc, #680]	@ (80007e8 <_malloc_r+0x33c>)
 8000540:	443b      	add	r3, r7
 8000542:	f1a3 0c08 	sub.w	ip, r3, #8
 8000546:	685c      	ldr	r4, [r3, #4]
 8000548:	45a4      	cmp	ip, r4
 800054a:	d107      	bne.n	800055c <_malloc_r+0xb0>
 800054c:	e00d      	b.n	800056a <_malloc_r+0xbe>
 800054e:	2a00      	cmp	r2, #0
 8000550:	68e1      	ldr	r1, [r4, #12]
 8000552:	f280 8129 	bge.w	80007a8 <_malloc_r+0x2fc>
 8000556:	458c      	cmp	ip, r1
 8000558:	d007      	beq.n	800056a <_malloc_r+0xbe>
 800055a:	460c      	mov	r4, r1
 800055c:	6863      	ldr	r3, [r4, #4]
 800055e:	f023 0303 	bic.w	r3, r3, #3
 8000562:	1b5a      	subs	r2, r3, r5
 8000564:	2a0f      	cmp	r2, #15
 8000566:	ddf2      	ble.n	800054e <_malloc_r+0xa2>
 8000568:	4670      	mov	r0, lr
 800056a:	f8df 8280 	ldr.w	r8, [pc, #640]	@ 80007ec <_malloc_r+0x340>
 800056e:	693c      	ldr	r4, [r7, #16]
 8000570:	4544      	cmp	r4, r8
 8000572:	f000 8106 	beq.w	8000782 <_malloc_r+0x2d6>
 8000576:	6863      	ldr	r3, [r4, #4]
 8000578:	f023 0c03 	bic.w	ip, r3, #3
 800057c:	ebac 0305 	sub.w	r3, ip, r5
 8000580:	2b0f      	cmp	r3, #15
 8000582:	f300 818a 	bgt.w	800089a <_malloc_r+0x3ee>
 8000586:	2b00      	cmp	r3, #0
 8000588:	e9c7 8804 	strd	r8, r8, [r7, #16]
 800058c:	f280 8174 	bge.w	8000878 <_malloc_r+0x3cc>
 8000590:	f5bc 7f00 	cmp.w	ip, #512	@ 0x200
 8000594:	f8d7 e004 	ldr.w	lr, [r7, #4]
 8000598:	f080 8112 	bcs.w	80007c0 <_malloc_r+0x314>
 800059c:	ea4f 03dc 	mov.w	r3, ip, lsr #3
 80005a0:	3301      	adds	r3, #1
 80005a2:	b219      	sxth	r1, r3
 80005a4:	ea4f 1c5c 	mov.w	ip, ip, lsr #5
 80005a8:	2301      	movs	r3, #1
 80005aa:	fa03 f30c 	lsl.w	r3, r3, ip
 80005ae:	f857 2031 	ldr.w	r2, [r7, r1, lsl #3]
 80005b2:	60a2      	str	r2, [r4, #8]
 80005b4:	ea4e 0e03 	orr.w	lr, lr, r3
 80005b8:	eb07 03c1 	add.w	r3, r7, r1, lsl #3
 80005bc:	3b08      	subs	r3, #8
 80005be:	60e3      	str	r3, [r4, #12]
 80005c0:	f8c7 e004 	str.w	lr, [r7, #4]
 80005c4:	f847 4031 	str.w	r4, [r7, r1, lsl #3]
 80005c8:	60d4      	str	r4, [r2, #12]
 80005ca:	1083      	asrs	r3, r0, #2
 80005cc:	f04f 0c01 	mov.w	ip, #1
 80005d0:	fa0c fc03 	lsl.w	ip, ip, r3
 80005d4:	45f4      	cmp	ip, lr
 80005d6:	d835      	bhi.n	8000644 <_malloc_r+0x198>
 80005d8:	ea1c 0f0e 	tst.w	ip, lr
 80005dc:	d108      	bne.n	80005f0 <_malloc_r+0x144>
 80005de:	f020 0003 	bic.w	r0, r0, #3
 80005e2:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 80005e6:	ea1c 0f0e 	tst.w	ip, lr
 80005ea:	f100 0004 	add.w	r0, r0, #4
 80005ee:	d0f8      	beq.n	80005e2 <_malloc_r+0x136>
 80005f0:	eb07 0ac0 	add.w	sl, r7, r0, lsl #3
 80005f4:	46d6      	mov	lr, sl
 80005f6:	4681      	mov	r9, r0
 80005f8:	f8de 300c 	ldr.w	r3, [lr, #12]
 80005fc:	e00b      	b.n	8000616 <_malloc_r+0x16a>
 80005fe:	6859      	ldr	r1, [r3, #4]
 8000600:	f021 0103 	bic.w	r1, r1, #3
 8000604:	1b4a      	subs	r2, r1, r5
 8000606:	2a0f      	cmp	r2, #15
 8000608:	461c      	mov	r4, r3
 800060a:	68db      	ldr	r3, [r3, #12]
 800060c:	f300 8110 	bgt.w	8000830 <_malloc_r+0x384>
 8000610:	2a00      	cmp	r2, #0
 8000612:	f280 8124 	bge.w	800085e <_malloc_r+0x3b2>
 8000616:	459e      	cmp	lr, r3
 8000618:	d1f1      	bne.n	80005fe <_malloc_r+0x152>
 800061a:	f109 0901 	add.w	r9, r9, #1
 800061e:	f019 0f03 	tst.w	r9, #3
 8000622:	f10e 0e08 	add.w	lr, lr, #8
 8000626:	d1e7      	bne.n	80005f8 <_malloc_r+0x14c>
 8000628:	e162      	b.n	80008f0 <_malloc_r+0x444>
 800062a:	230c      	movs	r3, #12
 800062c:	6033      	str	r3, [r6, #0]
 800062e:	2400      	movs	r4, #0
 8000630:	4620      	mov	r0, r4
 8000632:	b003      	add	sp, #12
 8000634:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000638:	f44f 7300 	mov.w	r3, #512	@ 0x200
 800063c:	2040      	movs	r0, #64	@ 0x40
 800063e:	f04f 0e3f 	mov.w	lr, #63	@ 0x3f
 8000642:	e77c      	b.n	800053e <_malloc_r+0x92>
 8000644:	68bc      	ldr	r4, [r7, #8]
 8000646:	6863      	ldr	r3, [r4, #4]
 8000648:	f023 0903 	bic.w	r9, r3, #3
 800064c:	45a9      	cmp	r9, r5
 800064e:	d304      	bcc.n	800065a <_malloc_r+0x1ae>
 8000650:	eba9 0305 	sub.w	r3, r9, r5
 8000654:	2b0f      	cmp	r3, #15
 8000656:	f300 8097 	bgt.w	8000788 <_malloc_r+0x2dc>
 800065a:	f8df b194 	ldr.w	fp, [pc, #404]	@ 80007f0 <_malloc_r+0x344>
 800065e:	f8db 2000 	ldr.w	r2, [fp]
 8000662:	eb04 0309 	add.w	r3, r4, r9
 8000666:	3210      	adds	r2, #16
 8000668:	2008      	movs	r0, #8
 800066a:	eb02 0805 	add.w	r8, r2, r5
 800066e:	9300      	str	r3, [sp, #0]
 8000670:	f000 fbd8 	bl	8000e24 <sysconf>
 8000674:	f8d7 1408 	ldr.w	r1, [r7, #1032]	@ 0x408
 8000678:	3101      	adds	r1, #1
 800067a:	4602      	mov	r2, r0
 800067c:	d005      	beq.n	800068a <_malloc_r+0x1de>
 800067e:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 8000682:	4480      	add	r8, r0
 8000684:	4241      	negs	r1, r0
 8000686:	ea01 0808 	and.w	r8, r1, r8
 800068a:	4641      	mov	r1, r8
 800068c:	4630      	mov	r0, r6
 800068e:	9200      	str	r2, [sp, #0]
 8000690:	f000 f9d4 	bl	8000a3c <_sbrk_r>
 8000694:	f1b0 3fff 	cmp.w	r0, #4294967295	@ 0xffffffff
 8000698:	9a00      	ldr	r2, [sp, #0]
 800069a:	4682      	mov	sl, r0
 800069c:	f000 8119 	beq.w	80008d2 <_malloc_r+0x426>
 80006a0:	eb04 0309 	add.w	r3, r4, r9
 80006a4:	4283      	cmp	r3, r0
 80006a6:	f200 8112 	bhi.w	80008ce <_malloc_r+0x422>
 80006aa:	f8db 1004 	ldr.w	r1, [fp, #4]
 80006ae:	4441      	add	r1, r8
 80006b0:	f8cb 1004 	str.w	r1, [fp, #4]
 80006b4:	f102 3cff 	add.w	ip, r2, #4294967295	@ 0xffffffff
 80006b8:	f000 816d 	beq.w	8000996 <_malloc_r+0x4ea>
 80006bc:	f8d7 0408 	ldr.w	r0, [r7, #1032]	@ 0x408
 80006c0:	3001      	adds	r0, #1
 80006c2:	f000 8174 	beq.w	80009ae <_malloc_r+0x502>
 80006c6:	eb04 0309 	add.w	r3, r4, r9
 80006ca:	ebaa 0303 	sub.w	r3, sl, r3
 80006ce:	4419      	add	r1, r3
 80006d0:	f8cb 1004 	str.w	r1, [fp, #4]
 80006d4:	f01a 0307 	ands.w	r3, sl, #7
 80006d8:	9300      	str	r3, [sp, #0]
 80006da:	f000 812e 	beq.w	800093a <_malloc_r+0x48e>
 80006de:	f1c3 0108 	rsb	r1, r3, #8
 80006e2:	448a      	add	sl, r1
 80006e4:	44d0      	add	r8, sl
 80006e6:	440a      	add	r2, r1
 80006e8:	ea08 010c 	and.w	r1, r8, ip
 80006ec:	1a52      	subs	r2, r2, r1
 80006ee:	ea02 010c 	and.w	r1, r2, ip
 80006f2:	4630      	mov	r0, r6
 80006f4:	9101      	str	r1, [sp, #4]
 80006f6:	f000 f9a1 	bl	8000a3c <_sbrk_r>
 80006fa:	1c42      	adds	r2, r0, #1
 80006fc:	f000 8174 	beq.w	80009e8 <_malloc_r+0x53c>
 8000700:	9901      	ldr	r1, [sp, #4]
 8000702:	eba0 000a 	sub.w	r0, r0, sl
 8000706:	eb00 0801 	add.w	r8, r0, r1
 800070a:	f8db 2004 	ldr.w	r2, [fp, #4]
 800070e:	f8c7 a008 	str.w	sl, [r7, #8]
 8000712:	f048 0001 	orr.w	r0, r8, #1
 8000716:	4411      	add	r1, r2
 8000718:	42bc      	cmp	r4, r7
 800071a:	f8ca 0004 	str.w	r0, [sl, #4]
 800071e:	f8cb 1004 	str.w	r1, [fp, #4]
 8000722:	d015      	beq.n	8000750 <_malloc_r+0x2a4>
 8000724:	f1b9 0f0f 	cmp.w	r9, #15
 8000728:	f240 8144 	bls.w	80009b4 <_malloc_r+0x508>
 800072c:	6862      	ldr	r2, [r4, #4]
 800072e:	f1a9 000c 	sub.w	r0, r9, #12
 8000732:	f020 0007 	bic.w	r0, r0, #7
 8000736:	f002 0201 	and.w	r2, r2, #1
 800073a:	4302      	orrs	r2, r0
 800073c:	6062      	str	r2, [r4, #4]
 800073e:	2305      	movs	r3, #5
 8000740:	1822      	adds	r2, r4, r0
 8000742:	280f      	cmp	r0, #15
 8000744:	e9c2 3301 	strd	r3, r3, [r2, #4]
 8000748:	f200 8156 	bhi.w	80009f8 <_malloc_r+0x54c>
 800074c:	f8da 0004 	ldr.w	r0, [sl, #4]
 8000750:	f8db 202c 	ldr.w	r2, [fp, #44]	@ 0x2c
 8000754:	428a      	cmp	r2, r1
 8000756:	f8db 2030 	ldr.w	r2, [fp, #48]	@ 0x30
 800075a:	bf38      	it	cc
 800075c:	f8cb 102c 	strcc.w	r1, [fp, #44]	@ 0x2c
 8000760:	428a      	cmp	r2, r1
 8000762:	bf38      	it	cc
 8000764:	f8cb 1030 	strcc.w	r1, [fp, #48]	@ 0x30
 8000768:	4654      	mov	r4, sl
 800076a:	f020 0803 	bic.w	r8, r0, #3
 800076e:	45a8      	cmp	r8, r5
 8000770:	eba8 0305 	sub.w	r3, r8, r5
 8000774:	d301      	bcc.n	800077a <_malloc_r+0x2ce>
 8000776:	2b0f      	cmp	r3, #15
 8000778:	dc06      	bgt.n	8000788 <_malloc_r+0x2dc>
 800077a:	4630      	mov	r0, r6
 800077c:	f000 fb50 	bl	8000e20 <__malloc_unlock>
 8000780:	e755      	b.n	800062e <_malloc_r+0x182>
 8000782:	f8d7 e004 	ldr.w	lr, [r7, #4]
 8000786:	e720      	b.n	80005ca <_malloc_r+0x11e>
 8000788:	1962      	adds	r2, r4, r5
 800078a:	f043 0301 	orr.w	r3, r3, #1
 800078e:	f045 0501 	orr.w	r5, r5, #1
 8000792:	6065      	str	r5, [r4, #4]
 8000794:	4630      	mov	r0, r6
 8000796:	60ba      	str	r2, [r7, #8]
 8000798:	6053      	str	r3, [r2, #4]
 800079a:	f000 fb41 	bl	8000e20 <__malloc_unlock>
 800079e:	3408      	adds	r4, #8
 80007a0:	4620      	mov	r0, r4
 80007a2:	b003      	add	sp, #12
 80007a4:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 80007a8:	68a2      	ldr	r2, [r4, #8]
 80007aa:	4423      	add	r3, r4
 80007ac:	60d1      	str	r1, [r2, #12]
 80007ae:	4630      	mov	r0, r6
 80007b0:	608a      	str	r2, [r1, #8]
 80007b2:	e69c      	b.n	80004ee <_malloc_r+0x42>
 80007b4:	68dc      	ldr	r4, [r3, #12]
 80007b6:	42a3      	cmp	r3, r4
 80007b8:	f47f ae90 	bne.w	80004dc <_malloc_r+0x30>
 80007bc:	3002      	adds	r0, #2
 80007be:	e6d4      	b.n	800056a <_malloc_r+0xbe>
 80007c0:	f5bc 6f20 	cmp.w	ip, #2560	@ 0xa00
 80007c4:	ea4f 225c 	mov.w	r2, ip, lsr #9
 80007c8:	d379      	bcc.n	80008be <_malloc_r+0x412>
 80007ca:	2a14      	cmp	r2, #20
 80007cc:	f200 80c5 	bhi.w	800095a <_malloc_r+0x4ae>
 80007d0:	f102 035c 	add.w	r3, r2, #92	@ 0x5c
 80007d4:	b21b      	sxth	r3, r3
 80007d6:	325b      	adds	r2, #91	@ 0x5b
 80007d8:	00db      	lsls	r3, r3, #3
 80007da:	18f9      	adds	r1, r7, r3
 80007dc:	58fb      	ldr	r3, [r7, r3]
 80007de:	3908      	subs	r1, #8
 80007e0:	4299      	cmp	r1, r3
 80007e2:	d10a      	bne.n	80007fa <_malloc_r+0x34e>
 80007e4:	e09f      	b.n	8000926 <_malloc_r+0x47a>
 80007e6:	bf00      	nop
 80007e8:	20000128 	.word	0x20000128
 80007ec:	20000130 	.word	0x20000130
 80007f0:	20000d80 	.word	0x20000d80
 80007f4:	689b      	ldr	r3, [r3, #8]
 80007f6:	4299      	cmp	r1, r3
 80007f8:	d004      	beq.n	8000804 <_malloc_r+0x358>
 80007fa:	685a      	ldr	r2, [r3, #4]
 80007fc:	f022 0203 	bic.w	r2, r2, #3
 8000800:	4562      	cmp	r2, ip
 8000802:	d8f7      	bhi.n	80007f4 <_malloc_r+0x348>
 8000804:	68d9      	ldr	r1, [r3, #12]
 8000806:	e9c4 3102 	strd	r3, r1, [r4, #8]
 800080a:	608c      	str	r4, [r1, #8]
 800080c:	60dc      	str	r4, [r3, #12]
 800080e:	e6dc      	b.n	80005ca <_malloc_r+0x11e>
 8000810:	f1be 0f14 	cmp.w	lr, #20
 8000814:	d960      	bls.n	80008d8 <_malloc_r+0x42c>
 8000816:	f1be 0f54 	cmp.w	lr, #84	@ 0x54
 800081a:	f200 80a8 	bhi.w	800096e <_malloc_r+0x4c2>
 800081e:	ea4f 3e15 	mov.w	lr, r5, lsr #12
 8000822:	f10e 006f 	add.w	r0, lr, #111	@ 0x6f
 8000826:	b203      	sxth	r3, r0
 8000828:	f10e 0e6e 	add.w	lr, lr, #110	@ 0x6e
 800082c:	00db      	lsls	r3, r3, #3
 800082e:	e686      	b.n	800053e <_malloc_r+0x92>
 8000830:	f8d4 c008 	ldr.w	ip, [r4, #8]
 8000834:	4630      	mov	r0, r6
 8000836:	1966      	adds	r6, r4, r5
 8000838:	f045 0501 	orr.w	r5, r5, #1
 800083c:	6065      	str	r5, [r4, #4]
 800083e:	f8cc 300c 	str.w	r3, [ip, #12]
 8000842:	f8c3 c008 	str.w	ip, [r3, #8]
 8000846:	f042 0301 	orr.w	r3, r2, #1
 800084a:	e9c7 6604 	strd	r6, r6, [r7, #16]
 800084e:	e9c6 8802 	strd	r8, r8, [r6, #8]
 8000852:	6073      	str	r3, [r6, #4]
 8000854:	5062      	str	r2, [r4, r1]
 8000856:	f000 fae3 	bl	8000e20 <__malloc_unlock>
 800085a:	3408      	adds	r4, #8
 800085c:	e6e8      	b.n	8000630 <_malloc_r+0x184>
 800085e:	4421      	add	r1, r4
 8000860:	4630      	mov	r0, r6
 8000862:	684a      	ldr	r2, [r1, #4]
 8000864:	f042 0201 	orr.w	r2, r2, #1
 8000868:	604a      	str	r2, [r1, #4]
 800086a:	f854 2f08 	ldr.w	r2, [r4, #8]!
 800086e:	60d3      	str	r3, [r2, #12]
 8000870:	609a      	str	r2, [r3, #8]
 8000872:	f000 fad5 	bl	8000e20 <__malloc_unlock>
 8000876:	e6db      	b.n	8000630 <_malloc_r+0x184>
 8000878:	44a4      	add	ip, r4
 800087a:	4630      	mov	r0, r6
 800087c:	f8dc 3004 	ldr.w	r3, [ip, #4]
 8000880:	f043 0301 	orr.w	r3, r3, #1
 8000884:	f8cc 3004 	str.w	r3, [ip, #4]
 8000888:	f000 faca 	bl	8000e20 <__malloc_unlock>
 800088c:	3408      	adds	r4, #8
 800088e:	e6cf      	b.n	8000630 <_malloc_r+0x184>
 8000890:	08e8      	lsrs	r0, r5, #3
 8000892:	1c43      	adds	r3, r0, #1
 8000894:	b21b      	sxth	r3, r3
 8000896:	00db      	lsls	r3, r3, #3
 8000898:	e618      	b.n	80004cc <_malloc_r+0x20>
 800089a:	1962      	adds	r2, r4, r5
 800089c:	f043 0101 	orr.w	r1, r3, #1
 80008a0:	f045 0501 	orr.w	r5, r5, #1
 80008a4:	6065      	str	r5, [r4, #4]
 80008a6:	4630      	mov	r0, r6
 80008a8:	e9c7 2204 	strd	r2, r2, [r7, #16]
 80008ac:	e9c2 8802 	strd	r8, r8, [r2, #8]
 80008b0:	6051      	str	r1, [r2, #4]
 80008b2:	f844 300c 	str.w	r3, [r4, ip]
 80008b6:	f000 fab3 	bl	8000e20 <__malloc_unlock>
 80008ba:	3408      	adds	r4, #8
 80008bc:	e6b8      	b.n	8000630 <_malloc_r+0x184>
 80008be:	ea4f 129c 	mov.w	r2, ip, lsr #6
 80008c2:	f102 0339 	add.w	r3, r2, #57	@ 0x39
 80008c6:	b21b      	sxth	r3, r3
 80008c8:	3238      	adds	r2, #56	@ 0x38
 80008ca:	00db      	lsls	r3, r3, #3
 80008cc:	e785      	b.n	80007da <_malloc_r+0x32e>
 80008ce:	42bc      	cmp	r4, r7
 80008d0:	d059      	beq.n	8000986 <_malloc_r+0x4da>
 80008d2:	68bc      	ldr	r4, [r7, #8]
 80008d4:	6860      	ldr	r0, [r4, #4]
 80008d6:	e748      	b.n	800076a <_malloc_r+0x2be>
 80008d8:	f10e 005c 	add.w	r0, lr, #92	@ 0x5c
 80008dc:	b203      	sxth	r3, r0
 80008de:	f10e 0e5b 	add.w	lr, lr, #91	@ 0x5b
 80008e2:	00db      	lsls	r3, r3, #3
 80008e4:	e62b      	b.n	800053e <_malloc_r+0x92>
 80008e6:	f85a 3908 	ldr.w	r3, [sl], #-8
 80008ea:	4553      	cmp	r3, sl
 80008ec:	f040 80a3 	bne.w	8000a36 <_malloc_r+0x58a>
 80008f0:	f010 0f03 	tst.w	r0, #3
 80008f4:	f100 30ff 	add.w	r0, r0, #4294967295	@ 0xffffffff
 80008f8:	d1f5      	bne.n	80008e6 <_malloc_r+0x43a>
 80008fa:	687b      	ldr	r3, [r7, #4]
 80008fc:	ea23 030c 	bic.w	r3, r3, ip
 8000900:	607b      	str	r3, [r7, #4]
 8000902:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 8000906:	459c      	cmp	ip, r3
 8000908:	f63f ae9c 	bhi.w	8000644 <_malloc_r+0x198>
 800090c:	f1bc 0f00 	cmp.w	ip, #0
 8000910:	d104      	bne.n	800091c <_malloc_r+0x470>
 8000912:	e697      	b.n	8000644 <_malloc_r+0x198>
 8000914:	ea4f 0c4c 	mov.w	ip, ip, lsl #1
 8000918:	f109 0904 	add.w	r9, r9, #4
 800091c:	ea1c 0f03 	tst.w	ip, r3
 8000920:	d0f8      	beq.n	8000914 <_malloc_r+0x468>
 8000922:	4648      	mov	r0, r9
 8000924:	e664      	b.n	80005f0 <_malloc_r+0x144>
 8000926:	1092      	asrs	r2, r2, #2
 8000928:	f04f 0c01 	mov.w	ip, #1
 800092c:	fa0c f202 	lsl.w	r2, ip, r2
 8000930:	ea4e 0e02 	orr.w	lr, lr, r2
 8000934:	f8c7 e004 	str.w	lr, [r7, #4]
 8000938:	e765      	b.n	8000806 <_malloc_r+0x35a>
 800093a:	eb0a 0108 	add.w	r1, sl, r8
 800093e:	ea01 010c 	and.w	r1, r1, ip
 8000942:	1a52      	subs	r2, r2, r1
 8000944:	ea02 010c 	and.w	r1, r2, ip
 8000948:	4630      	mov	r0, r6
 800094a:	9101      	str	r1, [sp, #4]
 800094c:	f000 f876 	bl	8000a3c <_sbrk_r>
 8000950:	1c43      	adds	r3, r0, #1
 8000952:	f47f aed5 	bne.w	8000700 <_malloc_r+0x254>
 8000956:	9900      	ldr	r1, [sp, #0]
 8000958:	e6d7      	b.n	800070a <_malloc_r+0x25e>
 800095a:	2a54      	cmp	r2, #84	@ 0x54
 800095c:	d82e      	bhi.n	80009bc <_malloc_r+0x510>
 800095e:	ea4f 321c 	mov.w	r2, ip, lsr #12
 8000962:	f102 036f 	add.w	r3, r2, #111	@ 0x6f
 8000966:	b21b      	sxth	r3, r3
 8000968:	326e      	adds	r2, #110	@ 0x6e
 800096a:	00db      	lsls	r3, r3, #3
 800096c:	e735      	b.n	80007da <_malloc_r+0x32e>
 800096e:	f5be 7faa 	cmp.w	lr, #340	@ 0x154
 8000972:	d82e      	bhi.n	80009d2 <_malloc_r+0x526>
 8000974:	ea4f 3ed5 	mov.w	lr, r5, lsr #15
 8000978:	f10e 0078 	add.w	r0, lr, #120	@ 0x78
 800097c:	b203      	sxth	r3, r0
 800097e:	f10e 0e77 	add.w	lr, lr, #119	@ 0x77
 8000982:	00db      	lsls	r3, r3, #3
 8000984:	e5db      	b.n	800053e <_malloc_r+0x92>
 8000986:	f8db 1004 	ldr.w	r1, [fp, #4]
 800098a:	4441      	add	r1, r8
 800098c:	f8cb 1004 	str.w	r1, [fp, #4]
 8000990:	f102 3cff 	add.w	ip, r2, #4294967295	@ 0xffffffff
 8000994:	e692      	b.n	80006bc <_malloc_r+0x210>
 8000996:	ea10 0f0c 	tst.w	r0, ip
 800099a:	f47f ae8f 	bne.w	80006bc <_malloc_r+0x210>
 800099e:	f8d7 a008 	ldr.w	sl, [r7, #8]
 80009a2:	44c8      	add	r8, r9
 80009a4:	f048 0001 	orr.w	r0, r8, #1
 80009a8:	f8ca 0004 	str.w	r0, [sl, #4]
 80009ac:	e6d0      	b.n	8000750 <_malloc_r+0x2a4>
 80009ae:	f8c7 a408 	str.w	sl, [r7, #1032]	@ 0x408
 80009b2:	e68f      	b.n	80006d4 <_malloc_r+0x228>
 80009b4:	2301      	movs	r3, #1
 80009b6:	f8ca 3004 	str.w	r3, [sl, #4]
 80009ba:	e6de      	b.n	800077a <_malloc_r+0x2ce>
 80009bc:	f5b2 7faa 	cmp.w	r2, #340	@ 0x154
 80009c0:	d824      	bhi.n	8000a0c <_malloc_r+0x560>
 80009c2:	ea4f 32dc 	mov.w	r2, ip, lsr #15
 80009c6:	f102 0378 	add.w	r3, r2, #120	@ 0x78
 80009ca:	b21b      	sxth	r3, r3
 80009cc:	3277      	adds	r2, #119	@ 0x77
 80009ce:	00db      	lsls	r3, r3, #3
 80009d0:	e703      	b.n	80007da <_malloc_r+0x32e>
 80009d2:	f240 5354 	movw	r3, #1364	@ 0x554
 80009d6:	459e      	cmp	lr, r3
 80009d8:	d823      	bhi.n	8000a22 <_malloc_r+0x576>
 80009da:	0cab      	lsrs	r3, r5, #18
 80009dc:	f103 007d 	add.w	r0, r3, #125	@ 0x7d
 80009e0:	f103 0e7c 	add.w	lr, r3, #124	@ 0x7c
 80009e4:	00c3      	lsls	r3, r0, #3
 80009e6:	e5aa      	b.n	800053e <_malloc_r+0x92>
 80009e8:	9b00      	ldr	r3, [sp, #0]
 80009ea:	f1a3 0208 	sub.w	r2, r3, #8
 80009ee:	4490      	add	r8, r2
 80009f0:	eba8 080a 	sub.w	r8, r8, sl
 80009f4:	2100      	movs	r1, #0
 80009f6:	e688      	b.n	800070a <_malloc_r+0x25e>
 80009f8:	f104 0108 	add.w	r1, r4, #8
 80009fc:	4630      	mov	r0, r6
 80009fe:	f000 f88b 	bl	8000b18 <_free_r>
 8000a02:	f8db 1004 	ldr.w	r1, [fp, #4]
 8000a06:	f8d7 a008 	ldr.w	sl, [r7, #8]
 8000a0a:	e69f      	b.n	800074c <_malloc_r+0x2a0>
 8000a0c:	f240 5354 	movw	r3, #1364	@ 0x554
 8000a10:	429a      	cmp	r2, r3
 8000a12:	d80c      	bhi.n	8000a2e <_malloc_r+0x582>
 8000a14:	ea4f 429c 	mov.w	r2, ip, lsr #18
 8000a18:	f102 037d 	add.w	r3, r2, #125	@ 0x7d
 8000a1c:	00db      	lsls	r3, r3, #3
 8000a1e:	327c      	adds	r2, #124	@ 0x7c
 8000a20:	e6db      	b.n	80007da <_malloc_r+0x32e>
 8000a22:	f44f 737e 	mov.w	r3, #1016	@ 0x3f8
 8000a26:	207f      	movs	r0, #127	@ 0x7f
 8000a28:	f04f 0e7e 	mov.w	lr, #126	@ 0x7e
 8000a2c:	e587      	b.n	800053e <_malloc_r+0x92>
 8000a2e:	f44f 737e 	mov.w	r3, #1016	@ 0x3f8
 8000a32:	227e      	movs	r2, #126	@ 0x7e
 8000a34:	e6d1      	b.n	80007da <_malloc_r+0x32e>
 8000a36:	687b      	ldr	r3, [r7, #4]
 8000a38:	e763      	b.n	8000902 <_malloc_r+0x456>
 8000a3a:	bf00      	nop

08000a3c <_sbrk_r>:
 8000a3c:	b538      	push	{r3, r4, r5, lr}
 8000a3e:	4d07      	ldr	r5, [pc, #28]	@ (8000a5c <_sbrk_r+0x20>)
 8000a40:	2200      	movs	r2, #0
 8000a42:	4604      	mov	r4, r0
 8000a44:	4608      	mov	r0, r1
 8000a46:	602a      	str	r2, [r5, #0]
 8000a48:	f002 fc10 	bl	800326c <_sbrk>
 8000a4c:	1c43      	adds	r3, r0, #1
 8000a4e:	d000      	beq.n	8000a52 <_sbrk_r+0x16>
 8000a50:	bd38      	pop	{r3, r4, r5, pc}
 8000a52:	682b      	ldr	r3, [r5, #0]
 8000a54:	2b00      	cmp	r3, #0
 8000a56:	d0fb      	beq.n	8000a50 <_sbrk_r+0x14>
 8000a58:	6023      	str	r3, [r4, #0]
 8000a5a:	bd38      	pop	{r3, r4, r5, pc}
 8000a5c:	20000f48 	.word	0x20000f48

08000a60 <_malloc_trim_r>:
 8000a60:	e92d 43f8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, lr}
 8000a64:	4606      	mov	r6, r0
 8000a66:	2008      	movs	r0, #8
 8000a68:	4689      	mov	r9, r1
 8000a6a:	f000 f9db 	bl	8000e24 <sysconf>
 8000a6e:	f8df 809c 	ldr.w	r8, [pc, #156]	@ 8000b0c <_malloc_trim_r+0xac>
 8000a72:	4605      	mov	r5, r0
 8000a74:	4630      	mov	r0, r6
 8000a76:	f000 f9d1 	bl	8000e1c <__malloc_lock>
 8000a7a:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000a7e:	685f      	ldr	r7, [r3, #4]
 8000a80:	f027 0703 	bic.w	r7, r7, #3
 8000a84:	f1a7 0411 	sub.w	r4, r7, #17
 8000a88:	eba4 0409 	sub.w	r4, r4, r9
 8000a8c:	442c      	add	r4, r5
 8000a8e:	fbb4 f4f5 	udiv	r4, r4, r5
 8000a92:	3c01      	subs	r4, #1
 8000a94:	fb05 f404 	mul.w	r4, r5, r4
 8000a98:	42a5      	cmp	r5, r4
 8000a9a:	dc08      	bgt.n	8000aae <_malloc_trim_r+0x4e>
 8000a9c:	2100      	movs	r1, #0
 8000a9e:	4630      	mov	r0, r6
 8000aa0:	f7ff ffcc 	bl	8000a3c <_sbrk_r>
 8000aa4:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000aa8:	443b      	add	r3, r7
 8000aaa:	4298      	cmp	r0, r3
 8000aac:	d005      	beq.n	8000aba <_malloc_trim_r+0x5a>
 8000aae:	4630      	mov	r0, r6
 8000ab0:	f000 f9b6 	bl	8000e20 <__malloc_unlock>
 8000ab4:	2000      	movs	r0, #0
 8000ab6:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
 8000aba:	4261      	negs	r1, r4
 8000abc:	4630      	mov	r0, r6
 8000abe:	f7ff ffbd 	bl	8000a3c <_sbrk_r>
 8000ac2:	3001      	adds	r0, #1
 8000ac4:	d00f      	beq.n	8000ae6 <_malloc_trim_r+0x86>
 8000ac6:	4a12      	ldr	r2, [pc, #72]	@ (8000b10 <_malloc_trim_r+0xb0>)
 8000ac8:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8000acc:	1b3f      	subs	r7, r7, r4
 8000ace:	f047 0701 	orr.w	r7, r7, #1
 8000ad2:	605f      	str	r7, [r3, #4]
 8000ad4:	6813      	ldr	r3, [r2, #0]
 8000ad6:	4630      	mov	r0, r6
 8000ad8:	1b1b      	subs	r3, r3, r4
 8000ada:	6013      	str	r3, [r2, #0]
 8000adc:	f000 f9a0 	bl	8000e20 <__malloc_unlock>
 8000ae0:	2001      	movs	r0, #1
 8000ae2:	e8bd 83f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, pc}
 8000ae6:	2100      	movs	r1, #0
 8000ae8:	4630      	mov	r0, r6
 8000aea:	f7ff ffa7 	bl	8000a3c <_sbrk_r>
 8000aee:	f8d8 2008 	ldr.w	r2, [r8, #8]
 8000af2:	1a83      	subs	r3, r0, r2
 8000af4:	2b0f      	cmp	r3, #15
 8000af6:	ddda      	ble.n	8000aae <_malloc_trim_r+0x4e>
 8000af8:	f043 0301 	orr.w	r3, r3, #1
 8000afc:	6053      	str	r3, [r2, #4]
 8000afe:	4b05      	ldr	r3, [pc, #20]	@ (8000b14 <_malloc_trim_r+0xb4>)
 8000b00:	4903      	ldr	r1, [pc, #12]	@ (8000b10 <_malloc_trim_r+0xb0>)
 8000b02:	681b      	ldr	r3, [r3, #0]
 8000b04:	1ac0      	subs	r0, r0, r3
 8000b06:	6008      	str	r0, [r1, #0]
 8000b08:	e7d1      	b.n	8000aae <_malloc_trim_r+0x4e>
 8000b0a:	bf00      	nop
 8000b0c:	20000128 	.word	0x20000128
 8000b10:	20000d84 	.word	0x20000d84
 8000b14:	20000530 	.word	0x20000530

08000b18 <_free_r>:
 8000b18:	2900      	cmp	r1, #0
 8000b1a:	d05b      	beq.n	8000bd4 <_free_r+0xbc>
 8000b1c:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 8000b1e:	460c      	mov	r4, r1
 8000b20:	4607      	mov	r7, r0
 8000b22:	f000 f97b 	bl	8000e1c <__malloc_lock>
 8000b26:	f854 cc04 	ldr.w	ip, [r4, #-4]
 8000b2a:	4d74      	ldr	r5, [pc, #464]	@ (8000cfc <_free_r+0x1e4>)
 8000b2c:	f1a4 0208 	sub.w	r2, r4, #8
 8000b30:	f02c 0301 	bic.w	r3, ip, #1
 8000b34:	18d1      	adds	r1, r2, r3
 8000b36:	68a8      	ldr	r0, [r5, #8]
 8000b38:	684e      	ldr	r6, [r1, #4]
 8000b3a:	4288      	cmp	r0, r1
 8000b3c:	f026 0603 	bic.w	r6, r6, #3
 8000b40:	f00c 0e01 	and.w	lr, ip, #1
 8000b44:	d07e      	beq.n	8000c44 <_free_r+0x12c>
 8000b46:	1988      	adds	r0, r1, r6
 8000b48:	604e      	str	r6, [r1, #4]
 8000b4a:	6840      	ldr	r0, [r0, #4]
 8000b4c:	f000 0001 	and.w	r0, r0, #1
 8000b50:	f1be 0f00 	cmp.w	lr, #0
 8000b54:	d12f      	bne.n	8000bb6 <_free_r+0x9e>
 8000b56:	f854 4c08 	ldr.w	r4, [r4, #-8]
 8000b5a:	1b12      	subs	r2, r2, r4
 8000b5c:	4423      	add	r3, r4
 8000b5e:	6894      	ldr	r4, [r2, #8]
 8000b60:	f105 0c08 	add.w	ip, r5, #8
 8000b64:	4564      	cmp	r4, ip
 8000b66:	d062      	beq.n	8000c2e <_free_r+0x116>
 8000b68:	f8d2 e00c 	ldr.w	lr, [r2, #12]
 8000b6c:	f8c4 e00c 	str.w	lr, [r4, #12]
 8000b70:	f8ce 4008 	str.w	r4, [lr, #8]
 8000b74:	2800      	cmp	r0, #0
 8000b76:	d07f      	beq.n	8000c78 <_free_r+0x160>
 8000b78:	f043 0001 	orr.w	r0, r3, #1
 8000b7c:	6050      	str	r0, [r2, #4]
 8000b7e:	600b      	str	r3, [r1, #0]
 8000b80:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
 8000b84:	d22f      	bcs.n	8000be6 <_free_r+0xce>
 8000b86:	08d9      	lsrs	r1, r3, #3
 8000b88:	6868      	ldr	r0, [r5, #4]
 8000b8a:	095c      	lsrs	r4, r3, #5
 8000b8c:	3101      	adds	r1, #1
 8000b8e:	2301      	movs	r3, #1
 8000b90:	b209      	sxth	r1, r1
 8000b92:	40a3      	lsls	r3, r4
 8000b94:	4303      	orrs	r3, r0
 8000b96:	606b      	str	r3, [r5, #4]
 8000b98:	f855 0031 	ldr.w	r0, [r5, r1, lsl #3]
 8000b9c:	6090      	str	r0, [r2, #8]
 8000b9e:	eb05 03c1 	add.w	r3, r5, r1, lsl #3
 8000ba2:	3b08      	subs	r3, #8
 8000ba4:	60d3      	str	r3, [r2, #12]
 8000ba6:	f845 2031 	str.w	r2, [r5, r1, lsl #3]
 8000baa:	60c2      	str	r2, [r0, #12]
 8000bac:	4638      	mov	r0, r7
 8000bae:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
 8000bb2:	f000 b935 	b.w	8000e20 <__malloc_unlock>
 8000bb6:	b970      	cbnz	r0, 8000bd6 <_free_r+0xbe>
 8000bb8:	4433      	add	r3, r6
 8000bba:	f105 0c08 	add.w	ip, r5, #8
 8000bbe:	6888      	ldr	r0, [r1, #8]
 8000bc0:	4560      	cmp	r0, ip
 8000bc2:	f043 0401 	orr.w	r4, r3, #1
 8000bc6:	d071      	beq.n	8000cac <_free_r+0x194>
 8000bc8:	68c9      	ldr	r1, [r1, #12]
 8000bca:	60c1      	str	r1, [r0, #12]
 8000bcc:	6088      	str	r0, [r1, #8]
 8000bce:	6054      	str	r4, [r2, #4]
 8000bd0:	50d3      	str	r3, [r2, r3]
 8000bd2:	e7d5      	b.n	8000b80 <_free_r+0x68>
 8000bd4:	4770      	bx	lr
 8000bd6:	f04c 0101 	orr.w	r1, ip, #1
 8000bda:	f5b3 7f00 	cmp.w	r3, #512	@ 0x200
 8000bde:	f844 1c04 	str.w	r1, [r4, #-4]
 8000be2:	50d3      	str	r3, [r2, r3]
 8000be4:	d3cf      	bcc.n	8000b86 <_free_r+0x6e>
 8000be6:	f5b3 6f20 	cmp.w	r3, #2560	@ 0xa00
 8000bea:	ea4f 2053 	mov.w	r0, r3, lsr #9
 8000bee:	d245      	bcs.n	8000c7c <_free_r+0x164>
 8000bf0:	0998      	lsrs	r0, r3, #6
 8000bf2:	f100 0139 	add.w	r1, r0, #57	@ 0x39
 8000bf6:	b209      	sxth	r1, r1
 8000bf8:	f100 0438 	add.w	r4, r0, #56	@ 0x38
 8000bfc:	00c9      	lsls	r1, r1, #3
 8000bfe:	1868      	adds	r0, r5, r1
 8000c00:	5869      	ldr	r1, [r5, r1]
 8000c02:	3808      	subs	r0, #8
 8000c04:	4288      	cmp	r0, r1
 8000c06:	d103      	bne.n	8000c10 <_free_r+0xf8>
 8000c08:	e057      	b.n	8000cba <_free_r+0x1a2>
 8000c0a:	6889      	ldr	r1, [r1, #8]
 8000c0c:	4288      	cmp	r0, r1
 8000c0e:	d004      	beq.n	8000c1a <_free_r+0x102>
 8000c10:	684c      	ldr	r4, [r1, #4]
 8000c12:	f024 0403 	bic.w	r4, r4, #3
 8000c16:	429c      	cmp	r4, r3
 8000c18:	d8f7      	bhi.n	8000c0a <_free_r+0xf2>
 8000c1a:	68c8      	ldr	r0, [r1, #12]
 8000c1c:	e9c2 1002 	strd	r1, r0, [r2, #8]
 8000c20:	6082      	str	r2, [r0, #8]
 8000c22:	4638      	mov	r0, r7
 8000c24:	60ca      	str	r2, [r1, #12]
 8000c26:	e8bd 40f8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, lr}
 8000c2a:	f000 b8f9 	b.w	8000e20 <__malloc_unlock>
 8000c2e:	bb88      	cbnz	r0, 8000c94 <_free_r+0x17c>
 8000c30:	441e      	add	r6, r3
 8000c32:	e9d1 1302 	ldrd	r1, r3, [r1, #8]
 8000c36:	60cb      	str	r3, [r1, #12]
 8000c38:	6099      	str	r1, [r3, #8]
 8000c3a:	f046 0301 	orr.w	r3, r6, #1
 8000c3e:	6053      	str	r3, [r2, #4]
 8000c40:	5196      	str	r6, [r2, r6]
 8000c42:	e7b3      	b.n	8000bac <_free_r+0x94>
 8000c44:	441e      	add	r6, r3
 8000c46:	f1be 0f00 	cmp.w	lr, #0
 8000c4a:	d107      	bne.n	8000c5c <_free_r+0x144>
 8000c4c:	f854 3c08 	ldr.w	r3, [r4, #-8]
 8000c50:	1ad2      	subs	r2, r2, r3
 8000c52:	441e      	add	r6, r3
 8000c54:	e9d2 1302 	ldrd	r1, r3, [r2, #8]
 8000c58:	60cb      	str	r3, [r1, #12]
 8000c5a:	6099      	str	r1, [r3, #8]
 8000c5c:	f046 0301 	orr.w	r3, r6, #1
 8000c60:	6053      	str	r3, [r2, #4]
 8000c62:	4b27      	ldr	r3, [pc, #156]	@ (8000d00 <_free_r+0x1e8>)
 8000c64:	60aa      	str	r2, [r5, #8]
 8000c66:	681b      	ldr	r3, [r3, #0]
 8000c68:	42b3      	cmp	r3, r6
 8000c6a:	d89f      	bhi.n	8000bac <_free_r+0x94>
 8000c6c:	4b25      	ldr	r3, [pc, #148]	@ (8000d04 <_free_r+0x1ec>)
 8000c6e:	4638      	mov	r0, r7
 8000c70:	6819      	ldr	r1, [r3, #0]
 8000c72:	f7ff fef5 	bl	8000a60 <_malloc_trim_r>
 8000c76:	e799      	b.n	8000bac <_free_r+0x94>
 8000c78:	4433      	add	r3, r6
 8000c7a:	e7a0      	b.n	8000bbe <_free_r+0xa6>
 8000c7c:	2814      	cmp	r0, #20
 8000c7e:	d90e      	bls.n	8000c9e <_free_r+0x186>
 8000c80:	2854      	cmp	r0, #84	@ 0x54
 8000c82:	d821      	bhi.n	8000cc8 <_free_r+0x1b0>
 8000c84:	0b18      	lsrs	r0, r3, #12
 8000c86:	f100 016f 	add.w	r1, r0, #111	@ 0x6f
 8000c8a:	b209      	sxth	r1, r1
 8000c8c:	f100 046e 	add.w	r4, r0, #110	@ 0x6e
 8000c90:	00c9      	lsls	r1, r1, #3
 8000c92:	e7b4      	b.n	8000bfe <_free_r+0xe6>
 8000c94:	f043 0001 	orr.w	r0, r3, #1
 8000c98:	6050      	str	r0, [r2, #4]
 8000c9a:	600b      	str	r3, [r1, #0]
 8000c9c:	e786      	b.n	8000bac <_free_r+0x94>
 8000c9e:	f100 015c 	add.w	r1, r0, #92	@ 0x5c
 8000ca2:	b209      	sxth	r1, r1
 8000ca4:	f100 045b 	add.w	r4, r0, #91	@ 0x5b
 8000ca8:	00c9      	lsls	r1, r1, #3
 8000caa:	e7a8      	b.n	8000bfe <_free_r+0xe6>
 8000cac:	e9c5 2204 	strd	r2, r2, [r5, #16]
 8000cb0:	e9c2 cc02 	strd	ip, ip, [r2, #8]
 8000cb4:	6054      	str	r4, [r2, #4]
 8000cb6:	50d3      	str	r3, [r2, r3]
 8000cb8:	e778      	b.n	8000bac <_free_r+0x94>
 8000cba:	686e      	ldr	r6, [r5, #4]
 8000cbc:	10a4      	asrs	r4, r4, #2
 8000cbe:	2301      	movs	r3, #1
 8000cc0:	40a3      	lsls	r3, r4
 8000cc2:	4333      	orrs	r3, r6
 8000cc4:	606b      	str	r3, [r5, #4]
 8000cc6:	e7a9      	b.n	8000c1c <_free_r+0x104>
 8000cc8:	f5b0 7faa 	cmp.w	r0, #340	@ 0x154
 8000ccc:	d807      	bhi.n	8000cde <_free_r+0x1c6>
 8000cce:	0bd8      	lsrs	r0, r3, #15
 8000cd0:	f100 0178 	add.w	r1, r0, #120	@ 0x78
 8000cd4:	b209      	sxth	r1, r1
 8000cd6:	f100 0477 	add.w	r4, r0, #119	@ 0x77
 8000cda:	00c9      	lsls	r1, r1, #3
 8000cdc:	e78f      	b.n	8000bfe <_free_r+0xe6>
 8000cde:	f240 5154 	movw	r1, #1364	@ 0x554
 8000ce2:	4288      	cmp	r0, r1
 8000ce4:	d806      	bhi.n	8000cf4 <_free_r+0x1dc>
 8000ce6:	0c98      	lsrs	r0, r3, #18
 8000ce8:	f100 017d 	add.w	r1, r0, #125	@ 0x7d
 8000cec:	f100 047c 	add.w	r4, r0, #124	@ 0x7c
 8000cf0:	00c9      	lsls	r1, r1, #3
 8000cf2:	e784      	b.n	8000bfe <_free_r+0xe6>
 8000cf4:	f44f 717e 	mov.w	r1, #1016	@ 0x3f8
 8000cf8:	247e      	movs	r4, #126	@ 0x7e
 8000cfa:	e780      	b.n	8000bfe <_free_r+0xe6>
 8000cfc:	20000128 	.word	0x20000128
 8000d00:	20000534 	.word	0x20000534
 8000d04:	20000d80 	.word	0x20000d80

08000d08 <__call_exitprocs>:
 8000d08:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8000d0c:	4f29      	ldr	r7, [pc, #164]	@ (8000db4 <__call_exitprocs+0xac>)
 8000d0e:	b083      	sub	sp, #12
 8000d10:	683e      	ldr	r6, [r7, #0]
 8000d12:	9001      	str	r0, [sp, #4]
 8000d14:	b1b6      	cbz	r6, 8000d44 <__call_exitprocs+0x3c>
 8000d16:	468b      	mov	fp, r1
 8000d18:	f04f 0900 	mov.w	r9, #0
 8000d1c:	f04f 0801 	mov.w	r8, #1
 8000d20:	6874      	ldr	r4, [r6, #4]
 8000d22:	1e65      	subs	r5, r4, #1
 8000d24:	d40e      	bmi.n	8000d44 <__call_exitprocs+0x3c>
 8000d26:	3401      	adds	r4, #1
 8000d28:	eb06 0484 	add.w	r4, r6, r4, lsl #2
 8000d2c:	f1bb 0f00 	cmp.w	fp, #0
 8000d30:	d00b      	beq.n	8000d4a <__call_exitprocs+0x42>
 8000d32:	f8d4 3100 	ldr.w	r3, [r4, #256]	@ 0x100
 8000d36:	455b      	cmp	r3, fp
 8000d38:	d007      	beq.n	8000d4a <__call_exitprocs+0x42>
 8000d3a:	3d01      	subs	r5, #1
 8000d3c:	1c6a      	adds	r2, r5, #1
 8000d3e:	f1a4 0404 	sub.w	r4, r4, #4
 8000d42:	d1f6      	bne.n	8000d32 <__call_exitprocs+0x2a>
 8000d44:	b003      	add	sp, #12
 8000d46:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000d4a:	6873      	ldr	r3, [r6, #4]
 8000d4c:	6822      	ldr	r2, [r4, #0]
 8000d4e:	3b01      	subs	r3, #1
 8000d50:	42ab      	cmp	r3, r5
 8000d52:	bf0c      	ite	eq
 8000d54:	6075      	streq	r5, [r6, #4]
 8000d56:	f8c4 9000 	strne.w	r9, [r4]
 8000d5a:	b17a      	cbz	r2, 8000d7c <__call_exitprocs+0x74>
 8000d5c:	f8d6 1188 	ldr.w	r1, [r6, #392]	@ 0x188
 8000d60:	f8d6 a004 	ldr.w	sl, [r6, #4]
 8000d64:	fa08 fc05 	lsl.w	ip, r8, r5
 8000d68:	ea1c 0f01 	tst.w	ip, r1
 8000d6c:	d10e      	bne.n	8000d8c <__call_exitprocs+0x84>
 8000d6e:	4790      	blx	r2
 8000d70:	6871      	ldr	r1, [r6, #4]
 8000d72:	683a      	ldr	r2, [r7, #0]
 8000d74:	4551      	cmp	r1, sl
 8000d76:	d116      	bne.n	8000da6 <__call_exitprocs+0x9e>
 8000d78:	42b2      	cmp	r2, r6
 8000d7a:	d114      	bne.n	8000da6 <__call_exitprocs+0x9e>
 8000d7c:	3d01      	subs	r5, #1
 8000d7e:	1c6b      	adds	r3, r5, #1
 8000d80:	f1a4 0404 	sub.w	r4, r4, #4
 8000d84:	d1d2      	bne.n	8000d2c <__call_exitprocs+0x24>
 8000d86:	b003      	add	sp, #12
 8000d88:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8000d8c:	f8d6 318c 	ldr.w	r3, [r6, #396]	@ 0x18c
 8000d90:	f8d4 1080 	ldr.w	r1, [r4, #128]	@ 0x80
 8000d94:	ea1c 0f03 	tst.w	ip, r3
 8000d98:	d109      	bne.n	8000dae <__call_exitprocs+0xa6>
 8000d9a:	9801      	ldr	r0, [sp, #4]
 8000d9c:	4790      	blx	r2
 8000d9e:	6871      	ldr	r1, [r6, #4]
 8000da0:	683a      	ldr	r2, [r7, #0]
 8000da2:	4551      	cmp	r1, sl
 8000da4:	d0e8      	beq.n	8000d78 <__call_exitprocs+0x70>
 8000da6:	2a00      	cmp	r2, #0
 8000da8:	d0cc      	beq.n	8000d44 <__call_exitprocs+0x3c>
 8000daa:	4616      	mov	r6, r2
 8000dac:	e7b8      	b.n	8000d20 <__call_exitprocs+0x18>
 8000dae:	4608      	mov	r0, r1
 8000db0:	4790      	blx	r2
 8000db2:	e7dd      	b.n	8000d70 <__call_exitprocs+0x68>
 8000db4:	20000db4 	.word	0x20000db4

08000db8 <__register_exitproc>:
 8000db8:	b470      	push	{r4, r5, r6}
 8000dba:	4d16      	ldr	r5, [pc, #88]	@ (8000e14 <__register_exitproc+0x5c>)
 8000dbc:	682c      	ldr	r4, [r5, #0]
 8000dbe:	b31c      	cbz	r4, 8000e08 <__register_exitproc+0x50>
 8000dc0:	6865      	ldr	r5, [r4, #4]
 8000dc2:	2d1f      	cmp	r5, #31
 8000dc4:	dc23      	bgt.n	8000e0e <__register_exitproc+0x56>
 8000dc6:	b938      	cbnz	r0, 8000dd8 <__register_exitproc+0x20>
 8000dc8:	1cab      	adds	r3, r5, #2
 8000dca:	3501      	adds	r5, #1
 8000dcc:	6065      	str	r5, [r4, #4]
 8000dce:	f844 1023 	str.w	r1, [r4, r3, lsl #2]
 8000dd2:	2000      	movs	r0, #0
 8000dd4:	bc70      	pop	{r4, r5, r6}
 8000dd6:	4770      	bx	lr
 8000dd8:	eb04 0c85 	add.w	ip, r4, r5, lsl #2
 8000ddc:	2802      	cmp	r0, #2
 8000dde:	f8cc 2088 	str.w	r2, [ip, #136]	@ 0x88
 8000de2:	f8d4 6188 	ldr.w	r6, [r4, #392]	@ 0x188
 8000de6:	f04f 0201 	mov.w	r2, #1
 8000dea:	fa02 f205 	lsl.w	r2, r2, r5
 8000dee:	ea46 0602 	orr.w	r6, r6, r2
 8000df2:	f8c4 6188 	str.w	r6, [r4, #392]	@ 0x188
 8000df6:	f8cc 3108 	str.w	r3, [ip, #264]	@ 0x108
 8000dfa:	d1e5      	bne.n	8000dc8 <__register_exitproc+0x10>
 8000dfc:	f8d4 318c 	ldr.w	r3, [r4, #396]	@ 0x18c
 8000e00:	4313      	orrs	r3, r2
 8000e02:	f8c4 318c 	str.w	r3, [r4, #396]	@ 0x18c
 8000e06:	e7df      	b.n	8000dc8 <__register_exitproc+0x10>
 8000e08:	4c03      	ldr	r4, [pc, #12]	@ (8000e18 <__register_exitproc+0x60>)
 8000e0a:	602c      	str	r4, [r5, #0]
 8000e0c:	e7d8      	b.n	8000dc0 <__register_exitproc+0x8>
 8000e0e:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 8000e12:	e7df      	b.n	8000dd4 <__register_exitproc+0x1c>
 8000e14:	20000db4 	.word	0x20000db4
 8000e18:	20000db8 	.word	0x20000db8

08000e1c <__malloc_lock>:
 8000e1c:	4770      	bx	lr
 8000e1e:	bf00      	nop

08000e20 <__malloc_unlock>:
 8000e20:	4770      	bx	lr
 8000e22:	bf00      	nop

08000e24 <sysconf>:
 8000e24:	2808      	cmp	r0, #8
 8000e26:	d102      	bne.n	8000e2e <sysconf+0xa>
 8000e28:	f44f 5080 	mov.w	r0, #4096	@ 0x1000
 8000e2c:	4770      	bx	lr
 8000e2e:	b508      	push	{r3, lr}
 8000e30:	f7ff fab0 	bl	8000394 <__errno>
 8000e34:	2316      	movs	r3, #22
 8000e36:	6003      	str	r3, [r0, #0]
 8000e38:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 8000e3c:	bd08      	pop	{r3, pc}
 8000e3e:	bf00      	nop

08000e40 <_exit>:
 8000e40:	e7fe      	b.n	8000e40 <_exit>
 8000e42:	bf00      	nop

08000e44 <identity>:
 8000e44:	b109      	cbz	r1, 8000e4a <identity+0x6>
 8000e46:	2001      	movs	r0, #1
 8000e48:	4770      	bx	lr
 8000e4a:	b530      	push	{r4, r5, lr}
 8000e4c:	4d0a      	ldr	r5, [pc, #40]	@ (8000e78 <identity+0x34>)
 8000e4e:	460c      	mov	r4, r1
 8000e50:	cd0f      	ldmia	r5!, {r0, r1, r2, r3}
 8000e52:	b087      	sub	sp, #28
 8000e54:	46ec      	mov	ip, sp
 8000e56:	e8ac 000f 	stmia.w	ip!, {r0, r1, r2, r3}
 8000e5a:	e895 0003 	ldmia.w	r5, {r0, r1}
 8000e5e:	f84c 0b04 	str.w	r0, [ip], #4
 8000e62:	466a      	mov	r2, sp
 8000e64:	f88c 1000 	strb.w	r1, [ip]
 8000e68:	2069      	movs	r0, #105	@ 0x69
 8000e6a:	2115      	movs	r1, #21
 8000e6c:	f002 fbb6 	bl	80035dc <simpleserial_put>
 8000e70:	4620      	mov	r0, r4
 8000e72:	b007      	add	sp, #28
 8000e74:	bd30      	pop	{r4, r5, pc}
 8000e76:	bf00      	nop
 8000e78:	08003730 	.word	0x08003730

08000e7c <sample>:
 8000e7c:	2922      	cmp	r1, #34	@ 0x22
 8000e7e:	d001      	beq.n	8000e84 <sample+0x8>
 8000e80:	2001      	movs	r0, #1
 8000e82:	4770      	bx	lr
 8000e84:	b510      	push	{r4, lr}
 8000e86:	f44f 7200 	mov.w	r2, #512	@ 0x200
 8000e8a:	2100      	movs	r1, #0
 8000e8c:	4604      	mov	r4, r0
 8000e8e:	4815      	ldr	r0, [pc, #84]	@ (8000ee4 <sample+0x68>)
 8000e90:	f7ff faaa 	bl	80003e8 <memset>
 8000e94:	f000 f850 	bl	8000f38 <lab_timing_begin>
 8000e98:	f001 fc9c 	bl	80027d4 <trigger_high>
 8000e9c:	4811      	ldr	r0, [pc, #68]	@ (8000ee4 <sample+0x68>)
 8000e9e:	4621      	mov	r1, r4
 8000ea0:	f000 f8d4 	bl	800104c <algorithmA0>
 8000ea4:	f001 fc9e 	bl	80027e4 <trigger_low>
 8000ea8:	f000 f866 	bl	8000f78 <lab_timing_end>
 8000eac:	490e      	ldr	r1, [pc, #56]	@ (8000ee8 <sample+0x6c>)
 8000eae:	f201 2302 	addw	r3, r1, #514	@ 0x202
 8000eb2:	f201 4002 	addw	r0, r1, #1026	@ 0x402
 8000eb6:	f931 2f02 	ldrsh.w	r2, [r1, #2]!
 8000eba:	701a      	strb	r2, [r3, #0]
 8000ebc:	f3c2 2207 	ubfx	r2, r2, #8, #8
 8000ec0:	705a      	strb	r2, [r3, #1]
 8000ec2:	3302      	adds	r3, #2
 8000ec4:	4283      	cmp	r3, r0
 8000ec6:	d1f6      	bne.n	8000eb6 <sample+0x3a>
 8000ec8:	4908      	ldr	r1, [pc, #32]	@ (8000eec <sample+0x70>)
 8000eca:	f44f 7200 	mov.w	r2, #512	@ 0x200
 8000ece:	1888      	adds	r0, r1, r2
 8000ed0:	f001 fba0 	bl	8002614 <sha3_256>
 8000ed4:	4a06      	ldr	r2, [pc, #24]	@ (8000ef0 <sample+0x74>)
 8000ed6:	2120      	movs	r1, #32
 8000ed8:	2072      	movs	r0, #114	@ 0x72
 8000eda:	f002 fb7f 	bl	80035dc <simpleserial_put>
 8000ede:	2000      	movs	r0, #0
 8000ee0:	bd10      	pop	{r4, pc}
 8000ee2:	bf00      	nop
 8000ee4:	20000558 	.word	0x20000558
 8000ee8:	20000556 	.word	0x20000556
 8000eec:	20000758 	.word	0x20000758
 8000ef0:	20000958 	.word	0x20000958

08000ef4 <main>:
 8000ef4:	b508      	push	{r3, lr}
 8000ef6:	f001 fbcb 	bl	8002690 <platform_init>
 8000efa:	f001 fc09 	bl	8002710 <init_uart>
 8000efe:	f001 fc47 	bl	8002790 <trigger_setup>
 8000f02:	f002 faa3 	bl	800344c <simpleserial_init>
 8000f06:	4a09      	ldr	r2, [pc, #36]	@ (8000f2c <main+0x38>)
 8000f08:	2122      	movs	r1, #34	@ 0x22
 8000f0a:	2070      	movs	r0, #112	@ 0x70
 8000f0c:	f002 fad4 	bl	80034b8 <simpleserial_addcmd>
 8000f10:	4a07      	ldr	r2, [pc, #28]	@ (8000f30 <main+0x3c>)
 8000f12:	2100      	movs	r1, #0
 8000f14:	2069      	movs	r0, #105	@ 0x69
 8000f16:	f002 facf 	bl	80034b8 <simpleserial_addcmd>
 8000f1a:	4a06      	ldr	r2, [pc, #24]	@ (8000f34 <main+0x40>)
 8000f1c:	2100      	movs	r1, #0
 8000f1e:	2074      	movs	r0, #116	@ 0x74
 8000f20:	f002 faca 	bl	80034b8 <simpleserial_addcmd>
 8000f24:	f002 fae4 	bl	80034f0 <simpleserial_get>
 8000f28:	e7fc      	b.n	8000f24 <main+0x30>
 8000f2a:	bf00      	nop
 8000f2c:	08000e7d 	.word	0x08000e7d
 8000f30:	08000e45 	.word	0x08000e45
 8000f34:	08000ff9 	.word	0x08000ff9

08000f38 <lab_timing_begin>:
 8000f38:	f04f 20e0 	mov.w	r0, #3758153728	@ 0xe000e000
 8000f3c:	490c      	ldr	r1, [pc, #48]	@ (8000f70 <lab_timing_begin+0x38>)
 8000f3e:	f8d0 2dfc 	ldr.w	r2, [r0, #3580]	@ 0xdfc
 8000f42:	4b0c      	ldr	r3, [pc, #48]	@ (8000f74 <lab_timing_begin+0x3c>)
 8000f44:	f042 7280 	orr.w	r2, r2, #16777216	@ 0x1000000
 8000f48:	b410      	push	{r4}
 8000f4a:	f8c0 2dfc 	str.w	r2, [r0, #3580]	@ 0xdfc
 8000f4e:	6808      	ldr	r0, [r1, #0]
 8000f50:	2200      	movs	r2, #0
 8000f52:	2401      	movs	r4, #1
 8000f54:	f040 0001 	orr.w	r0, r0, #1
 8000f58:	6008      	str	r0, [r1, #0]
 8000f5a:	601a      	str	r2, [r3, #0]
 8000f5c:	605a      	str	r2, [r3, #4]
 8000f5e:	609a      	str	r2, [r3, #8]
 8000f60:	60da      	str	r2, [r3, #12]
 8000f62:	611a      	str	r2, [r3, #16]
 8000f64:	615a      	str	r2, [r3, #20]
 8000f66:	619a      	str	r2, [r3, #24]
 8000f68:	604a      	str	r2, [r1, #4]
 8000f6a:	601c      	str	r4, [r3, #0]
 8000f6c:	bc10      	pop	{r4}
 8000f6e:	4770      	bx	lr
 8000f70:	e0001000 	.word	0xe0001000
 8000f74:	20000978 	.word	0x20000978

08000f78 <lab_timing_end>:
 8000f78:	4a03      	ldr	r2, [pc, #12]	@ (8000f88 <lab_timing_end+0x10>)
 8000f7a:	4b04      	ldr	r3, [pc, #16]	@ (8000f8c <lab_timing_end+0x14>)
 8000f7c:	6851      	ldr	r1, [r2, #4]
 8000f7e:	6159      	str	r1, [r3, #20]
 8000f80:	2200      	movs	r2, #0
 8000f82:	601a      	str	r2, [r3, #0]
 8000f84:	4770      	bx	lr
 8000f86:	bf00      	nop
 8000f88:	e0001000 	.word	0xe0001000
 8000f8c:	20000978 	.word	0x20000978

08000f90 <__wrap_shake128_inc_squeeze>:
 8000f90:	b570      	push	{r4, r5, r6, lr}
 8000f92:	4c17      	ldr	r4, [pc, #92]	@ (8000ff0 <__wrap_shake128_inc_squeeze+0x60>)
 8000f94:	69a5      	ldr	r5, [r4, #24]
 8000f96:	6823      	ldr	r3, [r4, #0]
 8000f98:	b143      	cbz	r3, 8000fac <__wrap_shake128_inc_squeeze+0x1c>
 8000f9a:	2d01      	cmp	r5, #1
 8000f9c:	d916      	bls.n	8000fcc <__wrap_shake128_inc_squeeze+0x3c>
 8000f9e:	f001 fb31 	bl	8002604 <shake128_inc_squeeze>
 8000fa2:	6823      	ldr	r3, [r4, #0]
 8000fa4:	b10b      	cbz	r3, 8000faa <__wrap_shake128_inc_squeeze+0x1a>
 8000fa6:	3501      	adds	r5, #1
 8000fa8:	61a5      	str	r5, [r4, #24]
 8000faa:	bd70      	pop	{r4, r5, r6, pc}
 8000fac:	f001 fb2a 	bl	8002604 <shake128_inc_squeeze>
 8000fb0:	6823      	ldr	r3, [r4, #0]
 8000fb2:	2b00      	cmp	r3, #0
 8000fb4:	d0f9      	beq.n	8000faa <__wrap_shake128_inc_squeeze+0x1a>
 8000fb6:	2d01      	cmp	r5, #1
 8000fb8:	d8f5      	bhi.n	8000fa6 <__wrap_shake128_inc_squeeze+0x16>
 8000fba:	4b0e      	ldr	r3, [pc, #56]	@ (8000ff4 <__wrap_shake128_inc_squeeze+0x64>)
 8000fbc:	006e      	lsls	r6, r5, #1
 8000fbe:	eb04 0686 	add.w	r6, r4, r6, lsl #2
 8000fc2:	685b      	ldr	r3, [r3, #4]
 8000fc4:	60b3      	str	r3, [r6, #8]
 8000fc6:	3501      	adds	r5, #1
 8000fc8:	61a5      	str	r5, [r4, #24]
 8000fca:	e7ee      	b.n	8000faa <__wrap_shake128_inc_squeeze+0x1a>
 8000fcc:	4b09      	ldr	r3, [pc, #36]	@ (8000ff4 <__wrap_shake128_inc_squeeze+0x64>)
 8000fce:	685e      	ldr	r6, [r3, #4]
 8000fd0:	eb04 03c5 	add.w	r3, r4, r5, lsl #3
 8000fd4:	605e      	str	r6, [r3, #4]
 8000fd6:	f001 fb15 	bl	8002604 <shake128_inc_squeeze>
 8000fda:	6823      	ldr	r3, [r4, #0]
 8000fdc:	006e      	lsls	r6, r5, #1
 8000fde:	2b00      	cmp	r3, #0
 8000fe0:	d0e3      	beq.n	8000faa <__wrap_shake128_inc_squeeze+0x1a>
 8000fe2:	4b04      	ldr	r3, [pc, #16]	@ (8000ff4 <__wrap_shake128_inc_squeeze+0x64>)
 8000fe4:	eb04 0686 	add.w	r6, r4, r6, lsl #2
 8000fe8:	685b      	ldr	r3, [r3, #4]
 8000fea:	60b3      	str	r3, [r6, #8]
 8000fec:	e7eb      	b.n	8000fc6 <__wrap_shake128_inc_squeeze+0x36>
 8000fee:	bf00      	nop
 8000ff0:	20000978 	.word	0x20000978
 8000ff4:	e0001000 	.word	0xe0001000

08000ff8 <lab_timing_reply>:
 8000ff8:	bb21      	cbnz	r1, 8001044 <lab_timing_reply+0x4c>
 8000ffa:	b510      	push	{r4, lr}
 8000ffc:	4c12      	ldr	r4, [pc, #72]	@ (8001048 <lab_timing_reply+0x50>)
 8000ffe:	6963      	ldr	r3, [r4, #20]
 8001000:	b086      	sub	sp, #24
 8001002:	b1e3      	cbz	r3, 800103e <lab_timing_reply+0x46>
 8001004:	69a3      	ldr	r3, [r4, #24]
 8001006:	2b01      	cmp	r3, #1
 8001008:	d919      	bls.n	800103e <lab_timing_reply+0x46>
 800100a:	46ee      	mov	lr, sp
 800100c:	4670      	mov	r0, lr
 800100e:	2300      	movs	r3, #0
 8001010:	eb04 0c81 	add.w	ip, r4, r1, lsl #2
 8001014:	f8dc 2004 	ldr.w	r2, [ip, #4]
 8001018:	40da      	lsrs	r2, r3
 800101a:	3308      	adds	r3, #8
 800101c:	2b20      	cmp	r3, #32
 800101e:	f800 2b01 	strb.w	r2, [r0], #1
 8001022:	d1f7      	bne.n	8001014 <lab_timing_reply+0x1c>
 8001024:	3101      	adds	r1, #1
 8001026:	2906      	cmp	r1, #6
 8001028:	f10e 0e04 	add.w	lr, lr, #4
 800102c:	d1ee      	bne.n	800100c <lab_timing_reply+0x14>
 800102e:	466a      	mov	r2, sp
 8001030:	2118      	movs	r1, #24
 8001032:	2074      	movs	r0, #116	@ 0x74
 8001034:	f002 fad2 	bl	80035dc <simpleserial_put>
 8001038:	2000      	movs	r0, #0
 800103a:	b006      	add	sp, #24
 800103c:	bd10      	pop	{r4, pc}
 800103e:	2001      	movs	r0, #1
 8001040:	b006      	add	sp, #24
 8001042:	bd10      	pop	{r4, pc}
 8001044:	2001      	movs	r0, #1
 8001046:	4770      	bx	lr
 8001048:	20000978 	.word	0x20000978

0800104c <algorithmA0>:
 800104c:	b570      	push	{r4, r5, r6, lr}
 800104e:	b082      	sub	sp, #8
 8001050:	460c      	mov	r4, r1
 8001052:	4606      	mov	r6, r0
 8001054:	a801      	add	r0, sp, #4
 8001056:	f001 fa8b 	bl	8002570 <shake128_inc_init>
 800105a:	4621      	mov	r1, r4
 800105c:	2222      	movs	r2, #34	@ 0x22
 800105e:	a801      	add	r0, sp, #4
 8001060:	f001 fa9a 	bl	8002598 <shake128_inc_absorb>
 8001064:	a801      	add	r0, sp, #4
 8001066:	f001 fa9d 	bl	80025a4 <shake128_inc_finalize>
 800106a:	f44f 758c 	mov.w	r5, #280	@ 0x118
 800106e:	2400      	movs	r4, #0
 8001070:	e00a      	b.n	8001088 <algorithmA0+0x3c>
 8001072:	f5b3 6f50 	cmp.w	r3, #3328	@ 0xd00
 8001076:	dc05      	bgt.n	8001084 <algorithmA0+0x38>
 8001078:	f826 3014 	strh.w	r3, [r6, r4, lsl #1]
 800107c:	3401      	adds	r4, #1
 800107e:	f5b4 7f80 	cmp.w	r4, #256	@ 0x100
 8001082:	d01e      	beq.n	80010c2 <algorithmA0+0x76>
 8001084:	3d01      	subs	r5, #1
 8001086:	d01c      	beq.n	80010c2 <algorithmA0+0x76>
 8001088:	aa01      	add	r2, sp, #4
 800108a:	2103      	movs	r1, #3
 800108c:	4668      	mov	r0, sp
 800108e:	f7ff ff7f 	bl	8000f90 <__wrap_shake128_inc_squeeze>
 8001092:	f8bd 2000 	ldrh.w	r2, [sp]
 8001096:	f89d 3002 	ldrb.w	r3, [sp, #2]
 800109a:	f89d 1001 	ldrb.w	r1, [sp, #1]
 800109e:	f3c2 020b 	ubfx	r2, r2, #0, #12
 80010a2:	011b      	lsls	r3, r3, #4
 80010a4:	f5b2 6f50 	cmp.w	r2, #3328	@ 0xd00
 80010a8:	ea43 1311 	orr.w	r3, r3, r1, lsr #4
 80010ac:	f104 0101 	add.w	r1, r4, #1
 80010b0:	dcdf      	bgt.n	8001072 <algorithmA0+0x26>
 80010b2:	f5b3 6f50 	cmp.w	r3, #3328	@ 0xd00
 80010b6:	f826 2014 	strh.w	r2, [r6, r4, lsl #1]
 80010ba:	dc07      	bgt.n	80010cc <algorithmA0+0x80>
 80010bc:	f5b1 7f80 	cmp.w	r1, #256	@ 0x100
 80010c0:	d106      	bne.n	80010d0 <algorithmA0+0x84>
 80010c2:	a801      	add	r0, sp, #4
 80010c4:	f001 faa2 	bl	800260c <shake128_inc_ctx_release>
 80010c8:	b002      	add	sp, #8
 80010ca:	bd70      	pop	{r4, r5, r6, pc}
 80010cc:	460c      	mov	r4, r1
 80010ce:	e7d6      	b.n	800107e <algorithmA0+0x32>
 80010d0:	460c      	mov	r4, r1
 80010d2:	e7d1      	b.n	8001078 <algorithmA0+0x2c>

080010d4 <KeccakF1600_StatePermute>:
 80010d4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 80010d8:	b0bf      	sub	sp, #252	@ 0xfc
 80010da:	6803      	ldr	r3, [r0, #0]
 80010dc:	9304      	str	r3, [sp, #16]
 80010de:	6843      	ldr	r3, [r0, #4]
 80010e0:	9305      	str	r3, [sp, #20]
 80010e2:	6883      	ldr	r3, [r0, #8]
 80010e4:	9306      	str	r3, [sp, #24]
 80010e6:	68c3      	ldr	r3, [r0, #12]
 80010e8:	9303      	str	r3, [sp, #12]
 80010ea:	4b35      	ldr	r3, [pc, #212]	@ (80011c0 <KeccakF1600_StatePermute+0xec>)
 80010ec:	9301      	str	r3, [sp, #4]
 80010ee:	6903      	ldr	r3, [r0, #16]
 80010f0:	9307      	str	r3, [sp, #28]
 80010f2:	6943      	ldr	r3, [r0, #20]
 80010f4:	9308      	str	r3, [sp, #32]
 80010f6:	6983      	ldr	r3, [r0, #24]
 80010f8:	9309      	str	r3, [sp, #36]	@ 0x24
 80010fa:	69c3      	ldr	r3, [r0, #28]
 80010fc:	930a      	str	r3, [sp, #40]	@ 0x28
 80010fe:	6a03      	ldr	r3, [r0, #32]
 8001100:	930b      	str	r3, [sp, #44]	@ 0x2c
 8001102:	6a43      	ldr	r3, [r0, #36]	@ 0x24
 8001104:	930c      	str	r3, [sp, #48]	@ 0x30
 8001106:	6a83      	ldr	r3, [r0, #40]	@ 0x28
 8001108:	930d      	str	r3, [sp, #52]	@ 0x34
 800110a:	6ac3      	ldr	r3, [r0, #44]	@ 0x2c
 800110c:	930e      	str	r3, [sp, #56]	@ 0x38
 800110e:	6b03      	ldr	r3, [r0, #48]	@ 0x30
 8001110:	930f      	str	r3, [sp, #60]	@ 0x3c
 8001112:	6b43      	ldr	r3, [r0, #52]	@ 0x34
 8001114:	9310      	str	r3, [sp, #64]	@ 0x40
 8001116:	6b83      	ldr	r3, [r0, #56]	@ 0x38
 8001118:	9311      	str	r3, [sp, #68]	@ 0x44
 800111a:	6bc3      	ldr	r3, [r0, #60]	@ 0x3c
 800111c:	9312      	str	r3, [sp, #72]	@ 0x48
 800111e:	6c03      	ldr	r3, [r0, #64]	@ 0x40
 8001120:	9313      	str	r3, [sp, #76]	@ 0x4c
 8001122:	6c43      	ldr	r3, [r0, #68]	@ 0x44
 8001124:	9314      	str	r3, [sp, #80]	@ 0x50
 8001126:	6c83      	ldr	r3, [r0, #72]	@ 0x48
 8001128:	9315      	str	r3, [sp, #84]	@ 0x54
 800112a:	6cc3      	ldr	r3, [r0, #76]	@ 0x4c
 800112c:	9316      	str	r3, [sp, #88]	@ 0x58
 800112e:	e9d0 9314 	ldrd	r9, r3, [r0, #80]	@ 0x50
 8001132:	9317      	str	r3, [sp, #92]	@ 0x5c
 8001134:	6d83      	ldr	r3, [r0, #88]	@ 0x58
 8001136:	9318      	str	r3, [sp, #96]	@ 0x60
 8001138:	6dc3      	ldr	r3, [r0, #92]	@ 0x5c
 800113a:	9319      	str	r3, [sp, #100]	@ 0x64
 800113c:	6e03      	ldr	r3, [r0, #96]	@ 0x60
 800113e:	931a      	str	r3, [sp, #104]	@ 0x68
 8001140:	6e43      	ldr	r3, [r0, #100]	@ 0x64
 8001142:	931b      	str	r3, [sp, #108]	@ 0x6c
 8001144:	6e83      	ldr	r3, [r0, #104]	@ 0x68
 8001146:	931c      	str	r3, [sp, #112]	@ 0x70
 8001148:	6ec3      	ldr	r3, [r0, #108]	@ 0x6c
 800114a:	931d      	str	r3, [sp, #116]	@ 0x74
 800114c:	6f03      	ldr	r3, [r0, #112]	@ 0x70
 800114e:	931e      	str	r3, [sp, #120]	@ 0x78
 8001150:	6f43      	ldr	r3, [r0, #116]	@ 0x74
 8001152:	931f      	str	r3, [sp, #124]	@ 0x7c
 8001154:	6f83      	ldr	r3, [r0, #120]	@ 0x78
 8001156:	9320      	str	r3, [sp, #128]	@ 0x80
 8001158:	6fc3      	ldr	r3, [r0, #124]	@ 0x7c
 800115a:	9321      	str	r3, [sp, #132]	@ 0x84
 800115c:	f8d0 3080 	ldr.w	r3, [r0, #128]	@ 0x80
 8001160:	9322      	str	r3, [sp, #136]	@ 0x88
 8001162:	f8d0 3084 	ldr.w	r3, [r0, #132]	@ 0x84
 8001166:	9323      	str	r3, [sp, #140]	@ 0x8c
 8001168:	f8d0 3088 	ldr.w	r3, [r0, #136]	@ 0x88
 800116c:	9324      	str	r3, [sp, #144]	@ 0x90
 800116e:	f8d0 308c 	ldr.w	r3, [r0, #140]	@ 0x8c
 8001172:	9325      	str	r3, [sp, #148]	@ 0x94
 8001174:	f8d0 3090 	ldr.w	r3, [r0, #144]	@ 0x90
 8001178:	9326      	str	r3, [sp, #152]	@ 0x98
 800117a:	f8d0 3094 	ldr.w	r3, [r0, #148]	@ 0x94
 800117e:	9327      	str	r3, [sp, #156]	@ 0x9c
 8001180:	f8d0 3098 	ldr.w	r3, [r0, #152]	@ 0x98
 8001184:	9328      	str	r3, [sp, #160]	@ 0xa0
 8001186:	f8d0 309c 	ldr.w	r3, [r0, #156]	@ 0x9c
 800118a:	9329      	str	r3, [sp, #164]	@ 0xa4
 800118c:	f8d0 30a8 	ldr.w	r3, [r0, #168]	@ 0xa8
 8001190:	932a      	str	r3, [sp, #168]	@ 0xa8
 8001192:	e9d0 832b 	ldrd	r8, r3, [r0, #172]	@ 0xac
 8001196:	932b      	str	r3, [sp, #172]	@ 0xac
 8001198:	f8d0 30b4 	ldr.w	r3, [r0, #180]	@ 0xb4
 800119c:	932c      	str	r3, [sp, #176]	@ 0xb0
 800119e:	f8d0 30b8 	ldr.w	r3, [r0, #184]	@ 0xb8
 80011a2:	932d      	str	r3, [sp, #180]	@ 0xb4
 80011a4:	f8d0 30bc 	ldr.w	r3, [r0, #188]	@ 0xbc
 80011a8:	932e      	str	r3, [sp, #184]	@ 0xb8
 80011aa:	f8d0 30c0 	ldr.w	r3, [r0, #192]	@ 0xc0
 80011ae:	e9d0 6a28 	ldrd	r6, sl, [r0, #160]	@ 0xa0
 80011b2:	932f      	str	r3, [sp, #188]	@ 0xbc
 80011b4:	f8d0 30c4 	ldr.w	r3, [r0, #196]	@ 0xc4
 80011b8:	9330      	str	r3, [sp, #192]	@ 0xc0
 80011ba:	903d      	str	r0, [sp, #244]	@ 0xf4
 80011bc:	46cb      	mov	fp, r9
 80011be:	e001      	b.n	80011c4 <KeccakF1600_StatePermute+0xf0>
 80011c0:	08003660 	.word	0x08003660
 80011c4:	9a0d      	ldr	r2, [sp, #52]	@ 0x34
 80011c6:	9b04      	ldr	r3, [sp, #16]
 80011c8:	9905      	ldr	r1, [sp, #20]
 80011ca:	980e      	ldr	r0, [sp, #56]	@ 0x38
 80011cc:	9c06      	ldr	r4, [sp, #24]
 80011ce:	9d0f      	ldr	r5, [sp, #60]	@ 0x3c
 80011d0:	f8dd c060 	ldr.w	ip, [sp, #96]	@ 0x60
 80011d4:	4053      	eors	r3, r2
 80011d6:	9a20      	ldr	r2, [sp, #128]	@ 0x80
 80011d8:	ea83 030b 	eor.w	r3, r3, fp
 80011dc:	4053      	eors	r3, r2
 80011de:	ea83 0706 	eor.w	r7, r3, r6
 80011e2:	ea81 0300 	eor.w	r3, r1, r0
 80011e6:	9917      	ldr	r1, [sp, #92]	@ 0x5c
 80011e8:	9821      	ldr	r0, [sp, #132]	@ 0x84
 80011ea:	9733      	str	r7, [sp, #204]	@ 0xcc
 80011ec:	404b      	eors	r3, r1
 80011ee:	4043      	eors	r3, r0
 80011f0:	ea83 000a 	eor.w	r0, r3, sl
 80011f4:	ea84 0e05 	eor.w	lr, r4, r5
 80011f8:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 80011fa:	9d03      	ldr	r5, [sp, #12]
 80011fc:	9f10      	ldr	r7, [sp, #64]	@ 0x40
 80011fe:	9a23      	ldr	r2, [sp, #140]	@ 0x8c
 8001200:	9c2a      	ldr	r4, [sp, #168]	@ 0xa8
 8001202:	9907      	ldr	r1, [sp, #28]
 8001204:	9034      	str	r0, [sp, #208]	@ 0xd0
 8001206:	ea8e 0e0c 	eor.w	lr, lr, ip
 800120a:	ea8e 0e03 	eor.w	lr, lr, r3
 800120e:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8001210:	9811      	ldr	r0, [sp, #68]	@ 0x44
 8001212:	ea85 0c07 	eor.w	ip, r5, r7
 8001216:	ea8c 0c03 	eor.w	ip, ip, r3
 800121a:	9f08      	ldr	r7, [sp, #32]
 800121c:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 800121e:	9d24      	ldr	r5, [sp, #144]	@ 0x90
 8001220:	ea8c 0c02 	eor.w	ip, ip, r2
 8001224:	9a12      	ldr	r2, [sp, #72]	@ 0x48
 8001226:	ea8e 0e04 	eor.w	lr, lr, r4
 800122a:	ea81 0400 	eor.w	r4, r1, r0
 800122e:	991b      	ldr	r1, [sp, #108]	@ 0x6c
 8001230:	9825      	ldr	r0, [sp, #148]	@ 0x94
 8001232:	405c      	eors	r4, r3
 8001234:	407a      	eors	r2, r7
 8001236:	9b2b      	ldr	r3, [sp, #172]	@ 0xac
 8001238:	9f09      	ldr	r7, [sp, #36]	@ 0x24
 800123a:	406c      	eors	r4, r5
 800123c:	404a      	eors	r2, r1
 800123e:	9d2c      	ldr	r5, [sp, #176]	@ 0xb0
 8001240:	9913      	ldr	r1, [sp, #76]	@ 0x4c
 8001242:	405c      	eors	r4, r3
 8001244:	4042      	eors	r2, r0
 8001246:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
 8001248:	406a      	eors	r2, r5
 800124a:	ea87 0501 	eor.w	r5, r7, r1
 800124e:	9926      	ldr	r1, [sp, #152]	@ 0x98
 8001250:	982d      	ldr	r0, [sp, #180]	@ 0xb4
 8001252:	9f0a      	ldr	r7, [sp, #40]	@ 0x28
 8001254:	f8dd 9050 	ldr.w	r9, [sp, #80]	@ 0x50
 8001258:	405d      	eors	r5, r3
 800125a:	404d      	eors	r5, r1
 800125c:	9b1d      	ldr	r3, [sp, #116]	@ 0x74
 800125e:	9927      	ldr	r1, [sp, #156]	@ 0x9c
 8001260:	4045      	eors	r5, r0
 8001262:	ea87 0009 	eor.w	r0, r7, r9
 8001266:	4058      	eors	r0, r3
 8001268:	9b2e      	ldr	r3, [sp, #184]	@ 0xb8
 800126a:	9f0b      	ldr	r7, [sp, #44]	@ 0x2c
 800126c:	f8dd 9054 	ldr.w	r9, [sp, #84]	@ 0x54
 8001270:	4048      	eors	r0, r1
 8001272:	4043      	eors	r3, r0
 8001274:	9302      	str	r3, [sp, #8]
 8001276:	9b1e      	ldr	r3, [sp, #120]	@ 0x78
 8001278:	ea87 0109 	eor.w	r1, r7, r9
 800127c:	4059      	eors	r1, r3
 800127e:	9b28      	ldr	r3, [sp, #160]	@ 0xa0
 8001280:	9f0c      	ldr	r7, [sp, #48]	@ 0x30
 8001282:	f8dd 9058 	ldr.w	r9, [sp, #88]	@ 0x58
 8001286:	4059      	eors	r1, r3
 8001288:	9b2f      	ldr	r3, [sp, #188]	@ 0xbc
 800128a:	ea8c 0c08 	eor.w	ip, ip, r8
 800128e:	4059      	eors	r1, r3
 8001290:	ea87 0309 	eor.w	r3, r7, r9
 8001294:	ea4f 094e 	mov.w	r9, lr, lsl #1
 8001298:	ea49 79dc 	orr.w	r9, r9, ip, lsr #31
 800129c:	ea89 0901 	eor.w	r9, r9, r1
 80012a0:	ea89 0606 	eor.w	r6, r9, r6
 80012a4:	9635      	str	r6, [sp, #212]	@ 0xd4
 80012a6:	9e04      	ldr	r6, [sp, #16]
 80012a8:	9f1f      	ldr	r7, [sp, #124]	@ 0x7c
 80012aa:	ea89 0606 	eor.w	r6, r9, r6
 80012ae:	9631      	str	r6, [sp, #196]	@ 0xc4
 80012b0:	9e0d      	ldr	r6, [sp, #52]	@ 0x34
 80012b2:	ea89 0606 	eor.w	r6, r9, r6
 80012b6:	407b      	eors	r3, r7
 80012b8:	9637      	str	r6, [sp, #220]	@ 0xdc
 80012ba:	9f29      	ldr	r7, [sp, #164]	@ 0xa4
 80012bc:	9e20      	ldr	r6, [sp, #128]	@ 0x80
 80012be:	407b      	eors	r3, r7
 80012c0:	ea89 0606 	eor.w	r6, r9, r6
 80012c4:	9f30      	ldr	r7, [sp, #192]	@ 0xc0
 80012c6:	9632      	str	r6, [sp, #200]	@ 0xc8
 80012c8:	ea4f 064c 	mov.w	r6, ip, lsl #1
 80012cc:	407b      	eors	r3, r7
 80012ce:	ea89 0b0b 	eor.w	fp, r9, fp
 80012d2:	ea46 76de 	orr.w	r6, r6, lr, lsr #31
 80012d6:	f8dd 905c 	ldr.w	r9, [sp, #92]	@ 0x5c
 80012da:	405e      	eors	r6, r3
 80012dc:	ea86 0909 	eor.w	r9, r6, r9
 80012e0:	f8cd 905c 	str.w	r9, [sp, #92]	@ 0x5c
 80012e4:	ea86 090a 	eor.w	r9, r6, sl
 80012e8:	f8cd 90d8 	str.w	r9, [sp, #216]	@ 0xd8
 80012ec:	f8dd 9014 	ldr.w	r9, [sp, #20]
 80012f0:	f8dd a038 	ldr.w	sl, [sp, #56]	@ 0x38
 80012f4:	ea86 0909 	eor.w	r9, r6, r9
 80012f8:	f8cd 9034 	str.w	r9, [sp, #52]	@ 0x34
 80012fc:	ea86 090a 	eor.w	r9, r6, sl
 8001300:	f8dd a084 	ldr.w	sl, [sp, #132]	@ 0x84
 8001304:	f8cd 90e0 	str.w	r9, [sp, #224]	@ 0xe0
 8001308:	ea86 060a 	eor.w	r6, r6, sl
 800130c:	963a      	str	r6, [sp, #232]	@ 0xe8
 800130e:	9f33      	ldr	r7, [sp, #204]	@ 0xcc
 8001310:	f8dd 903c 	ldr.w	r9, [sp, #60]	@ 0x3c
 8001314:	f8dd a018 	ldr.w	sl, [sp, #24]
 8001318:	9834      	ldr	r0, [sp, #208]	@ 0xd0
 800131a:	0066      	lsls	r6, r4, #1
 800131c:	ea46 76d2 	orr.w	r6, r6, r2, lsr #31
 8001320:	407e      	eors	r6, r7
 8001322:	ea86 0909 	eor.w	r9, r6, r9
 8001326:	f8cd 9014 	str.w	r9, [sp, #20]
 800132a:	f8dd 9088 	ldr.w	r9, [sp, #136]	@ 0x88
 800132e:	ea86 0909 	eor.w	r9, r6, r9
 8001332:	f8cd 9038 	str.w	r9, [sp, #56]	@ 0x38
 8001336:	ea86 090a 	eor.w	r9, r6, sl
 800133a:	f8dd a060 	ldr.w	sl, [sp, #96]	@ 0x60
 800133e:	f8cd 9080 	str.w	r9, [sp, #128]	@ 0x80
 8001342:	ea86 0a0a 	eor.w	sl, r6, sl
 8001346:	f8cd a0cc 	str.w	sl, [sp, #204]	@ 0xcc
 800134a:	f8dd a0a8 	ldr.w	sl, [sp, #168]	@ 0xa8
 800134e:	f8dd 9040 	ldr.w	r9, [sp, #64]	@ 0x40
 8001352:	ea86 060a 	eor.w	r6, r6, sl
 8001356:	963b      	str	r6, [sp, #236]	@ 0xec
 8001358:	0056      	lsls	r6, r2, #1
 800135a:	f8dd a08c 	ldr.w	sl, [sp, #140]	@ 0x8c
 800135e:	ea46 76d4 	orr.w	r6, r6, r4, lsr #31
 8001362:	4046      	eors	r6, r0
 8001364:	ea86 0a0a 	eor.w	sl, r6, sl
 8001368:	f8cd a03c 	str.w	sl, [sp, #60]	@ 0x3c
 800136c:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001370:	ea86 0a0a 	eor.w	sl, r6, sl
 8001374:	ea86 0808 	eor.w	r8, r6, r8
 8001378:	f8cd a00c 	str.w	sl, [sp, #12]
 800137c:	f8dd a064 	ldr.w	sl, [sp, #100]	@ 0x64
 8001380:	f8cd 80f0 	str.w	r8, [sp, #240]	@ 0xf0
 8001384:	f8dd 8008 	ldr.w	r8, [sp, #8]
 8001388:	ea86 0909 	eor.w	r9, r6, r9
 800138c:	ea86 0a0a 	eor.w	sl, r6, sl
 8001390:	006e      	lsls	r6, r5, #1
 8001392:	ea46 76d8 	orr.w	r6, r6, r8, lsr #31
 8001396:	ea86 060e 	eor.w	r6, r6, lr
 800139a:	f8dd e0ac 	ldr.w	lr, [sp, #172]	@ 0xac
 800139e:	f8cd a0a8 	str.w	sl, [sp, #168]	@ 0xa8
 80013a2:	f8dd a044 	ldr.w	sl, [sp, #68]	@ 0x44
 80013a6:	f8dd 8068 	ldr.w	r8, [sp, #104]	@ 0x68
 80013aa:	ea86 0e0e 	eor.w	lr, r6, lr
 80013ae:	f8cd e060 	str.w	lr, [sp, #96]	@ 0x60
 80013b2:	ea86 0e0a 	eor.w	lr, r6, sl
 80013b6:	f8cd e068 	str.w	lr, [sp, #104]	@ 0x68
 80013ba:	f8dd e090 	ldr.w	lr, [sp, #144]	@ 0x90
 80013be:	ea86 0e0e 	eor.w	lr, r6, lr
 80013c2:	f8cd e0ac 	str.w	lr, [sp, #172]	@ 0xac
 80013c6:	f8dd e01c 	ldr.w	lr, [sp, #28]
 80013ca:	ea86 0808 	eor.w	r8, r6, r8
 80013ce:	ea86 0e0e 	eor.w	lr, r6, lr
 80013d2:	9e02      	ldr	r6, [sp, #8]
 80013d4:	f8cd e0d0 	str.w	lr, [sp, #208]	@ 0xd0
 80013d8:	0076      	lsls	r6, r6, #1
 80013da:	ea46 76d5 	orr.w	r6, r6, r5, lsr #31
 80013de:	ea86 060c 	eor.w	r6, r6, ip
 80013e2:	f8dd c06c 	ldr.w	ip, [sp, #108]	@ 0x6c
 80013e6:	f8dd e0b0 	ldr.w	lr, [sp, #176]	@ 0xb0
 80013ea:	f8dd a048 	ldr.w	sl, [sp, #72]	@ 0x48
 80013ee:	ea86 0a0a 	eor.w	sl, r6, sl
 80013f2:	f8cd a010 	str.w	sl, [sp, #16]
 80013f6:	f8dd a094 	ldr.w	sl, [sp, #148]	@ 0x94
 80013fa:	ea86 0e0e 	eor.w	lr, r6, lr
 80013fe:	f8cd e064 	str.w	lr, [sp, #100]	@ 0x64
 8001402:	ea86 0e0a 	eor.w	lr, r6, sl
 8001406:	f8cd e0b0 	str.w	lr, [sp, #176]	@ 0xb0
 800140a:	f8dd e020 	ldr.w	lr, [sp, #32]
 800140e:	f8dd a028 	ldr.w	sl, [sp, #40]	@ 0x28
 8001412:	ea86 0c0c 	eor.w	ip, r6, ip
 8001416:	ea86 060e 	eor.w	r6, r6, lr
 800141a:	9639      	str	r6, [sp, #228]	@ 0xe4
 800141c:	004e      	lsls	r6, r1, #1
 800141e:	ea46 76d3 	orr.w	r6, r6, r3, lsr #31
 8001422:	4066      	eors	r6, r4
 8001424:	9c26      	ldr	r4, [sp, #152]	@ 0x98
 8001426:	005b      	lsls	r3, r3, #1
 8001428:	ea86 0e04 	eor.w	lr, r6, r4
 800142c:	ea43 73d1 	orr.w	r3, r3, r1, lsr #31
 8001430:	9c27      	ldr	r4, [sp, #156]	@ 0x9c
 8001432:	4053      	eors	r3, r2
 8001434:	ea83 0204 	eor.w	r2, r3, r4
 8001438:	9207      	str	r2, [sp, #28]
 800143a:	9a09      	ldr	r2, [sp, #36]	@ 0x24
 800143c:	ea86 0402 	eor.w	r4, r6, r2
 8001440:	9a1c      	ldr	r2, [sp, #112]	@ 0x70
 8001442:	4072      	eors	r2, r6
 8001444:	921b      	str	r2, [sp, #108]	@ 0x6c
 8001446:	9a2d      	ldr	r2, [sp, #180]	@ 0xb4
 8001448:	ea83 010a 	eor.w	r1, r3, sl
 800144c:	f8dd a074 	ldr.w	sl, [sp, #116]	@ 0x74
 8001450:	4072      	eors	r2, r6
 8001452:	ea83 0a0a 	eor.w	sl, r3, sl
 8001456:	9226      	str	r2, [sp, #152]	@ 0x98
 8001458:	9a13      	ldr	r2, [sp, #76]	@ 0x4c
 800145a:	f8cd a070 	str.w	sl, [sp, #112]	@ 0x70
 800145e:	f8dd a0b8 	ldr.w	sl, [sp, #184]	@ 0xb8
 8001462:	4072      	eors	r2, r6
 8001464:	9222      	str	r2, [sp, #136]	@ 0x88
 8001466:	ea83 020a 	eor.w	r2, r3, sl
 800146a:	9227      	str	r2, [sp, #156]	@ 0x9c
 800146c:	9a14      	ldr	r2, [sp, #80]	@ 0x50
 800146e:	463e      	mov	r6, r7
 8001470:	405a      	eors	r2, r3
 8001472:	ea4f 0a47 	mov.w	sl, r7, lsl #1
 8001476:	9b02      	ldr	r3, [sp, #8]
 8001478:	922d      	str	r2, [sp, #180]	@ 0xb4
 800147a:	0047      	lsls	r7, r0, #1
 800147c:	9a16      	ldr	r2, [sp, #88]	@ 0x58
 800147e:	ea4a 7ad0 	orr.w	sl, sl, r0, lsr #31
 8001482:	ea47 77d6 	orr.w	r7, r7, r6, lsr #31
 8001486:	ea8a 0a05 	eor.w	sl, sl, r5
 800148a:	405f      	eors	r7, r3
 800148c:	9d2f      	ldr	r5, [sp, #188]	@ 0xbc
 800148e:	ea87 0302 	eor.w	r3, r7, r2
 8001492:	9a28      	ldr	r2, [sp, #160]	@ 0xa0
 8001494:	ea8a 0605 	eor.w	r6, sl, r5
 8001498:	9d30      	ldr	r5, [sp, #192]	@ 0xc0
 800149a:	ea8a 0202 	eor.w	r2, sl, r2
 800149e:	ea87 0005 	eor.w	r0, r7, r5
 80014a2:	9214      	str	r2, [sp, #80]	@ 0x50
 80014a4:	9d15      	ldr	r5, [sp, #84]	@ 0x54
 80014a6:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 80014a8:	407a      	eors	r2, r7
 80014aa:	9215      	str	r2, [sp, #84]	@ 0x54
 80014ac:	9a0b      	ldr	r2, [sp, #44]	@ 0x2c
 80014ae:	ea8a 0202 	eor.w	r2, sl, r2
 80014b2:	9224      	str	r2, [sp, #144]	@ 0x90
 80014b4:	9a1e      	ldr	r2, [sp, #120]	@ 0x78
 80014b6:	ea8a 0505 	eor.w	r5, sl, r5
 80014ba:	ea8a 0a02 	eor.w	sl, sl, r2
 80014be:	9a0c      	ldr	r2, [sp, #48]	@ 0x30
 80014c0:	f8cd a08c 	str.w	sl, [sp, #140]	@ 0x8c
 80014c4:	ea87 0a02 	eor.w	sl, r7, r2
 80014c8:	9a1f      	ldr	r2, [sp, #124]	@ 0x7c
 80014ca:	f8cd a094 	str.w	sl, [sp, #148]	@ 0x94
 80014ce:	f8dd a004 	ldr.w	sl, [sp, #4]
 80014d2:	4057      	eors	r7, r2
 80014d4:	9728      	str	r7, [sp, #160]	@ 0xa0
 80014d6:	9a31      	ldr	r2, [sp, #196]	@ 0xc4
 80014d8:	f8da 7000 	ldr.w	r7, [sl]
 80014dc:	4057      	eors	r7, r2
 80014de:	9709      	str	r7, [sp, #36]	@ 0x24
 80014e0:	9a0d      	ldr	r2, [sp, #52]	@ 0x34
 80014e2:	f8da 7004 	ldr.w	r7, [sl, #4]
 80014e6:	4057      	eors	r7, r2
 80014e8:	9a05      	ldr	r2, [sp, #20]
 80014ea:	970a      	str	r7, [sp, #40]	@ 0x28
 80014ec:	0d17      	lsrs	r7, r2, #20
 80014ee:	ea47 3709 	orr.w	r7, r7, r9, lsl #12
 80014f2:	ea4f 5919 	mov.w	r9, r9, lsr #20
 80014f6:	ea49 3902 	orr.w	r9, r9, r2, lsl #12
 80014fa:	f8cd 9018 	str.w	r9, [sp, #24]
 80014fe:	ea4f 3986 	mov.w	r9, r6, lsl #14
 8001502:	ea49 4990 	orr.w	r9, r9, r0, lsr #18
 8001506:	0380      	lsls	r0, r0, #14
 8001508:	ea40 4096 	orr.w	r0, r0, r6, lsr #18
 800150c:	ea4f 5a58 	mov.w	sl, r8, lsr #21
 8001510:	0726      	lsls	r6, r4, #28
 8001512:	ea4a 2acc 	orr.w	sl, sl, ip, lsl #11
 8001516:	ea46 1611 	orr.w	r6, r6, r1, lsr #4
 800151a:	9a07      	ldr	r2, [sp, #28]
 800151c:	900b      	str	r0, [sp, #44]	@ 0x2c
 800151e:	ea4f 5c5c 	mov.w	ip, ip, lsr #21
 8001522:	0709      	lsls	r1, r1, #28
 8001524:	ea41 1014 	orr.w	r0, r1, r4, lsr #4
 8001528:	ea4c 28c8 	orr.w	r8, ip, r8, lsl #11
 800152c:	052c      	lsls	r4, r5, #20
 800152e:	ea4f 5c4e 	mov.w	ip, lr, lsl #21
 8001532:	ea4c 2cd2 	orr.w	ip, ip, r2, lsr #11
 8001536:	ea44 3413 	orr.w	r4, r4, r3, lsr #12
 800153a:	0552      	lsls	r2, r2, #21
 800153c:	051b      	lsls	r3, r3, #20
 800153e:	ea42 22de 	orr.w	r2, r2, lr, lsr #11
 8001542:	ea43 3e15 	orr.w	lr, r3, r5, lsr #12
 8001546:	9d17      	ldr	r5, [sp, #92]	@ 0x5c
 8001548:	f8cd e048 	str.w	lr, [sp, #72]	@ 0x48
 800154c:	f8dd e03c 	ldr.w	lr, [sp, #60]	@ 0x3c
 8001550:	f8cd 8020 	str.w	r8, [sp, #32]
 8001554:	00eb      	lsls	r3, r5, #3
 8001556:	ea4f 08cb 	mov.w	r8, fp, lsl #3
 800155a:	ea48 7855 	orr.w	r8, r8, r5, lsr #29
 800155e:	990e      	ldr	r1, [sp, #56]	@ 0x38
 8001560:	9410      	str	r4, [sp, #64]	@ 0x40
 8001562:	ea43 755b 	orr.w	r5, r3, fp, lsr #29
 8001566:	4673      	mov	r3, lr
 8001568:	9c18      	ldr	r4, [sp, #96]	@ 0x60
 800156a:	9513      	str	r5, [sp, #76]	@ 0x4c
 800156c:	0cdb      	lsrs	r3, r3, #19
 800156e:	ea43 3341 	orr.w	r3, r3, r1, lsl #13
 8001572:	0ccd      	lsrs	r5, r1, #19
 8001574:	9919      	ldr	r1, [sp, #100]	@ 0x64
 8001576:	9011      	str	r0, [sp, #68]	@ 0x44
 8001578:	ea45 354e 	orr.w	r5, r5, lr, lsl #13
 800157c:	ea4f 0ed4 	mov.w	lr, r4, lsr #3
 8001580:	ea4e 7e41 	orr.w	lr, lr, r1, lsl #29
 8001584:	08c9      	lsrs	r1, r1, #3
 8001586:	ea41 7144 	orr.w	r1, r1, r4, lsl #29
 800158a:	9c20      	ldr	r4, [sp, #128]	@ 0x80
 800158c:	9803      	ldr	r0, [sp, #12]
 800158e:	ea4f 0b44 	mov.w	fp, r4, lsl #1
 8001592:	ea4b 70d0 	orr.w	r0, fp, r0, lsr #31
 8001596:	f8dd b00c 	ldr.w	fp, [sp, #12]
 800159a:	901e      	str	r0, [sp, #120]	@ 0x78
 800159c:	ea4f 0b4b 	mov.w	fp, fp, lsl #1
 80015a0:	ea4b 7bd4 	orr.w	fp, fp, r4, lsr #31
 80015a4:	9c1a      	ldr	r4, [sp, #104]	@ 0x68
 80015a6:	9804      	ldr	r0, [sp, #16]
 80015a8:	f8cd b07c 	str.w	fp, [sp, #124]	@ 0x7c
 80015ac:	ea4f 1b84 	mov.w	fp, r4, lsl #6
 80015b0:	ea4b 6090 	orr.w	r0, fp, r0, lsr #26
 80015b4:	9002      	str	r0, [sp, #8]
 80015b6:	9804      	ldr	r0, [sp, #16]
 80015b8:	ea4f 1b80 	mov.w	fp, r0, lsl #6
 80015bc:	ea4b 6094 	orr.w	r0, fp, r4, lsr #26
 80015c0:	9c1b      	ldr	r4, [sp, #108]	@ 0x6c
 80015c2:	9004      	str	r0, [sp, #16]
 80015c4:	981c      	ldr	r0, [sp, #112]	@ 0x70
 80015c6:	ea4f 6b44 	mov.w	fp, r4, lsl #25
 80015ca:	ea4b 1bd0 	orr.w	fp, fp, r0, lsr #7
 80015ce:	f8cd b068 	str.w	fp, [sp, #104]	@ 0x68
 80015d2:	ea4f 6b40 	mov.w	fp, r0, lsl #25
 80015d6:	ea4b 10d4 	orr.w	r0, fp, r4, lsr #7
 80015da:	9c14      	ldr	r4, [sp, #80]	@ 0x50
 80015dc:	901b      	str	r0, [sp, #108]	@ 0x6c
 80015de:	9815      	ldr	r0, [sp, #84]	@ 0x54
 80015e0:	ea4f 2b04 	mov.w	fp, r4, lsl #8
 80015e4:	ea4b 6b10 	orr.w	fp, fp, r0, lsr #24
 80015e8:	f8cd b014 	str.w	fp, [sp, #20]
 80015ec:	ea4f 2b00 	mov.w	fp, r0, lsl #8
 80015f0:	ea4b 6014 	orr.w	r0, fp, r4, lsr #24
 80015f4:	9003      	str	r0, [sp, #12]
 80015f6:	9835      	ldr	r0, [sp, #212]	@ 0xd4
 80015f8:	9c36      	ldr	r4, [sp, #216]	@ 0xd8
 80015fa:	ea4f 4b80 	mov.w	fp, r0, lsl #18
 80015fe:	ea4b 3b94 	orr.w	fp, fp, r4, lsr #14
 8001602:	f8cd b070 	str.w	fp, [sp, #112]	@ 0x70
 8001606:	ea4f 4b84 	mov.w	fp, r4, lsl #18
 800160a:	9c09      	ldr	r4, [sp, #36]	@ 0x24
 800160c:	ea4b 3090 	orr.w	r0, fp, r0, lsr #14
 8001610:	ea2a 0b07 	bic.w	fp, sl, r7
 8001614:	ea84 040b 	eor.w	r4, r4, fp
 8001618:	901d      	str	r0, [sp, #116]	@ 0x74
 800161a:	f8dd b018 	ldr.w	fp, [sp, #24]
 800161e:	9808      	ldr	r0, [sp, #32]
 8001620:	9407      	str	r4, [sp, #28]
 8001622:	9c0a      	ldr	r4, [sp, #40]	@ 0x28
 8001624:	ea20 0b0b 	bic.w	fp, r0, fp
 8001628:	ea84 040b 	eor.w	r4, r4, fp
 800162c:	ea2c 0b0a 	bic.w	fp, ip, sl
 8001630:	9408      	str	r4, [sp, #32]
 8001632:	ea8b 0407 	eor.w	r4, fp, r7
 8001636:	f8dd b0c4 	ldr.w	fp, [sp, #196]	@ 0xc4
 800163a:	9409      	str	r4, [sp, #36]	@ 0x24
 800163c:	ea27 070b 	bic.w	r7, r7, fp
 8001640:	ea2b 0b09 	bic.w	fp, fp, r9
 8001644:	ea8b 040c 	eor.w	r4, fp, ip
 8001648:	ea29 0c0c 	bic.w	ip, r9, ip
 800164c:	ea8c 0c0a 	eor.w	ip, ip, sl
 8001650:	f8cd c028 	str.w	ip, [sp, #40]	@ 0x28
 8001654:	ea87 0c09 	eor.w	ip, r7, r9
 8001658:	940c      	str	r4, [sp, #48]	@ 0x30
 800165a:	f8cd c038 	str.w	ip, [sp, #56]	@ 0x38
 800165e:	f8dd 9018 	ldr.w	r9, [sp, #24]
 8001662:	9c10      	ldr	r4, [sp, #64]	@ 0x40
 8001664:	f8dd b07c 	ldr.w	fp, [sp, #124]	@ 0x7c
 8001668:	ea22 0700 	bic.w	r7, r2, r0
 800166c:	ea87 0c09 	eor.w	ip, r7, r9
 8001670:	4682      	mov	sl, r0
 8001672:	f8cd c018 	str.w	ip, [sp, #24]
 8001676:	980b      	ldr	r0, [sp, #44]	@ 0x2c
 8001678:	f8dd c034 	ldr.w	ip, [sp, #52]	@ 0x34
 800167c:	ea29 070c 	bic.w	r7, r9, ip
 8001680:	ea2c 0c00 	bic.w	ip, ip, r0
 8001684:	ea8c 0c02 	eor.w	ip, ip, r2
 8001688:	ea20 0202 	bic.w	r2, r0, r2
 800168c:	ea82 090a 	eor.w	r9, r2, sl
 8001690:	4047      	eors	r7, r0
 8001692:	ea28 0204 	bic.w	r2, r8, r4
 8001696:	970f      	str	r7, [sp, #60]	@ 0x3c
 8001698:	ea82 0706 	eor.w	r7, r2, r6
 800169c:	f8cd c034 	str.w	ip, [sp, #52]	@ 0x34
 80016a0:	9710      	str	r7, [sp, #64]	@ 0x40
 80016a2:	e9dd 7c12 	ldrd	r7, ip, [sp, #72]	@ 0x48
 80016a6:	9811      	ldr	r0, [sp, #68]	@ 0x44
 80016a8:	f8cd 902c 	str.w	r9, [sp, #44]	@ 0x2c
 80016ac:	ea2c 0207 	bic.w	r2, ip, r7
 80016b0:	4042      	eors	r2, r0
 80016b2:	9211      	str	r2, [sp, #68]	@ 0x44
 80016b4:	ea25 0208 	bic.w	r2, r5, r8
 80016b8:	ea82 0904 	eor.w	r9, r2, r4
 80016bc:	ea24 0406 	bic.w	r4, r4, r6
 80016c0:	ea26 060e 	bic.w	r6, r6, lr
 80016c4:	ea86 0a05 	eor.w	sl, r6, r5
 80016c8:	ea2e 0505 	bic.w	r5, lr, r5
 80016cc:	ea23 020c 	bic.w	r2, r3, ip
 80016d0:	ea85 0508 	eor.w	r5, r5, r8
 80016d4:	9e02      	ldr	r6, [sp, #8]
 80016d6:	f8dd 8078 	ldr.w	r8, [sp, #120]	@ 0x78
 80016da:	9514      	str	r5, [sp, #80]	@ 0x50
 80016dc:	ea84 0e0e 	eor.w	lr, r4, lr
 80016e0:	ea82 0507 	eor.w	r5, r2, r7
 80016e4:	ea27 0200 	bic.w	r2, r7, r0
 80016e8:	ea20 0001 	bic.w	r0, r0, r1
 80016ec:	9f1c      	ldr	r7, [sp, #112]	@ 0x70
 80016ee:	f8cd e060 	str.w	lr, [sp, #96]	@ 0x60
 80016f2:	ea80 0e03 	eor.w	lr, r0, r3
 80016f6:	ea21 0303 	bic.w	r3, r1, r3
 80016fa:	ea83 0c0c 	eor.w	ip, r3, ip
 80016fe:	ea26 0308 	bic.w	r3, r6, r8
 8001702:	9513      	str	r5, [sp, #76]	@ 0x4c
 8001704:	ea83 0507 	eor.w	r5, r3, r7
 8001708:	f8cd c054 	str.w	ip, [sp, #84]	@ 0x54
 800170c:	9520      	str	r5, [sp, #128]	@ 0x80
 800170e:	ea82 0c01 	eor.w	ip, r2, r1
 8001712:	9d04      	ldr	r5, [sp, #16]
 8001714:	f8cd c064 	str.w	ip, [sp, #100]	@ 0x64
 8001718:	f8dd c074 	ldr.w	ip, [sp, #116]	@ 0x74
 800171c:	9f25      	ldr	r7, [sp, #148]	@ 0x94
 800171e:	f8cd 9048 	str.w	r9, [sp, #72]	@ 0x48
 8001722:	ea25 030b 	bic.w	r3, r5, fp
 8001726:	9d24      	ldr	r5, [sp, #144]	@ 0x90
 8001728:	f8cd a058 	str.w	sl, [sp, #88]	@ 0x58
 800172c:	ea83 000c 	eor.w	r0, r3, ip
 8001730:	9b37      	ldr	r3, [sp, #220]	@ 0xdc
 8001732:	f8cd e05c 	str.w	lr, [sp, #92]	@ 0x5c
 8001736:	9021      	str	r0, [sp, #132]	@ 0x84
 8001738:	ea4f 6ec5 	mov.w	lr, r5, lsl #27
 800173c:	9938      	ldr	r1, [sp, #224]	@ 0xe0
 800173e:	f8dd 90cc 	ldr.w	r9, [sp, #204]	@ 0xcc
 8001742:	9c27      	ldr	r4, [sp, #156]	@ 0x9c
 8001744:	ea4e 1e57 	orr.w	lr, lr, r7, lsr #5
 8001748:	06f8      	lsls	r0, r7, #27
 800174a:	0f1f      	lsrs	r7, r3, #28
 800174c:	ea47 1701 	orr.w	r7, r7, r1, lsl #4
 8001750:	0f0a      	lsrs	r2, r1, #28
 8001752:	992a      	ldr	r1, [sp, #168]	@ 0xa8
 8001754:	ea40 1055 	orr.w	r0, r0, r5, lsr #5
 8001758:	028d      	lsls	r5, r1, #10
 800175a:	ea45 5599 	orr.w	r5, r5, r9, lsr #22
 800175e:	ea4f 2a89 	mov.w	sl, r9, lsl #10
 8001762:	f8dd 90ac 	ldr.w	r9, [sp, #172]	@ 0xac
 8001766:	ea4a 5a91 	orr.w	sl, sl, r1, lsr #22
 800176a:	992c      	ldr	r1, [sp, #176]	@ 0xb0
 800176c:	ea42 1203 	orr.w	r2, r2, r3, lsl #4
 8001770:	ea4f 3cc9 	mov.w	ip, r9, lsl #15
 8001774:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 8001776:	ea4c 4c51 	orr.w	ip, ip, r1, lsr #17
 800177a:	03c9      	lsls	r1, r1, #15
 800177c:	ea41 4159 	orr.w	r1, r1, r9, lsr #17
 8001780:	ea4f 2913 	mov.w	r9, r3, lsr #8
 8001784:	ea49 6904 	orr.w	r9, r9, r4, lsl #24
 8001788:	0a24      	lsrs	r4, r4, #8
 800178a:	ea44 6403 	orr.w	r4, r4, r3, lsl #24
 800178e:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 8001790:	ea23 0306 	bic.w	r3, r3, r6
 8001794:	9e1c      	ldr	r6, [sp, #112]	@ 0x70
 8001796:	ea83 0308 	eor.w	r3, r3, r8
 800179a:	931e      	str	r3, [sp, #120]	@ 0x78
 800179c:	ea28 0306 	bic.w	r3, r8, r6
 80017a0:	f8dd 8014 	ldr.w	r8, [sp, #20]
 80017a4:	ea26 0608 	bic.w	r6, r6, r8
 80017a8:	f8dd 8068 	ldr.w	r8, [sp, #104]	@ 0x68
 80017ac:	ea86 0608 	eor.w	r6, r6, r8
 80017b0:	961c      	str	r6, [sp, #112]	@ 0x70
 80017b2:	9e05      	ldr	r6, [sp, #20]
 80017b4:	ea26 0608 	bic.w	r6, r6, r8
 80017b8:	f8dd 8008 	ldr.w	r8, [sp, #8]
 80017bc:	ea86 0808 	eor.w	r8, r6, r8
 80017c0:	f8cd 8068 	str.w	r8, [sp, #104]	@ 0x68
 80017c4:	f8dd 8014 	ldr.w	r8, [sp, #20]
 80017c8:	9e1b      	ldr	r6, [sp, #108]	@ 0x6c
 80017ca:	ea83 0808 	eor.w	r8, r3, r8
 80017ce:	f8cd 807c 	str.w	r8, [sp, #124]	@ 0x7c
 80017d2:	f8dd 8010 	ldr.w	r8, [sp, #16]
 80017d6:	ea26 0308 	bic.w	r3, r6, r8
 80017da:	9e1d      	ldr	r6, [sp, #116]	@ 0x74
 80017dc:	f8dd 800c 	ldr.w	r8, [sp, #12]
 80017e0:	ea83 030b 	eor.w	r3, r3, fp
 80017e4:	9305      	str	r3, [sp, #20]
 80017e6:	ea2b 0306 	bic.w	r3, fp, r6
 80017ea:	f8dd b06c 	ldr.w	fp, [sp, #108]	@ 0x6c
 80017ee:	ea26 0608 	bic.w	r6, r6, r8
 80017f2:	ea86 060b 	eor.w	r6, r6, fp
 80017f6:	961b      	str	r6, [sp, #108]	@ 0x6c
 80017f8:	ea28 060b 	bic.w	r6, r8, fp
 80017fc:	f8dd 8010 	ldr.w	r8, [sp, #16]
 8001800:	ea86 0b08 	eor.w	fp, r6, r8
 8001804:	9e34      	ldr	r6, [sp, #208]	@ 0xd0
 8001806:	f8dd 800c 	ldr.w	r8, [sp, #12]
 800180a:	f8cd b010 	str.w	fp, [sp, #16]
 800180e:	f8dd b0e4 	ldr.w	fp, [sp, #228]	@ 0xe4
 8001812:	ea83 0808 	eor.w	r8, r3, r8
 8001816:	08b3      	lsrs	r3, r6, #2
 8001818:	f8cd 8074 	str.w	r8, [sp, #116]	@ 0x74
 800181c:	ea43 788b 	orr.w	r8, r3, fp, lsl #30
 8001820:	465b      	mov	r3, fp
 8001822:	089b      	lsrs	r3, r3, #2
 8001824:	ea43 7686 	orr.w	r6, r3, r6, lsl #30
 8001828:	f8cd 8008 	str.w	r8, [sp, #8]
 800182c:	962c      	str	r6, [sp, #176]	@ 0xb0
 800182e:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 8001830:	f8dd b0b4 	ldr.w	fp, [sp, #180]	@ 0xb4
 8001834:	0a5e      	lsrs	r6, r3, #9
 8001836:	ea46 56cb 	orr.w	r6, r6, fp, lsl #23
 800183a:	465b      	mov	r3, fp
 800183c:	f8dd b088 	ldr.w	fp, [sp, #136]	@ 0x88
 8001840:	0a5b      	lsrs	r3, r3, #9
 8001842:	ea43 58cb 	orr.w	r8, r3, fp, lsl #23
 8001846:	9b23      	ldr	r3, [sp, #140]	@ 0x8c
 8001848:	f8dd b0a0 	ldr.w	fp, [sp, #160]	@ 0xa0
 800184c:	f8cd 80b4 	str.w	r8, [sp, #180]	@ 0xb4
 8001850:	0e5b      	lsrs	r3, r3, #25
 8001852:	ea43 18cb 	orr.w	r8, r3, fp, lsl #7
 8001856:	465b      	mov	r3, fp
 8001858:	f8dd b08c 	ldr.w	fp, [sp, #140]	@ 0x8c
 800185c:	f8cd 800c 	str.w	r8, [sp, #12]
 8001860:	0e5b      	lsrs	r3, r3, #25
 8001862:	ea43 1bcb 	orr.w	fp, r3, fp, lsl #7
 8001866:	9b32      	ldr	r3, [sp, #200]	@ 0xc8
 8001868:	f8dd 80e8 	ldr.w	r8, [sp, #232]	@ 0xe8
 800186c:	f8cd b0b8 	str.w	fp, [sp, #184]	@ 0xb8
 8001870:	0ddb      	lsrs	r3, r3, #23
 8001872:	f8dd b0c8 	ldr.w	fp, [sp, #200]	@ 0xc8
 8001876:	ea43 2348 	orr.w	r3, r3, r8, lsl #9
 800187a:	ea4f 58d8 	mov.w	r8, r8, lsr #23
 800187e:	9330      	str	r3, [sp, #192]	@ 0xc0
 8001880:	ea48 234b 	orr.w	r3, r8, fp, lsl #9
 8001884:	932f      	str	r3, [sp, #188]	@ 0xbc
 8001886:	9b3b      	ldr	r3, [sp, #236]	@ 0xec
 8001888:	f8dd b0f0 	ldr.w	fp, [sp, #240]	@ 0xf0
 800188c:	ea4f 0883 	mov.w	r8, r3, lsl #2
 8001890:	ea48 789b 	orr.w	r8, r8, fp, lsr #30
 8001894:	ea4f 0b8b 	mov.w	fp, fp, lsl #2
 8001898:	ea4b 7b93 	orr.w	fp, fp, r3, lsr #30
 800189c:	f8cd b0d0 	str.w	fp, [sp, #208]	@ 0xd0
 80018a0:	ea2a 0b07 	bic.w	fp, sl, r7
 80018a4:	ea8b 0b0e 	eor.w	fp, fp, lr
 80018a8:	465b      	mov	r3, fp
 80018aa:	ea25 0b02 	bic.w	fp, r5, r2
 80018ae:	ea8b 0b00 	eor.w	fp, fp, r0
 80018b2:	f8cd b08c 	str.w	fp, [sp, #140]	@ 0x8c
 80018b6:	ea2c 0b0a 	bic.w	fp, ip, sl
 80018ba:	ea8b 0b07 	eor.w	fp, fp, r7
 80018be:	ea27 070e 	bic.w	r7, r7, lr
 80018c2:	ea2e 0e09 	bic.w	lr, lr, r9
 80018c6:	ea8e 0e0c 	eor.w	lr, lr, ip
 80018ca:	ea29 0c0c 	bic.w	ip, r9, ip
 80018ce:	ea8c 0a0a 	eor.w	sl, ip, sl
 80018d2:	f8cd e0a0 	str.w	lr, [sp, #160]	@ 0xa0
 80018d6:	ea87 0e09 	eor.w	lr, r7, r9
 80018da:	ea21 0705 	bic.w	r7, r1, r5
 80018de:	f8cd a098 	str.w	sl, [sp, #152]	@ 0x98
 80018e2:	ea87 0a02 	eor.w	sl, r7, r2
 80018e6:	ea22 0200 	bic.w	r2, r2, r0
 80018ea:	ea20 0004 	bic.w	r0, r0, r4
 80018ee:	4048      	eors	r0, r1
 80018f0:	ea24 0101 	bic.w	r1, r4, r1
 80018f4:	4069      	eors	r1, r5
 80018f6:	f8cd e0a8 	str.w	lr, [sp, #168]	@ 0xa8
 80018fa:	9d07      	ldr	r5, [sp, #28]
 80018fc:	f8dd e040 	ldr.w	lr, [sp, #64]	@ 0x40
 8001900:	9127      	str	r1, [sp, #156]	@ 0x9c
 8001902:	ea82 0104 	eor.w	r1, r2, r4
 8001906:	912b      	str	r1, [sp, #172]	@ 0xac
 8001908:	991e      	ldr	r1, [sp, #120]	@ 0x78
 800190a:	f8dd 9020 	ldr.w	r9, [sp, #32]
 800190e:	9f05      	ldr	r7, [sp, #20]
 8001910:	9029      	str	r0, [sp, #164]	@ 0xa4
 8001912:	ea85 0e0e 	eor.w	lr, r5, lr
 8001916:	9d11      	ldr	r5, [sp, #68]	@ 0x44
 8001918:	9322      	str	r3, [sp, #136]	@ 0x88
 800191a:	ea8e 0e01 	eor.w	lr, lr, r1
 800191e:	f8cd b090 	str.w	fp, [sp, #144]	@ 0x90
 8001922:	f8dd b08c 	ldr.w	fp, [sp, #140]	@ 0x8c
 8001926:	9909      	ldr	r1, [sp, #36]	@ 0x24
 8001928:	9812      	ldr	r0, [sp, #72]	@ 0x48
 800192a:	9a1a      	ldr	r2, [sp, #104]	@ 0x68
 800192c:	f8cd a094 	str.w	sl, [sp, #148]	@ 0x94
 8001930:	ea89 0c05 	eor.w	ip, r9, r5
 8001934:	ea8c 0c07 	eor.w	ip, ip, r7
 8001938:	ea81 0500 	eor.w	r5, r1, r0
 800193c:	9f13      	ldr	r7, [sp, #76]	@ 0x4c
 800193e:	9806      	ldr	r0, [sp, #24]
 8001940:	9924      	ldr	r1, [sp, #144]	@ 0x90
 8001942:	f8dd 9054 	ldr.w	r9, [sp, #84]	@ 0x54
 8001946:	ea8e 0e03 	eor.w	lr, lr, r3
 800194a:	4055      	eors	r5, r2
 800194c:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 800194e:	ea80 0207 	eor.w	r2, r0, r7
 8001952:	9804      	ldr	r0, [sp, #16]
 8001954:	9f0a      	ldr	r7, [sp, #40]	@ 0x28
 8001956:	4042      	eors	r2, r0
 8001958:	ea87 0403 	eor.w	r4, r7, r3
 800195c:	9f1c      	ldr	r7, [sp, #112]	@ 0x70
 800195e:	981f      	ldr	r0, [sp, #124]	@ 0x7c
 8001960:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8001962:	404d      	eors	r5, r1
 8001964:	ea82 0a0a 	eor.w	sl, r2, sl
 8001968:	990b      	ldr	r1, [sp, #44]	@ 0x2c
 800196a:	9a26      	ldr	r2, [sp, #152]	@ 0x98
 800196c:	407c      	eors	r4, r7
 800196e:	4054      	eors	r4, r2
 8001970:	ea81 0209 	eor.w	r2, r1, r9
 8001974:	991b      	ldr	r1, [sp, #108]	@ 0x6c
 8001976:	f8dd 909c 	ldr.w	r9, [sp, #156]	@ 0x9c
 800197a:	9f0c      	ldr	r7, [sp, #48]	@ 0x30
 800197c:	9431      	str	r4, [sp, #196]	@ 0xc4
 800197e:	9c16      	ldr	r4, [sp, #88]	@ 0x58
 8001980:	404a      	eors	r2, r1
 8001982:	ea8c 0c0b 	eor.w	ip, ip, fp
 8001986:	4067      	eors	r7, r4
 8001988:	ea82 0b09 	eor.w	fp, r2, r9
 800198c:	9c17      	ldr	r4, [sp, #92]	@ 0x5c
 800198e:	9a28      	ldr	r2, [sp, #160]	@ 0xa0
 8001990:	f8dd 9034 	ldr.w	r9, [sp, #52]	@ 0x34
 8001994:	4047      	eors	r7, r0
 8001996:	981d      	ldr	r0, [sp, #116]	@ 0x74
 8001998:	4057      	eors	r7, r2
 800199a:	ea89 0104 	eor.w	r1, r9, r4
 800199e:	9a29      	ldr	r2, [sp, #164]	@ 0xa4
 80019a0:	f8dd 9060 	ldr.w	r9, [sp, #96]	@ 0x60
 80019a4:	9c20      	ldr	r4, [sp, #128]	@ 0x80
 80019a6:	4041      	eors	r1, r0
 80019a8:	4051      	eors	r1, r2
 80019aa:	9a0e      	ldr	r2, [sp, #56]	@ 0x38
 80019ac:	ea89 0004 	eor.w	r0, r9, r4
 80019b0:	4050      	eors	r0, r2
 80019b2:	9c21      	ldr	r4, [sp, #132]	@ 0x84
 80019b4:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 80019b6:	4050      	eors	r0, r2
 80019b8:	ea83 0204 	eor.w	r2, r3, r4
 80019bc:	9b0f      	ldr	r3, [sp, #60]	@ 0x3c
 80019be:	405a      	eors	r2, r3
 80019c0:	9b2b      	ldr	r3, [sp, #172]	@ 0xac
 80019c2:	4053      	eors	r3, r2
 80019c4:	9a03      	ldr	r2, [sp, #12]
 80019c6:	9336      	str	r3, [sp, #216]	@ 0xd8
 80019c8:	9b02      	ldr	r3, [sp, #8]
 80019ca:	ea22 0906 	bic.w	r9, r2, r6
 80019ce:	ea89 0903 	eor.w	r9, r9, r3
 80019d2:	ea8e 0e09 	eor.w	lr, lr, r9
 80019d6:	f8cd e0cc 	str.w	lr, [sp, #204]	@ 0xcc
 80019da:	e9dd 4e2d 	ldrd	r4, lr, [sp, #180]	@ 0xb4
 80019de:	ea2e 0e04 	bic.w	lr, lr, r4
 80019e2:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 80019e4:	ea8e 0e04 	eor.w	lr, lr, r4
 80019e8:	4614      	mov	r4, r2
 80019ea:	9a30      	ldr	r2, [sp, #192]	@ 0xc0
 80019ec:	ea8c 0c0e 	eor.w	ip, ip, lr
 80019f0:	f8cd c0d4 	str.w	ip, [sp, #212]	@ 0xd4
 80019f4:	ea22 0c04 	bic.w	ip, r2, r4
 80019f8:	ea8c 0c06 	eor.w	ip, ip, r6
 80019fc:	ea26 0603 	bic.w	r6, r6, r3
 8001a00:	ea23 0308 	bic.w	r3, r3, r8
 8001a04:	4053      	eors	r3, r2
 8001a06:	f8cd c0c0 	str.w	ip, [sp, #192]	@ 0xc0
 8001a0a:	469c      	mov	ip, r3
 8001a0c:	ea28 0302 	bic.w	r3, r8, r2
 8001a10:	4063      	eors	r3, r4
 8001a12:	9c30      	ldr	r4, [sp, #192]	@ 0xc0
 8001a14:	9a34      	ldr	r2, [sp, #208]	@ 0xd0
 8001a16:	4065      	eors	r5, r4
 8001a18:	9c31      	ldr	r4, [sp, #196]	@ 0xc4
 8001a1a:	f8cd c0c4 	str.w	ip, [sp, #196]	@ 0xc4
 8001a1e:	405c      	eors	r4, r3
 8001a20:	ea86 0808 	eor.w	r8, r6, r8
 8001a24:	4646      	mov	r6, r8
 8001a26:	9402      	str	r4, [sp, #8]
 8001a28:	ea87 080c 	eor.w	r8, r7, ip
 8001a2c:	e9dd 472e 	ldrd	r4, r7, [sp, #184]	@ 0xb8
 8001a30:	4070      	eors	r0, r6
 8001a32:	9632      	str	r6, [sp, #200]	@ 0xc8
 8001a34:	9e2d      	ldr	r6, [sp, #180]	@ 0xb4
 8001a36:	f8cd 800c 	str.w	r8, [sp, #12]
 8001a3a:	ea27 0704 	bic.w	r7, r7, r4
 8001a3e:	4077      	eors	r7, r6
 8001a40:	46b4      	mov	ip, r6
 8001a42:	9e2c      	ldr	r6, [sp, #176]	@ 0xb0
 8001a44:	ea2c 0806 	bic.w	r8, ip, r6
 8001a48:	f8dd c0bc 	ldr.w	ip, [sp, #188]	@ 0xbc
 8001a4c:	ea26 0602 	bic.w	r6, r6, r2
 8001a50:	ea86 060c 	eor.w	r6, r6, ip
 8001a54:	962c      	str	r6, [sp, #176]	@ 0xb0
 8001a56:	ea22 060c 	bic.w	r6, r2, ip
 8001a5a:	4066      	eors	r6, r4
 8001a5c:	ea88 0802 	eor.w	r8, r8, r2
 8001a60:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 8001a62:	9a36      	ldr	r2, [sp, #216]	@ 0xd8
 8001a64:	ea8a 0a07 	eor.w	sl, sl, r7
 8001a68:	46c4      	mov	ip, r8
 8001a6a:	ea8b 0806 	eor.w	r8, fp, r6
 8001a6e:	ea4f 0b45 	mov.w	fp, r5, lsl #1
 8001a72:	4061      	eors	r1, r4
 8001a74:	f8cd c0b4 	str.w	ip, [sp, #180]	@ 0xb4
 8001a78:	4664      	mov	r4, ip
 8001a7a:	ea4b 7bda 	orr.w	fp, fp, sl, lsr #31
 8001a7e:	f8dd c078 	ldr.w	ip, [sp, #120]	@ 0x78
 8001a82:	ea8b 0b00 	eor.w	fp, fp, r0
 8001a86:	4062      	eors	r2, r4
 8001a88:	ea8c 040b 	eor.w	r4, ip, fp
 8001a8c:	f8dd c040 	ldr.w	ip, [sp, #64]	@ 0x40
 8001a90:	941e      	str	r4, [sp, #120]	@ 0x78
 8001a92:	ea89 040b 	eor.w	r4, r9, fp
 8001a96:	ea8c 090b 	eor.w	r9, ip, fp
 8001a9a:	942e      	str	r4, [sp, #184]	@ 0xb8
 8001a9c:	f8cd 90d0 	str.w	r9, [sp, #208]	@ 0xd0
 8001aa0:	f8dd c088 	ldr.w	ip, [sp, #136]	@ 0x88
 8001aa4:	9c02      	ldr	r4, [sp, #8]
 8001aa6:	ea8c 0c0b 	eor.w	ip, ip, fp
 8001aaa:	f8cd c0e4 	str.w	ip, [sp, #228]	@ 0xe4
 8001aae:	f8dd c01c 	ldr.w	ip, [sp, #28]
 8001ab2:	ea4f 094a 	mov.w	r9, sl, lsl #1
 8001ab6:	ea8c 0c0b 	eor.w	ip, ip, fp
 8001aba:	f8cd c01c 	str.w	ip, [sp, #28]
 8001abe:	ea49 79d5 	orr.w	r9, r9, r5, lsr #31
 8001ac2:	f8dd c014 	ldr.w	ip, [sp, #20]
 8001ac6:	ea89 0902 	eor.w	r9, r9, r2
 8001aca:	ea8c 0c09 	eor.w	ip, ip, r9
 8001ace:	ea8e 0e09 	eor.w	lr, lr, r9
 8001ad2:	f8cd c088 	str.w	ip, [sp, #136]	@ 0x88
 8001ad6:	f8dd c044 	ldr.w	ip, [sp, #68]	@ 0x44
 8001ada:	f8cd e0bc 	str.w	lr, [sp, #188]	@ 0xbc
 8001ade:	f8dd e08c 	ldr.w	lr, [sp, #140]	@ 0x8c
 8001ae2:	ea8c 0c09 	eor.w	ip, ip, r9
 8001ae6:	f8cd c0d8 	str.w	ip, [sp, #216]	@ 0xd8
 8001aea:	ea8e 0c09 	eor.w	ip, lr, r9
 8001aee:	f8dd e020 	ldr.w	lr, [sp, #32]
 8001af2:	f8cd c0e8 	str.w	ip, [sp, #232]	@ 0xe8
 8001af6:	ea8e 0e09 	eor.w	lr, lr, r9
 8001afa:	f8dd c0cc 	ldr.w	ip, [sp, #204]	@ 0xcc
 8001afe:	f8cd e020 	str.w	lr, [sp, #32]
 8001b02:	ea4f 0e44 	mov.w	lr, r4, lsl #1
 8001b06:	f8dd 9090 	ldr.w	r9, [sp, #144]	@ 0x90
 8001b0a:	ea4e 7ed8 	orr.w	lr, lr, r8, lsr #31
 8001b0e:	ea8e 0e0c 	eor.w	lr, lr, ip
 8001b12:	ea89 090e 	eor.w	r9, r9, lr
 8001b16:	f8cd 908c 	str.w	r9, [sp, #140]	@ 0x8c
 8001b1a:	f8dd 9024 	ldr.w	r9, [sp, #36]	@ 0x24
 8001b1e:	f8dd c048 	ldr.w	ip, [sp, #72]	@ 0x48
 8001b22:	ea89 090e 	eor.w	r9, r9, lr
 8001b26:	ea8c 0b0e 	eor.w	fp, ip, lr
 8001b2a:	f8cd 9014 	str.w	r9, [sp, #20]
 8001b2e:	f8dd 90c0 	ldr.w	r9, [sp, #192]	@ 0xc0
 8001b32:	f8cd b040 	str.w	fp, [sp, #64]	@ 0x40
 8001b36:	f8dd b068 	ldr.w	fp, [sp, #104]	@ 0x68
 8001b3a:	f8dd c04c 	ldr.w	ip, [sp, #76]	@ 0x4c
 8001b3e:	ea89 090e 	eor.w	r9, r9, lr
 8001b42:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001b46:	f8cd 90ec 	str.w	r9, [sp, #236]	@ 0xec
 8001b4a:	ea4f 0e48 	mov.w	lr, r8, lsl #1
 8001b4e:	f8dd 90d4 	ldr.w	r9, [sp, #212]	@ 0xd4
 8001b52:	f8cd b0dc 	str.w	fp, [sp, #220]	@ 0xdc
 8001b56:	ea4e 7ed4 	orr.w	lr, lr, r4, lsr #31
 8001b5a:	f8dd b094 	ldr.w	fp, [sp, #148]	@ 0x94
 8001b5e:	ea8e 0e09 	eor.w	lr, lr, r9
 8001b62:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001b66:	f8cd b024 	str.w	fp, [sp, #36]	@ 0x24
 8001b6a:	f8dd b018 	ldr.w	fp, [sp, #24]
 8001b6e:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001b72:	f8cd b090 	str.w	fp, [sp, #144]	@ 0x90
 8001b76:	f8dd b010 	ldr.w	fp, [sp, #16]
 8001b7a:	ea8b 0b0e 	eor.w	fp, fp, lr
 8001b7e:	f8cd b0c0 	str.w	fp, [sp, #192]	@ 0xc0
 8001b82:	9c03      	ldr	r4, [sp, #12]
 8001b84:	f8dd b028 	ldr.w	fp, [sp, #40]	@ 0x28
 8001b88:	ea87 070e 	eor.w	r7, r7, lr
 8001b8c:	973c      	str	r7, [sp, #240]	@ 0xf0
 8001b8e:	0067      	lsls	r7, r4, #1
 8001b90:	ea47 77d1 	orr.w	r7, r7, r1, lsr #31
 8001b94:	406f      	eors	r7, r5
 8001b96:	ea8c 0c0e 	eor.w	ip, ip, lr
 8001b9a:	f8dd e050 	ldr.w	lr, [sp, #80]	@ 0x50
 8001b9e:	9d1c      	ldr	r5, [sp, #112]	@ 0x70
 8001ba0:	407b      	eors	r3, r7
 8001ba2:	9313      	str	r3, [sp, #76]	@ 0x4c
 8001ba4:	ea8e 0307 	eor.w	r3, lr, r7
 8001ba8:	931c      	str	r3, [sp, #112]	@ 0x70
 8001baa:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 8001bac:	f8dd e030 	ldr.w	lr, [sp, #48]	@ 0x30
 8001bb0:	407b      	eors	r3, r7
 8001bb2:	9326      	str	r3, [sp, #152]	@ 0x98
 8001bb4:	004b      	lsls	r3, r1, #1
 8001bb6:	ea43 73d4 	orr.w	r3, r3, r4, lsr #31
 8001bba:	ea83 030a 	eor.w	r3, r3, sl
 8001bbe:	405e      	eors	r6, r3
 8001bc0:	961a      	str	r6, [sp, #104]	@ 0x68
 8001bc2:	9e15      	ldr	r6, [sp, #84]	@ 0x54
 8001bc4:	f8dd a06c 	ldr.w	sl, [sp, #108]	@ 0x6c
 8001bc8:	9c02      	ldr	r4, [sp, #8]
 8001bca:	405e      	eors	r6, r3
 8001bcc:	9615      	str	r6, [sp, #84]	@ 0x54
 8001bce:	9e27      	ldr	r6, [sp, #156]	@ 0x9c
 8001bd0:	405e      	eors	r6, r3
 8001bd2:	9627      	str	r6, [sp, #156]	@ 0x9c
 8001bd4:	9e0b      	ldr	r6, [sp, #44]	@ 0x2c
 8001bd6:	407d      	eors	r5, r7
 8001bd8:	ea8b 0707 	eor.w	r7, fp, r7
 8001bdc:	9735      	str	r7, [sp, #212]	@ 0xd4
 8001bde:	ea8a 0703 	eor.w	r7, sl, r3
 8001be2:	4073      	eors	r3, r6
 8001be4:	9338      	str	r3, [sp, #224]	@ 0xe0
 8001be6:	0043      	lsls	r3, r0, #1
 8001be8:	f8dd a0a0 	ldr.w	sl, [sp, #160]	@ 0xa0
 8001bec:	f8dd b034 	ldr.w	fp, [sp, #52]	@ 0x34
 8001bf0:	ea43 73d2 	orr.w	r3, r3, r2, lsr #31
 8001bf4:	0052      	lsls	r2, r2, #1
 8001bf6:	4063      	eors	r3, r4
 8001bf8:	ea42 72d0 	orr.w	r2, r2, r0, lsr #31
 8001bfc:	ea82 0208 	eor.w	r2, r2, r8
 8001c00:	ea8a 0803 	eor.w	r8, sl, r3
 8001c04:	f8dd a0a4 	ldr.w	sl, [sp, #164]	@ 0xa4
 8001c08:	981d      	ldr	r0, [sp, #116]	@ 0x74
 8001c0a:	ea8a 0602 	eor.w	r6, sl, r2
 8001c0e:	f8dd a07c 	ldr.w	sl, [sp, #124]	@ 0x7c
 8001c12:	ea8a 0a03 	eor.w	sl, sl, r3
 8001c16:	f8cd a02c 	str.w	sl, [sp, #44]	@ 0x2c
 8001c1a:	ea80 0a02 	eor.w	sl, r0, r2
 8001c1e:	f8cd a074 	str.w	sl, [sp, #116]	@ 0x74
 8001c22:	f8dd a0c4 	ldr.w	sl, [sp, #196]	@ 0xc4
 8001c26:	ea8b 0402 	eor.w	r4, fp, r2
 8001c2a:	ea8a 0003 	eor.w	r0, sl, r3
 8001c2e:	f8dd b058 	ldr.w	fp, [sp, #88]	@ 0x58
 8001c32:	f8dd a0b0 	ldr.w	sl, [sp, #176]	@ 0xb0
 8001c36:	9028      	str	r0, [sp, #160]	@ 0xa0
 8001c38:	ea8e 0e03 	eor.w	lr, lr, r3
 8001c3c:	ea8b 0003 	eor.w	r0, fp, r3
 8001c40:	ea8a 0302 	eor.w	r3, sl, r2
 8001c44:	9031      	str	r0, [sp, #196]	@ 0xc4
 8001c46:	9329      	str	r3, [sp, #164]	@ 0xa4
 8001c48:	9833      	ldr	r0, [sp, #204]	@ 0xcc
 8001c4a:	f8dd b05c 	ldr.w	fp, [sp, #92]	@ 0x5c
 8001c4e:	0043      	lsls	r3, r0, #1
 8001c50:	ea8b 0b02 	eor.w	fp, fp, r2
 8001c54:	9a03      	ldr	r2, [sp, #12]
 8001c56:	f8cd b0b0 	str.w	fp, [sp, #176]	@ 0xb0
 8001c5a:	ea43 73d9 	orr.w	r3, r3, r9, lsr #31
 8001c5e:	4053      	eors	r3, r2
 8001c60:	9a32      	ldr	r2, [sp, #200]	@ 0xc8
 8001c62:	ea4f 0b49 	mov.w	fp, r9, lsl #1
 8001c66:	ea82 0a03 	eor.w	sl, r2, r3
 8001c6a:	ea4b 7bd0 	orr.w	fp, fp, r0, lsr #31
 8001c6e:	9a2d      	ldr	r2, [sp, #180]	@ 0xb4
 8001c70:	9819      	ldr	r0, [sp, #100]	@ 0x64
 8001c72:	f8dd 9060 	ldr.w	r9, [sp, #96]	@ 0x60
 8001c76:	ea8b 0b01 	eor.w	fp, fp, r1
 8001c7a:	ea82 020b 	eor.w	r2, r2, fp
 8001c7e:	9202      	str	r2, [sp, #8]
 8001c80:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 8001c82:	405a      	eors	r2, r3
 8001c84:	921f      	str	r2, [sp, #124]	@ 0x7c
 8001c86:	9a2b      	ldr	r2, [sp, #172]	@ 0xac
 8001c88:	ea82 010b 	eor.w	r1, r2, fp
 8001c8c:	9a0e      	ldr	r2, [sp, #56]	@ 0x38
 8001c8e:	405a      	eors	r2, r3
 8001c90:	9225      	str	r2, [sp, #148]	@ 0x94
 8001c92:	9a20      	ldr	r2, [sp, #128]	@ 0x80
 8001c94:	405a      	eors	r2, r3
 8001c96:	9232      	str	r2, [sp, #200]	@ 0xc8
 8001c98:	9a0f      	ldr	r2, [sp, #60]	@ 0x3c
 8001c9a:	ea82 020b 	eor.w	r2, r2, fp
 8001c9e:	9220      	str	r2, [sp, #128]	@ 0x80
 8001ca0:	9a21      	ldr	r2, [sp, #132]	@ 0x84
 8001ca2:	ea80 000b 	eor.w	r0, r0, fp
 8001ca6:	ea82 020b 	eor.w	r2, r2, fp
 8001caa:	f8dd b004 	ldr.w	fp, [sp, #4]
 8001cae:	9233      	str	r2, [sp, #204]	@ 0xcc
 8001cb0:	ea89 0903 	eor.w	r9, r9, r3
 8001cb4:	9a07      	ldr	r2, [sp, #28]
 8001cb6:	f8db 3008 	ldr.w	r3, [fp, #8]
 8001cba:	4053      	eors	r3, r2
 8001cbc:	f10b 0210 	add.w	r2, fp, #16
 8001cc0:	9304      	str	r3, [sp, #16]
 8001cc2:	9201      	str	r2, [sp, #4]
 8001cc4:	f8db 300c 	ldr.w	r3, [fp, #12]
 8001cc8:	9a10      	ldr	r2, [sp, #64]	@ 0x40
 8001cca:	f8dd b020 	ldr.w	fp, [sp, #32]
 8001cce:	ea8b 0b03 	eor.w	fp, fp, r3
 8001cd2:	0d13      	lsrs	r3, r2, #20
 8001cd4:	f8cd b018 	str.w	fp, [sp, #24]
 8001cd8:	ea43 3b0c 	orr.w	fp, r3, ip, lsl #12
 8001cdc:	0d6b      	lsrs	r3, r5, #21
 8001cde:	ea43 23c7 	orr.w	r3, r3, r7, lsl #11
 8001ce2:	9303      	str	r3, [sp, #12]
 8001ce4:	ea4f 5348 	mov.w	r3, r8, lsl #21
 8001ce8:	ea43 23d6 	orr.w	r3, r3, r6, lsr #11
 8001cec:	ea4f 5c1c 	mov.w	ip, ip, lsr #20
 8001cf0:	0d7f      	lsrs	r7, r7, #21
 8001cf2:	0576      	lsls	r6, r6, #21
 8001cf4:	ea4c 3c02 	orr.w	ip, ip, r2, lsl #12
 8001cf8:	ea47 27c5 	orr.w	r7, r7, r5, lsl #11
 8001cfc:	ea46 26d8 	orr.w	r6, r6, r8, lsr #11
 8001d00:	f8cd c028 	str.w	ip, [sp, #40]	@ 0x28
 8001d04:	970c      	str	r7, [sp, #48]	@ 0x30
 8001d06:	960d      	str	r6, [sp, #52]	@ 0x34
 8001d08:	9a02      	ldr	r2, [sp, #8]
 8001d0a:	9f22      	ldr	r7, [sp, #136]	@ 0x88
 8001d0c:	ea4f 760e 	mov.w	r6, lr, lsl #28
 8001d10:	ea46 1814 	orr.w	r8, r6, r4, lsr #4
 8001d14:	ea4f 358a 	mov.w	r5, sl, lsl #14
 8001d18:	0724      	lsls	r4, r4, #28
 8001d1a:	ea45 4592 	orr.w	r5, r5, r2, lsr #18
 8001d1e:	ea44 1e1e 	orr.w	lr, r4, lr, lsr #4
 8001d22:	0392      	lsls	r2, r2, #14
 8001d24:	ea4f 5409 	mov.w	r4, r9, lsl #20
 8001d28:	ea42 429a 	orr.w	r2, r2, sl, lsr #18
 8001d2c:	ea44 3a10 	orr.w	sl, r4, r0, lsr #12
 8001d30:	9c1e      	ldr	r4, [sp, #120]	@ 0x78
 8001d32:	f8cd 8038 	str.w	r8, [sp, #56]	@ 0x38
 8001d36:	0500      	lsls	r0, r0, #20
 8001d38:	f8dd 8024 	ldr.w	r8, [sp, #36]	@ 0x24
 8001d3c:	f8cd e03c 	str.w	lr, [sp, #60]	@ 0x3c
 8001d40:	ea40 3919 	orr.w	r9, r0, r9, lsr #12
 8001d44:	00e0      	lsls	r0, r4, #3
 8001d46:	ea40 7657 	orr.w	r6, r0, r7, lsr #29
 8001d4a:	00f8      	lsls	r0, r7, #3
 8001d4c:	ea40 7754 	orr.w	r7, r0, r4, lsr #29
 8001d50:	9c23      	ldr	r4, [sp, #140]	@ 0x8c
 8001d52:	9602      	str	r6, [sp, #8]
 8001d54:	4640      	mov	r0, r8
 8001d56:	0cc0      	lsrs	r0, r0, #19
 8001d58:	ea40 3e44 	orr.w	lr, r0, r4, lsl #13
 8001d5c:	0ce6      	lsrs	r6, r4, #19
 8001d5e:	9c13      	ldr	r4, [sp, #76]	@ 0x4c
 8001d60:	981a      	ldr	r0, [sp, #104]	@ 0x68
 8001d62:	9710      	str	r7, [sp, #64]	@ 0x40
 8001d64:	08e7      	lsrs	r7, r4, #3
 8001d66:	ea47 7740 	orr.w	r7, r7, r0, lsl #29
 8001d6a:	08c0      	lsrs	r0, r0, #3
 8001d6c:	ea40 7044 	orr.w	r0, r0, r4, lsl #29
 8001d70:	9c05      	ldr	r4, [sp, #20]
 8001d72:	f8cd 9048 	str.w	r9, [sp, #72]	@ 0x48
 8001d76:	ea46 3648 	orr.w	r6, r6, r8, lsl #13
 8001d7a:	f8dd 8090 	ldr.w	r8, [sp, #144]	@ 0x90
 8001d7e:	f8dd 9014 	ldr.w	r9, [sp, #20]
 8001d82:	9016      	str	r0, [sp, #88]	@ 0x58
 8001d84:	0064      	lsls	r4, r4, #1
 8001d86:	ea44 70d8 	orr.w	r0, r4, r8, lsr #31
 8001d8a:	4644      	mov	r4, r8
 8001d8c:	0064      	lsls	r4, r4, #1
 8001d8e:	ea44 78d9 	orr.w	r8, r4, r9, lsr #31
 8001d92:	9017      	str	r0, [sp, #92]	@ 0x5c
 8001d94:	981c      	ldr	r0, [sp, #112]	@ 0x70
 8001d96:	f8cd 8060 	str.w	r8, [sp, #96]	@ 0x60
 8001d9a:	f8dd 8054 	ldr.w	r8, [sp, #84]	@ 0x54
 8001d9e:	f8cd e050 	str.w	lr, [sp, #80]	@ 0x50
 8001da2:	0184      	lsls	r4, r0, #6
 8001da4:	ea44 6998 	orr.w	r9, r4, r8, lsr #26
 8001da8:	4644      	mov	r4, r8
 8001daa:	01a4      	lsls	r4, r4, #6
 8001dac:	ea44 6c90 	orr.w	ip, r4, r0, lsr #26
 8001db0:	980b      	ldr	r0, [sp, #44]	@ 0x2c
 8001db2:	f8dd 8074 	ldr.w	r8, [sp, #116]	@ 0x74
 8001db6:	f8cd 9068 	str.w	r9, [sp, #104]	@ 0x68
 8001dba:	0644      	lsls	r4, r0, #25
 8001dbc:	f8dd 907c 	ldr.w	r9, [sp, #124]	@ 0x7c
 8001dc0:	f8cd c06c 	str.w	ip, [sp, #108]	@ 0x6c
 8001dc4:	ea44 1ed8 	orr.w	lr, r4, r8, lsr #7
 8001dc8:	f8cd e070 	str.w	lr, [sp, #112]	@ 0x70
 8001dcc:	4644      	mov	r4, r8
 8001dce:	f8dd e0bc 	ldr.w	lr, [sp, #188]	@ 0xbc
 8001dd2:	f8cd a044 	str.w	sl, [sp, #68]	@ 0x44
 8001dd6:	ea4f 2c09 	mov.w	ip, r9, lsl #8
 8001dda:	ea4c 6c11 	orr.w	ip, ip, r1, lsr #24
 8001dde:	0664      	lsls	r4, r4, #25
 8001de0:	0209      	lsls	r1, r1, #8
 8001de2:	ea44 18d0 	orr.w	r8, r4, r0, lsr #7
 8001de6:	ea41 6919 	orr.w	r9, r1, r9, lsr #24
 8001dea:	9c2e      	ldr	r4, [sp, #184]	@ 0xb8
 8001dec:	f8cd 9074 	str.w	r9, [sp, #116]	@ 0x74
 8001df0:	4671      	mov	r1, lr
 8001df2:	0489      	lsls	r1, r1, #18
 8001df4:	ea4f 4984 	mov.w	r9, r4, lsl #18
 8001df8:	ea41 3494 	orr.w	r4, r1, r4, lsr #14
 8001dfc:	f8cd 8064 	str.w	r8, [sp, #100]	@ 0x64
 8001e00:	941f      	str	r4, [sp, #124]	@ 0x7c
 8001e02:	9c25      	ldr	r4, [sp, #148]	@ 0x94
 8001e04:	f8dd 8080 	ldr.w	r8, [sp, #128]	@ 0x80
 8001e08:	9826      	ldr	r0, [sp, #152]	@ 0x98
 8001e0a:	06e1      	lsls	r1, r4, #27
 8001e0c:	ea49 399e 	orr.w	r9, r9, lr, lsr #14
 8001e10:	ea41 1e58 	orr.w	lr, r1, r8, lsr #5
 8001e14:	4641      	mov	r1, r8
 8001e16:	06c9      	lsls	r1, r1, #27
 8001e18:	ea41 1454 	orr.w	r4, r1, r4, lsr #5
 8001e1c:	9421      	str	r4, [sp, #132]	@ 0x84
 8001e1e:	9c34      	ldr	r4, [sp, #208]	@ 0xd0
 8001e20:	f8cd e080 	str.w	lr, [sp, #128]	@ 0x80
 8001e24:	f8dd e0d8 	ldr.w	lr, [sp, #216]	@ 0xd8
 8001e28:	0f21      	lsrs	r1, r4, #28
 8001e2a:	ea41 180e 	orr.w	r8, r1, lr, lsl #4
 8001e2e:	4671      	mov	r1, lr
 8001e30:	0f09      	lsrs	r1, r1, #28
 8001e32:	ea41 1404 	orr.w	r4, r1, r4, lsl #4
 8001e36:	9423      	str	r4, [sp, #140]	@ 0x8c
 8001e38:	9c37      	ldr	r4, [sp, #220]	@ 0xdc
 8001e3a:	f8cd 8088 	str.w	r8, [sp, #136]	@ 0x88
 8001e3e:	f8dd 80c0 	ldr.w	r8, [sp, #192]	@ 0xc0
 8001e42:	02a1      	lsls	r1, r4, #10
 8001e44:	ea41 5e98 	orr.w	lr, r1, r8, lsr #22
 8001e48:	4641      	mov	r1, r8
 8001e4a:	0289      	lsls	r1, r1, #10
 8001e4c:	ea41 5494 	orr.w	r4, r1, r4, lsr #22
 8001e50:	9927      	ldr	r1, [sp, #156]	@ 0x9c
 8001e52:	9425      	str	r4, [sp, #148]	@ 0x94
 8001e54:	03c4      	lsls	r4, r0, #15
 8001e56:	ea44 4451 	orr.w	r4, r4, r1, lsr #17
 8001e5a:	03c9      	lsls	r1, r1, #15
 8001e5c:	ea41 4150 	orr.w	r1, r1, r0, lsr #17
 8001e60:	f8cd e090 	str.w	lr, [sp, #144]	@ 0x90
 8001e64:	f8dd e0a0 	ldr.w	lr, [sp, #160]	@ 0xa0
 8001e68:	9127      	str	r1, [sp, #156]	@ 0x9c
 8001e6a:	9929      	ldr	r1, [sp, #164]	@ 0xa4
 8001e6c:	9835      	ldr	r0, [sp, #212]	@ 0xd4
 8001e6e:	ea4f 281e 	mov.w	r8, lr, lsr #8
 8001e72:	ea48 6801 	orr.w	r8, r8, r1, lsl #24
 8001e76:	0a09      	lsrs	r1, r1, #8
 8001e78:	ea41 610e 	orr.w	r1, r1, lr, lsl #24
 8001e7c:	f8dd e0e0 	ldr.w	lr, [sp, #224]	@ 0xe0
 8001e80:	9129      	str	r1, [sp, #164]	@ 0xa4
 8001e82:	0881      	lsrs	r1, r0, #2
 8001e84:	ea41 718e 	orr.w	r1, r1, lr, lsl #30
 8001e88:	912a      	str	r1, [sp, #168]	@ 0xa8
 8001e8a:	4671      	mov	r1, lr
 8001e8c:	0889      	lsrs	r1, r1, #2
 8001e8e:	ea41 7180 	orr.w	r1, r1, r0, lsl #30
 8001e92:	9831      	ldr	r0, [sp, #196]	@ 0xc4
 8001e94:	f8dd e0b0 	ldr.w	lr, [sp, #176]	@ 0xb0
 8001e98:	912b      	str	r1, [sp, #172]	@ 0xac
 8001e9a:	0a41      	lsrs	r1, r0, #9
 8001e9c:	ea41 5ace 	orr.w	sl, r1, lr, lsl #23
 8001ea0:	4671      	mov	r1, lr
 8001ea2:	0a49      	lsrs	r1, r1, #9
 8001ea4:	ea41 51c0 	orr.w	r1, r1, r0, lsl #23
 8001ea8:	9832      	ldr	r0, [sp, #200]	@ 0xc8
 8001eaa:	f8cd a0b0 	str.w	sl, [sp, #176]	@ 0xb0
 8001eae:	f8dd a0cc 	ldr.w	sl, [sp, #204]	@ 0xcc
 8001eb2:	912d      	str	r1, [sp, #180]	@ 0xb4
 8001eb4:	0e41      	lsrs	r1, r0, #25
 8001eb6:	ea41 1eca 	orr.w	lr, r1, sl, lsl #7
 8001eba:	4651      	mov	r1, sl
 8001ebc:	0e49      	lsrs	r1, r1, #25
 8001ebe:	f8dd a0e8 	ldr.w	sl, [sp, #232]	@ 0xe8
 8001ec2:	f8cd e0b8 	str.w	lr, [sp, #184]	@ 0xb8
 8001ec6:	ea41 11c0 	orr.w	r1, r1, r0, lsl #7
 8001eca:	9839      	ldr	r0, [sp, #228]	@ 0xe4
 8001ecc:	912f      	str	r1, [sp, #188]	@ 0xbc
 8001ece:	ea4f 5eda 	mov.w	lr, sl, lsr #23
 8001ed2:	0dc1      	lsrs	r1, r0, #23
 8001ed4:	ea41 214a 	orr.w	r1, r1, sl, lsl #9
 8001ed8:	ea4e 2a40 	orr.w	sl, lr, r0, lsl #9
 8001edc:	f8cd a0c0 	str.w	sl, [sp, #192]	@ 0xc0
 8001ee0:	983b      	ldr	r0, [sp, #236]	@ 0xec
 8001ee2:	f8dd a0f0 	ldr.w	sl, [sp, #240]	@ 0xf0
 8001ee6:	ea4f 0e80 	mov.w	lr, r0, lsl #2
 8001eea:	ea4e 7e9a 	orr.w	lr, lr, sl, lsr #30
 8001eee:	ea4f 0a8a 	mov.w	sl, sl, lsl #2
 8001ef2:	ea4a 7a90 	orr.w	sl, sl, r0, lsr #30
 8001ef6:	f8cd a0c4 	str.w	sl, [sp, #196]	@ 0xc4
 8001efa:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001efe:	9804      	ldr	r0, [sp, #16]
 8001f00:	ea2a 0a0b 	bic.w	sl, sl, fp
 8001f04:	ea80 000a 	eor.w	r0, r0, sl
 8001f08:	9004      	str	r0, [sp, #16]
 8001f0a:	f8dd a028 	ldr.w	sl, [sp, #40]	@ 0x28
 8001f0e:	980c      	ldr	r0, [sp, #48]	@ 0x30
 8001f10:	ea20 0a0a 	bic.w	sl, r0, sl
 8001f14:	9806      	ldr	r0, [sp, #24]
 8001f16:	ea80 000a 	eor.w	r0, r0, sl
 8001f1a:	f8dd a00c 	ldr.w	sl, [sp, #12]
 8001f1e:	9005      	str	r0, [sp, #20]
 8001f20:	ea23 0a0a 	bic.w	sl, r3, sl
 8001f24:	ea8a 000b 	eor.w	r0, sl, fp
 8001f28:	9006      	str	r0, [sp, #24]
 8001f2a:	9807      	ldr	r0, [sp, #28]
 8001f2c:	ea2b 0a00 	bic.w	sl, fp, r0
 8001f30:	ea20 0b05 	bic.w	fp, r0, r5
 8001f34:	ea8b 0b03 	eor.w	fp, fp, r3
 8001f38:	f8cd b024 	str.w	fp, [sp, #36]	@ 0x24
 8001f3c:	f8dd b00c 	ldr.w	fp, [sp, #12]
 8001f40:	980e      	ldr	r0, [sp, #56]	@ 0x38
 8001f42:	ea25 0303 	bic.w	r3, r5, r3
 8001f46:	ea83 030b 	eor.w	r3, r3, fp
 8001f4a:	9307      	str	r3, [sp, #28]
 8001f4c:	ea8a 0305 	eor.w	r3, sl, r5
 8001f50:	e9dd ab0c 	ldrd	sl, fp, [sp, #48]	@ 0x30
 8001f54:	9d0a      	ldr	r5, [sp, #40]	@ 0x28
 8001f56:	930b      	str	r3, [sp, #44]	@ 0x2c
 8001f58:	ea2b 030a 	bic.w	r3, fp, sl
 8001f5c:	406b      	eors	r3, r5
 8001f5e:	9303      	str	r3, [sp, #12]
 8001f60:	9b08      	ldr	r3, [sp, #32]
 8001f62:	ea25 0503 	bic.w	r5, r5, r3
 8001f66:	ea23 0302 	bic.w	r3, r3, r2
 8001f6a:	ea83 030b 	eor.w	r3, r3, fp
 8001f6e:	930a      	str	r3, [sp, #40]	@ 0x28
 8001f70:	ea22 030b 	bic.w	r3, r2, fp
 8001f74:	ea83 030a 	eor.w	r3, r3, sl
 8001f78:	9308      	str	r3, [sp, #32]
 8001f7a:	f8dd a044 	ldr.w	sl, [sp, #68]	@ 0x44
 8001f7e:	f8dd b048 	ldr.w	fp, [sp, #72]	@ 0x48
 8001f82:	ea85 0302 	eor.w	r3, r5, r2
 8001f86:	9a02      	ldr	r2, [sp, #8]
 8001f88:	930c      	str	r3, [sp, #48]	@ 0x30
 8001f8a:	ea22 030a 	bic.w	r3, r2, sl
 8001f8e:	4043      	eors	r3, r0
 8001f90:	930d      	str	r3, [sp, #52]	@ 0x34
 8001f92:	9b10      	ldr	r3, [sp, #64]	@ 0x40
 8001f94:	9d0f      	ldr	r5, [sp, #60]	@ 0x3c
 8001f96:	ea23 030b 	bic.w	r3, r3, fp
 8001f9a:	406b      	eors	r3, r5
 8001f9c:	930e      	str	r3, [sp, #56]	@ 0x38
 8001f9e:	ea26 0302 	bic.w	r3, r6, r2
 8001fa2:	ea83 030a 	eor.w	r3, r3, sl
 8001fa6:	ea20 0207 	bic.w	r2, r0, r7
 8001faa:	930f      	str	r3, [sp, #60]	@ 0x3c
 8001fac:	ea2a 0300 	bic.w	r3, sl, r0
 8001fb0:	9802      	ldr	r0, [sp, #8]
 8001fb2:	f8dd a070 	ldr.w	sl, [sp, #112]	@ 0x70
 8001fb6:	4072      	eors	r2, r6
 8001fb8:	ea27 0606 	bic.w	r6, r7, r6
 8001fbc:	9213      	str	r2, [sp, #76]	@ 0x4c
 8001fbe:	ea86 0200 	eor.w	r2, r6, r0
 8001fc2:	9e14      	ldr	r6, [sp, #80]	@ 0x50
 8001fc4:	9810      	ldr	r0, [sp, #64]	@ 0x40
 8001fc6:	9211      	str	r2, [sp, #68]	@ 0x44
 8001fc8:	407b      	eors	r3, r7
 8001fca:	9315      	str	r3, [sp, #84]	@ 0x54
 8001fcc:	9f16      	ldr	r7, [sp, #88]	@ 0x58
 8001fce:	ea26 0300 	bic.w	r3, r6, r0
 8001fd2:	ea83 030b 	eor.w	r3, r3, fp
 8001fd6:	9310      	str	r3, [sp, #64]	@ 0x40
 8001fd8:	ea25 0307 	bic.w	r3, r5, r7
 8001fdc:	4073      	eors	r3, r6
 8001fde:	9314      	str	r3, [sp, #80]	@ 0x50
 8001fe0:	ea27 0306 	bic.w	r3, r7, r6
 8001fe4:	4043      	eors	r3, r0
 8001fe6:	9e1a      	ldr	r6, [sp, #104]	@ 0x68
 8001fe8:	9312      	str	r3, [sp, #72]	@ 0x48
 8001fea:	ea2b 0205 	bic.w	r2, fp, r5
 8001fee:	463b      	mov	r3, r7
 8001ff0:	9817      	ldr	r0, [sp, #92]	@ 0x5c
 8001ff2:	9f1b      	ldr	r7, [sp, #108]	@ 0x6c
 8001ff4:	9d18      	ldr	r5, [sp, #96]	@ 0x60
 8001ff6:	4053      	eors	r3, r2
 8001ff8:	9316      	str	r3, [sp, #88]	@ 0x58
 8001ffa:	ea2a 0306 	bic.w	r3, sl, r6
 8001ffe:	ea83 0b00 	eor.w	fp, r3, r0
 8002002:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 8002004:	ea23 0307 	bic.w	r3, r3, r7
 8002008:	406b      	eors	r3, r5
 800200a:	9317      	str	r3, [sp, #92]	@ 0x5c
 800200c:	ea2c 030a 	bic.w	r3, ip, sl
 8002010:	ea20 0209 	bic.w	r2, r0, r9
 8002014:	4073      	eors	r3, r6
 8002016:	9318      	str	r3, [sp, #96]	@ 0x60
 8002018:	ea26 0300 	bic.w	r3, r6, r0
 800201c:	ea82 060c 	eor.w	r6, r2, ip
 8002020:	ea29 0c0c 	bic.w	ip, r9, ip
 8002024:	961c      	str	r6, [sp, #112]	@ 0x70
 8002026:	ea8c 060a 	eor.w	r6, ip, sl
 800202a:	9819      	ldr	r0, [sp, #100]	@ 0x64
 800202c:	961a      	str	r6, [sp, #104]	@ 0x68
 800202e:	9e1d      	ldr	r6, [sp, #116]	@ 0x74
 8002030:	f8dd c090 	ldr.w	ip, [sp, #144]	@ 0x90
 8002034:	ea83 0309 	eor.w	r3, r3, r9
 8002038:	931e      	str	r3, [sp, #120]	@ 0x78
 800203a:	ea26 0300 	bic.w	r3, r6, r0
 800203e:	407b      	eors	r3, r7
 8002040:	9319      	str	r3, [sp, #100]	@ 0x64
 8002042:	ea27 0305 	bic.w	r3, r7, r5
 8002046:	9f1f      	ldr	r7, [sp, #124]	@ 0x7c
 8002048:	ea25 0207 	bic.w	r2, r5, r7
 800204c:	ea82 0906 	eor.w	r9, r2, r6
 8002050:	ea27 0206 	bic.w	r2, r7, r6
 8002054:	ea82 0600 	eor.w	r6, r2, r0
 8002058:	407b      	eors	r3, r7
 800205a:	961b      	str	r6, [sp, #108]	@ 0x6c
 800205c:	9e22      	ldr	r6, [sp, #136]	@ 0x88
 800205e:	f8cd 9074 	str.w	r9, [sp, #116]	@ 0x74
 8002062:	931f      	str	r3, [sp, #124]	@ 0x7c
 8002064:	9820      	ldr	r0, [sp, #128]	@ 0x80
 8002066:	9f23      	ldr	r7, [sp, #140]	@ 0x8c
 8002068:	f8dd 9094 	ldr.w	r9, [sp, #148]	@ 0x94
 800206c:	9d21      	ldr	r5, [sp, #132]	@ 0x84
 800206e:	ea2c 0306 	bic.w	r3, ip, r6
 8002072:	4043      	eors	r3, r0
 8002074:	9320      	str	r3, [sp, #128]	@ 0x80
 8002076:	ea29 0307 	bic.w	r3, r9, r7
 800207a:	406b      	eors	r3, r5
 800207c:	9321      	str	r3, [sp, #132]	@ 0x84
 800207e:	ea24 030c 	bic.w	r3, r4, ip
 8002082:	4073      	eors	r3, r6
 8002084:	ea20 0208 	bic.w	r2, r0, r8
 8002088:	9322      	str	r3, [sp, #136]	@ 0x88
 800208a:	ea26 0300 	bic.w	r3, r6, r0
 800208e:	9827      	ldr	r0, [sp, #156]	@ 0x9c
 8002090:	ea82 0604 	eor.w	r6, r2, r4
 8002094:	ea83 0308 	eor.w	r3, r3, r8
 8002098:	ea28 0404 	bic.w	r4, r8, r4
 800209c:	9626      	str	r6, [sp, #152]	@ 0x98
 800209e:	9328      	str	r3, [sp, #160]	@ 0xa0
 80020a0:	ea84 060c 	eor.w	r6, r4, ip
 80020a4:	ea20 0309 	bic.w	r3, r0, r9
 80020a8:	9c29      	ldr	r4, [sp, #164]	@ 0xa4
 80020aa:	9624      	str	r6, [sp, #144]	@ 0x90
 80020ac:	407b      	eors	r3, r7
 80020ae:	ea25 0204 	bic.w	r2, r5, r4
 80020b2:	9323      	str	r3, [sp, #140]	@ 0x8c
 80020b4:	ea27 0305 	bic.w	r3, r7, r5
 80020b8:	9f2e      	ldr	r7, [sp, #184]	@ 0xb8
 80020ba:	f8dd c0bc 	ldr.w	ip, [sp, #188]	@ 0xbc
 80020be:	9d2d      	ldr	r5, [sp, #180]	@ 0xb4
 80020c0:	ea82 0600 	eor.w	r6, r2, r0
 80020c4:	4063      	eors	r3, r4
 80020c6:	ea24 0200 	bic.w	r2, r4, r0
 80020ca:	9c2c      	ldr	r4, [sp, #176]	@ 0xb0
 80020cc:	9627      	str	r6, [sp, #156]	@ 0x9c
 80020ce:	9329      	str	r3, [sp, #164]	@ 0xa4
 80020d0:	ea82 0609 	eor.w	r6, r2, r9
 80020d4:	ea21 0307 	bic.w	r3, r1, r7
 80020d8:	9a2a      	ldr	r2, [sp, #168]	@ 0xa8
 80020da:	9625      	str	r6, [sp, #148]	@ 0x94
 80020dc:	4063      	eors	r3, r4
 80020de:	ea27 0604 	bic.w	r6, r7, r4
 80020e2:	4056      	eors	r6, r2
 80020e4:	932a      	str	r3, [sp, #168]	@ 0xa8
 80020e6:	ea24 0302 	bic.w	r3, r4, r2
 80020ea:	ea22 020e 	bic.w	r2, r2, lr
 80020ee:	ea82 0801 	eor.w	r8, r2, r1
 80020f2:	ea2e 0101 	bic.w	r1, lr, r1
 80020f6:	404f      	eors	r7, r1
 80020f8:	9930      	ldr	r1, [sp, #192]	@ 0xc0
 80020fa:	982b      	ldr	r0, [sp, #172]	@ 0xac
 80020fc:	9c31      	ldr	r4, [sp, #196]	@ 0xc4
 80020fe:	f8cd 80b4 	str.w	r8, [sp, #180]	@ 0xb4
 8002102:	ea83 030e 	eor.w	r3, r3, lr
 8002106:	932f      	str	r3, [sp, #188]	@ 0xbc
 8002108:	ea21 030c 	bic.w	r3, r1, ip
 800210c:	ea20 0204 	bic.w	r2, r0, r4
 8002110:	ea2c 0a05 	bic.w	sl, ip, r5
 8002114:	ea83 0805 	eor.w	r8, r3, r5
 8002118:	ea25 0300 	bic.w	r3, r5, r0
 800211c:	4063      	eors	r3, r4
 800211e:	ea8a 0a00 	eor.w	sl, sl, r0
 8002122:	ea82 0001 	eor.w	r0, r2, r1
 8002126:	ea24 0201 	bic.w	r2, r4, r1
 800212a:	ea82 010c 	eor.w	r1, r2, ip
 800212e:	9330      	str	r3, [sp, #192]	@ 0xc0
 8002130:	9a01      	ldr	r2, [sp, #4]
 8002132:	4b3b      	ldr	r3, [pc, #236]	@ (8002220 <KeccakF1600_StatePermute+0x114c>)
 8002134:	972b      	str	r7, [sp, #172]	@ 0xac
 8002136:	4293      	cmp	r3, r2
 8002138:	902e      	str	r0, [sp, #184]	@ 0xb8
 800213a:	912c      	str	r1, [sp, #176]	@ 0xb0
 800213c:	f47f a842 	bne.w	80011c4 <KeccakF1600_StatePermute+0xf0>
 8002140:	983d      	ldr	r0, [sp, #244]	@ 0xf4
 8002142:	9b04      	ldr	r3, [sp, #16]
 8002144:	6003      	str	r3, [r0, #0]
 8002146:	9b05      	ldr	r3, [sp, #20]
 8002148:	6043      	str	r3, [r0, #4]
 800214a:	9b06      	ldr	r3, [sp, #24]
 800214c:	6083      	str	r3, [r0, #8]
 800214e:	9b03      	ldr	r3, [sp, #12]
 8002150:	60c3      	str	r3, [r0, #12]
 8002152:	9b07      	ldr	r3, [sp, #28]
 8002154:	6103      	str	r3, [r0, #16]
 8002156:	9b08      	ldr	r3, [sp, #32]
 8002158:	6143      	str	r3, [r0, #20]
 800215a:	9b09      	ldr	r3, [sp, #36]	@ 0x24
 800215c:	6183      	str	r3, [r0, #24]
 800215e:	9b0a      	ldr	r3, [sp, #40]	@ 0x28
 8002160:	61c3      	str	r3, [r0, #28]
 8002162:	9b0b      	ldr	r3, [sp, #44]	@ 0x2c
 8002164:	6203      	str	r3, [r0, #32]
 8002166:	9b0c      	ldr	r3, [sp, #48]	@ 0x30
 8002168:	6243      	str	r3, [r0, #36]	@ 0x24
 800216a:	9b0d      	ldr	r3, [sp, #52]	@ 0x34
 800216c:	6283      	str	r3, [r0, #40]	@ 0x28
 800216e:	9b0e      	ldr	r3, [sp, #56]	@ 0x38
 8002170:	62c3      	str	r3, [r0, #44]	@ 0x2c
 8002172:	9b0f      	ldr	r3, [sp, #60]	@ 0x3c
 8002174:	6303      	str	r3, [r0, #48]	@ 0x30
 8002176:	9b10      	ldr	r3, [sp, #64]	@ 0x40
 8002178:	6343      	str	r3, [r0, #52]	@ 0x34
 800217a:	9b11      	ldr	r3, [sp, #68]	@ 0x44
 800217c:	6383      	str	r3, [r0, #56]	@ 0x38
 800217e:	9b12      	ldr	r3, [sp, #72]	@ 0x48
 8002180:	63c3      	str	r3, [r0, #60]	@ 0x3c
 8002182:	9b13      	ldr	r3, [sp, #76]	@ 0x4c
 8002184:	6403      	str	r3, [r0, #64]	@ 0x40
 8002186:	9b14      	ldr	r3, [sp, #80]	@ 0x50
 8002188:	6443      	str	r3, [r0, #68]	@ 0x44
 800218a:	9b15      	ldr	r3, [sp, #84]	@ 0x54
 800218c:	6483      	str	r3, [r0, #72]	@ 0x48
 800218e:	9b16      	ldr	r3, [sp, #88]	@ 0x58
 8002190:	e9c0 3b13 	strd	r3, fp, [r0, #76]	@ 0x4c
 8002194:	9b17      	ldr	r3, [sp, #92]	@ 0x5c
 8002196:	6543      	str	r3, [r0, #84]	@ 0x54
 8002198:	9b18      	ldr	r3, [sp, #96]	@ 0x60
 800219a:	6583      	str	r3, [r0, #88]	@ 0x58
 800219c:	9b19      	ldr	r3, [sp, #100]	@ 0x64
 800219e:	65c3      	str	r3, [r0, #92]	@ 0x5c
 80021a0:	9b1a      	ldr	r3, [sp, #104]	@ 0x68
 80021a2:	6603      	str	r3, [r0, #96]	@ 0x60
 80021a4:	9b1b      	ldr	r3, [sp, #108]	@ 0x6c
 80021a6:	6643      	str	r3, [r0, #100]	@ 0x64
 80021a8:	9b1c      	ldr	r3, [sp, #112]	@ 0x70
 80021aa:	6683      	str	r3, [r0, #104]	@ 0x68
 80021ac:	9b1d      	ldr	r3, [sp, #116]	@ 0x74
 80021ae:	66c3      	str	r3, [r0, #108]	@ 0x6c
 80021b0:	9b1e      	ldr	r3, [sp, #120]	@ 0x78
 80021b2:	6703      	str	r3, [r0, #112]	@ 0x70
 80021b4:	9b1f      	ldr	r3, [sp, #124]	@ 0x7c
 80021b6:	6743      	str	r3, [r0, #116]	@ 0x74
 80021b8:	9b20      	ldr	r3, [sp, #128]	@ 0x80
 80021ba:	6783      	str	r3, [r0, #120]	@ 0x78
 80021bc:	9b21      	ldr	r3, [sp, #132]	@ 0x84
 80021be:	67c3      	str	r3, [r0, #124]	@ 0x7c
 80021c0:	9b22      	ldr	r3, [sp, #136]	@ 0x88
 80021c2:	f8c0 3080 	str.w	r3, [r0, #128]	@ 0x80
 80021c6:	9b23      	ldr	r3, [sp, #140]	@ 0x8c
 80021c8:	f8c0 3084 	str.w	r3, [r0, #132]	@ 0x84
 80021cc:	9b24      	ldr	r3, [sp, #144]	@ 0x90
 80021ce:	f8c0 3088 	str.w	r3, [r0, #136]	@ 0x88
 80021d2:	9b25      	ldr	r3, [sp, #148]	@ 0x94
 80021d4:	f8c0 308c 	str.w	r3, [r0, #140]	@ 0x8c
 80021d8:	9b26      	ldr	r3, [sp, #152]	@ 0x98
 80021da:	f8c0 3090 	str.w	r3, [r0, #144]	@ 0x90
 80021de:	9b27      	ldr	r3, [sp, #156]	@ 0x9c
 80021e0:	f8c0 3094 	str.w	r3, [r0, #148]	@ 0x94
 80021e4:	9b28      	ldr	r3, [sp, #160]	@ 0xa0
 80021e6:	f8c0 3098 	str.w	r3, [r0, #152]	@ 0x98
 80021ea:	9b29      	ldr	r3, [sp, #164]	@ 0xa4
 80021ec:	f8c0 a0a4 	str.w	sl, [r0, #164]	@ 0xa4
 80021f0:	e9c0 3627 	strd	r3, r6, [r0, #156]	@ 0x9c
 80021f4:	9b2a      	ldr	r3, [sp, #168]	@ 0xa8
 80021f6:	f8c0 70b0 	str.w	r7, [r0, #176]	@ 0xb0
 80021fa:	e9c0 382a 	strd	r3, r8, [r0, #168]	@ 0xa8
 80021fe:	9b2d      	ldr	r3, [sp, #180]	@ 0xb4
 8002200:	f8c0 30b8 	str.w	r3, [r0, #184]	@ 0xb8
 8002204:	9b2e      	ldr	r3, [sp, #184]	@ 0xb8
 8002206:	f8c0 30bc 	str.w	r3, [r0, #188]	@ 0xbc
 800220a:	9b2f      	ldr	r3, [sp, #188]	@ 0xbc
 800220c:	f8c0 30c0 	str.w	r3, [r0, #192]	@ 0xc0
 8002210:	9b30      	ldr	r3, [sp, #192]	@ 0xc0
 8002212:	f8c0 10b4 	str.w	r1, [r0, #180]	@ 0xb4
 8002216:	f8c0 30c4 	str.w	r3, [r0, #196]	@ 0xc4
 800221a:	b03f      	add	sp, #252	@ 0xfc
 800221c:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8002220:	08003720 	.word	0x08003720

08002224 <keccak_absorb>:
 8002224:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002228:	b0b7      	sub	sp, #220	@ 0xdc
 800222a:	460d      	mov	r5, r1
 800222c:	461e      	mov	r6, r3
 800222e:	4617      	mov	r7, r2
 8002230:	2100      	movs	r1, #0
 8002232:	22c8      	movs	r2, #200	@ 0xc8
 8002234:	f89d 9100 	ldrb.w	r9, [sp, #256]	@ 0x100
 8002238:	4683      	mov	fp, r0
 800223a:	f7fe f8d5 	bl	80003e8 <memset>
 800223e:	42ae      	cmp	r6, r5
 8002240:	ea4f 04d5 	mov.w	r4, r5, lsr #3
 8002244:	f1ab 0a08 	sub.w	sl, fp, #8
 8002248:	bf28      	it	cs
 800224a:	f8cd 900c 	strcs.w	r9, [sp, #12]
 800224e:	d339      	bcc.n	80022c4 <keccak_absorb+0xa0>
 8002250:	4650      	mov	r0, sl
 8002252:	46b9      	mov	r9, r7
 8002254:	f04f 0800 	mov.w	r8, #0
 8002258:	465a      	mov	r2, fp
 800225a:	e9cd 8901 	strd	r8, r9, [sp, #4]
 800225e:	2300      	movs	r3, #0
 8002260:	46cb      	mov	fp, r9
 8002262:	469e      	mov	lr, r3
 8002264:	469c      	mov	ip, r3
 8002266:	f81b 1b01 	ldrb.w	r1, [fp], #1
 800226a:	f1a3 0820 	sub.w	r8, r3, #32
 800226e:	f1c3 0920 	rsb	r9, r3, #32
 8002272:	fa01 f808 	lsl.w	r8, r1, r8
 8002276:	fa21 f909 	lsr.w	r9, r1, r9
 800227a:	4099      	lsls	r1, r3
 800227c:	3308      	adds	r3, #8
 800227e:	ea48 0809 	orr.w	r8, r8, r9
 8002282:	2b40      	cmp	r3, #64	@ 0x40
 8002284:	ea48 0c0c 	orr.w	ip, r8, ip
 8002288:	ea41 0e0e 	orr.w	lr, r1, lr
 800228c:	d1eb      	bne.n	8002266 <keccak_absorb+0x42>
 800228e:	f850 3f08 	ldr.w	r3, [r0, #8]!
 8002292:	e9dd 8901 	ldrd	r8, r9, [sp, #4]
 8002296:	ea83 030e 	eor.w	r3, r3, lr
 800229a:	6003      	str	r3, [r0, #0]
 800229c:	6843      	ldr	r3, [r0, #4]
 800229e:	f108 0801 	add.w	r8, r8, #1
 80022a2:	ea83 030c 	eor.w	r3, r3, ip
 80022a6:	45a0      	cmp	r8, r4
 80022a8:	f109 0908 	add.w	r9, r9, #8
 80022ac:	6043      	str	r3, [r0, #4]
 80022ae:	d3d4      	bcc.n	800225a <keccak_absorb+0x36>
 80022b0:	4610      	mov	r0, r2
 80022b2:	1b76      	subs	r6, r6, r5
 80022b4:	4693      	mov	fp, r2
 80022b6:	f7fe ff0d 	bl	80010d4 <KeccakF1600_StatePermute>
 80022ba:	42b5      	cmp	r5, r6
 80022bc:	442f      	add	r7, r5
 80022be:	d9c7      	bls.n	8002250 <keccak_absorb+0x2c>
 80022c0:	f8dd 900c 	ldr.w	r9, [sp, #12]
 80022c4:	462a      	mov	r2, r5
 80022c6:	2100      	movs	r1, #0
 80022c8:	a804      	add	r0, sp, #16
 80022ca:	f7fe f88d 	bl	80003e8 <memset>
 80022ce:	b126      	cbz	r6, 80022da <keccak_absorb+0xb6>
 80022d0:	4639      	mov	r1, r7
 80022d2:	4632      	mov	r2, r6
 80022d4:	a804      	add	r0, sp, #16
 80022d6:	f7fd ff9b 	bl	8000210 <memcpy>
 80022da:	446e      	add	r6, sp
 80022dc:	eb0d 0305 	add.w	r3, sp, r5
 80022e0:	f886 9010 	strb.w	r9, [r6, #16]
 80022e4:	7bda      	ldrb	r2, [r3, #15]
 80022e6:	f062 027f 	orn	r2, r2, #127	@ 0x7f
 80022ea:	46d4      	mov	ip, sl
 80022ec:	f10d 0e10 	add.w	lr, sp, #16
 80022f0:	73da      	strb	r2, [r3, #15]
 80022f2:	f04f 0800 	mov.w	r8, #0
 80022f6:	2300      	movs	r3, #0
 80022f8:	4677      	mov	r7, lr
 80022fa:	461e      	mov	r6, r3
 80022fc:	461d      	mov	r5, r3
 80022fe:	f817 1b01 	ldrb.w	r1, [r7], #1
 8002302:	f1a3 0220 	sub.w	r2, r3, #32
 8002306:	f1c3 0020 	rsb	r0, r3, #32
 800230a:	fa01 f202 	lsl.w	r2, r1, r2
 800230e:	fa21 f000 	lsr.w	r0, r1, r0
 8002312:	4099      	lsls	r1, r3
 8002314:	3308      	adds	r3, #8
 8002316:	4302      	orrs	r2, r0
 8002318:	2b40      	cmp	r3, #64	@ 0x40
 800231a:	ea46 0601 	orr.w	r6, r6, r1
 800231e:	ea45 0502 	orr.w	r5, r5, r2
 8002322:	d1ec      	bne.n	80022fe <keccak_absorb+0xda>
 8002324:	f85c 2f08 	ldr.w	r2, [ip, #8]!
 8002328:	f8dc 3004 	ldr.w	r3, [ip, #4]
 800232c:	f108 0801 	add.w	r8, r8, #1
 8002330:	4072      	eors	r2, r6
 8002332:	406b      	eors	r3, r5
 8002334:	45a0      	cmp	r8, r4
 8002336:	e9cc 2300 	strd	r2, r3, [ip]
 800233a:	f10e 0e08 	add.w	lr, lr, #8
 800233e:	d3da      	bcc.n	80022f6 <keccak_absorb+0xd2>
 8002340:	b037      	add	sp, #220	@ 0xdc
 8002342:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8002346:	bf00      	nop

08002348 <keccak_inc_absorb>:
 8002348:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
 800234c:	f8d0 40c8 	ldr.w	r4, [r0, #200]	@ 0xc8
 8002350:	460e      	mov	r6, r1
 8002352:	f8d0 10cc 	ldr.w	r1, [r0, #204]	@ 0xcc
 8002356:	4690      	mov	r8, r2
 8002358:	191a      	adds	r2, r3, r4
 800235a:	461f      	mov	r7, r3
 800235c:	f141 0300 	adc.w	r3, r1, #0
 8002360:	42b2      	cmp	r2, r6
 8002362:	f173 0300 	sbcs.w	r3, r3, #0
 8002366:	4605      	mov	r5, r0
 8002368:	d345      	bcc.n	80023f6 <keccak_inc_absorb+0xae>
 800236a:	42a6      	cmp	r6, r4
 800236c:	d10c      	bne.n	8002388 <keccak_inc_absorb+0x40>
 800236e:	2200      	movs	r2, #0
 8002370:	2300      	movs	r3, #0
 8002372:	1bbf      	subs	r7, r7, r6
 8002374:	4427      	add	r7, r4
 8002376:	e9c5 2332 	strd	r2, r3, [r5, #200]	@ 0xc8
 800237a:	4628      	mov	r0, r5
 800237c:	f7fe feaa 	bl	80010d4 <KeccakF1600_StatePermute>
 8002380:	2400      	movs	r4, #0
 8002382:	42b7      	cmp	r7, r6
 8002384:	4621      	mov	r1, r4
 8002386:	d336      	bcc.n	80023f6 <keccak_inc_absorb+0xae>
 8002388:	f04f 0c00 	mov.w	ip, #0
 800238c:	f108 32ff 	add.w	r2, r8, #4294967295	@ 0xffffffff
 8002390:	4663      	mov	r3, ip
 8002392:	eb14 040c 	adds.w	r4, r4, ip
 8002396:	eb43 0101 	adc.w	r1, r3, r1
 800239a:	08e0      	lsrs	r0, r4, #3
 800239c:	ea40 7041 	orr.w	r0, r0, r1, lsl #29
 80023a0:	f004 0407 	and.w	r4, r4, #7
 80023a4:	f812 ef01 	ldrb.w	lr, [r2, #1]!
 80023a8:	f855 1030 	ldr.w	r1, [r5, r0, lsl #3]
 80023ac:	00e4      	lsls	r4, r4, #3
 80023ae:	eb05 0ac0 	add.w	sl, r5, r0, lsl #3
 80023b2:	f1a4 0920 	sub.w	r9, r4, #32
 80023b6:	f1c4 0b20 	rsb	fp, r4, #32
 80023ba:	fa0e f909 	lsl.w	r9, lr, r9
 80023be:	fa2e fb0b 	lsr.w	fp, lr, fp
 80023c2:	fa0e fe04 	lsl.w	lr, lr, r4
 80023c6:	ea81 010e 	eor.w	r1, r1, lr
 80023ca:	f8da e004 	ldr.w	lr, [sl, #4]
 80023ce:	f845 1030 	str.w	r1, [r5, r0, lsl #3]
 80023d2:	ea49 040b 	orr.w	r4, r9, fp
 80023d6:	ea8e 0404 	eor.w	r4, lr, r4
 80023da:	f8ca 4004 	str.w	r4, [sl, #4]
 80023de:	e9d5 4132 	ldrd	r4, r1, [r5, #200]	@ 0xc8
 80023e2:	f11c 0c01 	adds.w	ip, ip, #1
 80023e6:	eba6 0004 	sub.w	r0, r6, r4
 80023ea:	f143 0300 	adc.w	r3, r3, #0
 80023ee:	4560      	cmp	r0, ip
 80023f0:	d8cf      	bhi.n	8002392 <keccak_inc_absorb+0x4a>
 80023f2:	4480      	add	r8, r0
 80023f4:	e7bb      	b.n	800236e <keccak_inc_absorb+0x26>
 80023f6:	b38f      	cbz	r7, 800245c <keccak_inc_absorb+0x114>
 80023f8:	1e7e      	subs	r6, r7, #1
 80023fa:	2300      	movs	r3, #0
 80023fc:	4446      	add	r6, r8
 80023fe:	4618      	mov	r0, r3
 8002400:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 8002404:	191c      	adds	r4, r3, r4
 8002406:	eb40 0101 	adc.w	r1, r0, r1
 800240a:	ea4f 0cd4 	mov.w	ip, r4, lsr #3
 800240e:	ea4c 7c41 	orr.w	ip, ip, r1, lsl #29
 8002412:	f004 0407 	and.w	r4, r4, #7
 8002416:	f818 ef01 	ldrb.w	lr, [r8, #1]!
 800241a:	f855 103c 	ldr.w	r1, [r5, ip, lsl #3]
 800241e:	00e4      	lsls	r4, r4, #3
 8002420:	eb05 09cc 	add.w	r9, r5, ip, lsl #3
 8002424:	f1a4 0220 	sub.w	r2, r4, #32
 8002428:	f1c4 0a20 	rsb	sl, r4, #32
 800242c:	fa0e f202 	lsl.w	r2, lr, r2
 8002430:	fa2e fa0a 	lsr.w	sl, lr, sl
 8002434:	fa0e fe04 	lsl.w	lr, lr, r4
 8002438:	f8d9 4004 	ldr.w	r4, [r9, #4]
 800243c:	ea81 010e 	eor.w	r1, r1, lr
 8002440:	ea42 020a 	orr.w	r2, r2, sl
 8002444:	f845 103c 	str.w	r1, [r5, ip, lsl #3]
 8002448:	4062      	eors	r2, r4
 800244a:	3301      	adds	r3, #1
 800244c:	f8c9 2004 	str.w	r2, [r9, #4]
 8002450:	f140 0000 	adc.w	r0, r0, #0
 8002454:	45b0      	cmp	r8, r6
 8002456:	e9d5 4132 	ldrd	r4, r1, [r5, #200]	@ 0xc8
 800245a:	d1d3      	bne.n	8002404 <keccak_inc_absorb+0xbc>
 800245c:	193f      	adds	r7, r7, r4
 800245e:	f141 0100 	adc.w	r1, r1, #0
 8002462:	e9c5 7132 	strd	r7, r1, [r5, #200]	@ 0xc8
 8002466:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 800246a:	bf00      	nop

0800246c <keccak_inc_squeeze>:
 800246c:	2900      	cmp	r1, #0
 800246e:	d07e      	beq.n	800256e <keccak_inc_squeeze+0x102>
 8002470:	e92d 4ff8 	stmdb	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002474:	4691      	mov	r9, r2
 8002476:	1e45      	subs	r5, r0, #1
 8002478:	2200      	movs	r2, #0
 800247a:	461e      	mov	r6, r3
 800247c:	186f      	adds	r7, r5, r1
 800247e:	4614      	mov	r4, r2
 8002480:	e027      	b.n	80024d2 <keccak_inc_squeeze+0x66>
 8002482:	1af3      	subs	r3, r6, r3
 8002484:	eb6e 0e4e 	sbc.w	lr, lr, lr, lsl #1
 8002488:	189b      	adds	r3, r3, r2
 800248a:	eb44 0e0e 	adc.w	lr, r4, lr
 800248e:	ea4f 0ad3 	mov.w	sl, r3, lsr #3
 8002492:	ea4a 7a4e 	orr.w	sl, sl, lr, lsl #29
 8002496:	eb09 0eca 	add.w	lr, r9, sl, lsl #3
 800249a:	f003 0307 	and.w	r3, r3, #7
 800249e:	f8de 8004 	ldr.w	r8, [lr, #4]
 80024a2:	f859 b03a 	ldr.w	fp, [r9, sl, lsl #3]
 80024a6:	00db      	lsls	r3, r3, #3
 80024a8:	f1c3 0a20 	rsb	sl, r3, #32
 80024ac:	f1a3 0e20 	sub.w	lr, r3, #32
 80024b0:	fa08 fa0a 	lsl.w	sl, r8, sl
 80024b4:	fa2b f303 	lsr.w	r3, fp, r3
 80024b8:	ea43 030a 	orr.w	r3, r3, sl
 80024bc:	fa28 fe0e 	lsr.w	lr, r8, lr
 80024c0:	ea43 030e 	orr.w	r3, r3, lr
 80024c4:	f805 3f01 	strb.w	r3, [r5, #1]!
 80024c8:	3201      	adds	r2, #1
 80024ca:	f144 0400 	adc.w	r4, r4, #0
 80024ce:	42bd      	cmp	r5, r7
 80024d0:	d048      	beq.n	8002564 <keccak_inc_squeeze+0xf8>
 80024d2:	e9d9 3e32 	ldrd	r3, lr, [r9, #200]	@ 0xc8
 80024d6:	429a      	cmp	r2, r3
 80024d8:	eb74 080e 	sbcs.w	r8, r4, lr
 80024dc:	4694      	mov	ip, r2
 80024de:	d3d0      	bcc.n	8002482 <keccak_inc_squeeze+0x16>
 80024e0:	1a9b      	subs	r3, r3, r2
 80024e2:	eb6e 0404 	sbc.w	r4, lr, r4
 80024e6:	ebb1 070c 	subs.w	r7, r1, ip
 80024ea:	e9c9 3432 	strd	r3, r4, [r9, #200]	@ 0xc8
 80024ee:	eb00 080c 	add.w	r8, r0, ip
 80024f2:	d030      	beq.n	8002556 <keccak_inc_squeeze+0xea>
 80024f4:	2400      	movs	r4, #0
 80024f6:	2500      	movs	r5, #0
 80024f8:	4648      	mov	r0, r9
 80024fa:	f7fe fdeb 	bl	80010d4 <KeccakF1600_StatePermute>
 80024fe:	f04f 0e00 	mov.w	lr, #0
 8002502:	f108 30ff 	add.w	r0, r8, #4294967295	@ 0xffffffff
 8002506:	e001      	b.n	800250c <keccak_inc_squeeze+0xa0>
 8002508:	4576      	cmp	r6, lr
 800250a:	d026      	beq.n	800255a <keccak_inc_squeeze+0xee>
 800250c:	f02e 0307 	bic.w	r3, lr, #7
 8002510:	ea4f 01de 	mov.w	r1, lr, lsr #3
 8002514:	444b      	add	r3, r9
 8002516:	f00e 0c07 	and.w	ip, lr, #7
 800251a:	685a      	ldr	r2, [r3, #4]
 800251c:	f859 1031 	ldr.w	r1, [r9, r1, lsl #3]
 8002520:	ea4f 0ccc 	mov.w	ip, ip, lsl #3
 8002524:	f1cc 0a20 	rsb	sl, ip, #32
 8002528:	f1ac 0320 	sub.w	r3, ip, #32
 800252c:	fa02 fa0a 	lsl.w	sl, r2, sl
 8002530:	fa21 fc0c 	lsr.w	ip, r1, ip
 8002534:	ea4c 0c0a 	orr.w	ip, ip, sl
 8002538:	fa22 f303 	lsr.w	r3, r2, r3
 800253c:	f10e 0e01 	add.w	lr, lr, #1
 8002540:	ea4c 0c03 	orr.w	ip, ip, r3
 8002544:	45be      	cmp	lr, r7
 8002546:	f800 cf01 	strb.w	ip, [r0, #1]!
 800254a:	d1dd      	bne.n	8002508 <keccak_inc_squeeze+0x9c>
 800254c:	eba6 060e 	sub.w	r6, r6, lr
 8002550:	2300      	movs	r3, #0
 8002552:	e9c9 6332 	strd	r6, r3, [r9, #200]	@ 0xc8
 8002556:	e8bd 8ff8 	ldmia.w	sp!, {r3, r4, r5, r6, r7, r8, r9, sl, fp, pc}
 800255a:	e9c9 4532 	strd	r4, r5, [r9, #200]	@ 0xc8
 800255e:	44b0      	add	r8, r6
 8002560:	1bbf      	subs	r7, r7, r6
 8002562:	e7c9      	b.n	80024f8 <keccak_inc_squeeze+0x8c>
 8002564:	e9d9 3e32 	ldrd	r3, lr, [r9, #200]	@ 0xc8
 8002568:	f10c 0c01 	add.w	ip, ip, #1
 800256c:	e7b8      	b.n	80024e0 <keccak_inc_squeeze+0x74>
 800256e:	4770      	bx	lr

08002570 <shake128_inc_init>:
 8002570:	b538      	push	{r3, r4, r5, lr}
 8002572:	4605      	mov	r5, r0
 8002574:	20d0      	movs	r0, #208	@ 0xd0
 8002576:	f7fd ff27 	bl	80003c8 <malloc>
 800257a:	6028      	str	r0, [r5, #0]
 800257c:	b148      	cbz	r0, 8002592 <shake128_inc_init+0x22>
 800257e:	22c8      	movs	r2, #200	@ 0xc8
 8002580:	2100      	movs	r1, #0
 8002582:	4604      	mov	r4, r0
 8002584:	f7fd ff30 	bl	80003e8 <memset>
 8002588:	2200      	movs	r2, #0
 800258a:	2300      	movs	r3, #0
 800258c:	e9c4 2332 	strd	r2, r3, [r4, #200]	@ 0xc8
 8002590:	bd38      	pop	{r3, r4, r5, pc}
 8002592:	206f      	movs	r0, #111	@ 0x6f
 8002594:	f7fd ff76 	bl	8000484 <exit>

08002598 <shake128_inc_absorb>:
 8002598:	4613      	mov	r3, r2
 800259a:	6800      	ldr	r0, [r0, #0]
 800259c:	460a      	mov	r2, r1
 800259e:	21a8      	movs	r1, #168	@ 0xa8
 80025a0:	f7ff bed2 	b.w	8002348 <keccak_inc_absorb>

080025a4 <shake128_inc_finalize>:
 80025a4:	6803      	ldr	r3, [r0, #0]
 80025a6:	e9d3 2132 	ldrd	r2, r1, [r3, #200]	@ 0xc8
 80025aa:	08d0      	lsrs	r0, r2, #3
 80025ac:	f002 0207 	and.w	r2, r2, #7
 80025b0:	ea40 7041 	orr.w	r0, r0, r1, lsl #29
 80025b4:	00d2      	lsls	r2, r2, #3
 80025b6:	b510      	push	{r4, lr}
 80025b8:	f04f 0c1f 	mov.w	ip, #31
 80025bc:	f1a2 0120 	sub.w	r1, r2, #32
 80025c0:	f1c2 0420 	rsb	r4, r2, #32
 80025c4:	eb03 0ec0 	add.w	lr, r3, r0, lsl #3
 80025c8:	fa2c f404 	lsr.w	r4, ip, r4
 80025cc:	fa0c f101 	lsl.w	r1, ip, r1
 80025d0:	fa0c fc02 	lsl.w	ip, ip, r2
 80025d4:	f853 2030 	ldr.w	r2, [r3, r0, lsl #3]
 80025d8:	4321      	orrs	r1, r4
 80025da:	ea82 040c 	eor.w	r4, r2, ip
 80025de:	f8de 2004 	ldr.w	r2, [lr, #4]
 80025e2:	f843 4030 	str.w	r4, [r3, r0, lsl #3]
 80025e6:	404a      	eors	r2, r1
 80025e8:	f8ce 2004 	str.w	r2, [lr, #4]
 80025ec:	f8d3 20a4 	ldr.w	r2, [r3, #164]	@ 0xa4
 80025f0:	2000      	movs	r0, #0
 80025f2:	2100      	movs	r1, #0
 80025f4:	f102 4200 	add.w	r2, r2, #2147483648	@ 0x80000000
 80025f8:	e9c3 0132 	strd	r0, r1, [r3, #200]	@ 0xc8
 80025fc:	f8c3 20a4 	str.w	r2, [r3, #164]	@ 0xa4
 8002600:	bd10      	pop	{r4, pc}
 8002602:	bf00      	nop

08002604 <shake128_inc_squeeze>:
 8002604:	6812      	ldr	r2, [r2, #0]
 8002606:	23a8      	movs	r3, #168	@ 0xa8
 8002608:	f7ff bf30 	b.w	800246c <keccak_inc_squeeze>

0800260c <shake128_inc_ctx_release>:
 800260c:	6800      	ldr	r0, [r0, #0]
 800260e:	f7fd bee3 	b.w	80003d8 <free>
 8002612:	bf00      	nop

08002614 <sha3_256>:
 8002614:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
 8002618:	b0d6      	sub	sp, #344	@ 0x158
 800261a:	4613      	mov	r3, r2
 800261c:	2206      	movs	r2, #6
 800261e:	9200      	str	r2, [sp, #0]
 8002620:	4606      	mov	r6, r0
 8002622:	460a      	mov	r2, r1
 8002624:	a824      	add	r0, sp, #144	@ 0x90
 8002626:	2188      	movs	r1, #136	@ 0x88
 8002628:	f7ff fdfc 	bl	8002224 <keccak_absorb>
 800262c:	a824      	add	r0, sp, #144	@ 0x90
 800262e:	f7fe fd51 	bl	80010d4 <KeccakF1600_StatePermute>
 8002632:	af02      	add	r7, sp, #8
 8002634:	f10d 0e88 	add.w	lr, sp, #136	@ 0x88
 8002638:	f50d 7888 	add.w	r8, sp, #272	@ 0x110
 800263c:	f85e 5f08 	ldr.w	r5, [lr, #8]!
 8002640:	f8de 4004 	ldr.w	r4, [lr, #4]
 8002644:	46bc      	mov	ip, r7
 8002646:	2300      	movs	r3, #0
 8002648:	f1c3 0020 	rsb	r0, r3, #32
 800264c:	f1a3 0120 	sub.w	r1, r3, #32
 8002650:	fa25 f203 	lsr.w	r2, r5, r3
 8002654:	fa04 f000 	lsl.w	r0, r4, r0
 8002658:	4302      	orrs	r2, r0
 800265a:	fa24 f101 	lsr.w	r1, r4, r1
 800265e:	3308      	adds	r3, #8
 8002660:	430a      	orrs	r2, r1
 8002662:	2b40      	cmp	r3, #64	@ 0x40
 8002664:	f80c 2b01 	strb.w	r2, [ip], #1
 8002668:	d1ee      	bne.n	8002648 <sha3_256+0x34>
 800266a:	45f0      	cmp	r8, lr
 800266c:	f107 0708 	add.w	r7, r7, #8
 8002670:	d1e4      	bne.n	800263c <sha3_256+0x28>
 8002672:	ac02      	add	r4, sp, #8
 8002674:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
 8002676:	6030      	str	r0, [r6, #0]
 8002678:	6071      	str	r1, [r6, #4]
 800267a:	60b2      	str	r2, [r6, #8]
 800267c:	60f3      	str	r3, [r6, #12]
 800267e:	cc0f      	ldmia	r4!, {r0, r1, r2, r3}
 8002680:	6130      	str	r0, [r6, #16]
 8002682:	6171      	str	r1, [r6, #20]
 8002684:	61b2      	str	r2, [r6, #24]
 8002686:	61f3      	str	r3, [r6, #28]
 8002688:	b056      	add	sp, #344	@ 0x158
 800268a:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 800268e:	bf00      	nop

08002690 <platform_init>:
 8002690:	b5f0      	push	{r4, r5, r6, r7, lr}
 8002692:	b093      	sub	sp, #76	@ 0x4c
 8002694:	2603      	movs	r6, #3
 8002696:	f44f 27a0 	mov.w	r7, #327680	@ 0x50000
 800269a:	2302      	movs	r3, #2
 800269c:	e9cd 6706 	strd	r6, r7, [sp, #24]
 80026a0:	2501      	movs	r5, #1
 80026a2:	f44f 0180 	mov.w	r1, #4194304	@ 0x400000
 80026a6:	930c      	str	r3, [sp, #48]	@ 0x30
 80026a8:	220c      	movs	r2, #12
 80026aa:	23c4      	movs	r3, #196	@ 0xc4
 80026ac:	2604      	movs	r6, #4
 80026ae:	2707      	movs	r7, #7
 80026b0:	a806      	add	r0, sp, #24
 80026b2:	e9cd 120d 	strd	r1, r2, [sp, #52]	@ 0x34
 80026b6:	e9cd 6710 	strd	r6, r7, [sp, #64]	@ 0x40
 80026ba:	9509      	str	r5, [sp, #36]	@ 0x24
 80026bc:	930f      	str	r3, [sp, #60]	@ 0x3c
 80026be:	f000 f8bf 	bl	8002840 <HAL_RCC_OscConfig>
 80026c2:	b100      	cbz	r0, 80026c6 <platform_init+0x36>
 80026c4:	e7fe      	b.n	80026c4 <platform_init+0x34>
 80026c6:	4604      	mov	r4, r0
 80026c8:	230f      	movs	r3, #15
 80026ca:	4601      	mov	r1, r0
 80026cc:	a801      	add	r0, sp, #4
 80026ce:	e9cd 3501 	strd	r3, r5, [sp, #4]
 80026d2:	e9cd 4403 	strd	r4, r4, [sp, #12]
 80026d6:	9405      	str	r4, [sp, #20]
 80026d8:	f000 fabe 	bl	8002c58 <HAL_RCC_ClockConfig>
 80026dc:	4b09      	ldr	r3, [pc, #36]	@ (8002704 <platform_init+0x74>)
 80026de:	9400      	str	r4, [sp, #0]
 80026e0:	6b5a      	ldr	r2, [r3, #52]	@ 0x34
 80026e2:	4809      	ldr	r0, [pc, #36]	@ (8002708 <platform_init+0x78>)
 80026e4:	4909      	ldr	r1, [pc, #36]	@ (800270c <platform_init+0x7c>)
 80026e6:	f042 0240 	orr.w	r2, r2, #64	@ 0x40
 80026ea:	635a      	str	r2, [r3, #52]	@ 0x34
 80026ec:	6b5b      	ldr	r3, [r3, #52]	@ 0x34
 80026ee:	6001      	str	r1, [r0, #0]
 80026f0:	f003 0340 	and.w	r3, r3, #64	@ 0x40
 80026f4:	9300      	str	r3, [sp, #0]
 80026f6:	9b00      	ldr	r3, [sp, #0]
 80026f8:	7144      	strb	r4, [r0, #5]
 80026fa:	f000 fdd5 	bl	80032a8 <HAL_RNG_Init>
 80026fe:	b013      	add	sp, #76	@ 0x4c
 8002700:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002702:	bf00      	nop
 8002704:	40023800 	.word	0x40023800
 8002708:	20000998 	.word	0x20000998
 800270c:	50060800 	.word	0x50060800

08002710 <init_uart>:
 8002710:	b530      	push	{r4, r5, lr}
 8002712:	2302      	movs	r3, #2
 8002714:	b089      	sub	sp, #36	@ 0x24
 8002716:	2207      	movs	r2, #7
 8002718:	f44f 60c0 	mov.w	r0, #1536	@ 0x600
 800271c:	e9cd 0303 	strd	r0, r3, [sp, #12]
 8002720:	e9cd 3206 	strd	r3, r2, [sp, #24]
 8002724:	4d16      	ldr	r5, [pc, #88]	@ (8002780 <init_uart+0x70>)
 8002726:	4817      	ldr	r0, [pc, #92]	@ (8002784 <init_uart+0x74>)
 8002728:	2400      	movs	r4, #0
 800272a:	2101      	movs	r1, #1
 800272c:	9401      	str	r4, [sp, #4]
 800272e:	9105      	str	r1, [sp, #20]
 8002730:	6b2b      	ldr	r3, [r5, #48]	@ 0x30
 8002732:	430b      	orrs	r3, r1
 8002734:	632b      	str	r3, [r5, #48]	@ 0x30
 8002736:	6b2b      	ldr	r3, [r5, #48]	@ 0x30
 8002738:	f003 0301 	and.w	r3, r3, #1
 800273c:	a903      	add	r1, sp, #12
 800273e:	9301      	str	r3, [sp, #4]
 8002740:	9b01      	ldr	r3, [sp, #4]
 8002742:	f000 fb47 	bl	8002dd4 <HAL_GPIO_Init>
 8002746:	9402      	str	r4, [sp, #8]
 8002748:	6c6a      	ldr	r2, [r5, #68]	@ 0x44
 800274a:	4b0f      	ldr	r3, [pc, #60]	@ (8002788 <init_uart+0x78>)
 800274c:	490f      	ldr	r1, [pc, #60]	@ (800278c <init_uart+0x7c>)
 800274e:	f44f 4016 	mov.w	r0, #38400	@ 0x9600
 8002752:	f042 0210 	orr.w	r2, r2, #16
 8002756:	6158      	str	r0, [r3, #20]
 8002758:	646a      	str	r2, [r5, #68]	@ 0x44
 800275a:	6c6a      	ldr	r2, [r5, #68]	@ 0x44
 800275c:	6119      	str	r1, [r3, #16]
 800275e:	f002 0210 	and.w	r2, r2, #16
 8002762:	210c      	movs	r1, #12
 8002764:	9202      	str	r2, [sp, #8]
 8002766:	f103 0010 	add.w	r0, r3, #16
 800276a:	e9c3 4406 	strd	r4, r4, [r3, #24]
 800276e:	e9c3 4108 	strd	r4, r1, [r3, #32]
 8002772:	9a02      	ldr	r2, [sp, #8]
 8002774:	629c      	str	r4, [r3, #40]	@ 0x28
 8002776:	f000 fc4f 	bl	8003018 <HAL_UART_Init>
 800277a:	b009      	add	sp, #36	@ 0x24
 800277c:	bd30      	pop	{r4, r5, pc}
 800277e:	bf00      	nop
 8002780:	40023800 	.word	0x40023800
 8002784:	40020000 	.word	0x40020000
 8002788:	20000998 	.word	0x20000998
 800278c:	40011000 	.word	0x40011000

08002790 <trigger_setup>:
 8002790:	b530      	push	{r4, r5, lr}
 8002792:	b089      	sub	sp, #36	@ 0x24
 8002794:	4b0d      	ldr	r3, [pc, #52]	@ (80027cc <trigger_setup+0x3c>)
 8002796:	480e      	ldr	r0, [pc, #56]	@ (80027d0 <trigger_setup+0x40>)
 8002798:	2200      	movs	r2, #0
 800279a:	9201      	str	r2, [sp, #4]
 800279c:	6b1a      	ldr	r2, [r3, #48]	@ 0x30
 800279e:	f042 0201 	orr.w	r2, r2, #1
 80027a2:	631a      	str	r2, [r3, #48]	@ 0x30
 80027a4:	6b1b      	ldr	r3, [r3, #48]	@ 0x30
 80027a6:	f003 0301 	and.w	r3, r3, #1
 80027aa:	9301      	str	r3, [sp, #4]
 80027ac:	2200      	movs	r2, #0
 80027ae:	f44f 5480 	mov.w	r4, #4096	@ 0x1000
 80027b2:	2501      	movs	r5, #1
 80027b4:	2302      	movs	r3, #2
 80027b6:	a902      	add	r1, sp, #8
 80027b8:	e9cd 2304 	strd	r2, r3, [sp, #16]
 80027bc:	e9cd 4502 	strd	r4, r5, [sp, #8]
 80027c0:	9b01      	ldr	r3, [sp, #4]
 80027c2:	f000 fb07 	bl	8002dd4 <HAL_GPIO_Init>
 80027c6:	b009      	add	sp, #36	@ 0x24
 80027c8:	bd30      	pop	{r4, r5, pc}
 80027ca:	bf00      	nop
 80027cc:	40023800 	.word	0x40023800
 80027d0:	40020000 	.word	0x40020000

080027d4 <trigger_high>:
 80027d4:	4802      	ldr	r0, [pc, #8]	@ (80027e0 <trigger_high+0xc>)
 80027d6:	2201      	movs	r2, #1
 80027d8:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
 80027dc:	f000 bc18 	b.w	8003010 <HAL_GPIO_WritePin>
 80027e0:	40020000 	.word	0x40020000

080027e4 <trigger_low>:
 80027e4:	4802      	ldr	r0, [pc, #8]	@ (80027f0 <trigger_low+0xc>)
 80027e6:	2200      	movs	r2, #0
 80027e8:	f44f 5180 	mov.w	r1, #4096	@ 0x1000
 80027ec:	f000 bc10 	b.w	8003010 <HAL_GPIO_WritePin>
 80027f0:	40020000 	.word	0x40020000

080027f4 <getch>:
 80027f4:	b500      	push	{lr}
 80027f6:	b083      	sub	sp, #12
 80027f8:	4807      	ldr	r0, [pc, #28]	@ (8002818 <getch+0x24>)
 80027fa:	f241 3388 	movw	r3, #5000	@ 0x1388
 80027fe:	2201      	movs	r2, #1
 8002800:	f10d 0107 	add.w	r1, sp, #7
 8002804:	f000 fce0 	bl	80031c8 <HAL_UART_Receive>
 8002808:	2800      	cmp	r0, #0
 800280a:	d1f5      	bne.n	80027f8 <getch+0x4>
 800280c:	f89d 0007 	ldrb.w	r0, [sp, #7]
 8002810:	b003      	add	sp, #12
 8002812:	f85d fb04 	ldr.w	pc, [sp], #4
 8002816:	bf00      	nop
 8002818:	200009a8 	.word	0x200009a8

0800281c <putch>:
 800281c:	b500      	push	{lr}
 800281e:	b083      	sub	sp, #12
 8002820:	4684      	mov	ip, r0
 8002822:	f241 3388 	movw	r3, #5000	@ 0x1388
 8002826:	2201      	movs	r2, #1
 8002828:	f10d 0107 	add.w	r1, sp, #7
 800282c:	4803      	ldr	r0, [pc, #12]	@ (800283c <putch+0x20>)
 800282e:	f88d c007 	strb.w	ip, [sp, #7]
 8002832:	f000 fc6d 	bl	8003110 <HAL_UART_Transmit>
 8002836:	b003      	add	sp, #12
 8002838:	f85d fb04 	ldr.w	pc, [sp], #4
 800283c:	200009a8 	.word	0x200009a8

08002840 <HAL_RCC_OscConfig>:
 8002840:	b4f0      	push	{r4, r5, r6, r7}
 8002842:	6805      	ldr	r5, [r0, #0]
 8002844:	07ea      	lsls	r2, r5, #31
 8002846:	b082      	sub	sp, #8
 8002848:	d53a      	bpl.n	80028c0 <HAL_RCC_OscConfig+0x80>
 800284a:	4aa4      	ldr	r2, [pc, #656]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 800284c:	6893      	ldr	r3, [r2, #8]
 800284e:	f003 030c 	and.w	r3, r3, #12
 8002852:	2b04      	cmp	r3, #4
 8002854:	f000 80fd 	beq.w	8002a52 <HAL_RCC_OscConfig+0x212>
 8002858:	6893      	ldr	r3, [r2, #8]
 800285a:	f003 030c 	and.w	r3, r3, #12
 800285e:	2b08      	cmp	r3, #8
 8002860:	f000 80f3 	beq.w	8002a4a <HAL_RCC_OscConfig+0x20a>
 8002864:	4a9e      	ldr	r2, [pc, #632]	@ (8002ae0 <HAL_RCC_OscConfig+0x2a0>)
 8002866:	6841      	ldr	r1, [r0, #4]
 8002868:	6816      	ldr	r6, [r2, #0]
 800286a:	f5b1 3f80 	cmp.w	r1, #65536	@ 0x10000
 800286e:	f106 0301 	add.w	r3, r6, #1
 8002872:	f000 813f 	beq.w	8002af4 <HAL_RCC_OscConfig+0x2b4>
 8002876:	f5b1 2fa0 	cmp.w	r1, #327680	@ 0x50000
 800287a:	f000 8180 	beq.w	8002b7e <HAL_RCC_OscConfig+0x33e>
 800287e:	f8df c25c 	ldr.w	ip, [pc, #604]	@ 8002adc <HAL_RCC_OscConfig+0x29c>
 8002882:	f8dc 4000 	ldr.w	r4, [ip]
 8002886:	f424 3480 	bic.w	r4, r4, #65536	@ 0x10000
 800288a:	f8cc 4000 	str.w	r4, [ip]
 800288e:	f8dc 4000 	ldr.w	r4, [ip]
 8002892:	f424 2480 	bic.w	r4, r4, #262144	@ 0x40000
 8002896:	f8cc 4000 	str.w	r4, [ip]
 800289a:	2900      	cmp	r1, #0
 800289c:	f040 812f 	bne.w	8002afe <HAL_RCC_OscConfig+0x2be>
 80028a0:	4f90      	ldr	r7, [pc, #576]	@ (8002ae4 <HAL_RCC_OscConfig+0x2a4>)
 80028a2:	6013      	str	r3, [r2, #0]
 80028a4:	e004      	b.n	80028b0 <HAL_RCC_OscConfig+0x70>
 80028a6:	42bb      	cmp	r3, r7
 80028a8:	6011      	str	r1, [r2, #0]
 80028aa:	f200 80dd 	bhi.w	8002a68 <HAL_RCC_OscConfig+0x228>
 80028ae:	460b      	mov	r3, r1
 80028b0:	f8dc 4000 	ldr.w	r4, [ip]
 80028b4:	03a4      	lsls	r4, r4, #14
 80028b6:	f103 0101 	add.w	r1, r3, #1
 80028ba:	eba3 0306 	sub.w	r3, r3, r6
 80028be:	d4f2      	bmi.n	80028a6 <HAL_RCC_OscConfig+0x66>
 80028c0:	07ab      	lsls	r3, r5, #30
 80028c2:	d531      	bpl.n	8002928 <HAL_RCC_OscConfig+0xe8>
 80028c4:	4b85      	ldr	r3, [pc, #532]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 80028c6:	689a      	ldr	r2, [r3, #8]
 80028c8:	f012 0f0c 	tst.w	r2, #12
 80028cc:	f000 80d4 	beq.w	8002a78 <HAL_RCC_OscConfig+0x238>
 80028d0:	689a      	ldr	r2, [r3, #8]
 80028d2:	f002 020c 	and.w	r2, r2, #12
 80028d6:	2a08      	cmp	r2, #8
 80028d8:	f000 80ca 	beq.w	8002a70 <HAL_RCC_OscConfig+0x230>
 80028dc:	68c3      	ldr	r3, [r0, #12]
 80028de:	2b00      	cmp	r3, #0
 80028e0:	f000 811e 	beq.w	8002b20 <HAL_RCC_OscConfig+0x2e0>
 80028e4:	4b80      	ldr	r3, [pc, #512]	@ (8002ae8 <HAL_RCC_OscConfig+0x2a8>)
 80028e6:	4a7e      	ldr	r2, [pc, #504]	@ (8002ae0 <HAL_RCC_OscConfig+0x2a0>)
 80028e8:	4d7c      	ldr	r5, [pc, #496]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 80028ea:	2101      	movs	r1, #1
 80028ec:	6019      	str	r1, [r3, #0]
 80028ee:	6816      	ldr	r6, [r2, #0]
 80028f0:	1873      	adds	r3, r6, r1
 80028f2:	6013      	str	r3, [r2, #0]
 80028f4:	e004      	b.n	8002900 <HAL_RCC_OscConfig+0xc0>
 80028f6:	2b02      	cmp	r3, #2
 80028f8:	6011      	str	r1, [r2, #0]
 80028fa:	f200 80b5 	bhi.w	8002a68 <HAL_RCC_OscConfig+0x228>
 80028fe:	460b      	mov	r3, r1
 8002900:	682c      	ldr	r4, [r5, #0]
 8002902:	07a7      	lsls	r7, r4, #30
 8002904:	f103 0101 	add.w	r1, r3, #1
 8002908:	eba3 0306 	sub.w	r3, r3, r6
 800290c:	d5f3      	bpl.n	80028f6 <HAL_RCC_OscConfig+0xb6>
 800290e:	6829      	ldr	r1, [r5, #0]
 8002910:	22f8      	movs	r2, #248	@ 0xf8
 8002912:	fa92 f2a2 	rbit	r2, r2
 8002916:	6903      	ldr	r3, [r0, #16]
 8002918:	fab2 f282 	clz	r2, r2
 800291c:	4093      	lsls	r3, r2
 800291e:	f021 02f8 	bic.w	r2, r1, #248	@ 0xf8
 8002922:	4313      	orrs	r3, r2
 8002924:	602b      	str	r3, [r5, #0]
 8002926:	6805      	ldr	r5, [r0, #0]
 8002928:	072b      	lsls	r3, r5, #28
 800292a:	d51d      	bpl.n	8002968 <HAL_RCC_OscConfig+0x128>
 800292c:	6944      	ldr	r4, [r0, #20]
 800292e:	4b6e      	ldr	r3, [pc, #440]	@ (8002ae8 <HAL_RCC_OscConfig+0x2a8>)
 8002930:	4a6b      	ldr	r2, [pc, #428]	@ (8002ae0 <HAL_RCC_OscConfig+0x2a0>)
 8002932:	2c00      	cmp	r4, #0
 8002934:	f000 80ab 	beq.w	8002a8e <HAL_RCC_OscConfig+0x24e>
 8002938:	2101      	movs	r1, #1
 800293a:	f8c3 1e80 	str.w	r1, [r3, #3712]	@ 0xe80
 800293e:	6814      	ldr	r4, [r2, #0]
 8002940:	4e66      	ldr	r6, [pc, #408]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 8002942:	1863      	adds	r3, r4, r1
 8002944:	6013      	str	r3, [r2, #0]
 8002946:	3404      	adds	r4, #4
 8002948:	2500      	movs	r5, #0
 800294a:	e005      	b.n	8002958 <HAL_RCC_OscConfig+0x118>
 800294c:	3301      	adds	r3, #1
 800294e:	42a3      	cmp	r3, r4
 8002950:	f04f 0501 	mov.w	r5, #1
 8002954:	f000 8087 	beq.w	8002a66 <HAL_RCC_OscConfig+0x226>
 8002958:	6f71      	ldr	r1, [r6, #116]	@ 0x74
 800295a:	078f      	lsls	r7, r1, #30
 800295c:	d5f6      	bpl.n	800294c <HAL_RCC_OscConfig+0x10c>
 800295e:	2d00      	cmp	r5, #0
 8002960:	f000 816d 	beq.w	8002c3e <HAL_RCC_OscConfig+0x3fe>
 8002964:	6805      	ldr	r5, [r0, #0]
 8002966:	6013      	str	r3, [r2, #0]
 8002968:	076b      	lsls	r3, r5, #29
 800296a:	d54a      	bpl.n	8002a02 <HAL_RCC_OscConfig+0x1c2>
 800296c:	4b5b      	ldr	r3, [pc, #364]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 800296e:	4d5f      	ldr	r5, [pc, #380]	@ (8002aec <HAL_RCC_OscConfig+0x2ac>)
 8002970:	2400      	movs	r4, #0
 8002972:	9401      	str	r4, [sp, #4]
 8002974:	6c1a      	ldr	r2, [r3, #64]	@ 0x40
 8002976:	f042 5280 	orr.w	r2, r2, #268435456	@ 0x10000000
 800297a:	641a      	str	r2, [r3, #64]	@ 0x40
 800297c:	6c1b      	ldr	r3, [r3, #64]	@ 0x40
 800297e:	4a58      	ldr	r2, [pc, #352]	@ (8002ae0 <HAL_RCC_OscConfig+0x2a0>)
 8002980:	f003 5380 	and.w	r3, r3, #268435456	@ 0x10000000
 8002984:	9301      	str	r3, [sp, #4]
 8002986:	9b01      	ldr	r3, [sp, #4]
 8002988:	682b      	ldr	r3, [r5, #0]
 800298a:	f443 7380 	orr.w	r3, r3, #256	@ 0x100
 800298e:	602b      	str	r3, [r5, #0]
 8002990:	6813      	ldr	r3, [r2, #0]
 8002992:	1c5e      	adds	r6, r3, #1
 8002994:	f103 0c04 	add.w	ip, r3, #4
 8002998:	6016      	str	r6, [r2, #0]
 800299a:	4633      	mov	r3, r6
 800299c:	e004      	b.n	80029a8 <HAL_RCC_OscConfig+0x168>
 800299e:	3301      	adds	r3, #1
 80029a0:	4563      	cmp	r3, ip
 80029a2:	f04f 0401 	mov.w	r4, #1
 80029a6:	d05e      	beq.n	8002a66 <HAL_RCC_OscConfig+0x226>
 80029a8:	6829      	ldr	r1, [r5, #0]
 80029aa:	05cf      	lsls	r7, r1, #23
 80029ac:	d5f7      	bpl.n	800299e <HAL_RCC_OscConfig+0x15e>
 80029ae:	2c00      	cmp	r4, #0
 80029b0:	f000 80ef 	beq.w	8002b92 <HAL_RCC_OscConfig+0x352>
 80029b4:	6013      	str	r3, [r2, #0]
 80029b6:	6884      	ldr	r4, [r0, #8]
 80029b8:	2c01      	cmp	r4, #1
 80029ba:	f103 0601 	add.w	r6, r3, #1
 80029be:	f000 80c4 	beq.w	8002b4a <HAL_RCC_OscConfig+0x30a>
 80029c2:	2c05      	cmp	r4, #5
 80029c4:	f000 8131 	beq.w	8002c2a <HAL_RCC_OscConfig+0x3ea>
 80029c8:	4d44      	ldr	r5, [pc, #272]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 80029ca:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 80029cc:	f021 0101 	bic.w	r1, r1, #1
 80029d0:	6729      	str	r1, [r5, #112]	@ 0x70
 80029d2:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 80029d4:	f021 0104 	bic.w	r1, r1, #4
 80029d8:	6729      	str	r1, [r5, #112]	@ 0x70
 80029da:	2c00      	cmp	r4, #0
 80029dc:	f040 80ba 	bne.w	8002b54 <HAL_RCC_OscConfig+0x314>
 80029e0:	f503 539c 	add.w	r3, r3, #4992	@ 0x1380
 80029e4:	6016      	str	r6, [r2, #0]
 80029e6:	330a      	adds	r3, #10
 80029e8:	e005      	b.n	80029f6 <HAL_RCC_OscConfig+0x1b6>
 80029ea:	3601      	adds	r6, #1
 80029ec:	429e      	cmp	r6, r3
 80029ee:	f04f 0401 	mov.w	r4, #1
 80029f2:	f000 8118 	beq.w	8002c26 <HAL_RCC_OscConfig+0x3e6>
 80029f6:	6f29      	ldr	r1, [r5, #112]	@ 0x70
 80029f8:	078f      	lsls	r7, r1, #30
 80029fa:	d4f6      	bmi.n	80029ea <HAL_RCC_OscConfig+0x1aa>
 80029fc:	2c00      	cmp	r4, #0
 80029fe:	f040 80bc 	bne.w	8002b7a <HAL_RCC_OscConfig+0x33a>
 8002a02:	6983      	ldr	r3, [r0, #24]
 8002a04:	b1eb      	cbz	r3, 8002a42 <HAL_RCC_OscConfig+0x202>
 8002a06:	4e35      	ldr	r6, [pc, #212]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 8002a08:	68b2      	ldr	r2, [r6, #8]
 8002a0a:	f002 020c 	and.w	r2, r2, #12
 8002a0e:	2a08      	cmp	r2, #8
 8002a10:	d039      	beq.n	8002a86 <HAL_RCC_OscConfig+0x246>
 8002a12:	2b02      	cmp	r3, #2
 8002a14:	4b34      	ldr	r3, [pc, #208]	@ (8002ae8 <HAL_RCC_OscConfig+0x2a8>)
 8002a16:	4a32      	ldr	r2, [pc, #200]	@ (8002ae0 <HAL_RCC_OscConfig+0x2a0>)
 8002a18:	f04f 0100 	mov.w	r1, #0
 8002a1c:	6619      	str	r1, [r3, #96]	@ 0x60
 8002a1e:	f000 80ba 	beq.w	8002b96 <HAL_RCC_OscConfig+0x356>
 8002a22:	6814      	ldr	r4, [r2, #0]
 8002a24:	4d32      	ldr	r5, [pc, #200]	@ (8002af0 <HAL_RCC_OscConfig+0x2b0>)
 8002a26:	1c63      	adds	r3, r4, #1
 8002a28:	6013      	str	r3, [r2, #0]
 8002a2a:	e003      	b.n	8002a34 <HAL_RCC_OscConfig+0x1f4>
 8002a2c:	42ab      	cmp	r3, r5
 8002a2e:	6011      	str	r1, [r2, #0]
 8002a30:	d81a      	bhi.n	8002a68 <HAL_RCC_OscConfig+0x228>
 8002a32:	460b      	mov	r3, r1
 8002a34:	6830      	ldr	r0, [r6, #0]
 8002a36:	0180      	lsls	r0, r0, #6
 8002a38:	f103 0101 	add.w	r1, r3, #1
 8002a3c:	eba3 0304 	sub.w	r3, r3, r4
 8002a40:	d4f4      	bmi.n	8002a2c <HAL_RCC_OscConfig+0x1ec>
 8002a42:	2000      	movs	r0, #0
 8002a44:	b002      	add	sp, #8
 8002a46:	bcf0      	pop	{r4, r5, r6, r7}
 8002a48:	4770      	bx	lr
 8002a4a:	6853      	ldr	r3, [r2, #4]
 8002a4c:	025f      	lsls	r7, r3, #9
 8002a4e:	f57f af09 	bpl.w	8002864 <HAL_RCC_OscConfig+0x24>
 8002a52:	4b22      	ldr	r3, [pc, #136]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 8002a54:	681b      	ldr	r3, [r3, #0]
 8002a56:	039e      	lsls	r6, r3, #14
 8002a58:	f57f af32 	bpl.w	80028c0 <HAL_RCC_OscConfig+0x80>
 8002a5c:	6843      	ldr	r3, [r0, #4]
 8002a5e:	2b00      	cmp	r3, #0
 8002a60:	f47f af2e 	bne.w	80028c0 <HAL_RCC_OscConfig+0x80>
 8002a64:	e00f      	b.n	8002a86 <HAL_RCC_OscConfig+0x246>
 8002a66:	6013      	str	r3, [r2, #0]
 8002a68:	2003      	movs	r0, #3
 8002a6a:	b002      	add	sp, #8
 8002a6c:	bcf0      	pop	{r4, r5, r6, r7}
 8002a6e:	4770      	bx	lr
 8002a70:	685b      	ldr	r3, [r3, #4]
 8002a72:	025a      	lsls	r2, r3, #9
 8002a74:	f53f af32 	bmi.w	80028dc <HAL_RCC_OscConfig+0x9c>
 8002a78:	4b18      	ldr	r3, [pc, #96]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 8002a7a:	681b      	ldr	r3, [r3, #0]
 8002a7c:	079b      	lsls	r3, r3, #30
 8002a7e:	d51c      	bpl.n	8002aba <HAL_RCC_OscConfig+0x27a>
 8002a80:	68c3      	ldr	r3, [r0, #12]
 8002a82:	2b01      	cmp	r3, #1
 8002a84:	d019      	beq.n	8002aba <HAL_RCC_OscConfig+0x27a>
 8002a86:	2001      	movs	r0, #1
 8002a88:	b002      	add	sp, #8
 8002a8a:	bcf0      	pop	{r4, r5, r6, r7}
 8002a8c:	4770      	bx	lr
 8002a8e:	f8c3 4e80 	str.w	r4, [r3, #3712]	@ 0xe80
 8002a92:	6815      	ldr	r5, [r2, #0]
 8002a94:	4e11      	ldr	r6, [pc, #68]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 8002a96:	1c6b      	adds	r3, r5, #1
 8002a98:	6013      	str	r3, [r2, #0]
 8002a9a:	3504      	adds	r5, #4
 8002a9c:	e004      	b.n	8002aa8 <HAL_RCC_OscConfig+0x268>
 8002a9e:	3301      	adds	r3, #1
 8002aa0:	42ab      	cmp	r3, r5
 8002aa2:	f04f 0401 	mov.w	r4, #1
 8002aa6:	d0de      	beq.n	8002a66 <HAL_RCC_OscConfig+0x226>
 8002aa8:	6f71      	ldr	r1, [r6, #116]	@ 0x74
 8002aaa:	0789      	lsls	r1, r1, #30
 8002aac:	d4f7      	bmi.n	8002a9e <HAL_RCC_OscConfig+0x25e>
 8002aae:	6805      	ldr	r5, [r0, #0]
 8002ab0:	2c00      	cmp	r4, #0
 8002ab2:	f43f af59 	beq.w	8002968 <HAL_RCC_OscConfig+0x128>
 8002ab6:	6013      	str	r3, [r2, #0]
 8002ab8:	e756      	b.n	8002968 <HAL_RCC_OscConfig+0x128>
 8002aba:	4c08      	ldr	r4, [pc, #32]	@ (8002adc <HAL_RCC_OscConfig+0x29c>)
 8002abc:	22f8      	movs	r2, #248	@ 0xf8
 8002abe:	6821      	ldr	r1, [r4, #0]
 8002ac0:	fa92 f2a2 	rbit	r2, r2
 8002ac4:	6903      	ldr	r3, [r0, #16]
 8002ac6:	fab2 f282 	clz	r2, r2
 8002aca:	f021 01f8 	bic.w	r1, r1, #248	@ 0xf8
 8002ace:	4093      	lsls	r3, r2
 8002ad0:	430b      	orrs	r3, r1
 8002ad2:	6023      	str	r3, [r4, #0]
 8002ad4:	072b      	lsls	r3, r5, #28
 8002ad6:	f57f af47 	bpl.w	8002968 <HAL_RCC_OscConfig+0x128>
 8002ada:	e727      	b.n	800292c <HAL_RCC_OscConfig+0xec>
 8002adc:	40023800 	.word	0x40023800
 8002ae0:	20000a38 	.word	0x20000a38
 8002ae4:	05f5e100 	.word	0x05f5e100
 8002ae8:	42470000 	.word	0x42470000
 8002aec:	40007000 	.word	0x40007000
 8002af0:	001e8480 	.word	0x001e8480
 8002af4:	4c53      	ldr	r4, [pc, #332]	@ (8002c44 <HAL_RCC_OscConfig+0x404>)
 8002af6:	6821      	ldr	r1, [r4, #0]
 8002af8:	f441 3180 	orr.w	r1, r1, #65536	@ 0x10000
 8002afc:	6021      	str	r1, [r4, #0]
 8002afe:	4f51      	ldr	r7, [pc, #324]	@ (8002c44 <HAL_RCC_OscConfig+0x404>)
 8002b00:	f8df c144 	ldr.w	ip, [pc, #324]	@ 8002c48 <HAL_RCC_OscConfig+0x408>
 8002b04:	6013      	str	r3, [r2, #0]
 8002b06:	e003      	b.n	8002b10 <HAL_RCC_OscConfig+0x2d0>
 8002b08:	4563      	cmp	r3, ip
 8002b0a:	6011      	str	r1, [r2, #0]
 8002b0c:	d8ac      	bhi.n	8002a68 <HAL_RCC_OscConfig+0x228>
 8002b0e:	460b      	mov	r3, r1
 8002b10:	683c      	ldr	r4, [r7, #0]
 8002b12:	03a4      	lsls	r4, r4, #14
 8002b14:	f103 0101 	add.w	r1, r3, #1
 8002b18:	eba3 0306 	sub.w	r3, r3, r6
 8002b1c:	d5f4      	bpl.n	8002b08 <HAL_RCC_OscConfig+0x2c8>
 8002b1e:	e6cf      	b.n	80028c0 <HAL_RCC_OscConfig+0x80>
 8002b20:	494a      	ldr	r1, [pc, #296]	@ (8002c4c <HAL_RCC_OscConfig+0x40c>)
 8002b22:	4a4b      	ldr	r2, [pc, #300]	@ (8002c50 <HAL_RCC_OscConfig+0x410>)
 8002b24:	600b      	str	r3, [r1, #0]
 8002b26:	6815      	ldr	r5, [r2, #0]
 8002b28:	4e46      	ldr	r6, [pc, #280]	@ (8002c44 <HAL_RCC_OscConfig+0x404>)
 8002b2a:	1c6b      	adds	r3, r5, #1
 8002b2c:	6013      	str	r3, [r2, #0]
 8002b2e:	e003      	b.n	8002b38 <HAL_RCC_OscConfig+0x2f8>
 8002b30:	2b02      	cmp	r3, #2
 8002b32:	6011      	str	r1, [r2, #0]
 8002b34:	d898      	bhi.n	8002a68 <HAL_RCC_OscConfig+0x228>
 8002b36:	460b      	mov	r3, r1
 8002b38:	6834      	ldr	r4, [r6, #0]
 8002b3a:	07a4      	lsls	r4, r4, #30
 8002b3c:	f103 0101 	add.w	r1, r3, #1
 8002b40:	eba3 0305 	sub.w	r3, r3, r5
 8002b44:	d4f4      	bmi.n	8002b30 <HAL_RCC_OscConfig+0x2f0>
 8002b46:	6805      	ldr	r5, [r0, #0]
 8002b48:	e6ee      	b.n	8002928 <HAL_RCC_OscConfig+0xe8>
 8002b4a:	4c3e      	ldr	r4, [pc, #248]	@ (8002c44 <HAL_RCC_OscConfig+0x404>)
 8002b4c:	6f21      	ldr	r1, [r4, #112]	@ 0x70
 8002b4e:	f041 0101 	orr.w	r1, r1, #1
 8002b52:	6721      	str	r1, [r4, #112]	@ 0x70
 8002b54:	f503 539c 	add.w	r3, r3, #4992	@ 0x1380
 8002b58:	4c3a      	ldr	r4, [pc, #232]	@ (8002c44 <HAL_RCC_OscConfig+0x404>)
 8002b5a:	6016      	str	r6, [r2, #0]
 8002b5c:	330a      	adds	r3, #10
 8002b5e:	2500      	movs	r5, #0
 8002b60:	e005      	b.n	8002b6e <HAL_RCC_OscConfig+0x32e>
 8002b62:	3601      	adds	r6, #1
 8002b64:	42b3      	cmp	r3, r6
 8002b66:	f04f 0501 	mov.w	r5, #1
 8002b6a:	f43f af7c 	beq.w	8002a66 <HAL_RCC_OscConfig+0x226>
 8002b6e:	6f21      	ldr	r1, [r4, #112]	@ 0x70
 8002b70:	0789      	lsls	r1, r1, #30
 8002b72:	d5f6      	bpl.n	8002b62 <HAL_RCC_OscConfig+0x322>
 8002b74:	2d00      	cmp	r5, #0
 8002b76:	f43f af44 	beq.w	8002a02 <HAL_RCC_OscConfig+0x1c2>
 8002b7a:	6016      	str	r6, [r2, #0]
 8002b7c:	e741      	b.n	8002a02 <HAL_RCC_OscConfig+0x1c2>
 8002b7e:	4931      	ldr	r1, [pc, #196]	@ (8002c44 <HAL_RCC_OscConfig+0x404>)
 8002b80:	680c      	ldr	r4, [r1, #0]
 8002b82:	f444 2480 	orr.w	r4, r4, #262144	@ 0x40000
 8002b86:	600c      	str	r4, [r1, #0]
 8002b88:	680c      	ldr	r4, [r1, #0]
 8002b8a:	f444 3480 	orr.w	r4, r4, #65536	@ 0x10000
 8002b8e:	600c      	str	r4, [r1, #0]
 8002b90:	e7b5      	b.n	8002afe <HAL_RCC_OscConfig+0x2be>
 8002b92:	4633      	mov	r3, r6
 8002b94:	e70f      	b.n	80029b6 <HAL_RCC_OscConfig+0x176>
 8002b96:	6815      	ldr	r5, [r2, #0]
 8002b98:	4f2e      	ldr	r7, [pc, #184]	@ (8002c54 <HAL_RCC_OscConfig+0x414>)
 8002b9a:	1c6b      	adds	r3, r5, #1
 8002b9c:	6013      	str	r3, [r2, #0]
 8002b9e:	e004      	b.n	8002baa <HAL_RCC_OscConfig+0x36a>
 8002ba0:	42bb      	cmp	r3, r7
 8002ba2:	6011      	str	r1, [r2, #0]
 8002ba4:	f63f af60 	bhi.w	8002a68 <HAL_RCC_OscConfig+0x228>
 8002ba8:	460b      	mov	r3, r1
 8002baa:	6834      	ldr	r4, [r6, #0]
 8002bac:	01a4      	lsls	r4, r4, #6
 8002bae:	f103 0101 	add.w	r1, r3, #1
 8002bb2:	eba3 0305 	sub.w	r3, r3, r5
 8002bb6:	d4f3      	bmi.n	8002ba0 <HAL_RCC_OscConfig+0x360>
 8002bb8:	f647 75c0 	movw	r5, #32704	@ 0x7fc0
 8002bbc:	fa95 f5a5 	rbit	r5, r5
 8002bc0:	f44f 3740 	mov.w	r7, #196608	@ 0x30000
 8002bc4:	fab5 f585 	clz	r5, r5
 8002bc8:	fa97 f7a7 	rbit	r7, r7
 8002bcc:	f04f 6470 	mov.w	r4, #251658240	@ 0xf000000
 8002bd0:	fab7 f787 	clz	r7, r7
 8002bd4:	fa94 f4a4 	rbit	r4, r4
 8002bd8:	6a83      	ldr	r3, [r0, #40]	@ 0x28
 8002bda:	0859      	lsrs	r1, r3, #1
 8002bdc:	3901      	subs	r1, #1
 8002bde:	40b9      	lsls	r1, r7
 8002be0:	e9d0 3707 	ldrd	r3, r7, [r0, #28]
 8002be4:	433b      	orrs	r3, r7
 8002be6:	6a47      	ldr	r7, [r0, #36]	@ 0x24
 8002be8:	40af      	lsls	r7, r5
 8002bea:	433b      	orrs	r3, r7
 8002bec:	430b      	orrs	r3, r1
 8002bee:	6ac1      	ldr	r1, [r0, #44]	@ 0x2c
 8002bf0:	4816      	ldr	r0, [pc, #88]	@ (8002c4c <HAL_RCC_OscConfig+0x40c>)
 8002bf2:	4d14      	ldr	r5, [pc, #80]	@ (8002c44 <HAL_RCC_OscConfig+0x404>)
 8002bf4:	fab4 f484 	clz	r4, r4
 8002bf8:	40a1      	lsls	r1, r4
 8002bfa:	430b      	orrs	r3, r1
 8002bfc:	6073      	str	r3, [r6, #4]
 8002bfe:	2301      	movs	r3, #1
 8002c00:	6603      	str	r3, [r0, #96]	@ 0x60
 8002c02:	6814      	ldr	r4, [r2, #0]
 8002c04:	4e13      	ldr	r6, [pc, #76]	@ (8002c54 <HAL_RCC_OscConfig+0x414>)
 8002c06:	18e3      	adds	r3, r4, r3
 8002c08:	6013      	str	r3, [r2, #0]
 8002c0a:	e004      	b.n	8002c16 <HAL_RCC_OscConfig+0x3d6>
 8002c0c:	42b3      	cmp	r3, r6
 8002c0e:	6011      	str	r1, [r2, #0]
 8002c10:	f63f af2a 	bhi.w	8002a68 <HAL_RCC_OscConfig+0x228>
 8002c14:	460b      	mov	r3, r1
 8002c16:	6828      	ldr	r0, [r5, #0]
 8002c18:	0187      	lsls	r7, r0, #6
 8002c1a:	f103 0101 	add.w	r1, r3, #1
 8002c1e:	eba3 0304 	sub.w	r3, r3, r4
 8002c22:	d5f3      	bpl.n	8002c0c <HAL_RCC_OscConfig+0x3cc>
 8002c24:	e70d      	b.n	8002a42 <HAL_RCC_OscConfig+0x202>
 8002c26:	6016      	str	r6, [r2, #0]
 8002c28:	e71e      	b.n	8002a68 <HAL_RCC_OscConfig+0x228>
 8002c2a:	4906      	ldr	r1, [pc, #24]	@ (8002c44 <HAL_RCC_OscConfig+0x404>)
 8002c2c:	6f0c      	ldr	r4, [r1, #112]	@ 0x70
 8002c2e:	f044 0404 	orr.w	r4, r4, #4
 8002c32:	670c      	str	r4, [r1, #112]	@ 0x70
 8002c34:	6f0c      	ldr	r4, [r1, #112]	@ 0x70
 8002c36:	f044 0401 	orr.w	r4, r4, #1
 8002c3a:	670c      	str	r4, [r1, #112]	@ 0x70
 8002c3c:	e78a      	b.n	8002b54 <HAL_RCC_OscConfig+0x314>
 8002c3e:	6805      	ldr	r5, [r0, #0]
 8002c40:	e692      	b.n	8002968 <HAL_RCC_OscConfig+0x128>
 8002c42:	bf00      	nop
 8002c44:	40023800 	.word	0x40023800
 8002c48:	05f5e100 	.word	0x05f5e100
 8002c4c:	42470000 	.word	0x42470000
 8002c50:	20000a38 	.word	0x20000a38
 8002c54:	001e8480 	.word	0x001e8480

08002c58 <HAL_RCC_ClockConfig>:
 8002c58:	4a5b      	ldr	r2, [pc, #364]	@ (8002dc8 <HAL_RCC_ClockConfig+0x170>)
 8002c5a:	6813      	ldr	r3, [r2, #0]
 8002c5c:	f003 030f 	and.w	r3, r3, #15
 8002c60:	428b      	cmp	r3, r1
 8002c62:	d208      	bcs.n	8002c76 <HAL_RCC_ClockConfig+0x1e>
 8002c64:	b2cb      	uxtb	r3, r1
 8002c66:	7013      	strb	r3, [r2, #0]
 8002c68:	6813      	ldr	r3, [r2, #0]
 8002c6a:	f003 030f 	and.w	r3, r3, #15
 8002c6e:	428b      	cmp	r3, r1
 8002c70:	d001      	beq.n	8002c76 <HAL_RCC_ClockConfig+0x1e>
 8002c72:	2001      	movs	r0, #1
 8002c74:	4770      	bx	lr
 8002c76:	b5f0      	push	{r4, r5, r6, r7, lr}
 8002c78:	6804      	ldr	r4, [r0, #0]
 8002c7a:	07a5      	lsls	r5, r4, #30
 8002c7c:	d506      	bpl.n	8002c8c <HAL_RCC_ClockConfig+0x34>
 8002c7e:	4a53      	ldr	r2, [pc, #332]	@ (8002dcc <HAL_RCC_ClockConfig+0x174>)
 8002c80:	6885      	ldr	r5, [r0, #8]
 8002c82:	6893      	ldr	r3, [r2, #8]
 8002c84:	f023 03f0 	bic.w	r3, r3, #240	@ 0xf0
 8002c88:	432b      	orrs	r3, r5
 8002c8a:	6093      	str	r3, [r2, #8]
 8002c8c:	07e2      	lsls	r2, r4, #31
 8002c8e:	d526      	bpl.n	8002cde <HAL_RCC_ClockConfig+0x86>
 8002c90:	6842      	ldr	r2, [r0, #4]
 8002c92:	2a01      	cmp	r2, #1
 8002c94:	d075      	beq.n	8002d82 <HAL_RCC_ClockConfig+0x12a>
 8002c96:	1e93      	subs	r3, r2, #2
 8002c98:	4e4c      	ldr	r6, [pc, #304]	@ (8002dcc <HAL_RCC_ClockConfig+0x174>)
 8002c9a:	2b01      	cmp	r3, #1
 8002c9c:	6833      	ldr	r3, [r6, #0]
 8002c9e:	d943      	bls.n	8002d28 <HAL_RCC_ClockConfig+0xd0>
 8002ca0:	079d      	lsls	r5, r3, #30
 8002ca2:	d529      	bpl.n	8002cf8 <HAL_RCC_ClockConfig+0xa0>
 8002ca4:	68b3      	ldr	r3, [r6, #8]
 8002ca6:	4d4a      	ldr	r5, [pc, #296]	@ (8002dd0 <HAL_RCC_ClockConfig+0x178>)
 8002ca8:	f023 0303 	bic.w	r3, r3, #3
 8002cac:	4313      	orrs	r3, r2
 8002cae:	60b3      	str	r3, [r6, #8]
 8002cb0:	682f      	ldr	r7, [r5, #0]
 8002cb2:	1c7b      	adds	r3, r7, #1
 8002cb4:	f04f 0c00 	mov.w	ip, #0
 8002cb8:	f241 3e88 	movw	lr, #5000	@ 0x1388
 8002cbc:	602b      	str	r3, [r5, #0]
 8002cbe:	e006      	b.n	8002cce <HAL_RCC_ClockConfig+0x76>
 8002cc0:	3301      	adds	r3, #1
 8002cc2:	1bda      	subs	r2, r3, r7
 8002cc4:	3a01      	subs	r2, #1
 8002cc6:	4572      	cmp	r2, lr
 8002cc8:	f04f 0c01 	mov.w	ip, #1
 8002ccc:	d878      	bhi.n	8002dc0 <HAL_RCC_ClockConfig+0x168>
 8002cce:	68b2      	ldr	r2, [r6, #8]
 8002cd0:	f012 0f0c 	tst.w	r2, #12
 8002cd4:	d1f4      	bne.n	8002cc0 <HAL_RCC_ClockConfig+0x68>
 8002cd6:	f1bc 0f00 	cmp.w	ip, #0
 8002cda:	d000      	beq.n	8002cde <HAL_RCC_ClockConfig+0x86>
 8002cdc:	602b      	str	r3, [r5, #0]
 8002cde:	4a3a      	ldr	r2, [pc, #232]	@ (8002dc8 <HAL_RCC_ClockConfig+0x170>)
 8002ce0:	6813      	ldr	r3, [r2, #0]
 8002ce2:	f003 030f 	and.w	r3, r3, #15
 8002ce6:	428b      	cmp	r3, r1
 8002ce8:	d909      	bls.n	8002cfe <HAL_RCC_ClockConfig+0xa6>
 8002cea:	b2cb      	uxtb	r3, r1
 8002cec:	7013      	strb	r3, [r2, #0]
 8002cee:	6813      	ldr	r3, [r2, #0]
 8002cf0:	f003 030f 	and.w	r3, r3, #15
 8002cf4:	428b      	cmp	r3, r1
 8002cf6:	d001      	beq.n	8002cfc <HAL_RCC_ClockConfig+0xa4>
 8002cf8:	2001      	movs	r0, #1
 8002cfa:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002cfc:	6804      	ldr	r4, [r0, #0]
 8002cfe:	0762      	lsls	r2, r4, #29
 8002d00:	d506      	bpl.n	8002d10 <HAL_RCC_ClockConfig+0xb8>
 8002d02:	4a32      	ldr	r2, [pc, #200]	@ (8002dcc <HAL_RCC_ClockConfig+0x174>)
 8002d04:	68c1      	ldr	r1, [r0, #12]
 8002d06:	6893      	ldr	r3, [r2, #8]
 8002d08:	f423 53e0 	bic.w	r3, r3, #7168	@ 0x1c00
 8002d0c:	430b      	orrs	r3, r1
 8002d0e:	6093      	str	r3, [r2, #8]
 8002d10:	0723      	lsls	r3, r4, #28
 8002d12:	d507      	bpl.n	8002d24 <HAL_RCC_ClockConfig+0xcc>
 8002d14:	4a2d      	ldr	r2, [pc, #180]	@ (8002dcc <HAL_RCC_ClockConfig+0x174>)
 8002d16:	6901      	ldr	r1, [r0, #16]
 8002d18:	6893      	ldr	r3, [r2, #8]
 8002d1a:	f423 4360 	bic.w	r3, r3, #57344	@ 0xe000
 8002d1e:	ea43 03c1 	orr.w	r3, r3, r1, lsl #3
 8002d22:	6093      	str	r3, [r2, #8]
 8002d24:	2000      	movs	r0, #0
 8002d26:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002d28:	019f      	lsls	r7, r3, #6
 8002d2a:	d5e5      	bpl.n	8002cf8 <HAL_RCC_ClockConfig+0xa0>
 8002d2c:	68b3      	ldr	r3, [r6, #8]
 8002d2e:	4d28      	ldr	r5, [pc, #160]	@ (8002dd0 <HAL_RCC_ClockConfig+0x178>)
 8002d30:	f023 0303 	bic.w	r3, r3, #3
 8002d34:	4313      	orrs	r3, r2
 8002d36:	60b3      	str	r3, [r6, #8]
 8002d38:	682f      	ldr	r7, [r5, #0]
 8002d3a:	2a02      	cmp	r2, #2
 8002d3c:	f107 0301 	add.w	r3, r7, #1
 8002d40:	602b      	str	r3, [r5, #0]
 8002d42:	f04f 0c00 	mov.w	ip, #0
 8002d46:	f241 3e88 	movw	lr, #5000	@ 0x1388
 8002d4a:	d007      	beq.n	8002d5c <HAL_RCC_ClockConfig+0x104>
 8002d4c:	e013      	b.n	8002d76 <HAL_RCC_ClockConfig+0x11e>
 8002d4e:	3301      	adds	r3, #1
 8002d50:	1bda      	subs	r2, r3, r7
 8002d52:	3a01      	subs	r2, #1
 8002d54:	4572      	cmp	r2, lr
 8002d56:	f04f 0c01 	mov.w	ip, #1
 8002d5a:	d831      	bhi.n	8002dc0 <HAL_RCC_ClockConfig+0x168>
 8002d5c:	68b2      	ldr	r2, [r6, #8]
 8002d5e:	f002 020c 	and.w	r2, r2, #12
 8002d62:	2a08      	cmp	r2, #8
 8002d64:	d1f3      	bne.n	8002d4e <HAL_RCC_ClockConfig+0xf6>
 8002d66:	e7b6      	b.n	8002cd6 <HAL_RCC_ClockConfig+0x7e>
 8002d68:	3301      	adds	r3, #1
 8002d6a:	1bda      	subs	r2, r3, r7
 8002d6c:	3a01      	subs	r2, #1
 8002d6e:	4572      	cmp	r2, lr
 8002d70:	f04f 0c01 	mov.w	ip, #1
 8002d74:	d824      	bhi.n	8002dc0 <HAL_RCC_ClockConfig+0x168>
 8002d76:	68b2      	ldr	r2, [r6, #8]
 8002d78:	f002 020c 	and.w	r2, r2, #12
 8002d7c:	2a0c      	cmp	r2, #12
 8002d7e:	d1f3      	bne.n	8002d68 <HAL_RCC_ClockConfig+0x110>
 8002d80:	e7a9      	b.n	8002cd6 <HAL_RCC_ClockConfig+0x7e>
 8002d82:	4f12      	ldr	r7, [pc, #72]	@ (8002dcc <HAL_RCC_ClockConfig+0x174>)
 8002d84:	683b      	ldr	r3, [r7, #0]
 8002d86:	039b      	lsls	r3, r3, #14
 8002d88:	d5b6      	bpl.n	8002cf8 <HAL_RCC_ClockConfig+0xa0>
 8002d8a:	68bb      	ldr	r3, [r7, #8]
 8002d8c:	4d10      	ldr	r5, [pc, #64]	@ (8002dd0 <HAL_RCC_ClockConfig+0x178>)
 8002d8e:	f023 0303 	bic.w	r3, r3, #3
 8002d92:	f043 0301 	orr.w	r3, r3, #1
 8002d96:	60bb      	str	r3, [r7, #8]
 8002d98:	682e      	ldr	r6, [r5, #0]
 8002d9a:	1c73      	adds	r3, r6, #1
 8002d9c:	f506 569c 	add.w	r6, r6, #4992	@ 0x1380
 8002da0:	f04f 0c00 	mov.w	ip, #0
 8002da4:	602b      	str	r3, [r5, #0]
 8002da6:	360a      	adds	r6, #10
 8002da8:	e004      	b.n	8002db4 <HAL_RCC_ClockConfig+0x15c>
 8002daa:	3301      	adds	r3, #1
 8002dac:	429e      	cmp	r6, r3
 8002dae:	f04f 0c01 	mov.w	ip, #1
 8002db2:	d005      	beq.n	8002dc0 <HAL_RCC_ClockConfig+0x168>
 8002db4:	68ba      	ldr	r2, [r7, #8]
 8002db6:	f002 020c 	and.w	r2, r2, #12
 8002dba:	2a04      	cmp	r2, #4
 8002dbc:	d1f5      	bne.n	8002daa <HAL_RCC_ClockConfig+0x152>
 8002dbe:	e78a      	b.n	8002cd6 <HAL_RCC_ClockConfig+0x7e>
 8002dc0:	602b      	str	r3, [r5, #0]
 8002dc2:	2003      	movs	r0, #3
 8002dc4:	bdf0      	pop	{r4, r5, r6, r7, pc}
 8002dc6:	bf00      	nop
 8002dc8:	40023c00 	.word	0x40023c00
 8002dcc:	40023800 	.word	0x40023800
 8002dd0:	20000a38 	.word	0x20000a38

08002dd4 <HAL_GPIO_Init>:
 8002dd4:	e92d 4ff0 	stmdb	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, lr}
 8002dd8:	2300      	movs	r3, #0
 8002dda:	680c      	ldr	r4, [r1, #0]
 8002ddc:	f8df b20c 	ldr.w	fp, [pc, #524]	@ 8002fec <HAL_GPIO_Init+0x218>
 8002de0:	b085      	sub	sp, #20
 8002de2:	468a      	mov	sl, r1
 8002de4:	e003      	b.n	8002dee <HAL_GPIO_Init+0x1a>
 8002de6:	3301      	adds	r3, #1
 8002de8:	2b10      	cmp	r3, #16
 8002dea:	f000 80a2 	beq.w	8002f32 <HAL_GPIO_Init+0x15e>
 8002dee:	2201      	movs	r2, #1
 8002df0:	fa02 f103 	lsl.w	r1, r2, r3
 8002df4:	ea31 0204 	bics.w	r2, r1, r4
 8002df8:	ea01 0704 	and.w	r7, r1, r4
 8002dfc:	d1f3      	bne.n	8002de6 <HAL_GPIO_Init+0x12>
 8002dfe:	f8da 2004 	ldr.w	r2, [sl, #4]
 8002e02:	f8da 5008 	ldr.w	r5, [sl, #8]
 8002e06:	005e      	lsls	r6, r3, #1
 8002e08:	fa05 fc06 	lsl.w	ip, r5, r6
 8002e0c:	f022 0810 	bic.w	r8, r2, #16
 8002e10:	2503      	movs	r5, #3
 8002e12:	40b5      	lsls	r5, r6
 8002e14:	f002 0e03 	and.w	lr, r2, #3
 8002e18:	f1b8 0f02 	cmp.w	r8, #2
 8002e1c:	ea6f 0505 	mvn.w	r5, r5
 8002e20:	fa0e fe06 	lsl.w	lr, lr, r6
 8002e24:	f000 8088 	beq.w	8002f38 <HAL_GPIO_Init+0x164>
 8002e28:	f8d0 9000 	ldr.w	r9, [r0]
 8002e2c:	f108 38ff 	add.w	r8, r8, #4294967295	@ 0xffffffff
 8002e30:	ea09 0905 	and.w	r9, r9, r5
 8002e34:	ea49 0e0e 	orr.w	lr, r9, lr
 8002e38:	f1b8 0f01 	cmp.w	r8, #1
 8002e3c:	f8c0 e000 	str.w	lr, [r0]
 8002e40:	f240 809a 	bls.w	8002f78 <HAL_GPIO_Init+0x1a4>
 8002e44:	68c1      	ldr	r1, [r0, #12]
 8002e46:	4029      	ands	r1, r5
 8002e48:	ea41 010c 	orr.w	r1, r1, ip
 8002e4c:	60c1      	str	r1, [r0, #12]
 8002e4e:	00d1      	lsls	r1, r2, #3
 8002e50:	d5c9      	bpl.n	8002de6 <HAL_GPIO_Init+0x12>
 8002e52:	4d67      	ldr	r5, [pc, #412]	@ (8002ff0 <HAL_GPIO_Init+0x21c>)
 8002e54:	2100      	movs	r1, #0
 8002e56:	9103      	str	r1, [sp, #12]
 8002e58:	6c69      	ldr	r1, [r5, #68]	@ 0x44
 8002e5a:	f441 4180 	orr.w	r1, r1, #16384	@ 0x4000
 8002e5e:	6469      	str	r1, [r5, #68]	@ 0x44
 8002e60:	6c69      	ldr	r1, [r5, #68]	@ 0x44
 8002e62:	f401 4180 	and.w	r1, r1, #16384	@ 0x4000
 8002e66:	9103      	str	r1, [sp, #12]
 8002e68:	9903      	ldr	r1, [sp, #12]
 8002e6a:	f023 0103 	bic.w	r1, r3, #3
 8002e6e:	f101 4180 	add.w	r1, r1, #1073741824	@ 0x40000000
 8002e72:	f501 319c 	add.w	r1, r1, #79872	@ 0x13800
 8002e76:	f003 0603 	and.w	r6, r3, #3
 8002e7a:	688d      	ldr	r5, [r1, #8]
 8002e7c:	00b6      	lsls	r6, r6, #2
 8002e7e:	f04f 0c0f 	mov.w	ip, #15
 8002e82:	fa0c fc06 	lsl.w	ip, ip, r6
 8002e86:	ea25 050c 	bic.w	r5, r5, ip
 8002e8a:	f8df c168 	ldr.w	ip, [pc, #360]	@ 8002ff4 <HAL_GPIO_Init+0x220>
 8002e8e:	4560      	cmp	r0, ip
 8002e90:	d028      	beq.n	8002ee4 <HAL_GPIO_Init+0x110>
 8002e92:	f50c 6c80 	add.w	ip, ip, #1024	@ 0x400
 8002e96:	4560      	cmp	r0, ip
 8002e98:	f000 8084 	beq.w	8002fa4 <HAL_GPIO_Init+0x1d0>
 8002e9c:	f8df c158 	ldr.w	ip, [pc, #344]	@ 8002ff8 <HAL_GPIO_Init+0x224>
 8002ea0:	4560      	cmp	r0, ip
 8002ea2:	f000 8085 	beq.w	8002fb0 <HAL_GPIO_Init+0x1dc>
 8002ea6:	f8df c154 	ldr.w	ip, [pc, #340]	@ 8002ffc <HAL_GPIO_Init+0x228>
 8002eaa:	4560      	cmp	r0, ip
 8002eac:	f000 8086 	beq.w	8002fbc <HAL_GPIO_Init+0x1e8>
 8002eb0:	f8df c14c 	ldr.w	ip, [pc, #332]	@ 8003000 <HAL_GPIO_Init+0x22c>
 8002eb4:	4560      	cmp	r0, ip
 8002eb6:	f000 8087 	beq.w	8002fc8 <HAL_GPIO_Init+0x1f4>
 8002eba:	f8df c148 	ldr.w	ip, [pc, #328]	@ 8003004 <HAL_GPIO_Init+0x230>
 8002ebe:	4560      	cmp	r0, ip
 8002ec0:	f000 8088 	beq.w	8002fd4 <HAL_GPIO_Init+0x200>
 8002ec4:	f8df c140 	ldr.w	ip, [pc, #320]	@ 8003008 <HAL_GPIO_Init+0x234>
 8002ec8:	4560      	cmp	r0, ip
 8002eca:	f000 8089 	beq.w	8002fe0 <HAL_GPIO_Init+0x20c>
 8002ece:	f8df c13c 	ldr.w	ip, [pc, #316]	@ 800300c <HAL_GPIO_Init+0x238>
 8002ed2:	4560      	cmp	r0, ip
 8002ed4:	bf0c      	ite	eq
 8002ed6:	f04f 0c07 	moveq.w	ip, #7
 8002eda:	f04f 0c08 	movne.w	ip, #8
 8002ede:	fa0c f606 	lsl.w	r6, ip, r6
 8002ee2:	4335      	orrs	r5, r6
 8002ee4:	608d      	str	r5, [r1, #8]
 8002ee6:	f8db 1000 	ldr.w	r1, [fp]
 8002eea:	43fd      	mvns	r5, r7
 8002eec:	03d6      	lsls	r6, r2, #15
 8002eee:	bf54      	ite	pl
 8002ef0:	4029      	andpl	r1, r5
 8002ef2:	4339      	orrmi	r1, r7
 8002ef4:	f8cb 1000 	str.w	r1, [fp]
 8002ef8:	f8db 1004 	ldr.w	r1, [fp, #4]
 8002efc:	0396      	lsls	r6, r2, #14
 8002efe:	bf54      	ite	pl
 8002f00:	4029      	andpl	r1, r5
 8002f02:	4339      	orrmi	r1, r7
 8002f04:	f8cb 1004 	str.w	r1, [fp, #4]
 8002f08:	f8db 1008 	ldr.w	r1, [fp, #8]
 8002f0c:	02d6      	lsls	r6, r2, #11
 8002f0e:	bf54      	ite	pl
 8002f10:	4029      	andpl	r1, r5
 8002f12:	4339      	orrmi	r1, r7
 8002f14:	f8cb 1008 	str.w	r1, [fp, #8]
 8002f18:	f8db 100c 	ldr.w	r1, [fp, #12]
 8002f1c:	0292      	lsls	r2, r2, #10
 8002f1e:	f103 0301 	add.w	r3, r3, #1
 8002f22:	bf54      	ite	pl
 8002f24:	4029      	andpl	r1, r5
 8002f26:	4339      	orrmi	r1, r7
 8002f28:	2b10      	cmp	r3, #16
 8002f2a:	f8cb 100c 	str.w	r1, [fp, #12]
 8002f2e:	f47f af5e 	bne.w	8002dee <HAL_GPIO_Init+0x1a>
 8002f32:	b005      	add	sp, #20
 8002f34:	e8bd 8ff0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, r9, sl, fp, pc}
 8002f38:	ea4f 09d3 	mov.w	r9, r3, lsr #3
 8002f3c:	eb00 0989 	add.w	r9, r0, r9, lsl #2
 8002f40:	f003 0807 	and.w	r8, r3, #7
 8002f44:	f8d9 7020 	ldr.w	r7, [r9, #32]
 8002f48:	9700      	str	r7, [sp, #0]
 8002f4a:	f8da 7010 	ldr.w	r7, [sl, #16]
 8002f4e:	ea4f 0888 	mov.w	r8, r8, lsl #2
 8002f52:	fa07 f708 	lsl.w	r7, r7, r8
 8002f56:	9701      	str	r7, [sp, #4]
 8002f58:	270f      	movs	r7, #15
 8002f5a:	fa07 f808 	lsl.w	r8, r7, r8
 8002f5e:	9f00      	ldr	r7, [sp, #0]
 8002f60:	ea27 0808 	bic.w	r8, r7, r8
 8002f64:	9f01      	ldr	r7, [sp, #4]
 8002f66:	ea47 0708 	orr.w	r7, r7, r8
 8002f6a:	f8c9 7020 	str.w	r7, [r9, #32]
 8002f6e:	6807      	ldr	r7, [r0, #0]
 8002f70:	402f      	ands	r7, r5
 8002f72:	ea47 070e 	orr.w	r7, r7, lr
 8002f76:	6007      	str	r7, [r0, #0]
 8002f78:	6887      	ldr	r7, [r0, #8]
 8002f7a:	ea07 0e05 	and.w	lr, r7, r5
 8002f7e:	f8da 700c 	ldr.w	r7, [sl, #12]
 8002f82:	40b7      	lsls	r7, r6
 8002f84:	ea47 070e 	orr.w	r7, r7, lr
 8002f88:	6087      	str	r7, [r0, #8]
 8002f8a:	6846      	ldr	r6, [r0, #4]
 8002f8c:	0912      	lsrs	r2, r2, #4
 8002f8e:	409a      	lsls	r2, r3
 8002f90:	ea26 0101 	bic.w	r1, r6, r1
 8002f94:	430a      	orrs	r2, r1
 8002f96:	6042      	str	r2, [r0, #4]
 8002f98:	68c2      	ldr	r2, [r0, #12]
 8002f9a:	402a      	ands	r2, r5
 8002f9c:	ea42 020c 	orr.w	r2, r2, ip
 8002fa0:	60c2      	str	r2, [r0, #12]
 8002fa2:	e720      	b.n	8002de6 <HAL_GPIO_Init+0x12>
 8002fa4:	f04f 0c01 	mov.w	ip, #1
 8002fa8:	fa0c f606 	lsl.w	r6, ip, r6
 8002fac:	4335      	orrs	r5, r6
 8002fae:	e799      	b.n	8002ee4 <HAL_GPIO_Init+0x110>
 8002fb0:	f04f 0c02 	mov.w	ip, #2
 8002fb4:	fa0c f606 	lsl.w	r6, ip, r6
 8002fb8:	4335      	orrs	r5, r6
 8002fba:	e793      	b.n	8002ee4 <HAL_GPIO_Init+0x110>
 8002fbc:	f04f 0c03 	mov.w	ip, #3
 8002fc0:	fa0c f606 	lsl.w	r6, ip, r6
 8002fc4:	4335      	orrs	r5, r6
 8002fc6:	e78d      	b.n	8002ee4 <HAL_GPIO_Init+0x110>
 8002fc8:	f04f 0c04 	mov.w	ip, #4
 8002fcc:	fa0c f606 	lsl.w	r6, ip, r6
 8002fd0:	4335      	orrs	r5, r6
 8002fd2:	e787      	b.n	8002ee4 <HAL_GPIO_Init+0x110>
 8002fd4:	f04f 0c05 	mov.w	ip, #5
 8002fd8:	fa0c f606 	lsl.w	r6, ip, r6
 8002fdc:	4335      	orrs	r5, r6
 8002fde:	e781      	b.n	8002ee4 <HAL_GPIO_Init+0x110>
 8002fe0:	f04f 0c06 	mov.w	ip, #6
 8002fe4:	fa0c f606 	lsl.w	r6, ip, r6
 8002fe8:	4335      	orrs	r5, r6
 8002fea:	e77b      	b.n	8002ee4 <HAL_GPIO_Init+0x110>
 8002fec:	40013c00 	.word	0x40013c00
 8002ff0:	40023800 	.word	0x40023800
 8002ff4:	40020000 	.word	0x40020000
 8002ff8:	40020800 	.word	0x40020800
 8002ffc:	40020c00 	.word	0x40020c00
 8003000:	40021000 	.word	0x40021000
 8003004:	40021400 	.word	0x40021400
 8003008:	40021800 	.word	0x40021800
 800300c:	40021c00 	.word	0x40021c00

08003010 <HAL_GPIO_WritePin>:
 8003010:	b902      	cbnz	r2, 8003014 <HAL_GPIO_WritePin+0x4>
 8003012:	0409      	lsls	r1, r1, #16
 8003014:	6181      	str	r1, [r0, #24]
 8003016:	4770      	bx	lr

08003018 <HAL_UART_Init>:
 8003018:	2800      	cmp	r0, #0
 800301a:	d073      	beq.n	8003104 <HAL_UART_Init+0xec>
 800301c:	b430      	push	{r4, r5}
 800301e:	f890 2039 	ldrb.w	r2, [r0, #57]	@ 0x39
 8003022:	4603      	mov	r3, r0
 8003024:	f002 01ff 	and.w	r1, r2, #255	@ 0xff
 8003028:	2a00      	cmp	r2, #0
 800302a:	d04f      	beq.n	80030cc <HAL_UART_Init+0xb4>
 800302c:	681a      	ldr	r2, [r3, #0]
 800302e:	68dc      	ldr	r4, [r3, #12]
 8003030:	691d      	ldr	r5, [r3, #16]
 8003032:	2124      	movs	r1, #36	@ 0x24
 8003034:	f883 1039 	strb.w	r1, [r3, #57]	@ 0x39
 8003038:	68d1      	ldr	r1, [r2, #12]
 800303a:	f421 5100 	bic.w	r1, r1, #8192	@ 0x2000
 800303e:	60d1      	str	r1, [r2, #12]
 8003040:	6910      	ldr	r0, [r2, #16]
 8003042:	6899      	ldr	r1, [r3, #8]
 8003044:	f420 5040 	bic.w	r0, r0, #12288	@ 0x3000
 8003048:	4320      	orrs	r0, r4
 800304a:	6110      	str	r0, [r2, #16]
 800304c:	68d0      	ldr	r0, [r2, #12]
 800304e:	69dc      	ldr	r4, [r3, #28]
 8003050:	4329      	orrs	r1, r5
 8003052:	695d      	ldr	r5, [r3, #20]
 8003054:	f420 4016 	bic.w	r0, r0, #38400	@ 0x9600
 8003058:	4329      	orrs	r1, r5
 800305a:	f020 000c 	bic.w	r0, r0, #12
 800305e:	4321      	orrs	r1, r4
 8003060:	4301      	orrs	r1, r0
 8003062:	60d1      	str	r1, [r2, #12]
 8003064:	6951      	ldr	r1, [r2, #20]
 8003066:	6998      	ldr	r0, [r3, #24]
 8003068:	f421 7140 	bic.w	r1, r1, #768	@ 0x300
 800306c:	4301      	orrs	r1, r0
 800306e:	f5b4 4f00 	cmp.w	r4, #32768	@ 0x8000
 8003072:	6858      	ldr	r0, [r3, #4]
 8003074:	6151      	str	r1, [r2, #20]
 8003076:	d02c      	beq.n	80030d2 <HAL_UART_Init+0xba>
 8003078:	4c23      	ldr	r4, [pc, #140]	@ (8003108 <HAL_UART_Init+0xf0>)
 800307a:	4924      	ldr	r1, [pc, #144]	@ (800310c <HAL_UART_Init+0xf4>)
 800307c:	0080      	lsls	r0, r0, #2
 800307e:	fbb1 f1f0 	udiv	r1, r1, r0
 8003082:	fba4 5001 	umull	r5, r0, r4, r1
 8003086:	0940      	lsrs	r0, r0, #5
 8003088:	2564      	movs	r5, #100	@ 0x64
 800308a:	fb05 1110 	mls	r1, r5, r0, r1
 800308e:	0109      	lsls	r1, r1, #4
 8003090:	3132      	adds	r1, #50	@ 0x32
 8003092:	fba4 4101 	umull	r4, r1, r4, r1
 8003096:	0100      	lsls	r0, r0, #4
 8003098:	eb00 1051 	add.w	r0, r0, r1, lsr #5
 800309c:	6090      	str	r0, [r2, #8]
 800309e:	6911      	ldr	r1, [r2, #16]
 80030a0:	f421 4190 	bic.w	r1, r1, #18432	@ 0x4800
 80030a4:	6111      	str	r1, [r2, #16]
 80030a6:	6951      	ldr	r1, [r2, #20]
 80030a8:	f021 012a 	bic.w	r1, r1, #42	@ 0x2a
 80030ac:	6151      	str	r1, [r2, #20]
 80030ae:	68d1      	ldr	r1, [r2, #12]
 80030b0:	2400      	movs	r4, #0
 80030b2:	f04f 0c20 	mov.w	ip, #32
 80030b6:	f441 5100 	orr.w	r1, r1, #8192	@ 0x2000
 80030ba:	60d1      	str	r1, [r2, #12]
 80030bc:	63dc      	str	r4, [r3, #60]	@ 0x3c
 80030be:	f883 c039 	strb.w	ip, [r3, #57]	@ 0x39
 80030c2:	f883 c03a 	strb.w	ip, [r3, #58]	@ 0x3a
 80030c6:	4620      	mov	r0, r4
 80030c8:	bc30      	pop	{r4, r5}
 80030ca:	4770      	bx	lr
 80030cc:	f880 1038 	strb.w	r1, [r0, #56]	@ 0x38
 80030d0:	e7ac      	b.n	800302c <HAL_UART_Init+0x14>
 80030d2:	4d0d      	ldr	r5, [pc, #52]	@ (8003108 <HAL_UART_Init+0xf0>)
 80030d4:	490d      	ldr	r1, [pc, #52]	@ (800310c <HAL_UART_Init+0xf4>)
 80030d6:	0040      	lsls	r0, r0, #1
 80030d8:	fbb1 f1f0 	udiv	r1, r1, r0
 80030dc:	fba5 0401 	umull	r0, r4, r5, r1
 80030e0:	0964      	lsrs	r4, r4, #5
 80030e2:	2064      	movs	r0, #100	@ 0x64
 80030e4:	fb00 1114 	mls	r1, r0, r4, r1
 80030e8:	00c9      	lsls	r1, r1, #3
 80030ea:	3132      	adds	r1, #50	@ 0x32
 80030ec:	fba5 5101 	umull	r5, r1, r5, r1
 80030f0:	f3c1 1042 	ubfx	r0, r1, #5, #3
 80030f4:	0909      	lsrs	r1, r1, #4
 80030f6:	eb00 1004 	add.w	r0, r0, r4, lsl #4
 80030fa:	f401 71f8 	and.w	r1, r1, #496	@ 0x1f0
 80030fe:	4401      	add	r1, r0
 8003100:	6091      	str	r1, [r2, #8]
 8003102:	e7cc      	b.n	800309e <HAL_UART_Init+0x86>
 8003104:	2001      	movs	r0, #1
 8003106:	4770      	bx	lr
 8003108:	51eb851f 	.word	0x51eb851f
 800310c:	0afb6e90 	.word	0x0afb6e90

08003110 <HAL_UART_Transmit>:
 8003110:	f890 3039 	ldrb.w	r3, [r0, #57]	@ 0x39
 8003114:	2b20      	cmp	r3, #32
 8003116:	d141      	bne.n	800319c <HAL_UART_Transmit+0x8c>
 8003118:	2900      	cmp	r1, #0
 800311a:	d03d      	beq.n	8003198 <HAL_UART_Transmit+0x88>
 800311c:	2a00      	cmp	r2, #0
 800311e:	d03b      	beq.n	8003198 <HAL_UART_Transmit+0x88>
 8003120:	f890 3038 	ldrb.w	r3, [r0, #56]	@ 0x38
 8003124:	2b01      	cmp	r3, #1
 8003126:	d039      	beq.n	800319c <HAL_UART_Transmit+0x8c>
 8003128:	b410      	push	{r4}
 800312a:	2321      	movs	r3, #33	@ 0x21
 800312c:	2400      	movs	r4, #0
 800312e:	63c4      	str	r4, [r0, #60]	@ 0x3c
 8003130:	f880 3039 	strb.w	r3, [r0, #57]	@ 0x39
 8003134:	84c2      	strh	r2, [r0, #38]	@ 0x26
 8003136:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 8003138:	6804      	ldr	r4, [r0, #0]
 800313a:	8482      	strh	r2, [r0, #36]	@ 0x24
 800313c:	f04f 0c01 	mov.w	ip, #1
 8003140:	b29b      	uxth	r3, r3
 8003142:	f880 c038 	strb.w	ip, [r0, #56]	@ 0x38
 8003146:	b1db      	cbz	r3, 8003180 <HAL_UART_Transmit+0x70>
 8003148:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 800314a:	6882      	ldr	r2, [r0, #8]
 800314c:	3b01      	subs	r3, #1
 800314e:	b29b      	uxth	r3, r3
 8003150:	f5b2 5f80 	cmp.w	r2, #4096	@ 0x1000
 8003154:	84c3      	strh	r3, [r0, #38]	@ 0x26
 8003156:	d023      	beq.n	80031a0 <HAL_UART_Transmit+0x90>
 8003158:	6823      	ldr	r3, [r4, #0]
 800315a:	061a      	lsls	r2, r3, #24
 800315c:	d5fc      	bpl.n	8003158 <HAL_UART_Transmit+0x48>
 800315e:	f811 3b01 	ldrb.w	r3, [r1], #1
 8003162:	6063      	str	r3, [r4, #4]
 8003164:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 8003166:	b29b      	uxth	r3, r3
 8003168:	b153      	cbz	r3, 8003180 <HAL_UART_Transmit+0x70>
 800316a:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 800316c:	3b01      	subs	r3, #1
 800316e:	b29b      	uxth	r3, r3
 8003170:	84c3      	strh	r3, [r0, #38]	@ 0x26
 8003172:	6823      	ldr	r3, [r4, #0]
 8003174:	061a      	lsls	r2, r3, #24
 8003176:	d5ef      	bpl.n	8003158 <HAL_UART_Transmit+0x48>
 8003178:	e7f1      	b.n	800315e <HAL_UART_Transmit+0x4e>
 800317a:	b29b      	uxth	r3, r3
 800317c:	3101      	adds	r1, #1
 800317e:	b9f3      	cbnz	r3, 80031be <HAL_UART_Transmit+0xae>
 8003180:	6823      	ldr	r3, [r4, #0]
 8003182:	065b      	lsls	r3, r3, #25
 8003184:	d5fc      	bpl.n	8003180 <HAL_UART_Transmit+0x70>
 8003186:	2300      	movs	r3, #0
 8003188:	2220      	movs	r2, #32
 800318a:	f880 2039 	strb.w	r2, [r0, #57]	@ 0x39
 800318e:	f880 3038 	strb.w	r3, [r0, #56]	@ 0x38
 8003192:	bc10      	pop	{r4}
 8003194:	4618      	mov	r0, r3
 8003196:	4770      	bx	lr
 8003198:	2001      	movs	r0, #1
 800319a:	4770      	bx	lr
 800319c:	2002      	movs	r0, #2
 800319e:	4770      	bx	lr
 80031a0:	6902      	ldr	r2, [r0, #16]
 80031a2:	6823      	ldr	r3, [r4, #0]
 80031a4:	061b      	lsls	r3, r3, #24
 80031a6:	d5fc      	bpl.n	80031a2 <HAL_UART_Transmit+0x92>
 80031a8:	880b      	ldrh	r3, [r1, #0]
 80031aa:	f3c3 0308 	ubfx	r3, r3, #0, #9
 80031ae:	6063      	str	r3, [r4, #4]
 80031b0:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 80031b2:	2a00      	cmp	r2, #0
 80031b4:	d1e1      	bne.n	800317a <HAL_UART_Transmit+0x6a>
 80031b6:	b29b      	uxth	r3, r3
 80031b8:	3102      	adds	r1, #2
 80031ba:	2b00      	cmp	r3, #0
 80031bc:	d0e0      	beq.n	8003180 <HAL_UART_Transmit+0x70>
 80031be:	8cc3      	ldrh	r3, [r0, #38]	@ 0x26
 80031c0:	3b01      	subs	r3, #1
 80031c2:	b29b      	uxth	r3, r3
 80031c4:	84c3      	strh	r3, [r0, #38]	@ 0x26
 80031c6:	e7ec      	b.n	80031a2 <HAL_UART_Transmit+0x92>

080031c8 <HAL_UART_Receive>:
 80031c8:	f890 303a 	ldrb.w	r3, [r0, #58]	@ 0x3a
 80031cc:	2b20      	cmp	r3, #32
 80031ce:	d146      	bne.n	800325e <HAL_UART_Receive+0x96>
 80031d0:	2900      	cmp	r1, #0
 80031d2:	d03e      	beq.n	8003252 <HAL_UART_Receive+0x8a>
 80031d4:	2a00      	cmp	r2, #0
 80031d6:	d03c      	beq.n	8003252 <HAL_UART_Receive+0x8a>
 80031d8:	f890 3038 	ldrb.w	r3, [r0, #56]	@ 0x38
 80031dc:	2b01      	cmp	r3, #1
 80031de:	d03e      	beq.n	800325e <HAL_UART_Receive+0x96>
 80031e0:	b410      	push	{r4}
 80031e2:	2322      	movs	r3, #34	@ 0x22
 80031e4:	2400      	movs	r4, #0
 80031e6:	63c4      	str	r4, [r0, #60]	@ 0x3c
 80031e8:	f880 303a 	strb.w	r3, [r0, #58]	@ 0x3a
 80031ec:	85c2      	strh	r2, [r0, #46]	@ 0x2e
 80031ee:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 80031f0:	8582      	strh	r2, [r0, #44]	@ 0x2c
 80031f2:	f04f 0c01 	mov.w	ip, #1
 80031f6:	b29b      	uxth	r3, r3
 80031f8:	f880 c038 	strb.w	ip, [r0, #56]	@ 0x38
 80031fc:	b1ab      	cbz	r3, 800322a <HAL_UART_Receive+0x62>
 80031fe:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 8003200:	6802      	ldr	r2, [r0, #0]
 8003202:	3b01      	subs	r3, #1
 8003204:	b29b      	uxth	r3, r3
 8003206:	85c3      	strh	r3, [r0, #46]	@ 0x2e
 8003208:	6883      	ldr	r3, [r0, #8]
 800320a:	f5b3 5f80 	cmp.w	r3, #4096	@ 0x1000
 800320e:	d015      	beq.n	800323c <HAL_UART_Receive+0x74>
 8003210:	6813      	ldr	r3, [r2, #0]
 8003212:	069b      	lsls	r3, r3, #26
 8003214:	d5fc      	bpl.n	8003210 <HAL_UART_Receive+0x48>
 8003216:	6903      	ldr	r3, [r0, #16]
 8003218:	b9eb      	cbnz	r3, 8003256 <HAL_UART_Receive+0x8e>
 800321a:	6853      	ldr	r3, [r2, #4]
 800321c:	b2db      	uxtb	r3, r3
 800321e:	f801 3b01 	strb.w	r3, [r1], #1
 8003222:	8dc3      	ldrh	r3, [r0, #46]	@ 0x2e
 8003224:	b29b      	uxth	r3, r3
 8003226:	2b00      	cmp	r3, #0
 8003228:	d1e9      	bne.n	80031fe <HAL_UART_Receive+0x36>
 800322a:	2300      	movs	r3, #0
 800322c:	2220      	movs	r2, #32
 800322e:	f880 203a 	strb.w	r2, [r0, #58]	@ 0x3a
 8003232:	f880 3038 	strb.w	r3, [r0, #56]	@ 0x38
 8003236:	bc10      	pop	{r4}
 8003238:	4618      	mov	r0, r3
 800323a:	4770      	bx	lr
 800323c:	6813      	ldr	r3, [r2, #0]
 800323e:	069c      	lsls	r4, r3, #26
 8003240:	d5fc      	bpl.n	800323c <HAL_UART_Receive+0x74>
 8003242:	6903      	ldr	r3, [r0, #16]
 8003244:	b96b      	cbnz	r3, 8003262 <HAL_UART_Receive+0x9a>
 8003246:	6853      	ldr	r3, [r2, #4]
 8003248:	f3c3 0308 	ubfx	r3, r3, #0, #9
 800324c:	f821 3b02 	strh.w	r3, [r1], #2
 8003250:	e7e7      	b.n	8003222 <HAL_UART_Receive+0x5a>
 8003252:	2001      	movs	r0, #1
 8003254:	4770      	bx	lr
 8003256:	6853      	ldr	r3, [r2, #4]
 8003258:	f003 037f 	and.w	r3, r3, #127	@ 0x7f
 800325c:	e7df      	b.n	800321e <HAL_UART_Receive+0x56>
 800325e:	2002      	movs	r0, #2
 8003260:	4770      	bx	lr
 8003262:	6853      	ldr	r3, [r2, #4]
 8003264:	b2db      	uxtb	r3, r3
 8003266:	f821 3b01 	strh.w	r3, [r1], #1
 800326a:	e7da      	b.n	8003222 <HAL_UART_Receive+0x5a>

0800326c <_sbrk>:
 800326c:	4a0b      	ldr	r2, [pc, #44]	@ (800329c <_sbrk+0x30>)
 800326e:	b508      	push	{r3, lr}
 8003270:	4603      	mov	r3, r0
 8003272:	6810      	ldr	r0, [r2, #0]
 8003274:	b128      	cbz	r0, 8003282 <_sbrk+0x16>
 8003276:	4403      	add	r3, r0
 8003278:	4669      	mov	r1, sp
 800327a:	428b      	cmp	r3, r1
 800327c:	d807      	bhi.n	800328e <_sbrk+0x22>
 800327e:	6013      	str	r3, [r2, #0]
 8003280:	bd08      	pop	{r3, pc}
 8003282:	4807      	ldr	r0, [pc, #28]	@ (80032a0 <_sbrk+0x34>)
 8003284:	6010      	str	r0, [r2, #0]
 8003286:	4403      	add	r3, r0
 8003288:	4669      	mov	r1, sp
 800328a:	428b      	cmp	r3, r1
 800328c:	d9f7      	bls.n	800327e <_sbrk+0x12>
 800328e:	f7fd f881 	bl	8000394 <__errno>
 8003292:	230c      	movs	r3, #12
 8003294:	6003      	str	r3, [r0, #0]
 8003296:	f04f 30ff 	mov.w	r0, #4294967295	@ 0xffffffff
 800329a:	bd08      	pop	{r3, pc}
 800329c:	20000a3c 	.word	0x20000a3c
 80032a0:	20000f50 	.word	0x20000f50

080032a4 <HAL_RNG_MspInit>:
 80032a4:	4770      	bx	lr
 80032a6:	bf00      	nop

080032a8 <HAL_RNG_Init>:
 80032a8:	b1c0      	cbz	r0, 80032dc <HAL_RNG_Init+0x34>
 80032aa:	b510      	push	{r4, lr}
 80032ac:	7903      	ldrb	r3, [r0, #4]
 80032ae:	2b01      	cmp	r3, #1
 80032b0:	4604      	mov	r4, r0
 80032b2:	d015      	beq.n	80032e0 <HAL_RNG_Init+0x38>
 80032b4:	7943      	ldrb	r3, [r0, #5]
 80032b6:	f003 02ff 	and.w	r2, r3, #255	@ 0xff
 80032ba:	b15b      	cbz	r3, 80032d4 <HAL_RNG_Init+0x2c>
 80032bc:	6822      	ldr	r2, [r4, #0]
 80032be:	2302      	movs	r3, #2
 80032c0:	7163      	strb	r3, [r4, #5]
 80032c2:	6813      	ldr	r3, [r2, #0]
 80032c4:	2000      	movs	r0, #0
 80032c6:	f043 0304 	orr.w	r3, r3, #4
 80032ca:	2101      	movs	r1, #1
 80032cc:	6013      	str	r3, [r2, #0]
 80032ce:	7161      	strb	r1, [r4, #5]
 80032d0:	7120      	strb	r0, [r4, #4]
 80032d2:	bd10      	pop	{r4, pc}
 80032d4:	7102      	strb	r2, [r0, #4]
 80032d6:	f7ff ffe5 	bl	80032a4 <HAL_RNG_MspInit>
 80032da:	e7ef      	b.n	80032bc <HAL_RNG_Init+0x14>
 80032dc:	2001      	movs	r0, #1
 80032de:	4770      	bx	lr
 80032e0:	2002      	movs	r0, #2
 80032e2:	bd10      	pop	{r4, pc}

080032e4 <check_version>:
 80032e4:	2001      	movs	r0, #1
 80032e6:	4770      	bx	lr

080032e8 <simpleserial_put.part.0>:
 80032e8:	b570      	push	{r4, r5, r6, lr}
 80032ea:	460e      	mov	r6, r1
 80032ec:	4614      	mov	r4, r2
 80032ee:	f7ff fa95 	bl	800281c <putch>
 80032f2:	b17e      	cbz	r6, 8003314 <simpleserial_put.part.0+0x2c>
 80032f4:	4d0a      	ldr	r5, [pc, #40]	@ (8003320 <simpleserial_put.part.0+0x38>)
 80032f6:	4426      	add	r6, r4
 80032f8:	7823      	ldrb	r3, [r4, #0]
 80032fa:	091b      	lsrs	r3, r3, #4
 80032fc:	5ce8      	ldrb	r0, [r5, r3]
 80032fe:	f7ff fa8d 	bl	800281c <putch>
 8003302:	f814 3b01 	ldrb.w	r3, [r4], #1
 8003306:	f003 030f 	and.w	r3, r3, #15
 800330a:	5ce8      	ldrb	r0, [r5, r3]
 800330c:	f7ff fa86 	bl	800281c <putch>
 8003310:	42a6      	cmp	r6, r4
 8003312:	d1f1      	bne.n	80032f8 <simpleserial_put.part.0+0x10>
 8003314:	e8bd 4070 	ldmia.w	sp!, {r4, r5, r6, lr}
 8003318:	200a      	movs	r0, #10
 800331a:	f7ff ba7f 	b.w	800281c <putch>
 800331e:	bf00      	nop
 8003320:	08003720 	.word	0x08003720

08003324 <ss_get_commands>:
 8003324:	b530      	push	{r4, r5, lr}
 8003326:	4c12      	ldr	r4, [pc, #72]	@ (8003370 <ss_get_commands+0x4c>)
 8003328:	6825      	ldr	r5, [r4, #0]
 800332a:	f015 0eff 	ands.w	lr, r5, #255	@ 0xff
 800332e:	b099      	sub	sp, #100	@ 0x64
 8003330:	d013      	beq.n	800335a <ss_get_commands+0x36>
 8003332:	2200      	movs	r2, #0
 8003334:	4613      	mov	r3, r2
 8003336:	eb04 1003 	add.w	r0, r4, r3, lsl #4
 800333a:	3201      	adds	r2, #1
 800333c:	eb03 0343 	add.w	r3, r3, r3, lsl #1
 8003340:	446b      	add	r3, sp
 8003342:	b2d2      	uxtb	r2, r2
 8003344:	f890 c004 	ldrb.w	ip, [r0, #4]
 8003348:	6881      	ldr	r1, [r0, #8]
 800334a:	7c00      	ldrb	r0, [r0, #16]
 800334c:	f883 c000 	strb.w	ip, [r3]
 8003350:	4572      	cmp	r2, lr
 8003352:	7059      	strb	r1, [r3, #1]
 8003354:	7098      	strb	r0, [r3, #2]
 8003356:	4613      	mov	r3, r2
 8003358:	dbed      	blt.n	8003336 <ss_get_commands+0x12>
 800335a:	eb05 0545 	add.w	r5, r5, r5, lsl #1
 800335e:	466a      	mov	r2, sp
 8003360:	b2e9      	uxtb	r1, r5
 8003362:	2072      	movs	r0, #114	@ 0x72
 8003364:	f7ff ffc0 	bl	80032e8 <simpleserial_put.part.0>
 8003368:	2000      	movs	r0, #0
 800336a:	b019      	add	sp, #100	@ 0x64
 800336c:	bd30      	pop	{r4, r5, pc}
 800336e:	bf00      	nop
 8003370:	20000a40 	.word	0x20000a40

08003374 <ss_num_commands>:
 8003374:	b538      	push	{r3, r4, r5, lr}
 8003376:	4b0a      	ldr	r3, [pc, #40]	@ (80033a0 <ss_num_commands+0x2c>)
 8003378:	4d0a      	ldr	r5, [pc, #40]	@ (80033a4 <ss_num_commands+0x30>)
 800337a:	781c      	ldrb	r4, [r3, #0]
 800337c:	2072      	movs	r0, #114	@ 0x72
 800337e:	f7ff fa4d 	bl	800281c <putch>
 8003382:	0923      	lsrs	r3, r4, #4
 8003384:	f004 040f 	and.w	r4, r4, #15
 8003388:	5ce8      	ldrb	r0, [r5, r3]
 800338a:	f7ff fa47 	bl	800281c <putch>
 800338e:	5d28      	ldrb	r0, [r5, r4]
 8003390:	f7ff fa44 	bl	800281c <putch>
 8003394:	200a      	movs	r0, #10
 8003396:	f7ff fa41 	bl	800281c <putch>
 800339a:	2000      	movs	r0, #0
 800339c:	bd38      	pop	{r3, r4, r5, pc}
 800339e:	bf00      	nop
 80033a0:	20000a40 	.word	0x20000a40
 80033a4:	08003720 	.word	0x08003720

080033a8 <hex_decode>:
 80033a8:	2800      	cmp	r0, #0
 80033aa:	dd4c      	ble.n	8003446 <hex_decode+0x9e>
 80033ac:	b500      	push	{lr}
 80033ae:	eb01 0e40 	add.w	lr, r1, r0, lsl #1
 80033b2:	e00e      	b.n	80033d2 <hex_decode+0x2a>
 80033b4:	7013      	strb	r3, [r2, #0]
 80033b6:	f1ac 0330 	sub.w	r3, ip, #48	@ 0x30
 80033ba:	b2db      	uxtb	r3, r3
 80033bc:	2b09      	cmp	r3, #9
 80033be:	d81b      	bhi.n	80033f8 <hex_decode+0x50>
 80033c0:	7810      	ldrb	r0, [r2, #0]
 80033c2:	ea40 1303 	orr.w	r3, r0, r3, lsl #4
 80033c6:	7013      	strb	r3, [r2, #0]
 80033c8:	3102      	adds	r1, #2
 80033ca:	4571      	cmp	r1, lr
 80033cc:	f102 0201 	add.w	r2, r2, #1
 80033d0:	d021      	beq.n	8003416 <hex_decode+0x6e>
 80033d2:	7848      	ldrb	r0, [r1, #1]
 80033d4:	f891 c000 	ldrb.w	ip, [r1]
 80033d8:	f1a0 0330 	sub.w	r3, r0, #48	@ 0x30
 80033dc:	b2db      	uxtb	r3, r3
 80033de:	2b09      	cmp	r3, #9
 80033e0:	d9e8      	bls.n	80033b4 <hex_decode+0xc>
 80033e2:	f1a0 0341 	sub.w	r3, r0, #65	@ 0x41
 80033e6:	2b05      	cmp	r3, #5
 80033e8:	d818      	bhi.n	800341c <hex_decode+0x74>
 80033ea:	f1ac 0330 	sub.w	r3, ip, #48	@ 0x30
 80033ee:	b2db      	uxtb	r3, r3
 80033f0:	3837      	subs	r0, #55	@ 0x37
 80033f2:	2b09      	cmp	r3, #9
 80033f4:	7010      	strb	r0, [r2, #0]
 80033f6:	d9e3      	bls.n	80033c0 <hex_decode+0x18>
 80033f8:	f1ac 0341 	sub.w	r3, ip, #65	@ 0x41
 80033fc:	2b05      	cmp	r3, #5
 80033fe:	d814      	bhi.n	800342a <hex_decode+0x82>
 8003400:	7813      	ldrb	r3, [r2, #0]
 8003402:	f1ac 0c37 	sub.w	ip, ip, #55	@ 0x37
 8003406:	3102      	adds	r1, #2
 8003408:	ea43 130c 	orr.w	r3, r3, ip, lsl #4
 800340c:	4571      	cmp	r1, lr
 800340e:	7013      	strb	r3, [r2, #0]
 8003410:	f102 0201 	add.w	r2, r2, #1
 8003414:	d1dd      	bne.n	80033d2 <hex_decode+0x2a>
 8003416:	2000      	movs	r0, #0
 8003418:	f85d fb04 	ldr.w	pc, [sp], #4
 800341c:	f1a0 0361 	sub.w	r3, r0, #97	@ 0x61
 8003420:	2b05      	cmp	r3, #5
 8003422:	d80d      	bhi.n	8003440 <hex_decode+0x98>
 8003424:	3857      	subs	r0, #87	@ 0x57
 8003426:	7010      	strb	r0, [r2, #0]
 8003428:	e7c5      	b.n	80033b6 <hex_decode+0xe>
 800342a:	f1ac 0361 	sub.w	r3, ip, #97	@ 0x61
 800342e:	2b05      	cmp	r3, #5
 8003430:	d806      	bhi.n	8003440 <hex_decode+0x98>
 8003432:	7813      	ldrb	r3, [r2, #0]
 8003434:	f1ac 0c57 	sub.w	ip, ip, #87	@ 0x57
 8003438:	ea43 130c 	orr.w	r3, r3, ip, lsl #4
 800343c:	7013      	strb	r3, [r2, #0]
 800343e:	e7c3      	b.n	80033c8 <hex_decode+0x20>
 8003440:	2001      	movs	r0, #1
 8003442:	f85d fb04 	ldr.w	pc, [sp], #4
 8003446:	2000      	movs	r0, #0
 8003448:	4770      	bx	lr
 800344a:	bf00      	nop

0800344c <simpleserial_init>:
 800344c:	4b16      	ldr	r3, [pc, #88]	@ (80034a8 <simpleserial_init+0x5c>)
 800344e:	681a      	ldr	r2, [r3, #0]
 8003450:	2a1f      	cmp	r2, #31
 8003452:	dc27      	bgt.n	80034a4 <simpleserial_init+0x58>
 8003454:	4815      	ldr	r0, [pc, #84]	@ (80034ac <simpleserial_init+0x60>)
 8003456:	b410      	push	{r4}
 8003458:	eb03 1102 	add.w	r1, r3, r2, lsl #4
 800345c:	2400      	movs	r4, #0
 800345e:	e9c1 4002 	strd	r4, r0, [r1, #8]
 8003462:	1c50      	adds	r0, r2, #1
 8003464:	f04f 0c76 	mov.w	ip, #118	@ 0x76
 8003468:	2820      	cmp	r0, #32
 800346a:	f881 c004 	strb.w	ip, [r1, #4]
 800346e:	740c      	strb	r4, [r1, #16]
 8003470:	6018      	str	r0, [r3, #0]
 8003472:	d015      	beq.n	80034a0 <simpleserial_init+0x54>
 8003474:	eb03 1000 	add.w	r0, r3, r0, lsl #4
 8003478:	2177      	movs	r1, #119	@ 0x77
 800347a:	7101      	strb	r1, [r0, #4]
 800347c:	490c      	ldr	r1, [pc, #48]	@ (80034b0 <simpleserial_init+0x64>)
 800347e:	7404      	strb	r4, [r0, #16]
 8003480:	e9c0 4102 	strd	r4, r1, [r0, #8]
 8003484:	1c91      	adds	r1, r2, #2
 8003486:	2920      	cmp	r1, #32
 8003488:	6019      	str	r1, [r3, #0]
 800348a:	d009      	beq.n	80034a0 <simpleserial_init+0x54>
 800348c:	eb03 1101 	add.w	r1, r3, r1, lsl #4
 8003490:	2079      	movs	r0, #121	@ 0x79
 8003492:	7108      	strb	r0, [r1, #4]
 8003494:	4807      	ldr	r0, [pc, #28]	@ (80034b4 <simpleserial_init+0x68>)
 8003496:	740c      	strb	r4, [r1, #16]
 8003498:	e9c1 4002 	strd	r4, r0, [r1, #8]
 800349c:	3203      	adds	r2, #3
 800349e:	601a      	str	r2, [r3, #0]
 80034a0:	bc10      	pop	{r4}
 80034a2:	4770      	bx	lr
 80034a4:	4770      	bx	lr
 80034a6:	bf00      	nop
 80034a8:	20000a40 	.word	0x20000a40
 80034ac:	080032e5 	.word	0x080032e5
 80034b0:	08003325 	.word	0x08003325
 80034b4:	08003375 	.word	0x08003375

080034b8 <simpleserial_addcmd>:
 80034b8:	b410      	push	{r4}
 80034ba:	4c0c      	ldr	r4, [pc, #48]	@ (80034ec <simpleserial_addcmd+0x34>)
 80034bc:	6823      	ldr	r3, [r4, #0]
 80034be:	2b1f      	cmp	r3, #31
 80034c0:	dc10      	bgt.n	80034e4 <simpleserial_addcmd+0x2c>
 80034c2:	293f      	cmp	r1, #63	@ 0x3f
 80034c4:	d80e      	bhi.n	80034e4 <simpleserial_addcmd+0x2c>
 80034c6:	eb04 1c03 	add.w	ip, r4, r3, lsl #4
 80034ca:	3301      	adds	r3, #1
 80034cc:	f88c 0004 	strb.w	r0, [ip, #4]
 80034d0:	2000      	movs	r0, #0
 80034d2:	f88c 0010 	strb.w	r0, [ip, #16]
 80034d6:	6023      	str	r3, [r4, #0]
 80034d8:	f8cc 1008 	str.w	r1, [ip, #8]
 80034dc:	bc10      	pop	{r4}
 80034de:	f8cc 200c 	str.w	r2, [ip, #12]
 80034e2:	4770      	bx	lr
 80034e4:	2001      	movs	r0, #1
 80034e6:	bc10      	pop	{r4}
 80034e8:	4770      	bx	lr
 80034ea:	bf00      	nop
 80034ec:	20000a40 	.word	0x20000a40

080034f0 <simpleserial_get>:
 80034f0:	e92d 41f0 	stmdb	sp!, {r4, r5, r6, r7, r8, lr}
 80034f4:	4e37      	ldr	r6, [pc, #220]	@ (80035d4 <simpleserial_get+0xe4>)
 80034f6:	b0b0      	sub	sp, #192	@ 0xc0
 80034f8:	f7ff f97c 	bl	80027f4 <getch>
 80034fc:	6831      	ldr	r1, [r6, #0]
 80034fe:	2900      	cmp	r1, #0
 8003500:	f04f 0300 	mov.w	r3, #0
 8003504:	dd08      	ble.n	8003518 <simpleserial_get+0x28>
 8003506:	1d34      	adds	r4, r6, #4
 8003508:	e002      	b.n	8003510 <simpleserial_get+0x20>
 800350a:	3301      	adds	r3, #1
 800350c:	428b      	cmp	r3, r1
 800350e:	d022      	beq.n	8003556 <simpleserial_get+0x66>
 8003510:	011a      	lsls	r2, r3, #4
 8003512:	5ca2      	ldrb	r2, [r4, r2]
 8003514:	4282      	cmp	r2, r0
 8003516:	d1f8      	bne.n	800350a <simpleserial_get+0x1a>
 8003518:	428b      	cmp	r3, r1
 800351a:	d01c      	beq.n	8003556 <simpleserial_get+0x66>
 800351c:	eb06 1503 	add.w	r5, r6, r3, lsl #4
 8003520:	011c      	lsls	r4, r3, #4
 8003522:	7c2b      	ldrb	r3, [r5, #16]
 8003524:	07db      	lsls	r3, r3, #31
 8003526:	d419      	bmi.n	800355c <simpleserial_get+0x6c>
 8003528:	68ab      	ldr	r3, [r5, #8]
 800352a:	005b      	lsls	r3, r3, #1
 800352c:	d02c      	beq.n	8003588 <simpleserial_get+0x98>
 800352e:	af10      	add	r7, sp, #64	@ 0x40
 8003530:	2500      	movs	r5, #0
 8003532:	eb06 0804 	add.w	r8, r6, r4
 8003536:	e008      	b.n	800354a <simpleserial_get+0x5a>
 8003538:	280d      	cmp	r0, #13
 800353a:	d00c      	beq.n	8003556 <simpleserial_get+0x66>
 800353c:	f8d8 3008 	ldr.w	r3, [r8, #8]
 8003540:	f807 0b01 	strb.w	r0, [r7], #1
 8003544:	ebb5 0f43 	cmp.w	r5, r3, lsl #1
 8003548:	d21e      	bcs.n	8003588 <simpleserial_get+0x98>
 800354a:	f7ff f953 	bl	80027f4 <getch>
 800354e:	280a      	cmp	r0, #10
 8003550:	f105 0501 	add.w	r5, r5, #1
 8003554:	d1f0      	bne.n	8003538 <simpleserial_get+0x48>
 8003556:	b030      	add	sp, #192	@ 0xc0
 8003558:	e8bd 81f0 	ldmia.w	sp!, {r4, r5, r6, r7, r8, pc}
 800355c:	2300      	movs	r3, #0
 800355e:	f88d 3000 	strb.w	r3, [sp]
 8003562:	f7ff f947 	bl	80027f4 <getch>
 8003566:	f88d 0040 	strb.w	r0, [sp, #64]	@ 0x40
 800356a:	f7ff f943 	bl	80027f4 <getch>
 800356e:	466a      	mov	r2, sp
 8003570:	f88d 0041 	strb.w	r0, [sp, #65]	@ 0x41
 8003574:	a910      	add	r1, sp, #64	@ 0x40
 8003576:	2001      	movs	r0, #1
 8003578:	f7ff ff16 	bl	80033a8 <hex_decode>
 800357c:	2800      	cmp	r0, #0
 800357e:	d1ea      	bne.n	8003556 <simpleserial_get+0x66>
 8003580:	f89d 3000 	ldrb.w	r3, [sp]
 8003584:	60ab      	str	r3, [r5, #8]
 8003586:	e7d0      	b.n	800352a <simpleserial_get+0x3a>
 8003588:	f7ff f934 	bl	80027f4 <getch>
 800358c:	280a      	cmp	r0, #10
 800358e:	d001      	beq.n	8003594 <simpleserial_get+0xa4>
 8003590:	280d      	cmp	r0, #13
 8003592:	d1e0      	bne.n	8003556 <simpleserial_get+0x66>
 8003594:	4426      	add	r6, r4
 8003596:	466a      	mov	r2, sp
 8003598:	68b4      	ldr	r4, [r6, #8]
 800359a:	a910      	add	r1, sp, #64	@ 0x40
 800359c:	4620      	mov	r0, r4
 800359e:	f7ff ff03 	bl	80033a8 <hex_decode>
 80035a2:	2800      	cmp	r0, #0
 80035a4:	d1d7      	bne.n	8003556 <simpleserial_get+0x66>
 80035a6:	b2e1      	uxtb	r1, r4
 80035a8:	68f3      	ldr	r3, [r6, #12]
 80035aa:	4d0b      	ldr	r5, [pc, #44]	@ (80035d8 <simpleserial_get+0xe8>)
 80035ac:	4668      	mov	r0, sp
 80035ae:	4798      	blx	r3
 80035b0:	4604      	mov	r4, r0
 80035b2:	207a      	movs	r0, #122	@ 0x7a
 80035b4:	f7ff f932 	bl	800281c <putch>
 80035b8:	f3c4 1307 	ubfx	r3, r4, #4, #8
 80035bc:	f004 040f 	and.w	r4, r4, #15
 80035c0:	5ce8      	ldrb	r0, [r5, r3]
 80035c2:	f7ff f92b 	bl	800281c <putch>
 80035c6:	5d28      	ldrb	r0, [r5, r4]
 80035c8:	f7ff f928 	bl	800281c <putch>
 80035cc:	200a      	movs	r0, #10
 80035ce:	f7ff f925 	bl	800281c <putch>
 80035d2:	e7c0      	b.n	8003556 <simpleserial_get+0x66>
 80035d4:	20000a40 	.word	0x20000a40
 80035d8:	08003720 	.word	0x08003720

080035dc <simpleserial_put>:
 80035dc:	b10a      	cbz	r2, 80035e2 <simpleserial_put+0x6>
 80035de:	f7ff be83 	b.w	80032e8 <simpleserial_put.part.0>
 80035e2:	4770      	bx	lr

080035e4 <Reset_Handler>:
 80035e4:	2100      	movs	r1, #0
 80035e6:	e003      	b.n	80035f0 <LoopCopyDataInit>

080035e8 <CopyDataInit>:
 80035e8:	4b0b      	ldr	r3, [pc, #44]	@ (8003618 <LoopForever+0x2>)
 80035ea:	585b      	ldr	r3, [r3, r1]
 80035ec:	5043      	str	r3, [r0, r1]
 80035ee:	3104      	adds	r1, #4

080035f0 <LoopCopyDataInit>:
 80035f0:	480a      	ldr	r0, [pc, #40]	@ (800361c <LoopForever+0x6>)
 80035f2:	4b0b      	ldr	r3, [pc, #44]	@ (8003620 <LoopForever+0xa>)
 80035f4:	1842      	adds	r2, r0, r1
 80035f6:	429a      	cmp	r2, r3
 80035f8:	d3f6      	bcc.n	80035e8 <CopyDataInit>
 80035fa:	4a0a      	ldr	r2, [pc, #40]	@ (8003624 <LoopForever+0xe>)
 80035fc:	e002      	b.n	8003604 <LoopFillZerobss>

080035fe <FillZerobss>:
 80035fe:	2300      	movs	r3, #0
 8003600:	6013      	str	r3, [r2, #0]
 8003602:	3204      	adds	r2, #4

08003604 <LoopFillZerobss>:
 8003604:	4b08      	ldr	r3, [pc, #32]	@ (8003628 <LoopForever+0x12>)
 8003606:	429a      	cmp	r2, r3
 8003608:	d3f9      	bcc.n	80035fe <FillZerobss>
 800360a:	f3af 8000 	nop.w
 800360e:	f7fc fe99 	bl	8000344 <__libc_init_array>
 8003612:	f7fd fc6f 	bl	8000ef4 <main>

08003616 <LoopForever>:
 8003616:	e7fe      	b.n	8003616 <LoopForever>
 8003618:	0800375c 	.word	0x0800375c
 800361c:	20000000 	.word	0x20000000
 8003620:	20000538 	.word	0x20000538
 8003624:	20000538 	.word	0x20000538
 8003628:	20000f4c 	.word	0x20000f4c

0800362c <BusFault_Handler>:
 800362c:	e7fe      	b.n	800362c <BusFault_Handler>
	...

08003630 <register_fini>:
 8003630:	4b02      	ldr	r3, [pc, #8]	@ (800363c <register_fini+0xc>)
 8003632:	b113      	cbz	r3, 800363a <register_fini+0xa>
 8003634:	4802      	ldr	r0, [pc, #8]	@ (8003640 <register_fini+0x10>)
 8003636:	f7fc bf33 	b.w	80004a0 <atexit>
 800363a:	4770      	bx	lr
 800363c:	00000000 	.word	0x00000000
 8003640:	080003a1 	.word	0x080003a1

08003644 <_init>:
 8003644:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 8003646:	bf00      	nop
 8003648:	bcf8      	pop	{r3, r4, r5, r6, r7}
 800364a:	bc08      	pop	{r3}
 800364c:	469e      	mov	lr, r3
 800364e:	4770      	bx	lr

08003650 <_fini>:
 8003650:	b5f8      	push	{r3, r4, r5, r6, r7, lr}
 8003652:	bf00      	nop
 8003654:	bcf8      	pop	{r3, r4, r5, r6, r7}
 8003656:	bc08      	pop	{r3}
 8003658:	469e      	mov	lr, r3
 800365a:	4770      	bx	lr
