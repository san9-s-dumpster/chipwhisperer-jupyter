# SampleNTT validity experiment

Evidence of a held-out single-trace validity association in this conditioned population.

Independent final-test seeds: 256.
Primary single-trace balanced accuracy: 1.000, 95% CI [1.0, 1.0].
ROC AUC: 1.000; permutation p (balanced accuracy): 0.00020.
Power minus timing AUC 95% CI: [0.3282142639160156, 0.468017578125].

Plan: `40ea0a09c21472ddf5d598d4bfce443a92a5a441fb8025a81d60c3e9706fb3ea`
Frozen fit: `c4a9cef412f184f934ea324be8f315fe5fa4a03a064387fcf8c897a493e3c9f0`

- Primary inference uses one trace per independent seed; repeated traces are secondary.
- Balanced, workload-conditioned seeds: precision is not the precision on naturally distributed seeds.
- Timing and shuffled-label controls are diagnostic; a failed control needs investigation.
- AUC difference from timing is descriptive; no causal branch attribution or secret recovery follows.
- Never tune against this holdout. Any rework needs a new plan and fresh final seeds.
- Firmware identity proves variant/revision/profile, not the complete flashed binary hash; program the recorded image explicitly.